"""Titelschriften (AP13.5e §3): je Familie eine woff2-Datei (SIL OFL, Subset Latin) nur für Titel, Kicker und
Überschriften. Die Dateien liegen im Repo unter web/vendor/schriften/ und im Generator-Zip unter templates/schriften/
(web_bundle.py); gelesen wird erst, wenn eine Familie sie braucht.

    font_face(datei)               -> @font-face-Regel mit der Schrift als data:font/woff2 (für <style> und SVG)
    name(datei)                    -> Familienname der Schrift (erster Name in schrift.kopf)
    zeilen(datei, text, groesse, breite, hoechstens) -> Zeilen, die in `breite` passen (Breitentabelle aus <datei>.json)
"""
import base64
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
ORTE = (os.path.join(HERE, "..", "templates", "schriften"), os.path.join(HERE, "..", "..", "web", "vendor", "schriften"))
_META, _B64 = {}, {}


def pfad(datei, endung):
    for ort in ORTE:
        p = os.path.join(ort, datei + endung)
        if os.path.exists(p):
            return p
    raise FileNotFoundError(f"Schrift „{datei}{endung}“ fehlt (web/vendor/schriften/ oder templates/schriften/)")


def meta(datei):
    if datei not in _META:
        with open(pfad(datei, ".json"), encoding="utf-8") as f:
            m = json.load(f)
        m["tabelle"] = dict(zip(m["zeichen"], m["breite"]))
        _META[datei] = m
    return _META[datei]


def name(datei):
    return meta(datei)["name"]


def nur_versalien(datei):
    """Schrift ohne eigene Kleinbuchstaben (Bebas Neue): a ist so breit wie A und so fort."""
    t = meta(datei)["tabelle"] if datei else {}
    return bool(t) and all(t.get(k) == t.get(k.upper()) for k in "aeimnorsw")


def woff2(datei):
    if datei not in _B64:
        with open(pfad(datei, ".woff2"), "rb") as f:
            _B64[datei] = base64.b64encode(f.read()).decode()
    return _B64[datei]


def font_face(datei):
    """Eine Regel; font-weight als Spanne, damit der Browser keinen fetten Schnitt nachrechnet."""
    return (f"@font-face{{font-family:'{name(datei)}';src:url(data:font/woff2;base64,{woff2(datei)}) format('woff2');"
            f"font-weight:100 900;font-display:swap}}")


def breite(datei, text, groesse):
    """Breite von `text` in der Schriftgröße `groesse` (gleiche Einheit); ohne Datei 0,56 Geviert je Zeichen."""
    if not datei:
        return len(text) * groesse * 0.56
    m = meta(datei)
    standard = m["tabelle"].get("n", m["upm"] // 2)
    return sum(m["tabelle"].get(z, standard) for z in text) * groesse / m["upm"]


def zeilen(datei, text, groesse, max_breite, hoechstens=2):
    """Wortweise umbrechen; None, wenn der Text in `hoechstens` Zeilen nicht passt."""
    out = []
    for wort in text.split():
        if out and breite(datei, out[-1] + " " + wort, groesse) <= max_breite:
            out[-1] += " " + wort
        else:
            out.append(wort)
        if len(out) > hoechstens or breite(datei, out[-1], groesse) > max_breite:
            return None
    return out
