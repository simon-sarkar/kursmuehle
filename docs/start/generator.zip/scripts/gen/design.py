"""Designfamilien (AP13.5): references/design/familien.yaml laden, prüfen und zu einem Tokensatz auflösen.

    laden()                         -> {"standard": name, "familien": {name: eintrag}} (geprüft, zwischengespeichert)
    tokens(familie, akzent, dichte, kasten) -> D, flaches dict für gen/html.py und gen/website.py
    migriere(name)                  -> Familienname aus einem Vorlagennamen bis 2.0.0-b6 (schlicht -> sachlich …)
    akzent_fuer(D, hue) / auf_akzent(D, hue) / zweitfarbe(D, hue)   Farbrechnung (einmal, deterministisch)

Eine Familie ist ein Datensatz, kein Code-Zweig: html.py schlägt die Formen in D["formen"] nach. Ein Fehler in der
Datei bricht den Bau mit Dateiname und Schlüssel ab (DesignFehler, ein ValueError).
"""
import colorsys
import os

import yaml

PFAD = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "references", "design", "familien.yaml")
DATEI = "references/design/familien.yaml"

# Formnamen je Form (familien.yaml darf nur diese nennen; html.py hat für jeden Namen einen Fall)
FORMEN = {
    "h2": ["schlicht", "linie", "balken", "punktiert", "flaeche", "nummeriert", "gross", "unterstrichen"],
    "kasten": ["balken", "flaeche", "linie_oben", "gestrichelt", "haarlinie", "offen", "einzug", "papier", "rahmen",
               "rahmen_dick", "links", "zitat"],
    "merk": ["fuellung", "rahmen", "rand_dick", "balken", "einzug", "doppelt", "gestrichelt", "zitat", "toenung"],
    "nummer": ["kreis", "quadrat", "kreis_gross", "sticker", "zahl", "klammer", "eckig", "kreis_ton", "liste"],
    "chip": ["pille", "eckig", "pille_dick", "sticker", "punkt", "klammer", "eckklammer", "papier", "text"],
    "banner": ["balken", "linie", "offen", "buch", "papier", "rund", "sticker", "rahmen", "schlicht", "flaeche"],
    "karte": ["rand", "flaeche", "bunt", "linie", "abstand", "gestrichelt", "papier", "rahmen", "links", "einzug",
              "ohne"],
    "uebung": ["oben", "rand_dick", "gestrichelt", "linie_oben", "rahmen", "papier"],
    "kicker": ["versal", "klein", "kapitaelchen", "etikett", "invers", "normal"],
    # Anordnung (AP13.5c): Titel zum Bannerbild, Bildzeile, Schritte des Überblicks, Kopf des Übungsblocks
    "titel": ["block", "zeile", "ueberlagert", "vorangestellt"],
    "bildzeile": ["links", "oben", "rechts", "klein"],
    "ablauf": ["leiste", "liste", "spalte", "satz"],
    "uebung_kopf": ["kopf", "ohne", "titel_im_rahmen", "streifen"],
}
SCHLUESSEL = {
    "name": None, "text": None, "zeile": None, "bildstil": None, "probe": None, "druck": None,
    "begleiter": None, "kasten_farben": None,
    "schrift": ["grund", "kopf", "datei"],
    "motiv": ["name", "banner", "h2", "kasten"],
    "farben": ["ink", "muted", "line", "line_card", "flaeche", "flaeche_alt", "tint", "akzent", "zweitfarbe",
               "korrektur"],
    "masse": ["r", "r_lg", "r_sm", "pad", "tile_pad", "gap", "lead", "h2", "grund_px", "zeilenhoehe"],
    "formen": list(FORMEN),
    "uebung": ["ok", "okbg", "bad", "badbg", "feld", "knopf", "knopf_hoehe"],
}
ZWEITFARBE = ("keine", "pastell", "gedreht")
KNOPF = ("gefuellt", "pille", "rahmen", "text")
DICHTE = {"luftig": 1.3, "normal": 1, "kompakt": 0.8}
KASTEN = ("familie", "rund", "eckig", "linie")
MIGRATION = {"schlicht": "sachlich", "kacheln": "freundlich", "magazin": "magazin"}
# Farben, die bis 2.0.0-b6 in Kursen standen (fünf Namen, Standard, Beispiel, Hinweis, Chip „exemplarisch“); in
# Familien mit `korrektur: nein` bleiben sie unverändert, damit die Anker byteidentisch bauen
BEKANNT = {"#1D5FD1", "#15803D", "#BE123C", "#B45309", "#6D28D9", "#0F766E", "#9AA3B5"}
BILDSTIL_MAX = 120
# AP13.5e: Motive, Begleiter (gen/motiv.py zeichnet sie), Stellen des Motivs, Vorsatz der Bannerfläche im Text für den Chat
MOTIVE = ("kreide", "aquarell", "pinsel", "punkte", "papier", "schraeg", "linie", "raster", "keins")
BEGLEITER = ("stern", "sprechblase", "blatt", "punkt", "ornament", "balken", "ring", "keiner")
MOTIV_KASTEN = ("ecke", "reiter", "vorn", "rand", "nein")
BILDSTIL_FLAECHE = "Ein Kursbild ist nicht nötig; die Mühle setzt eine Fläche im Design. Schlägst du eines vor, passe es " \
                   "diesem Stil an: {stil}."
BILDSTIL_FLAECHE_MAX = 160

_CACHE = None


class DesignFehler(ValueError):
    pass


def _fehler(familie, schluessel, was):
    wo = f"Familie „{familie}“, " if familie else ""
    raise DesignFehler(f"{DATEI}: {wo}Schlüssel „{schluessel}“ {was}")


def _hex(v):
    s = str(v or "").strip()
    if len(s) in (4, 7) and s.startswith("#") and all(c in "0123456789abcdefABCDEF" for c in s[1:]):
        return s
    return None


def _pruefe(f):
    name = f.get("name") or "?"
    for k, sub in SCHLUESSEL.items():
        if k not in f:
            _fehler(name, k, "fehlt")
        for s in sub or []:
            if not isinstance(f[k], dict) or s not in f[k]:
                _fehler(name, f"{k}.{s}", "fehlt")
    for form, namen in FORMEN.items():
        if f["formen"][form] not in namen:
            _fehler(name, f"formen.{form}", f"hat „{f['formen'][form]}“; erlaubt: {', '.join(namen)}")
    fa = f["farben"]
    for s in ("ink", "muted", "line", "line_card", "flaeche", "flaeche_alt"):
        if not _hex(fa[s]):
            _fehler(name, f"farben.{s}", "ist keine Farbe #RRGGBB")
    for s in ("ok", "okbg", "bad", "badbg", "feld"):
        if not _hex(f["uebung"][s]):
            _fehler(name, f"uebung.{s}", "ist keine Farbe #RRGGBB")
    ak = fa["akzent"]
    if not (isinstance(ak, dict) and len(ak) == 1 and next(iter(ak)) in ("standard", "ignoriert")
            and _hex(next(iter(ak.values())))):
        _fehler(name, "farben.akzent", "braucht standard: \"#RRGGBB\" oder ignoriert: \"#RRGGBB\"")
    if fa["zweitfarbe"] not in ZWEITFARBE and not _hex(fa["zweitfarbe"]):
        _fehler(name, "farben.zweitfarbe", f"hat „{fa['zweitfarbe']}“; erlaubt: {', '.join(ZWEITFARBE)} oder #RRGGBB")
    if fa["korrektur"] not in ("ja", "nein"):
        _fehler(name, "farben.korrektur", "ist ja oder nein")
    if f["uebung"]["knopf"] not in KNOPF:
        _fehler(name, "uebung.knopf", f"hat „{f['uebung']['knopf']}“; erlaubt: {', '.join(KNOPF)}")
    if not isinstance(f["uebung"]["knopf_hoehe"], int) or f["uebung"]["knopf_hoehe"] < 0:
        _fehler(name, "uebung.knopf_hoehe", "ist eine ganze Zahl (px, 0 = Standard)")
    m = f["masse"]
    if not (isinstance(m["pad"], list) and len(m["pad"]) == 2 and isinstance(m["tile_pad"], list)
            and len(m["tile_pad"]) == 4):
        _fehler(name, "masse.pad", "ist eine Liste [oben/unten, links/rechts], tile_pad eine Liste mit vier Werten")
    if len(str(f["bildstil"]).encode()) > BILDSTIL_MAX:
        _fehler(name, "bildstil", f"ist länger als {BILDSTIL_MAX} Bytes")
    if not isinstance(f["probe"], list):
        _fehler(name, "probe", "ist eine Liste")
    mo = f["motiv"]
    if mo["name"] not in MOTIVE:
        _fehler(name, "motiv.name", f"hat „{mo['name']}“; erlaubt: {', '.join(MOTIVE)}")
    for s in ("banner", "h2"):
        if mo[s] not in ("ja", "nein"):
            _fehler(name, f"motiv.{s}", "ist ja oder nein")
    if mo["kasten"] not in MOTIV_KASTEN:
        _fehler(name, "motiv.kasten", f"hat „{mo['kasten']}“; erlaubt: {', '.join(MOTIV_KASTEN)}")
    if f["begleiter"] not in BEGLEITER:
        _fehler(name, "begleiter", f"hat „{f['begleiter']}“; erlaubt: {', '.join(BEGLEITER)}")
    if f["kasten_farben"] not in ("ja", "nein"):
        _fehler(name, "kasten_farben", "ist ja oder nein")
    if f["formen"]["banner"] == "flaeche" and len(BILDSTIL_FLAECHE.format(stil=f["bildstil"]).encode()) > \
            BILDSTIL_FLAECHE_MAX:
        _fehler(name, "bildstil", f"ist mit dem Vorsatz der Bannerfläche länger als {BILDSTIL_FLAECHE_MAX} Bytes")
    datei = f["schrift"]["datei"] or ""
    if datei:
        from . import schrift
        try:
            schriftname = schrift.name(datei)
        except FileNotFoundError:
            _fehler(name, "schrift.datei", f"nennt „{datei}“; die Datei fehlt unter web/vendor/schriften/")
        if not str(f["schrift"]["kopf"]).startswith(f'"{schriftname}"'):
            _fehler(name, "schrift.kopf", f"beginnt nicht mit der Titelschrift „{schriftname}“")


def laden(pfad=None):
    """familien.yaml lesen und prüfen; Ergebnis {"standard", "familien": {name: eintrag}} in Dateireihenfolge."""
    global _CACHE
    if _CACHE is not None and pfad is None:
        return _CACHE
    with open(pfad or PFAD, encoding="utf-8") as fh:
        roh = yaml.safe_load(fh)
    if not isinstance(roh, dict) or not isinstance(roh.get("familien"), list):
        _fehler(None, "familien", "fehlt oder ist keine Liste")
    fam = {}
    for f in roh["familien"]:
        if not isinstance(f, dict):
            _fehler(None, "familien", "enthält einen Eintrag, der kein Mapping ist")
        _pruefe(f)
        fam[f["name"]] = f
    if roh.get("standard") not in fam:
        _fehler(None, "standard", "nennt keine Familie der Datei")
    erg = {"standard": roh["standard"], "familien": fam}
    if pfad is None:
        _CACHE = erg
    return erg


def namen():
    return list(laden()["familien"])


def standard():
    return laden()["standard"]


def migriere(name):
    """Vorlagenname bis b6 oder Familienname -> Familienname (klein, getrimmt); leer -> Standard."""
    n = str(name or "").strip().lower()
    return MIGRATION.get(n, n) or standard()


def familie(name):
    n = migriere(name)
    fam = laden()["familien"]
    if n not in fam:
        raise DesignFehler(f"{DATEI}: Designfamilie „{n}“ unbekannt (erlaubt: {', '.join(fam)})")
    return fam[n]


# ---------------------------------------------------------------- Farbrechnung
def rgb(h):
    h = h.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def hexf(r, g, b):
    return f"#{int(r):02x}{int(g):02x}{int(b):02x}"


def luminanz(h):
    def kanal(c):
        c /= 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = rgb(h)
    return 0.2126 * kanal(r) + 0.7152 * kanal(g) + 0.0722 * kanal(b)


def kontrast(a, b):
    la, lb = sorted((luminanz(a), luminanz(b)))
    return (lb + 0.05) / (la + 0.05)


def mische(hue, grund, s):
    """Tönung: Akzent mit Stärke s über dem Grund (Grund weiß = die Rechnung von html._tint bis b6)."""
    gr = rgb(grund)
    return hexf(*(int(g - (g - c) * s) for c, g in zip(rgb(hue), gr)))


def dunkel(h):
    return luminanz(h) < 0.2


def drehe(hue, grad):
    r, g, b = (c / 255 for c in rgb(hue))
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    r, g, b = colorsys.hls_to_rgb((h + grad / 360) % 1, l, s)
    return hexf(round(r * 255), round(g * 255), round(b * 255))


def pastell(hue, hell=0.92):
    """Heller, sauberer Ton gleicher Farbrichtung (Helligkeit fest, Sättigung mindestens 0,6)."""
    r, g, b = (c / 255 for c in rgb(hue))
    h, _, s = colorsys.rgb_to_hls(r, g, b)
    r, g, b = colorsys.hls_to_rgb(h, hell, max(s, 0.6))
    return hexf(round(r * 255), round(g * 255), round(b * 255))


def _ziehe(hue, gruende, ziel=4.5, nach="#000000"):
    """hue schrittweise Richtung `nach` mischen, bis der Kontrast zu jedem Grund mindestens `ziel` ist."""
    h = hexf(*rgb(hue))
    for i in range(0, 21):
        c = mische(nach, h, i / 20) if i else h
        if all(kontrast(c, g) >= ziel for g in gruende):
            return c
    return nach


# ---------------------------------------------------------------- Tokens
def _px(werte, f):
    return " ".join(f"{round(v * f)}px" if v else "0" for v in werte)


def tokens(name=None, akzent=None, dichte=None, kasten=None):
    """Familie plus Hebel -> D. akzent: Hex oder None (Standard der Familie); dichte: luftig|normal|kompakt;
    kasten: familie|rund|eckig|linie."""
    f = familie(name)
    dichte = str(dichte or "normal").strip().lower()
    kasten = str(kasten or "familie").strip().lower().replace("wie die familie", "familie")
    if dichte not in DICHTE:
        raise DesignFehler(f"{DATEI}: Dichte „{dichte}“ unbekannt (erlaubt: {', '.join(DICHTE)})")
    if kasten not in KASTEN:
        raise DesignFehler(f"{DATEI}: Kasten „{kasten}“ unbekannt (erlaubt: {', '.join(KASTEN)})")
    fa, m = f["farben"], f["masse"]
    fak = DICHTE[dichte]
    formen = dict(f["formen"])
    r, r_lg, r_sm = m["r"], m["r_lg"], m["r_sm"]
    if kasten == "rund":
        r, r_lg, r_sm = 16, 20, 10
        formen["kasten"] = {"linie_oben": "balken", "einzug": "links", "haarlinie": "rahmen",
                                                                                         "offen": "rahmen"}.get(formen["kasten"],
                                                                                                    formen["kasten"])
        formen["karte"] = {"linie": "rand", "abstand": "rand"}.get(formen["karte"], formen["karte"])
    elif kasten == "eckig":
        r, r_lg, r_sm = 0, 0, 0
    elif kasten == "linie":
        r, r_lg, r_sm = 0, 0, 0
        if formen["kasten"] != "zitat":
            formen["kasten"], formen["karte"] = "links", "links"
    fest = "ignoriert" in fa["akzent"]
    std = fa["akzent"].get("ignoriert") or fa["akzent"]["standard"]
    zh = m["zeilenhoehe"]
    if fak != 1:
        zh = round((zh or 1.55) * (1.1 if fak > 1 else 0.92), 2)
    D = {
        "name": f["name"], "text": f["text"],
        "ink": fa["ink"], "muted": fa["muted"], "line": fa["line"], "line_card": fa["line_card"],
        "flaeche": fa["flaeche"], "flaeche_alt": fa["flaeche_alt"], "tint": fa["tint"],
        "zweitfarbe": fa["zweitfarbe"], "korrektur": fa["korrektur"] == "ja",
        "akzent_fest": fest, "akzent_standard": std,
        "r": r, "r_lg": r_lg, "r_sm": r_sm,
        "pad": _px(m["pad"], fak), "tile_pad": _px(m["tile_pad"], fak), "gap": round(m["gap"] * fak),
        "lead": f"{m['lead']}em", "h2": f"{m['h2']}em",
        "grund_px": m["grund_px"], "zeilenhoehe": zh,
        # Schriftnamen in einfachen Anführungszeichen: sie stehen im style-Attribut (doppelte Anführungszeichen)
        "schrift_grund": (f["schrift"]["grund"] or "").replace('"', "'"),
        "schrift_kopf": (f["schrift"]["kopf"] or "").replace('"', "'"),
        "formen": formen, "uebung": dict(f["uebung"]),
        "dunkel": dunkel(fa["flaeche"]), "dichte": dichte, "kasten": kasten,
        "bildstil": f["bildstil"], "probe": list(f["probe"]),
        "schrift_datei": f["schrift"]["datei"] or "",
        "motiv": {"name": f["motiv"]["name"], "banner": f["motiv"]["banner"] == "ja", "h2": f["motiv"]["h2"] == "ja",
                  "kasten": f["motiv"]["kasten"]},
        "begleiter": f["begleiter"], "kasten_farben": f["kasten_farben"] == "ja",
    }
    D["hue"] = akzent_fuer(D, akzent or std)
    return D


def akzent_fuer(D, hue):
    """Farbe, die ein Baustein für `hue` zeigt: fest bei `ignoriert`, bekannt und unverändert bei korrektur: nein,
    sonst auf 4,5:1 zum Grund und zur Tönung gezogen (helle Familien dunkeln nach, dunkle hellen auf)."""
    if D["akzent_fest"]:
        return D["akzent_standard"]
    h = _hex(hue) or D["akzent_standard"]
    if len(h) == 4:
        h = hexf(*rgb(h))
    if not D["korrektur"] and h.upper() in BEKANNT:
        return h
    grund, staerke = D["flaeche"], max(D["tint"], 0.13)

    def passt(c):       # Text in c auf Grund, Kasten und der eigenen Tönung; bei dunklen Familien auch dunkle Zahl auf c
        gr = [grund, D["flaeche_alt"], mische(c, grund, staerke)]
        return all(kontrast(c, g) >= 4.5 for g in gr) and (not D["dunkel"] or kontrast(c, grund) >= 4.5)
    if not D["korrektur"] and passt(h):
        return h
    nach = "#ffffff" if D["dunkel"] else "#000000"
    for i in range(0, 41):
        c = mische(nach, h, i / 40) if i else hexf(*rgb(h))
        if passt(c):
            return c
    return nach


def auf_akzent(D, hue):
    """Schrift auf einer Fläche in Akzentfarbe: Weiß, wenn es 4,5:1 erreicht, sonst die dunkle Farbe der Familie."""
    if kontrast("#ffffff", hue) >= 4.5:
        return "#fff"
    ink, fl = D["ink"], D["flaeche"]
    return ink if luminanz(ink) < luminanz(fl) else fl


def zweitfarbe(D, hue):
    """Zweitfarbe aus dem Akzent: pastell (150° gedreht, mit Weiß 0,7 gemischt), gedreht (60°, satt, dunkel genug für
    weiße Schrift), fest (#RRGGBB der Familie) oder None."""
    regel = D["zweitfarbe"]
    if _hex(regel):
        return regel
    if regel == "pastell":
        return mische(drehe(hue, 150), "#ffffff", 0.3)
    if regel == "gedreht":     # trägt weiße Schrift (Etikett): auf 4,5:1 zu Weiß gezogen
        return _ziehe(drehe(hue, 60), ["#ffffff"])
    return None


# Farbe je Aufgabentyp (AP13.5e §4, kasten_farben: ja): Drehung des Grundtons in Grad, Grundton Akzent oder Zweitfarbe
KASTEN_ARTEN = {"merke": ("akzent", 0), "hinweis": ("zweit", 0), "aufgabe": ("akzent", 30), "beispiel": ("zweit", 30)}


def kasten_farben(D, hue):
    """Vier Pastelltöne für Merke, Hinweis, Aufgabe (Kasten), Beispiel -> {art: (fläche, titelfarbe)}; die Titelfarbe
    ist der Ton selbst, auf 4,5:1 zur Fläche und zum Grund nachgedunkelt. None, wenn die Familie einen Ton nimmt."""
    if not D.get("kasten_farben"):
        return None
    zweit = drehe(hue, 60 if D["zweitfarbe"] == "gedreht" else 150)
    out = {}
    for art, (basis, grad) in KASTEN_ARTEN.items():
        ton = drehe(hue if basis == "akzent" else zweit, grad)
        flaeche = pastell(ton)
        out[art] = (flaeche, _ziehe(ton, [flaeche, D["flaeche"], D["flaeche_alt"]]))
    return out


def familien_json():
    """Was die Oberfläche je Familie braucht (web/familien.json): Name, Text, Zeile, Probe, Akzent, Hebelwerte."""
    out = []
    for f in laden()["familien"].values():
        ak = f["farben"]["akzent"]
        out.append({"name": f["name"], "text": f["text"], "zeile": f["zeile"], "probe": list(f["probe"]),
                    "akzent": ak.get("standard") or ak.get("ignoriert"), "akzent_fest": "ignoriert" in ak})
    return {"standard": standard(), "familien": out,
            "dichte": [{"wert": w, "text": t} for w, t in zip(DICHTE, ("Luftig", "Normal", "Kompakt"))],
            "kasten": [{"wert": w, "text": t} for w, t in zip(KASTEN, ("Wie die Familie", "Rund", "Eckig", "Linie"))]}
