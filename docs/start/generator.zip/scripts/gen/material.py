"""Eigenes Material aus Dateien lesen (AP13.13): Text, Word, LibreOffice, PowerPoint, PDF -> schlichtes Markdown.

    lesen(name, daten)  -> {ok, format, abschnitte: [{titel, text, art, zeichen}], zeichen, hinweis}
    zusammensetzen(name, abschnitte)  -> Text fürs Materialfeld: `# Aus <name>`, darunter die Abschnitte

`art`: `abschnitt` (Überschrift im Dokument), `folie`, `seite` oder `ganz` (Datei ohne Gliederung). Überschriften der
Datei stehen eine Stufe tiefer (`##` für die oberste), damit `# Aus <name>` darüber passt. `zeichen` zählt ohne
Markdown-Zeichen und Zeilenumbrüche. Ein Leser für Kommandozeile und Browser (über gen.api, in Pyodide); ZIP-Formate
nur mit der Standardbibliothek, PDF mit pypdf (Wheel unter web/vendor/pyodide/, erst beim ersten PDF importiert).
Jede Meldung steht in `hinweis`; bei `ok: False` gibt es keine Abschnitte.

usage: python3 -m gen.material DATEI ...   (im Ordner scripts/; gibt das Markdown aus)
"""
import glob
import io
import os
import posixpath
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET

MAX_DATEI = 20 * 1024 * 1024        # Bytes der Datei (prüft die Seite schon vorher über File.size)
MAX_ENTPACKT = 50 * 1024 * 1024     # gelesene Bytes aus einem ZIP je Datei
MAX_EINTRAEGE = 2000
MAX_ZEICHEN = 200_000
SCAN_ZEICHEN = 20                   # PDF: weniger Zeichen je Seite im Mittel = keine Textebene

BILDER = {"png", "jpg", "jpeg", "gif", "webp", "heic", "heif", "bmp", "tif", "tiff", "svg"}
ALT = {"doc", "ppt", "rtf", "xls"}
OLE = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"


class _Meldung(Exception):
    """Lesen abbrechen mit einem Satz für die Lehrkraft."""


# ---------------------------------------------------------------- Meldungen (§4)
def _nicht_lesbar(name):
    return f"{name} lässt sich nicht lesen."


def _geschuetzt(name):
    return f"{name} ist geschützt."


# ---------------------------------------------------------------- Bausteine -> Markdown
# Ein Leser liefert Blöcke: ("h", ebene, text) | ("p", text) | ("li", tiefe, text) | ("tr", [zellen])
# | ("fn", text) Fußnote, kommt ans Ende des Abschnitts.
_RE_LEER = re.compile(r"[ \t  -   　]+")
_RE_WEG = re.compile(r"[­​-‍⁠﻿]|[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def _sauber(t):
    """Eine Zeile oder ein Absatz: Steuerzeichen und weiche Trennstriche weg, Leerraum zu einem Leerzeichen."""
    t = _RE_WEG.sub("", unicodedata.normalize("NFC", t or ""))
    zeilen = [_RE_LEER.sub(" ", z).strip() for z in t.replace("\r", "\n").split("\n")]
    return "\n".join(z for z in zeilen if z)


def _zelle(t):
    return _sauber(t).replace("\n", " ").replace("|", "/")


def _md_zeilen(bloecke):
    """Blöcke -> Markdown; Listen und Tabellenzeilen ohne Leerzeile dazwischen."""
    out, vorher, noten = [], None, []
    for b in bloecke:
        art = b[0]
        if art == "fn":
            noten.append(b[1])
            continue
        if art == "h":
            text = "#" * min(b[1] + 1, 6) + " " + _sauber(b[2]).replace("\n", " ")
        elif art == "p":
            text = _sauber(b[1])
        elif art == "li":
            text = "  " * b[1] + "- " + _sauber(b[2]).replace("\n", " ")
        else:
            zellen = [_zelle(z) for z in b[1]]
            text = "| " + " | ".join(zellen) + " |" if any(zellen) else ""
        if not text.strip("#|- "):
            continue
        if out and not (art == vorher and art in ("li", "tr")):
            out.append("")
        out.append(text)
        vorher = art
    if noten:
        out += [""] + [_sauber(n).replace("\n", " ") for n in noten if _sauber(n)]
    return "\n".join(out)


_RE_MARKE = re.compile(r"^(#{1,6} |\s*- |\s*\| )")


def zeichen(text):
    """Zeichen ohne Markdown-Zeichen (Überschrift, Listenstrich, Tabellenstriche) und ohne Zeilenumbrüche."""
    n = 0
    for z in text.split("\n"):
        z = _RE_MARKE.sub("", z)
        if z.endswith(" |"):
            z = z[:-2].replace(" | ", " ")
        n += len(z)
    return n


def _abschnitte_aus(bloecke):
    """Blöcke an Überschriften der obersten zwei vorkommenden Ebenen teilen; ohne Überschrift ein Abschnitt `ganz`."""
    ebenen = [b[1] for b in bloecke if b[0] == "h"]
    if not ebenen:
        return [{"titel": "Ganzer Text", "text": _md_zeilen(bloecke), "art": "ganz"}]
    grenze = min(ebenen) + 1
    teile, akt = [], None
    for b in bloecke:
        if b[0] == "h" and b[1] <= grenze:
            akt = {"titel": _sauber(b[2]).replace("\n", " "), "bloecke": [b]}
            teile.append(akt)
        else:
            if akt is None:
                akt = {"titel": "Anfang", "bloecke": []}
                teile.append(akt)
            akt["bloecke"].append(b)
    return [{"titel": t["titel"], "text": _md_zeilen(t["bloecke"]), "art": "abschnitt"} for t in teile]


def _ergebnis(name, fmt, abschnitte, hinweis=None):
    """Leere Abschnitte weg, Zeichen zählen, nach MAX_ZEICHEN abschneiden."""
    out, summe, gekuerzt = [], 0, False
    for a in abschnitte:
        text = re.sub(r"\n{3,}", "\n\n", a["text"]).strip()
        z = zeichen(text)
        if not z:
            continue
        if summe + z > MAX_ZEICHEN:
            gekuerzt = True
            rest, zeilen = MAX_ZEICHEN - summe, []
            for zeile in text.split("\n"):
                n = zeichen(zeile)
                if n > rest:
                    break
                zeilen.append(zeile)
                rest -= n
            text = "\n".join(zeilen).strip()
            z = zeichen(text)
            if z:
                out.append(dict(a, text=text, zeichen=z))
                summe += z
            break
        out.append(dict(a, text=text, zeichen=z))
        summe += z
    if gekuerzt:
        hinweis = f"{name} ist sehr lang; gelesen sind die ersten Abschnitte."
    if not out:
        return _fehler(fmt, hinweis or f"{name} enthält keinen Text.")
    return {"ok": True, "format": fmt, "abschnitte": out, "zeichen": summe, "hinweis": hinweis}


def _fehler(fmt, satz):
    return {"ok": False, "format": fmt, "abschnitte": [], "zeichen": 0, "hinweis": satz}


# ---------------------------------------------------------------- ZIP und XML sicher lesen
class _Zip:
    def __init__(self, name, daten):
        self.name = name
        try:
            self.zf = zipfile.ZipFile(io.BytesIO(daten))
            liste = self.zf.infolist()
        except (zipfile.BadZipFile, OSError, ValueError, EOFError):
            raise _Meldung(_nicht_lesbar(name))
        if len(liste) > MAX_EINTRAEGE:
            raise _Meldung(_nicht_lesbar(name))
        self.namen = {i.filename for i in liste}
        self.budget = MAX_ENTPACKT

    def da(self, pfad):
        return pfad in self.namen

    def bytes(self, pfad):
        try:
            with self.zf.open(pfad) as f:
                d = f.read(self.budget + 1)
        except (KeyError, zipfile.BadZipFile, OSError, ValueError, EOFError, NotImplementedError, RuntimeError):
            raise _Meldung(_nicht_lesbar(self.name))
        if len(d) > self.budget:
            raise _Meldung(_nicht_lesbar(self.name))
        self.budget -= len(d)
        return d

    def xml(self, pfad):
        return _xml(self.bytes(pfad), self.name)


_RE_DTD = re.compile(rb"<!\s*(DOCTYPE|ENTITY)", re.I)


def _xml(d, name):
    """OOXML und ODF haben keine DTD: eine Datei mit <!DOCTYPE oder <!ENTITY wird nicht gelesen."""
    if _RE_DTD.search(d):
        raise _Meldung(_nicht_lesbar(name))
    try:
        return ET.fromstring(d)
    except ET.ParseError:
        raise _Meldung(_nicht_lesbar(name))


def _lokal(tag):
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def _rels(z, pfad):
    """Beziehungen eines OOXML-Teils: Id -> (Typ-Ende, Zielpfad im ZIP)."""
    ordner, datei = posixpath.split(pfad)
    rp = posixpath.join(ordner, "_rels", datei + ".rels")
    if not z.da(rp):
        return {}
    out = {}
    for r in z.xml(rp):
        ziel = r.get("Target") or ""
        if r.get("TargetMode") == "External":
            continue
        ziel = ziel.lstrip("/") if ziel.startswith("/") else posixpath.normpath(posixpath.join(ordner, ziel))
        out[r.get("Id")] = ((r.get("Type") or "").rsplit("/", 1)[-1], ziel)
    return out


# ---------------------------------------------------------------- docx
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_FELD_WEG = {"PAGE", "NUMPAGES", "SECTIONPAGES", "DATE", "TIME", "CREATEDATE", "SAVEDATE", "PRINTDATE", "FILENAME",
             "TOC", "PAGEREF", "AUTHOR", "LASTSAVEDBY", "NUMWORDS", "NUMCHARS", "EDITTIME", "REVNUM"}


def _feld_weg(instr):
    w = (instr or "").strip().split()
    return bool(w) and w[0].upper() in _FELD_WEG


def _docx_stile(z):
    """styleId -> (Ebene der Überschrift oder None, ist Liste); über w:name und w:outlineLvl, mit basedOn."""
    if not z.da("word/styles.xml"):
        return {}
    roh = {}
    for s in z.xml("word/styles.xml").iter(W + "style"):
        sid = s.get(W + "styleId")
        n = s.find(W + "name")
        name = (n.get(W + "val") if n is not None else "") or ""
        b = s.find(W + "basedOn")
        o = s.find(f"{W}pPr/{W}outlineLvl")
        ebene = None
        m = re.fullmatch(r"heading\s*(\d)", name.strip(), re.I)
        if m:
            ebene = int(m.group(1))
        elif name.strip().lower() == "title":
            ebene = 1
        elif o is not None and (o.get(W + "val") or "").isdigit() and int(o.get(W + "val")) < 9:
            ebene = int(o.get(W + "val")) + 1
        liste = "list" in name.lower() or s.find(f"{W}pPr/{W}numPr") is not None
        roh[sid] = (ebene, liste, b.get(W + "val") if b is not None else None)
    out = {}
    for sid in roh:
        ebene, liste, basis, tiefe = roh[sid][0], roh[sid][1], roh[sid][2], 0
        while ebene is None and basis in roh and tiefe < 10:
            ebene, basis, tiefe = roh[basis][0], roh[basis][2], tiefe + 1
        out[sid] = (ebene, liste)
    return out


class _Docx:
    def __init__(self, z):
        self.z = z
        self.stile = _docx_stile(z)
        self.noten = {}
        for teil, tag in (("word/footnotes.xml", "footnote"), ("word/endnotes.xml", "endnote")):
            if z.da(teil):
                for fn in z.xml(teil).iter(W + tag):
                    if fn.get(W + "type") in (None, "normal"):
                        self.noten[(tag, fn.get(W + "id"))] = fn
        self.nr = 0
        self.feld = []          # Stapel offener Felder: [instr, ergebnis_weg, im_ergebnis]
        self.bloecke = []
        self.offen_noten = []

    def _weg(self):
        return any(f[1] and f[2] for f in self.feld)

    def lauf(self, el, teile, kaesten):
        """Text unter el in teile sammeln; Textfelder (w:txbxContent) in kaesten."""
        for k in el:
            t = _lokal(k.tag)
            if t in ("del", "moveFrom", "instrText", "delText", "rPr", "pPr", "commentReference", "Fallback"):
                if t == "instrText" and self.feld:
                    self.feld[-1][0] += k.text or ""
                    self.feld[-1][1] = _feld_weg(self.feld[-1][0])
                continue
            if t == "fldChar":
                art = k.get(W + "fldCharType")
                if art == "begin":
                    self.feld.append(["", False, False])
                elif art == "separate" and self.feld:
                    self.feld[-1][2] = True
                elif art == "end" and self.feld:
                    self.feld.pop()
                continue
            if t == "fldSimple":
                if not _feld_weg(k.get(W + "instr")):
                    self.lauf(k, teile, kaesten)
                continue
            if t == "txbxContent":
                kaesten.append(k)
                continue
            if self._weg():
                if t not in ("t", "tab", "br", "cr"):
                    self.lauf(k, teile, kaesten)
                continue
            if t == "t":
                teile.append(k.text or "")
            elif t in ("tab", "ptab"):
                teile.append(" ")
            elif t in ("br", "cr"):
                teile.append("\n")
            elif t == "noBreakHyphen":
                teile.append("-")
            elif t in ("footnoteReference", "endnoteReference"):
                fn = self.noten.get((t[:-9], k.get(W + "id")))
                if fn is not None:
                    self.nr += 1
                    teile.append(f"[{self.nr}]")
                    self.offen_noten.append((self.nr, fn))
            else:
                self.lauf(k, teile, kaesten)

    def absatz(self, p, in_tabelle=False):
        teile, kaesten, vorher = [], [], len(self.offen_noten)
        self.lauf(p, teile, kaesten)
        text = "".join(teile)
        if in_tabelle:
            for k in kaesten:
                text += " " + " ".join(self.zelltext(k))
            return text
        ppr = p.find(W + "pPr")
        sid = ebene = num = None
        liste = False
        if ppr is not None:
            s = ppr.find(W + "pStyle")
            sid = s.get(W + "val") if s is not None else None
            o = ppr.find(W + "outlineLvl")
            if o is not None and (o.get(W + "val") or "").isdigit() and int(o.get(W + "val")) < 9:
                ebene = int(o.get(W + "val")) + 1
            num = ppr.find(W + "numPr")
        st_ebene, st_liste = self.stile.get(sid, (None, False))
        ebene = ebene or st_ebene
        if num is not None:
            nid = num.find(W + "numId")
            liste = nid is None or nid.get(W + "val") != "0"
        else:
            liste = st_liste
        if _sauber(text):
            if ebene:
                self.noten_ausgeben(vorher)
                self.bloecke.append(("h", ebene, text))
            elif liste:
                il = num.find(W + "ilvl") if num is not None else None
                tiefe = int(il.get(W + "val")) if il is not None and (il.get(W + "val") or "").isdigit() else 0
                self.bloecke.append(("li", min(tiefe, 5), text))
            else:
                self.bloecke.append(("p", text))
        for k in kaesten:
            self.block(k)

    def zelltext(self, el):
        out = []
        for k in el.iter():
            if _lokal(k.tag) == "p" and k.tag == W + "p":
                t = self.absatz(k, in_tabelle=True)
                if _sauber(t):
                    out.append(t)
        return out

    def tabelle(self, tbl):
        zeilen = []
        for tr in tbl.findall(W + "tr"):
            zellen = []
            for tc in tr.findall(W + "tc"):
                ps = []
                for k in tc:
                    if k.tag == W + "p":
                        ps.append(self.absatz(k, in_tabelle=True))
                    elif k.tag == W + "tbl":
                        ps += self.zelltext(k)
                    elif k.tag == W + "sdt":
                        ps += self.zelltext(k)
                zellen.append(" ".join(p for p in ps if _sauber(p)))
            zeilen.append(zellen)
        _tabelle_bloecke(zeilen, self.bloecke)

    def block(self, el):
        for k in el:
            t = _lokal(k.tag)
            if t == "p":
                self.absatz(k)
            elif t == "tbl":
                self.tabelle(k)
            elif t in ("sdt", "sdtContent", "customXml", "ins", "AlternateContent", "Choice", "smartTag"):
                self.block(k)

    def noten_ausgeben(self, bis=None):
        # Fußnoten ans Ende des Abschnitts: vor die nächste Überschrift oder ans Ende des Dokuments
        jetzt, self.offen_noten = self.offen_noten[:bis], self.offen_noten[len(self.offen_noten[:bis]):]
        for nr, fn in jetzt:
            teile = []
            for p in fn.iter(W + "p"):
                tt = []
                self.lauf(p, tt, [])
                teile.append("".join(tt))
            self.bloecke.append(("fn", f"[{nr}] " + " ".join(_sauber(x) for x in teile if _sauber(x))))


def _tabelle_bloecke(zeilen, bloecke):
    """Tabelle mit einer Spalte (Kasten) als Absätze, sonst Zeilen `| a | b |` ohne Trennzeile."""
    zeilen = [z for z in zeilen if any(_sauber(c) for c in z)]
    if not zeilen:
        return
    if max(len(z) for z in zeilen) == 1:
        bloecke += [("p", z[0]) for z in zeilen]
    else:
        bloecke += [("tr", z) for z in zeilen]


def _docx(z):
    if not z.da("word/document.xml"):
        raise _Meldung(_nicht_lesbar(z.name))
    d = _Docx(z)
    body = z.xml("word/document.xml").find(W + "body")
    if body is not None:
        d.block(body)
    d.noten_ausgeben()
    return _abschnitte_aus(d.bloecke)


# ---------------------------------------------------------------- odt / odp
NS_ODF = {
    "office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
    "text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
    "table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
    "draw": "urn:oasis:names:tc:opendocument:xmlns:drawing:1.0",
    "presentation": "urn:oasis:names:tc:opendocument:xmlns:presentation:1.0",
}
TX = "{%s}" % NS_ODF["text"]
TB = "{%s}" % NS_ODF["table"]
DR = "{%s}" % NS_ODF["draw"]
PR = "{%s}" % NS_ODF["presentation"]
_ODF_WEG = {"tracked-changes", "page-number", "page-count", "date", "time", "note-citation", "table-of-content",
            "alphabetical-index", "illustration-index", "bibliography", "sequence-decls", "variable-decls",
            "user-field-decls", "soft-page-break", "bookmark-ref", "chapter", "file-name", "sheet-name", "creator",
            "author-name", "author-initials", "word-count", "page-continuation", "annotation", "annotation-end"}


def _odf_pruefen(z):
    if z.da("META-INF/manifest.xml") and b"encryption-data" in z.bytes("META-INF/manifest.xml"):
        raise _Meldung(_geschuetzt(z.name))
    if not z.da("content.xml"):
        raise _Meldung(_nicht_lesbar(z.name))


class _Odf:
    def __init__(self):
        self.bloecke = []
        self.noten = []
        self.nr = 0

    def inline(self, el, teile, kaesten):
        if el.text:
            teile.append(el.text)
        for k in el:
            t = _lokal(k.tag)
            if t in _ODF_WEG:
                pass
            elif t == "s":
                teile.append(" ")
            elif t == "tab":
                teile.append(" ")
            elif t == "line-break":
                teile.append("\n")
            elif t == "note":
                body = k.find(TX + "note-body")
                if body is not None:
                    self.nr += 1
                    teile.append(f"[{self.nr}]")
                    tt = []
                    for p in body.iter():
                        if p.tag in (TX + "p", TX + "h"):
                            x = []
                            self.inline(p, x, [])
                            tt.append(_sauber("".join(x)))
                    self.noten.append(f"[{self.nr}] " + " ".join(x for x in tt if x))
            elif k.tag == DR + "frame" or t == "text-box":
                kaesten.append(k)
            elif k.tag.startswith(DR) or t in ("desc", "title"):
                pass
            else:
                self.inline(k, teile, kaesten)
            if k.tail:
                teile.append(k.tail)

    def text_von(self, p):
        teile, kaesten = [], []
        self.inline(p, teile, kaesten)
        return "".join(teile), kaesten

    def block(self, el, liste_tiefe=None):
        for k in el:
            t = k.tag
            if t == TX + "h":
                text, kaesten = self.text_von(k)
                ebene = k.get(TX + "outline-level")
                if _sauber(text):
                    self.noten_ausgeben()
                    self.bloecke.append(("h", int(ebene) if (ebene or "").isdigit() else 1, text))
                self.kaesten(kaesten)
            elif t == TX + "p":
                text, kaesten = self.text_von(k)
                if _sauber(text):
                    self.bloecke.append(("li", liste_tiefe, text) if liste_tiefe is not None else ("p", text))
                self.kaesten(kaesten)
            elif t == TX + "list":
                tiefe = 0 if liste_tiefe is None else min(liste_tiefe + 1, 5)
                for item in k:
                    if _lokal(item.tag) in ("list-item", "list-header"):
                        self.block(item, tiefe)
            elif t == TB + "table":
                self.tabelle(k)
            elif t == TX + "section":
                self.block(k, liste_tiefe)
            elif t == DR + "frame":
                self.kaesten([k])

    def kaesten(self, kaesten):
        for f in kaesten:
            for k in f.iter():
                if k.tag == DR + "text-box":
                    self.block(k)
                    break

    def zellen(self, tc):
        ps = []
        for k in tc.iter():
            if k.tag in (TX + "p", TX + "h"):
                ps.append(_sauber(self.text_von(k)[0]))
        return " ".join(p for p in ps if p)

    def tabelle(self, tbl):
        zeilen = []
        for tr in tbl.iter(TB + "table-row"):
            zeilen.append([self.zellen(tc) for tc in tr if tc.tag == TB + "table-cell"])
        _tabelle_bloecke(zeilen, self.bloecke)

    def noten_ausgeben(self):
        self.bloecke += [("fn", n) for n in self.noten]
        self.noten = []


def _odt(z):
    _odf_pruefen(z)
    wurzel = z.xml("content.xml")
    text = wurzel.find("{%s}body/{%s}text" % (NS_ODF["office"], NS_ODF["office"]))
    if text is None:
        raise _Meldung(_nicht_lesbar(z.name))
    o = _Odf()
    o.block(text)
    o.noten_ausgeben()
    return _abschnitte_aus(o.bloecke)


def _odp(z):
    _odf_pruefen(z)
    wurzel = z.xml("content.xml")
    pres = wurzel.find("{%s}body/{%s}presentation" % (NS_ODF["office"], NS_ODF["office"]))
    if pres is None:
        raise _Meldung(_nicht_lesbar(z.name))
    folien = []
    for nr, seite in enumerate(pres.findall(DR + "page"), 1):
        titel, inhalt, notizen = [], [], []

        def formen(el, ziel_inhalt):
            for k in el:
                if k.tag == DR + "g":
                    formen(k, ziel_inhalt)
                elif k.tag in (DR + "frame", DR + "custom-shape", DR + "rect", DR + "ellipse"):
                    klasse = k.get(PR + "class") or ""
                    if klasse in ("page-number", "footer", "date-time", "header", "graphic"):
                        continue
                    o = _Odf()
                    for tb in [k] if k.tag != DR + "frame" else list(k):
                        if tb.tag == DR + "text-box" or k.tag != DR + "frame":
                            o.block(tb)
                        elif tb.tag == TB + "table":
                            o.tabelle(tb)
                    o.noten_ausgeben()
                    if klasse == "title":
                        titel.extend(_sauber(b[-1]).replace("\n", " ") for b in o.bloecke if b[0] in ("p", "li", "h"))
                    else:
                        ziel_inhalt.extend(o.bloecke)
        formen(seite, inhalt)
        n = seite.find(PR + "notes")
        if n is not None:
            nb = []
            for k in n:
                if k.tag == DR + "frame" and (k.get(PR + "class") or "") == "notes":
                    o = _Odf()
                    for tb in k:
                        if tb.tag == DR + "text-box":
                            o.block(tb)
                    nb += [b[-1] for b in o.bloecke if b[0] != "tr"]
            notizen = [_sauber(x).replace("\n", " ") for x in nb if _sauber(x)]
        folien.append((nr, " ".join(titel), inhalt, notizen))
    return _folien_abschnitte(folien)


def _folien_abschnitte(folien):
    out = []
    for nr, titel, inhalt, notizen in folien:
        titel = _sauber(titel).replace("\n", " ")
        if not titel and not any(_sauber(b[-1] if b[0] != "tr" else " ".join(b[1])) for b in inhalt) and not notizen:
            continue
        kopf = f"Folie {nr}: {titel}" if titel else f"Folie {nr}"
        text = "## " + kopf
        rumpf = _md_zeilen(inhalt)
        if rumpf:
            text += "\n\n" + rumpf
        if notizen:
            text += "\n\nNotiz: " + " ".join(notizen)
        out.append({"titel": kopf, "text": text, "art": "folie"})
    return out


# ---------------------------------------------------------------- pptx
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
P_ = "{http://schemas.openxmlformats.org/presentationml/2006/main}"
R_ = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"


def _pptx_text(txbody, liste):
    """a:txBody -> Blöcke; liste = Platzhalter mit Aufzählung (Body), a:buNone und a:buChar entscheiden je Absatz."""
    out = []
    for p in txbody.findall(A + "p"):
        teile = []
        for k in p:
            t = _lokal(k.tag)
            if t == "r":
                tt = k.find(A + "t")
                teile.append(tt.text or "" if tt is not None else "")
            elif t == "br":
                teile.append("\n")
            elif t == "fld":
                if not (k.get("type") or "").startswith(("slidenum", "datetime")):
                    tt = k.find(A + "t")
                    teile.append(tt.text or "" if tt is not None else "")
        text = "".join(teile)
        if not _sauber(text):
            continue
        ppr = p.find(A + "pPr")
        lvl = int(ppr.get("lvl")) if ppr is not None and (ppr.get("lvl") or "").isdigit() else 0
        punkt = liste
        if ppr is not None:
            if ppr.find(A + "buNone") is not None:
                punkt = False
            elif ppr.find(A + "buChar") is not None or ppr.find(A + "buAutoNum") is not None:
                punkt = True
        out.append(("li", min(lvl, 5), text) if punkt else ("p", text))
    return out


def _pptx_formen(baum, titel, inhalt, notiz=False):
    for k in baum:
        t = _lokal(k.tag)
        if t == "grpSp":
            _pptx_formen(k, titel, inhalt, notiz)
        elif t == "AlternateContent":
            ch = k.find("{http://schemas.openxmlformats.org/markup-compatibility/2006}Choice")
            if ch is not None:
                _pptx_formen(ch, titel, inhalt, notiz)
        elif t == "sp":
            ph = k.find(f"{P_}nvSpPr/{P_}nvPr/{P_}ph")
            art = (ph.get("type") or "body") if ph is not None else None
            if art in ("sldNum", "dt", "ftr", "hdr", "sldImg"):
                continue
            if notiz and art != "body":
                continue
            tx = k.find(P_ + "txBody")
            if tx is None:
                continue
            bl = _pptx_text(tx, art in ("body", "obj") and not notiz)
            if art in ("title", "ctrTitle"):
                titel.append(" ".join(_sauber(b[-1]).replace("\n", " ") for b in bl))
            else:
                inhalt.extend(bl)
        elif t == "graphicFrame" and not notiz:
            for tbl in k.iter(A + "tbl"):
                zeilen = []
                for tr in tbl.findall(A + "tr"):
                    zellen = []
                    for tc in tr.findall(A + "tc"):
                        tx = tc.find(A + "txBody")
                        bl = _pptx_text(tx, False) if tx is not None else []
                        zellen.append(" ".join(_sauber(b[-1]) for b in bl))
                    zeilen.append(zellen)
                _tabelle_bloecke(zeilen, inhalt)


def _pptx(z):
    if not z.da("ppt/presentation.xml"):
        raise _Meldung(_nicht_lesbar(z.name))
    rels = _rels(z, "ppt/presentation.xml")
    liste = z.xml("ppt/presentation.xml").find(P_ + "sldIdLst")
    folien = []
    for nr, s in enumerate(liste if liste is not None else [], 1):
        typ, pfad = rels.get(s.get(R_ + "id"), (None, None))
        if typ != "slide" or not z.da(pfad):
            continue
        titel, inhalt, notizen = [], [], []
        baum = z.xml(pfad).find(f"{P_}cSld/{P_}spTree")
        if baum is not None:
            _pptx_formen(baum, titel, inhalt)
        for ntyp, npfad in _rels(z, pfad).values():
            if ntyp == "notesSlide" and z.da(npfad):
                nb = z.xml(npfad).find(f"{P_}cSld/{P_}spTree")
                if nb is not None:
                    nbl = []
                    _pptx_formen(nb, [], nbl, notiz=True)
                    notizen += [_sauber(b[-1]).replace("\n", " ") for b in nbl if b[0] != "tr"]
        folien.append((nr, " ".join(t for t in titel if t), inhalt, [n for n in notizen if n]))
    return _folien_abschnitte(folien)


# ---------------------------------------------------------------- pdf
_RE_SEITENZAHL = re.compile(r"^(seite|s\.|page)?\s*\d{1,4}(\s*(von|/|of)\s*\d{1,4})?$", re.I)
_RE_PUNKT = re.compile(r"^([•▪◦●○■□➢►–—*]|-(?=\s))\s*")
_RE_NUMMER = re.compile(r"^(\d{1,2}[.)]|[a-z][)])\s")
_NICHT_ZUSAMMEN = {"und", "oder", "bis", "sowie", "als", "noch", "bzw", "statt"}


def _pypdf():
    """pypdf aus dem Wheel unter web/vendor/pyodide/ (Kommandozeile); in Pyodide installiert es der Worker."""
    hier = os.path.dirname(os.path.abspath(__file__))
    for whl in sorted(glob.glob(os.path.join(hier, "..", "..", "web", "vendor", "pyodide", "pypdf-*.whl"))):
        whl = os.path.abspath(whl)
        if whl not in sys.path:
            sys.path.insert(0, whl)
    import logging
    logging.getLogger("pypdf").setLevel(logging.ERROR)
    import pypdf
    return pypdf


def _pdf_rand(seiten):
    """Kopf und Fuß: Zeilen, die unter den ersten oder letzten zwei Zeilen von mindestens der Hälfte der Seiten (ab
    3 Seiten) gleich stehen, Ziffern vor dem Vergleich ersetzt; allein stehende Seitenzahlen dort ebenso."""
    norm = lambda z: re.sub(r"\d+", "#", z.strip().lower())
    zaehler = {}
    for zeilen in seiten:
        rand = {norm(z) for z in zeilen[:2] + zeilen[-2:] if z.strip()}
        for r in rand:
            zaehler[r] = zaehler.get(r, 0) + 1
    oft = {r for r, n in zaehler.items() if len(seiten) >= 3 and n * 2 >= len(seiten)}
    out = []
    for zeilen in seiten:
        n = len(zeilen)
        rand = set(range(min(2, n))) | set(range(max(0, n - 2), n))
        out.append([z for i, z in enumerate(zeilen)
                    if not (i in rand and (norm(z) in oft or _RE_SEITENZAHL.match(z.strip())))])
    return out


def _pdf_absaetze(zeilen):
    """Zeilen einer Seite -> Blöcke: Trennstriche am Zeilenende zusammenziehen, Zeilen eines Satzes verbinden,
    Aufzählungszeichen als Liste, Absatz an Leerzeilen und nach einer kurzen Zeile (Überschrift, Absatzende), auf die
    keine Fortsetzung in Kleinschreibung folgt."""
    bloecke, akt, kurz = [], None, False
    breite = max((len(_sauber(z)) for z in zeilen), default=0)
    for roh in zeilen + [""]:
        z = _sauber(roh)
        if not z or (akt and kurz and not z[:1].islower()):
            if akt:
                bloecke.append(akt)
            akt = None
            if not z:
                continue
        kurz = len(z) < 0.6 * breite
        m = _RE_PUNKT.match(z)
        if m and len(z) > len(m.group(0)):
            if akt:
                bloecke.append(akt)
            akt = ["li", 0, z[m.end():]]
            continue
        if akt and _RE_NUMMER.match(z):
            bloecke.append(akt)
            akt = None
        if akt is None:
            akt = ["p", z]
            continue
        vorher = akt[-1]
        erstes = z.split(" ", 1)[0].rstrip(",.;:").lower()
        if re.search(r"[A-Za-zÄÖÜäöüß]-$", vorher) and z[:1].islower() and erstes not in _NICHT_ZUSAMMEN:
            akt[-1] = vorher[:-1] + z
        elif re.search(r"[.!?:]$", vorher) and not z[:1].islower():
            akt[-1] = vorher + "\n" + z
        else:
            akt[-1] = vorher + " " + z
    return [tuple(b) for b in bloecke]


def _pdf(name, daten):
    pypdf = _pypdf()
    from pypdf.errors import DependencyError, PdfReadError
    try:
        r = pypdf.PdfReader(io.BytesIO(daten))
        if r.is_encrypted:
            try:
                if not r.decrypt(""):
                    raise _Meldung(_geschuetzt(name))
            except _Meldung:
                raise
            except Exception:
                raise _Meldung(_geschuetzt(name))
        seiten_roh, summe = [], 0
        for seite in r.pages:
            t = seite.extract_text() or ""
            seiten_roh.append(t.replace("\r\n", "\n").replace("\r", "\n").split("\n"))
            summe += len(t)
            if summe > MAX_ZEICHEN * 1.2:
                break
        anzahl = len(r.pages)
        marken = []         # (Seite, Titel, Tiefe) aller Lesezeichen

        def flach(liste, tiefe):
            for eintrag in liste:
                if len(marken) >= 500:
                    return
                if isinstance(eintrag, list):
                    flach(eintrag, tiefe + 1)
                    continue
                try:
                    marken.append((r.get_destination_page_number(eintrag), _sauber(eintrag.title or ""), tiefe))
                except Exception:
                    pass
        try:
            flach(r.outline, 0)
        except Exception:
            marken = []
    except _Meldung:
        raise
    except (DependencyError, NotImplementedError):
        raise _Meldung(_geschuetzt(name))
    except (PdfReadError, ValueError, KeyError, TypeError, IndexError, AttributeError, RecursionError, OSError):
        raise _Meldung(_nicht_lesbar(name))
    if not anzahl or sum(len(_sauber(" ".join(z))) for z in seiten_roh) / max(len(seiten_roh), 1) < SCAN_ZEICHEN:
        raise _Meldung(f"{name} enthält keinen lesbaren Text, vermutlich ein Scan. Tippe die wichtigsten Stellen ab "
                       "oder nutze eine Fassung mit Text.")
    seiten = _pdf_rand(seiten_roh)
    # Abschnitte je Lesezeichen der obersten Ebene (mehrere auf einer Seite: das erste); eine Zeile, die genau einem
    # Lesezeichen gleicht, wird Überschrift seiner Ebene, die Zeile mit dem Titel des Abschnitts fällt weg
    titel_ebene = {}
    for _, t, tiefe in marken:
        titel_ebene.setdefault(t.lower(), tiefe + 1)
    oben = sorted({s: t for s, t, tiefe in reversed(marken) if t and tiefe == 0 and 0 <= s < len(seiten)}.items())
    if oben:
        out = []
        for i, (start, titel) in enumerate(oben):
            ende = oben[i + 1][0] if i + 1 < len(oben) else len(seiten)
            bl = []
            for s in seiten[0 if i == 0 else start:ende]:
                for b in _pdf_absaetze(s):
                    t = b[1].lower() if b[0] == "p" else None
                    if t == titel.lower():
                        continue
                    bl.append(("h", titel_ebene[t], b[1]) if t in titel_ebene else b)
            out.append({"titel": titel, "text": "## " + titel + "\n\n" + _md_zeilen(bl), "art": "abschnitt"})
        return out
    return [{"titel": f"Seite {i + 1}", "text": f"## Seite {i + 1}\n\n" + _md_zeilen(_pdf_absaetze(s)), "art": "seite"}
            for i, s in enumerate(seiten) if any(_sauber(z) for z in s)]


# ---------------------------------------------------------------- txt / md
_RE_KOPF = re.compile(r"^(#{1,6})\s+(.*?)\s*#*\s*$")


def _text_dekodieren(d):
    if d.startswith(b"\xef\xbb\xbf"):
        d = d[3:]
    try:
        return d.decode("utf-8")
    except UnicodeDecodeError:
        return d.decode("cp1252", errors="replace")


def _txt(daten):
    t = _text_dekodieren(daten).replace("\r\n", "\n").replace("\r", "\n")
    t = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", t)                       # Bilder
    t = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", t)                   # Links -> Text
    t = re.sub(r"(\*\*|__)(?=\S)(.+?)(?<=\S)\1", r"\2", t)           # Fettung
    bloecke, absatz, im_code = [], [], False

    def fertig():
        if absatz:
            bloecke.append(("p", "\n".join(absatz)))
            absatz.clear()
    for z in t.split("\n"):
        if z.lstrip().startswith(("```", "~~~")):
            im_code = not im_code
        m = None if im_code else _RE_KOPF.match(z)
        li = None if im_code else re.match(r"^(\s*)[-*+]\s+(.*)$", z)
        if m:
            fertig()
            bloecke.append(("h", len(m.group(1)), m.group(2)))
        elif li:
            fertig()
            bloecke.append(("li", min(len(li.group(1).expandtabs(2)) // 2, 5), li.group(2)))
        elif not z.strip():
            fertig()
        else:
            absatz.append(z)
    fertig()
    return _abschnitte_aus(bloecke)


# ---------------------------------------------------------------- Einstieg
def _endung(name):
    return name.rsplit(".", 1)[-1].lower() if "." in name else ""


def lesen(name, daten):
    """Datei lesen. name: Dateiname (Endung entscheidet), daten: Bytes."""
    name = os.path.basename(str(name or "Datei").replace("\\", "/")) or "Datei"
    daten = bytes(daten or b"")
    fmt = _endung(name)
    if len(daten) > MAX_DATEI:
        return _fehler(fmt, f"{name} ist größer als 20 MB.")
    if fmt in BILDER:
        return _fehler(fmt, "Bilder liest die Mühle nicht als Material; im Bilder-Schritt kannst du eigene Bilder einsetzen.")
    if fmt in ALT:
        return _fehler(fmt, f"Speichere {name} als .docx oder .pptx und lies die Datei dann ein.")
    try:
        if fmt in ("docx", "pptx", "odt", "odp"):
            if daten.startswith(OLE):
                return _fehler(fmt, _geschuetzt(name))
            z = _Zip(name, daten)
            abschnitte = {"docx": _docx, "pptx": _pptx, "odt": _odt, "odp": _odp}[fmt](z)
        elif fmt == "pdf":
            abschnitte = _pdf(name, daten)
        elif fmt in ("txt", "md", "markdown", "text"):
            abschnitte = _txt(daten)
        else:
            return _fehler(fmt, _nicht_lesbar(name))
    except _Meldung as m:
        return _fehler(fmt, str(m))
    except Exception:       # jede Datei bekommt eine Meldung, nie einen Abbruch der Auswahl
        return _fehler(fmt, _nicht_lesbar(name))
    return _ergebnis(name, fmt, abschnitte)


def zusammensetzen(name, abschnitte):
    """Gewählte Abschnitte als Text fürs Materialfeld (wie materialText() in web/material.js)."""
    teile = [a["text"] for a in abschnitte if a.get("text")]
    return f"# Aus {name}\n\n" + "\n\n".join(teile) if teile else ""


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if not argv:
        print(__doc__.strip().splitlines()[-1], file=sys.stderr)
        return 2
    code = 0
    for i, pfad in enumerate(argv):
        with open(pfad, "rb") as f:
            r = lesen(os.path.basename(pfad), f.read())
        if r["hinweis"]:
            print(r["hinweis"], file=sys.stderr)
        if not r["ok"]:
            code = 1
            continue
        print(("\n" if i else "") + zusammensetzen(os.path.basename(pfad), r["abschnitte"]))
    return code


if __name__ == "__main__":
    sys.exit(main())
