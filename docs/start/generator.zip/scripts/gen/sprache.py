"""Sprachmessung je Lesetext (AP13.14): Sätze, Wörter, Wörter je Satz, längster Satz mit Zeile, Anteil langer Wörter
und LIX (Wörter je Satz plus 100 mal Anteil der Wörter mit mehr als sechs Buchstaben). Gemessen wird derselbe Text wie
in `api.woerter()`, ohne Überschriften der Textbausteine, Kastentitel, Tabellen, Bildzeilen, Rückmeldungen, Zeilen
`Offen:` und `Hilfe:` und ohne Übungsblöcke (deren Arbeitsaufträge sind zu kurz für einen Wert). Richtwerte je
Jahrgangsband stehen in `katalog.yaml` unter `sprache_richtwerte`; sie sind Richtwerte der Mühle, keine Lesestufen.

    messen(b)                         -> Werte eines Bausteins (dict) oder None (kein Lesetext)
    richtwert(jahrgang, sprache)      -> Richtwerte des Bands, mit Ab- oder Zuschlag für `kurs.sprache`
    bewerten(werte, rw)               -> stärkster Verstoß oder None (unter `mindest_woerter` nie eine Bewertung)
"""
import re

from . import mappe as M

LESETYPEN = {"Textfeld", "Seite", "Buch", "Lesebuch"}
# Zeilen, die nicht zählen: Titel der Textbausteine und Kästen, Kapitel- und Seitentitel, Zusätze der Mühle
_RE_TITEL = re.compile(r"^(?:Überschrift|Kasten|Beispiel|Hinweis|Schritte|Vergleich|Text|Seite|Kapitel|Unterkapitel|"
                       r"Offen|Hilfe|Bild|Bildzeile|Fahrplan|Kacheln|Themenfeld)(?:\s*\([^)]*\))?:")
_RE_EINZEILER = re.compile(r"^(?:Vorspann|Merke|Hervorhebung)(?:\s*\([^)]*\))?:")
_RE_GRUPPE = re.compile(r"^(?:\d+\.\s+)?(?:Schnellquiz|Aussagen)\b")
_RE_LISTE = re.compile(r"^(?:[-*•]|\d+\.)\s+")
_RE_ENDE = re.compile(r"[.!?]+[\"“”'»«)\]]*(?=\s|$)|:\s*$")
_RE_ZAHLPUNKT = re.compile(r"(?<![\w.])(\d+)\.(?=\s|$)")


def _kat():
    return M.katalog()["sprache_richtwerte"]


def _einheiten(b):
    """Zeilen des Bausteins, die zählen, als Einheiten [(Listenzeile?, [(Zeile im Baustein, Text)])]: ein Absatz
    (Zeilen bis zur Leerzeile), eine Listenzeile, ein Einzeiler wie `Merke:`. Übungsblöcke beginnen mit einer
    Fragezeile wie in `mappe.zeitbedarf` und reichen bis zur Leerzeile oder zum nächsten Textbaustein."""
    from . import api
    out, absatz, aufgabe = [], [], False

    def schliessen():
        if absatz:
            out.append((False, list(absatz)))
            absatz.clear()
    for nr, roh in enumerate((b.get("text") or "").splitlines()[1:], 2):
        t = roh.strip()
        if not t:
            schliessen()
            aufgabe = False
            continue
        if M._RE_FRAGEZEILE.match(t) or _RE_GRUPPE.match(t):
            schliessen()
            aufgabe = True
            continue
        if aufgabe and not (_RE_TITEL.match(t) or _RE_EINZEILER.match(t)):
            continue
        aufgabe = False
        if (api._RE_ANGABE.match(t) or t.startswith(("→", "|", "<")) or "✔" in t or "✘" in t
                or _RE_TITEL.match(t)):
            schliessen()
            continue
        t = M._RE_PRAEFIX.sub("", M._RE_HTML.sub(" ", t)) if not _RE_LISTE.match(t) else \
            M._RE_HTML.sub(" ", _RE_LISTE.sub("", t))
        if _RE_EINZEILER.match(roh.strip()) or _RE_LISTE.match(roh.strip()):
            schliessen()
            out.append((True, [(nr, t)]))
            continue
        absatz.append((nr, t))
    schliessen()
    return out


def _maske(t, abk):
    """Punkte, die keinen Satz beenden (Abkürzungen aus dem Katalog, Zahl mit Punkt), durch \\0 ersetzen; Länge bleibt."""
    for a in abk:
        t = re.sub(r"(?<![\w])" + re.escape(a), lambda m: m.group(0).replace(".", "\0"), t)
    return _RE_ZAHLPUNKT.sub(lambda m: m.group(1) + "\0", t)


def saetze(b):
    """Sätze eines Bausteins -> [(Zeile des Satzanfangs im Baustein, Wörter, lange Wörter)]. Satzende: `.`, `!`, `?`,
    `:` vor Zeilenende, Ende einer Listenzeile, eines Einzeilers und eines Absatzes."""
    kat = _kat()
    abk, lang = kat["abkuerzungen"], kat["lang_buchstaben"]
    out = []
    for _, zeilen in _einheiten(b):
        start, w, l = None, 0, 0
        for nr, t in zeilen:
            pos = 0
            for m in list(_RE_ENDE.finditer(_maske(t, abk))) + [None]:
                stueck = t[pos:m.end() if m else len(t)]
                woerter = M._RE_WORT.findall(stueck)
                if woerter and start is None:
                    start = nr
                w += len(woerter)
                l += sum(1 for x in woerter if sum(c.isalpha() for c in x) > lang)
                if m is None:
                    break
                pos = m.end()
                if w:
                    out.append((start, w, l))
                start, w, l = None, 0, 0
        if w:
            out.append((start, w, l))
    return out


def messen(b):
    """Werte eines Lesetexts (Textfeld, Seite, Buch, Lesebuch ohne seine Fragen): saetze, woerter, satz_mittel,
    satz_max, satz_max_zeile (Zeile im Baustein, 1 = Überschrift), lang_anteil (0 bis 1), lix. None für andere Typen
    und Bausteine ohne Satz."""
    if b.get("typ") not in LESETYPEN:
        return None
    s = saetze(b)
    if not s:
        return None
    w = sum(x[1] for x in s)
    l = sum(x[2] for x in s)
    laengster = max(s, key=lambda x: x[1])
    mittel = w / len(s)
    return {"saetze": len(s), "woerter": w, "satz_mittel": round(mittel, 1), "satz_max": laengster[1],
            "satz_max_zeile": laengster[0], "lang_anteil": round(l / w, 2), "lix": round(mittel + 100 * l / w)}


def richtwert(jahrgang=None, sprache=None):
    """Richtwerte für eine Jahrgangsstufe (erste Zahl im Feld, sonst `zeitbedarf.jahrgang_ohne`), Band nach dem
    Schlüssel „ab Stufe“; `sprache` einfach oder anspruchsvoll verschiebt sie um den Ab- oder Zuschlag des Katalogs.
    -> {satz_mittel, satz_max, lix, jahrgang, angenommen, sprache}"""
    kat = _kat()
    jg = M.jahrgang_zahl(jahrgang)
    angenommen = not jg
    stufe = int(jg) if jg else int(M.katalog()["zeitbedarf"]["jahrgang_ohne"])
    baender = {int(k): v for k, v in kat["baender"].items()}
    band = baender[max([k for k in baender if stufe >= k] or [min(baender)])]
    rw = {k: band[k] for k in ("satz_mittel", "satz_max", "lix")}
    if sprache in ("einfach", "anspruchsvoll"):
        for k, v in kat[sprache].items():
            rw[k] = max(1, rw[k] + v)
    return dict(rw, jahrgang=stufe, angenommen=angenommen, sprache=sprache if sprache in kat else None)


def bewerten(werte, rw):
    """Stärkster Verstoß gegen die Richtwerte (größte relative Überschreitung) -> {art, wert, grenze} oder None; unter
    `mindest_woerter` Wörtern keine Bewertung."""
    if not werte or werte["woerter"] < _kat()["mindest_woerter"]:
        return None
    verstoesse = [(werte[k] / rw[k], k) for k in ("satz_mittel", "satz_max", "lix") if werte[k] > rw[k]]
    if not verstoesse:
        return None
    _, art = max(verstoesse)
    return {"art": art, "wert": werte[art], "grenze": rw[art]}


def _zahl(x):
    return f"{x:g}".replace(".", ",")


def hinweis(werte, rw):
    """Satz für die Karte zum stärksten Verstoß (ohne Zeile; die Karte setzt „Zeile N:“ davor) oder None."""
    v = bewerten(werte, rw)
    if not v:
        return None
    t = _kat()["texte"]
    wofuer = t["fuer"].format(jahrgang=rw["jahrgang"]) + (t["angenommen"] if rw["angenommen"] else "") \
        + (t[rw["sprache"]] if rw.get("sprache") else "")
    satz = t[v["art"]].format(wert=_zahl(v["wert"]), grenze=v["grenze"], fuer=wofuer)
    if v["art"] == "lix" and werte["satz_mittel"] <= rw["satz_mittel"]:
        satz += t["lix_woerter"]
    return satz
