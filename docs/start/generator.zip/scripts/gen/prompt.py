"""Text für den Chat (AP11): aus `references/katalog.yaml` und dem Stand der Kursmappe, für CLI und Browser derselbe Text.

    chats()                                        Chat-Auswahl aus dem Katalog
    einheit(mappe, steckbrief, chat, material, nur_leere)  -> {teile, groessen, ids, typen}: Text „Diese Einheit“ oder
                                                   „Alle leeren Bausteine“, gestückelt über 14 KB oder nach Chat
    baustein(mappe, ids, kurs_md, steckbrief, chat)  -> Text „Nur dieser Baustein“ (etwa 1 KB, bisheriger Inhalt als Kontext)
    diagnose(text)                                 -> Karte und Satz, wenn eine Antwort keinen Baustein ergab (AP13.4)
    korrektur(pruefung)                            -> Sätze an den Chat, einer je Fehler (eigener Satz, wenn die Prüfung
                                                   einen mitgibt: `bitte`, etwa bei einer Zeit-Annahme)
    fragen(pruefung)                               -> Ansicht „Fragen und Lösungen“ (Fragen, Optionen, Lösungen, ohne Rückmeldung)
    fachcheck(pruefung, steckbrief)                -> Text für einen neuen Chat: Aufgaben ohne Lösungen
    vergleich(pruefung, antwort)                   -> Abweichungen zwischen Antwort des neuen Chats und Kursdatei

Der Text richtet sich an das Modell, nicht an die Lehrkraft; die Sätze stehen im Katalog unter `prompt`.
"""
import re

from . import api
from . import design as DS
from . import mappe as M

GRENZE = 14 * 1024          # Ziel je Text in Bytes (Plan §4; 14 KB seit AP13.3, damit sechs Karten in einen Teil passen; 68 KB
                            # liefen im Test in AIS-Chat und fobizz); darüber stückelt einheit() nach Abschnitten
_TEXTTYPEN = {"Textfeld", "Seite", "Lesebuch", "Buch", "Aufgabe", "Datei", "Geschichte"}
_FRAGETYPEN = {"Quiz", "Test", "Lesebuch"}


def _kat():
    return M.katalog()


def chats():
    return _kat()["chats"]


def chat(wert=None):
    """Eintrag der Chat-Auswahl; unbekannt oder leer = „anderer Chat“. Ein dict wird unverändert genommen (Tests)."""
    if isinstance(wert, dict):
        return wert
    liste = chats()
    return next((c for c in liste if c["wert"] == wert), next(c for c in liste if c["wert"] == "anderer"))


def _text_von(feld, wert):
    return next((w["text"] for w in _kat()["oberflaeche"][feld] if w["wert"] == wert), wert)


def _typ(typ):
    return next((e for e in _kat()["typen"] if e["typ"] == typ), None)


# ---------------------------------------------------------------- Teile des Textes
def _auftrag(mappe, angaben):
    e = mappe.get("einheit") or {}
    teile = []
    thema = e.get("thema") or angaben.get("thema") or mappe.get("titel")
    if thema:
        teile.append(f"Thema: {thema}")
    if angaben.get("fach"):
        teile.append(f"Fach: {angaben['fach']}")
    if angaben.get("schulart"):
        teile.append(f"Schulart: {angaben['schulart']}")
    jg = e.get("jahrgang") or angaben.get("jahrgang")
    if jg:
        teile.append(f"Jahrgangsstufe {jg}")
    else:
        teile.append(_kat()["prompt"]["jahrgang_fehlt"].format(jahrgang=_kat()["zeitbedarf"]["jahrgang_ohne"]))
    minuten = e.get("minuten") or angaben.get("minuten")
    if minuten:
        teile.append(f"{minuten} Minuten")
    return " · ".join(teile), thema or "Einheit", minuten


def _angenommen(angaben):
    website = "auf der Kursseite (formative Übungen als Block im Textfeld, Kursdatei-Angabe `website: textfeld` am " \
              "Abschnitt)" if angaben.get("website") == "textfeld" else "als eigene Aktivitäten"
    return [f"Angenommen: Kursformat {_text_von('format', angaben.get('format', 'themen'))}",
            f"Angenommen: Übungen erscheinen {website}",
            f"Angenommen: {_text_von('abschluss', angaben.get('abschluss', 'keiner'))}",
            f"Angenommen: {_text_von('portionierung', angaben.get('portionierung', 'keine'))}"]


_LESETYPEN = {"Textfeld", "Seite", "Buch", "Lesebuch"}
_AUFGABENTYPEN = {"Quiz", "Test", "Lückentext"}


def wortziel(e, jahrgang=None):
    """Länge, die ein Baustein für seine Soll-Minuten braucht, aus denselben Werten wie die Rechnung (katalog.yaml
    `zeitbedarf`): Lesetext nach Rolle und Jahrgangsstufe in Wörtern, Hefteintrag im Abschreibtempo, Quiz und Test in
    Aufgaben (Mittel aus einfach und rechnen), Zuordnen und Lernkarten in Elementen. Leer ohne Soll."""
    soll, typ = e.get("soll"), e.get("typ")
    if not soll or typ in M.struktur():
        return ""
    k = _kat()
    z, p = k["zeitbedarf"], k["prompt"]
    faktor = M._jahrgang_faktor(jahrgang)
    rolle = M.rolle_von(e)
    minuten = f"{soll} Minute" + ("" if soll == 1 else "n")
    if typ in _LESETYPEN:
        if rolle == "rahmen":
            return p["wortziel_kurz"]
        heft = "Hefteintrag" in (e.get("titel") or "") or "Hefteintrag" in (e.get("schritt") or "")
        einstieg = rolle == "einstieg" and typ == "Textfeld"
        wpm = z["abschreiben"] if heft else z["woerter_je_minute"].get(rolle, z["woerter_je_minute"]["rahmen"])
        lesen = max(0.5, soll - z["aufgabe_minuten"]["einfach"]) if einstieg else soll   # Denkaufgabe abziehen
        woerter = max(20, int(round(lesen * wpm * faktor / 10.0)) * 10)
        if rolle == "einstieg":                      # Einstieg kurz (AP13.1), mit Abstand zur Grenze der Prüfung
            woerter = min(woerter, k["pruefregeln"]["einstieg_woerter"] - 20)
        if heft:                                     # Wortziel nie unter dem Mindestmaß des Hefteintrags
            woerter = max(woerter, next((M.mindestzahl(t["mindest"], jahrgang) for t in k["typen"]
                                         if t["typ"] == typ and t.get("mindest")), 0))
        art = "wortziel_heft" if heft else "wortziel_einstieg" if einstieg else "wortziel_text"
        return p[art].format(min=minuten, woerter=woerter)
    if typ in _AUFGABENTYPEN:
        mittel = (z["aufgabe_minuten"]["einfach"] + z["aufgabe_minuten"]["rechnen"]) / 2
        n = max(1, round(soll / mittel))
        return p["wortziel_aufgaben"].format(n=f"{n} Aufgabe" + ("" if n == 1 else "n"), min=minuten)
    if typ in ("Zuordnen", "Lernkarten"):
        sek = z["sekunden"]["zuordnung" if typ == "Zuordnen" else "karte"]
        return p["wortziel_elemente"].format(n=max(3, min(12, round(soll * 60 / sek / 2))))
    return ""


AUTO = "automatisch"           # Typ einer Karte, deren Typ das Modell wählt (AP13)


def zeit_selbst(mappe):
    """Hat die Lehrkraft die Zeit je Phase selbst eingestellt? Schalter `zeit_selbst` der Mappe (AP13); ohne Schlüssel
    (Kursdateien vor 2.0.0-b1) gelten die Soll-Minuten wie bisher."""
    return mappe.get("zeit_selbst", True) is not False


def _zeile(e, nr, jahrgang=None, selbst=True):
    """Eine Zeile der Bausteinliste: id, Typ (oder „Typ frei“), Arbeitstitel, Phase, mit `selbst` die Soll-Minuten mit
    Wortziel, Teilschritt aus der Vorlage, Auftrag der Lehrkraft."""
    teile = [f"{nr}. id: {e['id']}", "Typ frei" if e.get("typ") == AUTO else e.get("typ", ""),
             f"Arbeitstitel „{e.get('titel', '')}“"]
    if e.get("typ") not in M.struktur():
        if e.get("phase"):
            teile.append(f"Phase {e['phase']}")
        ziel = wortziel(e, jahrgang) if selbst and e.get("typ") != AUTO else ""
        if ziel:
            teile.append(ziel)
        elif selbst and e.get("soll"):
            teile.append(f"{e['soll']} min")
        elif not selbst and M.rolle_von(e) == "einstieg":
            teile.append(_kat()["prompt"]["einstieg_dauer"])     # Prompttest AP13.3: sonst schrieb das Modell 1 min
    if (e.get("schritt") or "").strip():
        teile.append("Teilschritt: " + " ".join(e["schritt"].split()))
    if (e.get("auftrag") or "").strip():
        teile.append("Auftrag: " + " ".join(e["auftrag"].split()))
    return " · ".join(teile)


def zaehlregeln(liste, typen, uebung=True, jahrgang=None):
    """Zählregeln für den Inhalt (AP13.1): Mindestmaße der Typen dieser Einheit (`mindest` im Katalog; der Hefteintrag
    nur, wenn eine Karte so heißt oder diesen Teilschritt hat), Einstieg kurz (wenn eine Karte die Rolle Einstieg hat),
    mit `uebung` die Regel, dass Denkaufgaben keine Übung sind (nur im Text für die ganze Einheit)."""
    k = _kat()
    p, regeln = k["prompt"], k["pruefregeln"]
    teile = []
    for e in k["typen"]:
        m = e.get("mindest")
        if not m or e["typ"] not in typen or m.get("nur"):
            continue
        teile.append(p["mindest_typ"].format(typ=e["typ"], zahl=M.mindestzahl(m, jahrgang), einheit=m["einheit"]))
    heft = next((e["mindest"] for e in k["typen"] if (e.get("mindest") or {}).get("nur") == "Hefteintrag"), None)
    if heft and any("Hefteintrag" in f"{x.get('titel', '')} {x.get('schritt', '')}" for x in liste):
        teile.append(p["mindest_hefteintrag"].format(zahl=M.mindestzahl(heft, jahrgang)))
    out = [p["mindest"].format(liste="; ".join(teile))] if teile else []
    if any(M.rolle_von(x) == "einstieg" for x in liste):
        out.append(p["einstieg"].format(woerter=regeln["einstieg_woerter"]))
    if uebung:
        out.append(p["uebung"].format(typen=", ".join(regeln["uebung"][:-1]) + " oder " + regeln["uebung"][-1]))
        out.append(p["variation"])
    return out


def braucht_skizze(angaben, thema=""):
    """Fach aus `skizze_faecher` oder ein Stichwort aus `skizze_stichworte` im Thema (Geometrie, Brüche, Diagramme …)."""
    p = _kat()["prompt"]
    fach = (angaben.get("fach") or "").lower()
    text = f"{thema} {angaben.get('thema') or ''}".lower()
    return any(f.lower() in fach for f in p["skizze_faecher"]) or any(w.lower() in text for w in p["skizze_stichworte"])


def _regeln(e):
    """Regeln eines Typs für den Text: `kurzregeln`, wenn der Katalog welche hat (AP13.4), sonst `regeln`."""
    return ["- " + r for r in e.get("kurzregeln", e.get("regeln", []))]


def _beispiel(e):
    """Formatbeispiel eines Typs für den Text: das kürzere `kurzbeispiel`, wenn der Katalog eins hat (AP13.4)."""
    return (e.get("kurzbeispiel") or e["beispiel"]).rstrip("\n").splitlines()


def bilder_saetze(angaben):
    """Regel zu Bildern nach der Stufe aus Schritt 3 (AP13.4): keine `Bild:`-Zeilen, oder mindestens/höchstens n."""
    p, st = _kat()["prompt"], M.bilder_stufe((angaben or {}).get("bilder", M.bilder_standard()))
    if not st["max"] and st["max"] is not None:
        return None, p["bilder_keine"]
    wie = f"mindestens {st['min']}" + (f" und höchstens {st['max']}" if st["max"] else "")
    return st, p["bilder_stufe"].format(wie=wie)


def bildstil(angaben):
    """Ein Satz Bildstil aus der Designfamilie (familien.yaml `bildstil`, AP13.5 §5); optionale Zeile, zählt zur
    zweiten Stufe der Grenze. Sonst sieht der Chat nichts vom Design: Farben, Schrift und Formen setzt der Generator."""
    try:
        f = DS.familie((angaben or {}).get("familie"))
    except DS.DesignFehler:
        f = DS.familie(None)
    return f"Stil der Bilder: {f['bildstil']}."


def _format(typen, ch, kopf=True, nur_typen=False, angaben=None):
    k = _kat()
    if nur_typen:                     # Teil 2 und folgende: nur die Formatzeilen neuer Typen (AP13.3)
        zeilen = ["Format der Typen, die neu dazukommen:"]
        for e in k["typen"]:
            if e["typ"] in typen:
                zeilen += ["```"] + _beispiel(e) + ["```"] + _regeln(e)
        return zeilen
    zeilen = ["Format der Kursdatei"]
    if kopf:
        zeilen.append("- Erste Zeile `# Drehbuch v1 · Thema · N min`; darunter im Kopf nur Zeilen `Angenommen: …`, "
                      "`Bildwunsch: …`, `Bildprompt: …` und `Offen: …` (fachliche Zweifel für die Lehrkraft).")
        zeilen.append("- " + k["kopf"]["abschnitt"]["regeln"][0])
    zeilen += ["- " + r for r in k["gemeinsam"]["regeln"]]
    if set(typen) & _TEXTTYPEN:
        zeilen.append("- " + k["prompt"]["textbausteine"])
    if set(typen) & _FRAGETYPEN:
        zeilen.append("- " + k["prompt"]["fragen"])
    if "Test" in typen:
        zeilen.append("- " + k["prompt"]["fragen_test"])
    stufe, satz = bilder_saetze(angaben)
    if stufe:
        zeilen.append("- " + " ".join([k["prompt"]["bilder"]] + k["prompt"]["bildprompt"] + [bildstil(angaben)]
                                      + ([k["prompt"]["bilder_erzeugen"]] if ch.get("bilder") else [])))
    zeilen.append("- " + satz)
    zeilen.append("")
    zeilen.append("Beispiel und Regeln je Typ (nur die Typen dieser Einheit):")
    for e in k["typen"]:
        if e["typ"] not in typen:
            continue
        zeilen.append("```")
        zeilen += _beispiel(e)
        zeilen.append("```")
        zeilen += _regeln(e)
    return zeilen


def _ausgabe(ch):
    p = _kat()["prompt"]
    return [p["ausgabe_codeblock"] if ch.get("codeblock", True) else p["ausgabe_text"], p["ausgabe_ids"]]


def _gruppen(eintraege):
    """Bausteinliste nach Abschnitten: geplante Bausteine ohne Abschnitt gehören zum vorigen."""
    out, letzter = [], None
    for e in eintraege:
        a = e.get("abschnitt") or letzter
        if not out or a != out[-1][0]:
            out.append((a, []))
        out[-1][1].append(e)
        letzter = a
    return out


def _anteil(e):
    """Gewicht einer Karte für die Minuten eines Teils: Soll, sonst Richtwert nach Rolle (`zeitbedarf.karte_minuten`)."""
    if e.get("typ") in M.struktur():
        return 0
    richt = _kat()["zeitbedarf"]["karte_minuten"]
    return e.get("soll") or richt.get(M.rolle_von(e), richt["rahmen"])


def teil_minuten(liste, stueck, minuten):
    """Minuten, die ein Teil der Stückelung trägt (AP13.3): Anteil seiner Karten an allen Karten des Textes."""
    gesamt = sum(_anteil(e) for e in liste)
    if not minuten or not gesamt:
        return None
    return max(1, round(int(minuten) * sum(_anteil(e) for e in stueck) / gesamt))


def _kontext(angaben):
    """„Worum geht es genau?“ (AP13.4, Steckbrief `kurs.kontext`) als Zeile direkt unter dem Auftrag."""
    t = " ".join(str((angaben or {}).get("kontext") or "").split())
    return [_kat()["prompt"]["kontext"].format(text=t)] if t else []


RICHTUNG_MAX = 400


def richtung(mappe, angaben, grundschule=False):
    """AP13.5b: Zeilen des Zweigs „Ich gebe die Richtung“ unter dem Auftrag (optional, zusammen höchstens 400 Bytes):
    Schwerpunkt und Sprache in „Ich gebe die Richtung“ und „Ich steuere“, bevorzugte Übungstypen nur in „Ich gebe die
    Richtung“ (in „Ich steuere“ tragen die Karten die Typen); in „Mach du“ keine. `einfach` fügt bei aktiver
    Grundschul-Regel nichts hinzu (dieselbe Forderung steht dort schon)."""
    zweig = (mappe or {}).get("zweig")
    if zweig not in ("richtung", "steuer"):
        return []
    r, a = _kat()["prompt"]["richtung"], angaben or {}
    z = []
    sp = [r["schwerpunkte"][w] for w in a.get("schwerpunkt") or [] if w in r["schwerpunkte"]]
    if sp:
        z.append(r["schwerpunkt"].format(was=" und ".join(x["was"] for x in sp),
                                         pruefen=" und ".join(x["pruefen"] for x in sp)))
    if zweig == "richtung" and a.get("uebungstypen"):
        z.append(r["uebungstypen"].format(typen=", ".join(a["uebungstypen"])))
    if a.get("sprache") in r["sprache"] and not (grundschule and a["sprache"] == "einfach"):
        z.append(r["sprache"][a["sprache"]])
    if sp and len("\n".join(z).encode()) > RICHTUNG_MAX:     # alles gewählt: Schwerpunkt ohne den Prüfsatz
        z[0] = f"Schwerpunkt: {' und '.join(x['was'] for x in sp)}."
    return z


def bevorzugt(mappe, angaben):
    """Bevorzugte Übungstypen, die im Text bleiben (nur Zweig „Ich gebe die Richtung“)."""
    return (angaben or {}).get("uebungstypen") if (mappe or {}).get("zweig") == "richtung" else None


def _grundschule(jahrgang, angaben):
    jg = re.match(r"\d+", str(jahrgang or ""))
    return (bool(jg) and int(jg.group(0)) <= 4) or (angaben.get("schulart") or "") == "Grundschule"


def _einheit_text(mappe, angaben, ch, liste, alle, material, teil, von, nur_leere, ganz=None, erste=None):
    """Text eines Teils. `ganz` = alle Karten des Textes (für die Minuten je Teil), `erste` = Karten von Teil 1 (Teil 2
    und folgende wiederholen Format und Prüfliste nicht, nur die Formatzeilen der Typen, die Teil 1 nicht hatte)."""
    k = _kat()
    p = k["prompt"]
    auftrag, thema, minuten = _auftrag(mappe, angaben)
    jahrgang = (mappe.get("einheit") or {}).get("jahrgang") or angaben.get("jahrgang")
    selbst = zeit_selbst(mappe)
    folge = von > 1 and teil > 1

    angebot = M.auto_typen(alle, bevorzugt(mappe, angaben))   # AP13.4: acht Typen, bei mehr als vier Karten sechs

    def typen_von(karten):
        # Typen zur Wahl auch ohne Karte „automatisch“, sobald die Zeitregel zum Ergänzen auffordert (Prompttest AP13.1, Lauf C)
        out, auto_ = [], any(e.get("typ") == AUTO for e in karten) or bool(minuten)
        for e in karten:
            if e.get("typ") and e["typ"] != AUTO and e["typ"] not in out:
                out.append(e["typ"])
        if auto_:
            out += [t for t in angebot if t not in out]
        return out, auto_
    typen, auto = typen_von(liste)
    if folge:
        schon = set(typen_von(erste or [])[0])
        z = [p["einheit_teil"], "", "Auftrag", auftrag, ""]
    else:
        z = ([p["einheit"], "", "Auftrag", auftrag] + _kontext(angaben)
             + richtung(mappe, angaben, _grundschule(jahrgang, angaben)) + [p["lernende"]])
        if _grundschule(jahrgang, angaben):
            z.append(p["grundschule"])
        z.append("")
        z.append("Vorgaben, schon entschieden (übernimm diese Zeilen unverändert in den Kopf):")
        z += _angenommen(angaben)
        z.append(p["angenommen_nur"])
        z.append("")
    if nur_leere and not folge:
        fertig = [e for e in alle if not e.get("geplant") and e.get("typ") not in M.struktur()]
        if fertig:
            z.append("Diese Bausteine der Einheit gibt es schon, schreib sie nicht noch einmal: "
                     + "; ".join(f"„{e['titel']}“" for e in fertig) + ".")
    if von > 1:
        z.append(p["teil"].format(n=teil, von=von, weiter=p["teil_weiter"] if teil < von else p["teil_letzter"]))
    z.append("Bausteine (genau diese, in dieser Reihenfolge; Arbeitstitel ersetzt du durch einen Titel, der sagt, "
             "worum es geht):")
    nr = {e["id"]: i + 1 for i, e in enumerate(alle)}
    for abschnitt, gruppe in _gruppen(liste):
        z.append(f"Abschnitt „{abschnitt or thema}“" + (f" · {minuten} min" if minuten and von == 1 and len(_gruppen(alle)) == 1 else ""))
        z += [_zeile(e, nr[e["id"]], jahrgang, selbst) for e in gruppe]
    if auto and not folge:
        z += [p["automatisch"]] + [f"- {t}: {k['automatisch']['typen'][t]}" for t in angebot] + [p["automatisch_zwei"]]
    anteil = teil_minuten(ganz or liste, liste, minuten) if von > 1 else None
    if not selbst and minuten and not folge:
        zb, f = k["zeitbedarf"], M._jahrgang_faktor(jahrgang)
        wpm = zb["woerter_je_minute"]
        zahl = lambda x: f"{x:g}".replace(".", ",")
        z.append(p["zeit_frei"].format(minuten=anteil or minuten, lesen=int(round(wpm["lesen"] * f)),
                                       einstieg=int(round(wpm["einstieg"] * f)), heft=int(round(zb["abschreiben"] * f)),
                                       einfach=zahl(zb["aufgabe_minuten"]["einfach"]),
                                       rechnen=zahl(zb["aufgabe_minuten"]["rechnen"])))
    if minuten:
        z.append(p["zeit_teil"].format(minuten=minuten, n=anteil) if anteil else p["zeit_summe"].format(minuten=minuten))
        if not folge:
            z.append(p["zeit"].format(minuten=minuten))
    z.append("")
    if folge:
        neu = [t for t in typen if t not in schon]
        z.append(p["teil_format"])
        regeln = zaehlregeln(liste, neu, uebung=False, jahrgang=jahrgang)     # Mindestmaße der Typen, die neu dazukommen
        if neu or regeln:
            z.append("")
            z += _format(neu, ch, kopf=False, nur_typen=True) if neu else []
            z += ["- " + r for r in regeln]
        z += ["", p["ausgabe_teil"].format(als="als ein Codeblock" if ch.get("codeblock", True) else "als reiner Text")]
        return "\n".join(z) + "\n", typen
    if material and teil == 1:
        z += ["Material der Lehrkraft (nutze es als Grundlage; Tatsachen daraus haben Vorrang vor deinen):",
              material.strip(), ""]
    z += _format(typen, ch, angaben=angaben)
    z += ["", "Vorgaben für den Inhalt (zähle nach, bevor du ausgibst):"] + ["- " + r for r in p["leitplanken"]]
    z += ["- " + r for r in zaehlregeln(liste, typen, jahrgang=jahrgang)]
    if braucht_skizze(angaben, thema) and bilder_saetze(angaben)[0]:
        z.append("- " + p["skizze"])
    z += ["", "Prüfe vor der Ausgabe:"] + ["- " + r for r in p["checkliste"]]
    z += [""] + _ausgabe(ch)
    return "\n".join(z) + "\n", typen


def _groesse(t):
    return len(t.encode("utf-8"))


def einheit(mappe, steckbrief=None, chat_wert=None, material=None, nur_leere=False, grenze=GRENZE):
    """Text „Diese Einheit“ (oder mit nur_leere „Alle leeren Bausteine“). Sprengt der Text die Grenze oder hat er mehr
    Bausteine, als der Chat je Antwort schafft (`teil_bausteine`), stückelt die Seite nach Abschnitten, notfalls
    innerhalb eines Abschnitts; jeder Teil sagt „Teil n von m“ und nennt seinen Anteil an den Minuten. Nur Karten der
    laufenden Einheit (AP13.3). Steht in der Mappe eine eingefrorene Stückelung (`stueckelung`, gesetzt beim ersten
    Kopieren, gelöscht, wenn alle Teile eingefügt sind) für diese Einheit und Textart, gelten ihre Teile.
    -> {teile: [Text], groessen: [Bytes], ids: [[id]], typen: [[Typ]], minuten: [Minuten je Teil]}"""
    ch = chat(chat_wert if chat_wert is not None else mappe.get("chat"))
    angaben = M.angaben_lesen(steckbrief or "")
    material = material if material is not None else mappe.get("material", "")
    tag = M.laufende_einheit(mappe)
    alle = [e for e in mappe.get("bausteine", []) if e.get("typ") != "Badge" and not e.get("aus")
            and (e.get("einheit") or None) == tag]
    liste = [e for e in alle if e.get("geplant")] if nur_leere else alle
    st = mappe.get("stueckelung") or {}
    if st.get("ids") and (st.get("einheit") or None) == tag and bool(st.get("leer")) == bool(nur_leere):
        nach_id = {e["id"]: e for e in alle}
        teile = [[nach_id[i] for i in ids if i in nach_id] for ids in st["ids"]]
        liste = [e for t in teile for e in t]
        if liste:
            return _teile_texte(mappe, angaben, ch, liste, alle, material, nur_leere, teile)
    if not liste:
        return {"teile": [], "groessen": [], "ids": [], "typen": [], "minuten": []}
    n = ch.get("teil_bausteine") or len(liste)

    ganz, typen = _einheit_text(mappe, angaben, ch, liste, alle, material, 1, 1, nur_leere)
    if _groesse(ganz) <= grenze and len(liste) <= n:
        return {"teile": [ganz], "groessen": [_groesse(ganz)], "ids": [[e["id"] for e in liste]], "typen": [typen],
                "minuten": [(mappe.get("einheit") or {}).get("minuten")]}
    # Teile: ganze Abschnitte, solange sie passen; ein Abschnitt, der nicht passt, füllt den laufenden Teil Baustein für
    # Baustein auf (Grenze: Bytes und Bausteine je Teil; Teil 1 mit Format und Prüfliste, die übrigen ohne)
    teile = [[]]

    def passt(stueck):
        erster = len(teile) == 1
        t = _einheit_text(mappe, angaben, ch, stueck, alle, material, 1 if erster else 2, 2, nur_leere, liste,
                          None if erster else teile[0])[0]
        return len(stueck) <= n and _groesse(t) <= grenze

    for _, gruppe in _gruppen(liste):
        if passt(teile[-1] + gruppe):
            teile[-1] += gruppe
            continue
        if teile[-1]:
            teile.append([])
            if passt(gruppe):
                teile[-1] += gruppe
                continue
        for e in gruppe:
            if teile[-1] and not passt(teile[-1] + [e]):
                teile.append([])
            teile[-1].append(e)
    return _teile_texte(mappe, angaben, ch, liste, alle, material, nur_leere, teile)


def _teile_texte(mappe, angaben, ch, liste, alle, material, nur_leere, teile):
    teile = [t for t in teile if t]
    von = len(teile)
    minuten = (mappe.get("einheit") or {}).get("minuten")
    texte = [_einheit_text(mappe, angaben, ch, t, alle, material, i + 1, von, nur_leere, liste, teile[0])
             for i, t in enumerate(teile)]
    return {"teile": [t for t, _ in texte], "groessen": [_groesse(t) for t, _ in texte],
            "ids": [[e["id"] for e in t] for t in teile], "typen": [ty for _, ty in texte],
            "minuten": [teil_minuten(liste, t, minuten) if von > 1 else minuten for t in teile]}


def baustein(mappe, ids, kurs_md="", steckbrief=None, chat_wert=None, kontext=900, pruefung=None):
    """Text „Nur dieser Baustein“ für eine oder mehrere markierte Karten: Auftrag, die Zeile der Bausteinliste, Format
    nur für diesen Typ, der bisherige Inhalt (gekürzt) als Kontext und, mit `pruefung`, die Fehler der Prüfung. Ziel
    etwa 1 KB je Baustein."""
    if isinstance(ids, str):
        ids = [ids]
    ch = chat(chat_wert if chat_wert is not None else mappe.get("chat"))
    p = _kat()["prompt"]
    angaben = M.angaben_lesen(steckbrief or "")
    alle = mappe.get("bausteine", [])
    nr = {e["id"]: i + 1 for i, e in enumerate(alle)}
    liste = [e for e in alle if e["id"] in ids]
    bisher = {}
    if (kurs_md or "").strip():
        bisher = {b["id"]: b["text"] for b in api.pruefe(kurs_md)["bausteine"]}
    auftrag, _, _ = _auftrag(mappe, angaben)
    z = [p["baustein"] if len(liste) == 1 else p["baustein"].replace("einen Baustein", "diese Bausteine")
         .replace("nur diesen Baustein", "nur diese Bausteine"), "", "Einheit: " + auftrag, p["lernende"], ""]
    typen = []
    jahrgang = (mappe.get("einheit") or {}).get("jahrgang") or angaben.get("jahrgang")
    for e in liste:
        z.append(_zeile(e, nr[e["id"]], jahrgang, zeit_selbst(mappe)))
        for t in (M.auto_typen(alle, bevorzugt(mappe, angaben)) if e["typ"] == AUTO else [e["typ"]]):
            if t not in typen:
                typen.append(t)
        alt = bisher.get(e["id"])
        if alt and not e.get("geplant"):
            alt = alt.strip()
            if len(alt) > kontext:
                alt = alt[:kontext].rsplit("\n", 1)[0] + "\n…"
            z += ["Bisheriger Inhalt (verbessern, nicht wiederholen):", "```", alt, "```"]
        meldungen = [d for d in (pruefung or {}).get("diagnosen", []) if d.get("baustein") == e["id"] and d["stufe"] == "fehler"]
        for d in meldungen:
            z.append("Die Prüfung meldet" + (f" in Zeile {d['zeile_im_baustein']}" if d.get("zeile_im_baustein") else "")
                     + f": {d['text'].rstrip('. ')}.")
    if any(e["typ"] == AUTO for e in liste):
        z += [p["automatisch"]] + [f"- {t}: {_kat()['automatisch']['typen'][t]}" for t in M.auto_typen(alle, bevorzugt(mappe, angaben))]
    z += ["- " + r for r in zaehlregeln(liste, typen, uebung=False, jahrgang=jahrgang)]
    z.append("")
    k = _kat()
    z.append("Format")
    z += ["- " + k["gemeinsam"]["regeln"][0], "- " + k["gemeinsam"]["regeln"][1]]
    if set(typen) & _TEXTTYPEN:
        z.append("- " + p["textbausteine"])
    if set(typen) & _FRAGETYPEN:
        z.append("- " + p["fragen"])
    if "Test" in typen:
        z.append("- " + p["fragen_test"])
    for e in k["typen"]:
        if e["typ"] in typen:
            z += ["```"] + _beispiel(e) + ["```"] + _regeln(e)
    z.append("")
    z.append(("Ausgabe: nur " + ("dieser Baustein" if len(liste) == 1 else "diese Bausteine")
              + (" als ein Codeblock" if ch.get("codeblock", True) else " als reiner Text")
              + ", ohne Text davor oder danach; in der Zeile unter der Überschrift `id:` genau wie oben."))
    return "\n".join(z) + "\n"


# ---------------------------------------------------------------- Korrekturbitte
# Meldung der Prüfung -> Satz aus `prompt.korrektursaetze` (AP13.4 §2). Reihenfolge zählt: das erste Muster gewinnt.
_SAETZE = [
    (r"^Zone „(?P<wert>[^“]*)“ nicht in zonen \((?P<zonen>.*)\)$", "zone"),
    (r"^Zuordnen: nur eine Liste", "zuordnen_liste"),
    (r"^Zuordnen: `zonen", "zonen_fehlt"),
    (r"^(?:Quiz|Test) ohne Fragen$|^Zuordnen ohne Elemente$|^Lernkarten ohne Karten$|^Umfrage ohne Fragen$", "leer"),
    (r"^(?:Quiz|Test): jede Frage beginnt mit", "frage_anfang"),
    (r"^MC ohne ✔|^MC: keine Antwort mit ✔", "mc_haken"),
    (r"^MC: mindestens zwei Antworten", "mc_zwei"),
    (r"^RF: Aussage mit ✔", "rf_haken"),
    (r"^RF: Rückmeldung", "rf_rueck"),
    (r"^(?:Einsetzen|Markieren|Lückentext): Text mit \*", "luecken"),
    (r"^Lückentext: `aufgabe", "lueckentext_aufgabe"),
    (r"^unbekannter Elementtyp „(?P<wert>[^“]*)“", "typ"),
    (r"^unbekannte Angabe „(?P<wert>[^“]*)“ \(erlaubt: (?P<erlaubt>.*)\)$", "angabe"),
    (r"^website am Element", "website"),
    (r"ohne Inhalt – Inhalt um zwei", "kasten_leer"),
    (r"^Nur (?P<ist>\d+) (?P<einheit_ist>\S+), nötig sind mindestens (?P<soll>\d+)", "mindest"),
    (r"keinen Merksatz", "heft_merke"),
    (r"keine fett gesetzten", "heft_fett"),
    (r"^Lernkarten?: ", "lernkarte"),
]
_SAETZE = [(re.compile(m), k) for m, k in _SAETZE]
_MEHRZAHL = {"Frage": "Fragen", "Paar": "Paare", "Lücke": "Lücken", "Karte": "Karten", "Wort": "Wörter"}
_EINZAHL = {v: k for k, v in _MEHRZAHL.items()}
# Wörter, die nur die Kursdatei-Doku erklärt: im Satz an den Chat nie außerhalb von `…` (test_check.py prüft das)
SPERRLISTE = ("zonen", "Parser", "Element", "Schlüssel", "Feld", "ungültig")
_ERSATZ = [(r"\bElement(?:e|en)?\b", "Eintrag"), (r"\bzonen\b", "Gruppen"), (r"\bParser\b", "Kursmühle"),
           (r"\bSchlüssel\b", "Kennung"), (r"\bFeld\b", "Zeile"), (r"\bungültig\b", "nicht lesbar")]


def _klartext(text):
    """Meldung des Parsers ohne Wörter der Sperrliste (außerhalb von `…`)."""
    teile = text.split("`")
    for i in range(0, len(teile), 2):
        for muster, ersatz in _ERSATZ:
            teile[i] = re.sub(muster, ersatz, teile[i], flags=re.I if muster.endswith("zonen\\b") else 0)
    return "`".join(teile)


def _zitat(b, d):
    zeilen = (b or {}).get("text", "").splitlines()
    n = d.get("zeile_im_baustein")
    z = zeilen[n - 1].strip() if n and 0 < n <= len(zeilen) else ""
    return z[:59] + "…" if len(z) > 60 else z


def _was(d, b):
    """Satz aus `korrektursaetze` für eine Meldung an einem Baustein."""
    saetze = _kat()["prompt"]["korrektursaetze"]
    text = d["text"].rstrip(". ")
    werte = {"typ": (b or {}).get("typ") or "diesen Typ", "titel": d.get("titel") or (b or {}).get("titel") or "",
             "z": d.get("zeile_im_baustein") or "", "zitat": _zitat(b, d), "text": _klartext(text)}
    for muster, kennung in _SAETZE:
        m = muster.search(text)
        if not m:
            continue
        werte.update({k: v for k, v in m.groupdict().items() if v is not None})
        if kennung == "zone":
            zonen = [z.strip() for z in werte["zonen"].split(",") if z.strip()]
            werte["zonen"] = ", ".join(zonen)
            werte["oder"] = " oder ".join([", ".join(zonen[:-1]), zonen[-1]]) if len(zonen) > 1 else zonen[0]
            werte["n"] = sum(1 for z in (b or {}).get("text", "").splitlines() if z.strip().startswith("- ") and "→" in z) or "alle"
        if kennung == "mindest":
            ist, soll = int(werte["ist"]), int(werte["soll"])
            mehr = _MEHRZAHL.get(werte["einheit_ist"], werte["einheit_ist"])
            werte["einheit_ist"] = _EINZAHL.get(mehr, mehr) if ist == 1 else mehr
            werte["fehlt"] = soll - ist
            werte["einheit_fehlt"] = _EINZAHL.get(mehr, mehr) if soll - ist == 1 else mehr
        if kennung in ("frage_anfang", "mc_haken", "mc_zwei", "rf_haken", "rf_rueck", "luecken", "kasten_leer",
                       "zuordnen_liste", "lernkarte") and not werte["zitat"]:
            break                            # ohne Zeile lieber der allgemeine Satz
        return saetze[kennung].format(**werte)
    return saetze["sonst"].format(**werte)


def korrektur(pruefung):
    """Je Fehler ein Satz an den Chat (AP13.4 §2): Baustein und `id:`, was falsch ist, wie es richtig aussieht, mit dem
    Beispiel aus der Antwort, und ein Satz im Imperativ; Fehler außerhalb eines Bausteins bitten um die ganze Kursdatei.
    Eine Prüfregel mit eigenem Satz gibt ihn als `bitte` mit. -> [{baustein, titel, satz, regel}]"""
    p = _kat()["prompt"]
    bausteine = {b["id"]: b for b in (pruefung or {}).get("bausteine", [])}
    out = []
    for d in (pruefung or {}).get("diagnosen", []):
        if d.get("stufe") != "fehler":
            continue
        b = bausteine.get(d.get("baustein"))
        if d.get("bitte"):
            satz = d["bitte"]
        elif d.get("baustein"):
            satz = p["korrektur"].format(titel=d.get("titel") or (b or {}).get("titel", ""), id=d["baustein"],
                                         was=_was(d, b).rstrip() + ("" if _was(d, b).rstrip().endswith(".") else "."))
        else:
            from . import api as _api
            text = next((t for m, t in _api._DIAGNOSE_TEXT if m.search(d["text"])), None)
            was = (text[0].upper() + text[1:] + ".") if text else _klartext(d["text"].rstrip(". ")) + "."
            satz = p["korrektur_ohne"].format(zeile=f" (Zeile {d['zeile']})" if d.get("zeile") else "", was=was)
        out.append({"baustein": d.get("baustein"), "titel": d.get("titel"), "satz": satz, "regel": api.regel(d)})
    return out


# ---------------------------------------------------------------- Antwort ohne Bausteine (AP13.4)
def diagnose(text):
    """Karte unter dem Einfügefeld, wenn die Antwort keinen Baustein ergab: die ersten drei Meldungen aus
    `api.diagnose` und derselbe Inhalt als Satz für den Chat. -> {leer, meldungen, tipp, satz}"""
    d = api.diagnose(text, pr=M.antwort(text))
    if d["leer"]:
        return dict(d, satz="")
    teile = [f"Zeile {m['zeile']}" + (f" („{m['zitat']}“)" if m["zitat"] else "") + f": {m['text']}"
             for m in d["meldungen"]]
    return dict(d, satz=_kat()["prompt"]["diagnose"].format(meldungen="; ".join(teile) or "kein Baustein erkannt"))


# ---------------------------------------------------------------- Fragen und Lösungen, Fachcheck
_RE_ART = re.compile(r"^(?:\d+\.\s+)?(MC|RF|Kurzantwort|Einsetzen|Markieren|Lückentext|Schnellquiz|Aussagen)"
                     r"(?:\s*\([^)]*\))?:\s*(.*)$")
_RE_NUM = re.compile(r"^\d+\.\s+(.*)$")
_RE_STERN = re.compile(r"(?<!\*)\*(?!\*)([^*\n]+?)(?<!\*)\*(?!\*)")


def _sauber(t):
    t = re.sub(r"<br\s*/?>", " ", t)
    t = re.sub(r"<[^<>]*>", "", t)
    t = t.replace("**", "").replace("==", "")
    return " ".join(t.split())


def _option(o):
    o = o.split(" → ")[0].strip()
    richtig = o.startswith("✔")
    return richtig, _sauber(o.lstrip("✔").strip())


def _luecken(zeilen):
    """Text mit *Lücken*: (Text mit ___, Lösungen je Lücke als Liste der Alternativen)."""
    loes, text = [], []
    for z in zeilen:
        z = re.sub(r"\*\*([^*]+)\*\*", r"\1", z)

        def ersetze(m):
            teile = m.group(1).split(":")[0].split("/")
            loes.append([t.strip() for t in teile if t.strip()])
            return "___"
        text.append(_RE_STERN.sub(ersetze, z))
    return _sauber(" ".join(text)), loes


_RE_KASTEN = re.compile(r"^(?:Hinweis|Merke|Beispiel|Kasten|Bild):")


def _ohne_kaesten(zeilen):
    """Zeilen einer Übung ohne Kästen und Bilder: ein Hinweis nennt oft je Lücke das falsche Wort und verrät so die
    Lösung. Ein Kasten reicht über die eingerückten Zeilen, ohne Einrückung bis zur Leerzeile; Merke und Bild sind
    einzeilig."""
    out, i = [], 0
    while i < len(zeilen):
        if not _RE_KASTEN.match(zeilen[i]):
            out.append(zeilen[i])
            i += 1
            continue
        einzeilig = zeilen[i].startswith(("Merke:", "Bild:"))
        i += 1
        eingerueckt = i < len(zeilen) and zeilen[i].startswith("  ")
        while not einzeilig and i < len(zeilen) and zeilen[i].strip() and (zeilen[i].startswith("  ") or not eingerueckt) \
                and not _RE_ART.match(zeilen[i].strip()) and not zeilen[i].startswith("- "):
            i += 1
    return out


def _fragen_baustein(b):
    typ, out = b.get("typ"), []
    zeilen = _ohne_kaesten((b.get("text") or "").splitlines()[1:])
    def angabe(name):
        m = next((re.match(rf"^{name}:\s*(.+)$", z) for z in zeilen if z.startswith(name + ":")), None)
        return m.group(1).strip() if m else ""
    if typ == "Zuordnen":
        zonen = [z.strip() for z in angabe("zonen").split("|") if z.strip()]
        for z in zeilen:
            if z.startswith("- "):
                teil = z[2:].rsplit(" → ", 1)          # der letzte Pfeil trennt die Zone (AP13.3)
                out.append({"art": "zuordnen", "frage": _sauber(teil[0]), "optionen": zonen + ["keine"],
                            "loesung": [[_sauber(teil[1]) if len(teil) > 1 else "keine"]]})
        return out
    if typ == "Lückentext":
        aufgabe = angabe("aufgabe")
        text = [z for z in zeilen if z.strip() and not re.match(r"^[a-zäöüß ]+:\s", z)]
        t, loes = _luecken(text)
        if loes:
            out.append({"art": "luecken", "frage": (aufgabe + " " if aufgabe else "") + t, "optionen": [], "loesung": loes})
        return out
    if typ not in _FRAGETYPEN:
        return out
    aktuell, gruppe = None, None

    def abschliessen():
        if aktuell and aktuell["art"] == "luecken":
            t, loes = _luecken(aktuell.pop("_text"))
            if loes:
                aktuell["frage"] = (aktuell["frage"] + " " + t).strip()
                aktuell["loesung"] = loes
                out.append(aktuell)
        elif aktuell and aktuell["art"] == "auswahl" and aktuell["optionen"]:
            out.append(aktuell)

    for roh in zeilen:
        z = roh.strip()
        m = _RE_ART.match(z)
        num = _RE_NUM.match(z)
        if m or (num and " · " in z and "✔" in z) or z.startswith(("Seite:", "Kapitel:")):
            abschliessen()
            aktuell, gruppe = None, None
            if not m and num:
                m = re.match(r"^()(.*)$", num.group(1))
                art = "MC"
            elif m:
                art = m.group(1)
            else:
                continue
            rest = m.group(2).strip()
            if art == "MC":
                if " · " in rest:
                    teile = rest.split(" · ")
                    opts = [_option(o) for o in teile[1:]]
                    out.append({"art": "auswahl", "frage": _sauber(teile[0]), "optionen": [o for _, o in opts],
                                "loesung": [[o] for r, o in opts if r], "mehrfach": sum(r for r, _ in opts) > 1})
                else:
                    aktuell = {"art": "auswahl", "frage": _sauber(rest), "optionen": [], "loesung": []}
            elif art == "RF":
                vor = re.split(r"[✔✘]", rest)[0]
                wert = "richtig" if "✔" in rest.split("→")[0] else "falsch"
                out.append({"art": "rf", "frage": _sauber(vor), "optionen": ["richtig", "falsch"], "loesung": [[wert]]})
            elif art == "Kurzantwort":
                teile = rest.split(" · ")
                out.append({"art": "kurz", "frage": _sauber(teile[0]), "optionen": [],
                            "loesung": [[_sauber(t) for t in teile[1:]]]})
            elif art in ("Einsetzen", "Markieren", "Lückentext"):
                aktuell = {"art": "luecken", "frage": _sauber(rest), "optionen": [], "loesung": [], "_text": []}
            else:
                gruppe = (art, _sauber(rest))
            continue
        if z.startswith("- ") and gruppe:
            teile = z[2:].split(" · ")
            if gruppe[0] == "Schnellquiz":
                opts = [_option(o) for o in teile[1:]]
                frage = _sauber(teile[0])
            else:
                opts = [_option(o) for o in teile]
                frage = gruppe[1] or "Welche Aussage stimmt?"
            out.append({"art": "auswahl", "frage": frage, "optionen": [o for _, o in opts],
                        "loesung": [[o] for r, o in opts if r], "mehrfach": False})
            continue
        if aktuell and aktuell["art"] == "auswahl" and z.startswith("- "):
            r, o = _option(z[2:])
            aktuell["optionen"].append(o)
            if r:
                aktuell["loesung"].append([o])
            aktuell["mehrfach"] = len(aktuell["loesung"]) > 1
            continue
        if aktuell and aktuell["art"] == "luecken" and z:
            aktuell["_text"].append(z)
            continue
        if z and aktuell and aktuell["art"] == "auswahl" and not aktuell["optionen"]:
            continue
        if z:
            abschliessen()
            aktuell = None
    abschliessen()
    return out


def fragen(pruefung):
    """Ansicht „Fragen und Lösungen“: je Frage Baustein, Art, Frage, Optionen und Lösung (Liste je Lücke mit
    Alternativen), ohne Rückmeldungen; nummeriert über die Einheit."""
    out = []
    for b in (pruefung or {}).get("bausteine", []):
        for f in _fragen_baustein(b):
            f.pop("_text", None)
            f.setdefault("mehrfach", False)
            out.append(dict(f, nr=len(out) + 1, baustein=b["id"], titel=b["titel"]))
    return out


_BUCHST = "ABCDEFGHIJ"


def fachcheck(pruefung, steckbrief=None):
    """Text für einen NEUEN Chat: alle Aufgaben der Einheit ohne Lösungen und ohne Rückmeldungen."""
    liste = fragen(pruefung)
    if not liste:
        return {"text": "", "fragen": 0}
    a = M.angaben_lesen(steckbrief or "")
    z = [_kat()["prompt"]["fachcheck"]]
    kopf = " · ".join(x for x in (a.get("fach"), a.get("schulart"),
                                  f"Jahrgangsstufe {a['jahrgang']}" if a.get("jahrgang") else "", a.get("thema")) if x)
    if kopf:
        z.append(kopf)
    z.append("")
    for f in liste:
        if f["art"] == "auswahl":
            z.append(f"{f['nr']}. {f['frage']}" + (" (mehrere richtig)" if f["mehrfach"] else ""))
            z += [f"   {_BUCHST[i]}) {o}" for i, o in enumerate(f["optionen"][:len(_BUCHST)])]
        elif f["art"] == "rf":
            z.append(f"{f['nr']}. Richtig oder falsch: {f['frage']}")
        elif f["art"] == "luecken":
            z.append(f"{f['nr']}. Lücken ({len(f['loesung'])}): {f['frage']}")
        elif f["art"] == "zuordnen":
            z.append(f"{f['nr']}. Ordne zu (Gruppen: {', '.join(f['optionen'])}): {f['frage']}")
        else:
            z.append(f"{f['nr']}. {f['frage']}")
    return {"text": "\n".join(z) + "\n", "fragen": len(liste)}


def _norm(t):
    t = str(t).lower().replace("^2", "²").replace("^3", "³").replace(",", ".")
    t = re.sub(r"[\s]+", " ", t).strip().strip(".;:")
    return t.replace(" ", "")


def _anzeige(f):
    if f["art"] == "auswahl":
        return ", ".join(_BUCHST[f["optionen"].index(l[0])] + ") " + l[0] for l in f["loesung"] if l[0] in f["optionen"])
    return "; ".join(l[0] if l else "" for l in f["loesung"])


def vergleich(pruefung, antwort):
    """Antwort des neuen Chats („3: B“) mechanisch mit den Lösungen der Kursdatei vergleichen; nur Abweichungen und
    fehlende Nummern zurück. -> {geprueft, abweichungen: [{nr, titel, baustein, frage, chat, kursdatei}], fehlend}"""
    liste = {f["nr"]: f for f in fragen(pruefung)}
    gesehen, abw = set(), []
    for z in (antwort or "").replace("\r", "").splitlines():
        m = re.match(r"^\s*[*#>\-\s]*(?:Aufgabe\s*)?(\d+)\s*[:.)\-–]\s*(.+?)\s*$", z)
        if not m or int(m.group(1)) not in liste:
            continue
        nr, wert = int(m.group(1)), m.group(2).replace("**", "").strip()
        f = liste[nr]
        gesehen.add(nr)
        if f["art"] == "auswahl":
            mb = re.match(r"^([A-J](?:\s*(?:,|;|und|&|\s)\s*[A-J])*)(?![A-Za-zäöü])", wert.strip().upper())
            chat_l = set(re.findall(r"[A-J]", mb.group(1))) if mb else set()
            soll = {_BUCHST[f["optionen"].index(l[0])] for l in f["loesung"] if l[0] in f["optionen"]}
            gleich = chat_l == soll
        elif f["art"] == "rf":
            w = wert.lower()
            chat_w = "falsch" if re.search(r"falsch|unwahr|false", w) else ("richtig" if re.search(r"richtig|wahr|true|stimmt", w) else "")
            gleich = chat_w == f["loesung"][0][0]
        elif f["art"] == "luecken":
            teile = [t for t in re.split(r"\s*;\s*", wert)]
            gleich = len(teile) == len(f["loesung"]) and all(_norm(t) in {_norm(x) for x in alt}
                                                              for t, alt in zip(teile, f["loesung"]))
        else:
            gleich = _norm(wert) in {_norm(x) for x in f["loesung"][0]}
        if not gleich:
            abw.append({"nr": nr, "titel": f["titel"], "baustein": f["baustein"], "frage": f["frage"], "chat": wert,
                        "kursdatei": _anzeige(f)})
    return {"geprueft": len(liste), "abweichungen": abw, "fehlend": sorted(set(liste) - gesehen)}
