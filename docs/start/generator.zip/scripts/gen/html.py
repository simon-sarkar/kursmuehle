"""HTML-Bausteine für Textfelder, Seiten und H5P-Textblöcke (inline-styled, filtersicher).

Nur CSS, das der Filter der ByCS-Lernplattform durchlässt (Tabellen, inline-block, Rahmen, Hintergründe; spec §K).
Das Theme zeichnet einen Rahmen um jede <td>, daher setzt jede Zelle ihren Rahmen explizit.
Der Parser (gen/kursdatei.py) ruft diese Funktionen auf; Python-Kursinhalte (Fallback) können sie direkt importieren.

Designfamilien (AP13.5): der Tokensatz D kommt aus gen/design.py (references/design/familien.yaml).
`set_design(familie, dichte=…, kasten=…)` schaltet um (api.py liest `design.familie` aus dem Steckbrief); alle
Bausteine lesen D beim Aufruf und schlagen ihre Form in D["formen"] nach (eine Funktion je Form, kein Zweig je
Familie). Standard ist „sachlich“, Emojis sind aus.
"""
import re

from . import design as DS

EMOJI = False   # aus steckbrief design.emoji_marker, gesetzt in api.py

D = {}
HUE = ""        # Standard-Akzentfarbe der Familie (kurs.md `farbe:` und Steckbrief überschreiben sie)
_N = {"h2": 0, "kasten": 0, "karte": 0}     # Zähler je Baustein: nummerierte Überschriften, Kästen im Farbwechsel


def set_design(familie=None, dichte=None, kasten=None):
    """Tokensatz umschalten. Unbekannte Familien sind ein Fehler (keine stille Rückfalllösung)."""
    global D, HUE
    D = DS.tokens(familie, None, dichte, kasten)
    HUE = D["akzent_standard"]
    _FARBE.clear()
    baustein_start()


def baustein_start():
    """Zähler zurücksetzen (Parser ruft es je Element)."""
    _N["h2"] = _N["kasten"] = _N["karte"] = 0


_FARBE = {}


def _a(hue):
    """Akzent, wie ihn die Familie zeigt (fest, unverändert oder auf 4,5:1 gezogen)."""
    hue = hue or HUE
    if hue not in _FARBE:
        _FARBE[hue] = DS.akzent_fuer(D, hue)
    return _FARBE[hue]


def _auf(hue):
    return DS.auf_akzent(D, hue)


def _zweit(hue):
    return DS.zweitfarbe(D, hue) or _tint(hue)


def _signal():
    """Feste Zweitfarbe der Familie (`zweitfarbe: "#RRGGBB"`) für Kicker und Titellinie, sonst None."""
    z = D["zweitfarbe"]
    return z if z.startswith("#") else None


TBL = 'style="width:100%;table-layout:fixed;border-collapse:separate;border-spacing:{sp};margin:{m};border:0"'


def _tint(hue, strength=None):
    """Helle Tönung der Akzentfarbe (Flächen hinter Text); bei dunklen Familien über dem dunklen Grund."""
    s = D["tint"] if strength is None else strength
    return DS.mische(hue, D["flaeche"], s)


def _r(key="r"):
    return f"{D[key]}px"


def _kopf():
    """Schrift der Überschriften, wenn sie von der Grundschrift abweicht (sonst setzt die Hülle sie)."""
    k = D["schrift_kopf"]
    return f"font-family:{k};" if k and k != D["schrift_grund"] else ""


def _lh(standard):
    return D["zeilenhoehe"] or standard


# „Ohne Vorlage“: nur semantisches HTML; Farben, Schriften, Flächen und farbige Rahmen fallen aus jedem style
_RE_STYLE = re.compile(r' style="([^"]*)"')
_WEG = {"color", "background", "background-color", "font-family", "box-shadow", "opacity", "font-variant"}


def _semantisch(html):
    def stil(m):
        bleibt = []
        for d in m.group(1).split(";"):
            prop, _, wert = d.partition(":")
            prop = prop.strip().lower()
            if not prop or prop in _WEG:
                continue
            if prop.startswith("border") and prop not in ("border-collapse", "border-spacing", "border-radius") \
                    and wert.strip() != "0":
                continue
            bleibt.append(d)
        return f' style="{";".join(bleibt)}"' if bleibt else ""
    return _RE_STYLE.sub(stil, html)


def _baustein(fn):
    def aufruf(*a, **k):
        html = fn(*a, **k)
        return _semantisch(html) if D.get("name") == "ohne" else html
    aufruf.__name__, aufruf.__doc__ = fn.__name__, fn.__doc__
    return aufruf


def huelle(html, eng=False):
    """Ein ganzer Baustein (Textfeld, Seite, Buchseite): Grundschrift, -größe und Zeilenhöhe der Familie und, wenn der
    Grund der Familie nicht weiß ist (dunkel, Papier), die Karte darum; eng (Banner): ohne Innenabstand, damit keine
    Karte in der Karte entsteht. Ohne solche Angaben (sachlich, freundlich, magazin) bleibt das HTML, wie es ist."""
    if not html:
        return html
    st = ""
    if D["schrift_grund"]:
        st += f"font-family:{D['schrift_grund']};"
    if D["grund_px"]:
        st += f"font-size:{D['grund_px']}px;"
    if D["zeilenhoehe"]:
        st += f"line-height:{D['zeilenhoehe']};"
    if D["grund_px"] >= 18:     # große Schrift: lange Wörter (Fehlercodes, Adressen) brechen statt überzulaufen
        st += "overflow-wrap:break-word;"
    if D["flaeche"].lower() not in ("#fff", "#ffffff"):
        st += (f"background:{D['flaeche']};color:{D['ink']};padding:{'0' if eng else '18px 22px'};"
               f"border-radius:{_r('r_lg')};border:1px solid {D['line']}")
    if D.get("name") == "ohne" or not st:
        return html
    return f'<div style="{st.rstrip(";")}">{html}</div>'


# ---------------------------------------------------------------- Textbausteine
@_baustein
def h2(text, hue=None):
    """Zwischenüberschrift im Lesetext."""
    hue = _a(hue)
    form = D["formen"]["h2"]
    size, lh, margin, extra = D["h2"], "1.25", "22px 0 8px 0", ""
    match form:
        case "linie":
            extra = f'border-bottom:1px solid {D["line"]};padding-bottom:4px;'
        case "balken":
            extra = f'border-bottom:3px solid {D["ink"]};padding-bottom:4px;'
        case "punktiert":
            extra = f'border-bottom:2px dotted {D["line_card"]};padding-bottom:6px;'
        case "flaeche":
            extra = f'background:{_tint(hue)};padding:8px 16px;border-radius:{_r("r_lg")};'
        case "nummeriert":
            _N["h2"] += 1
            text = f'{_N["h2"]}.&nbsp;{text}'
        case "gross":
            lh, margin = "1.1", "30px 0 10px 0"
        case "unterstrichen":
            extra = f'display:inline-block;border-bottom:4px solid {_zweit(hue)};padding-bottom:2px;'
    return (f'<h3 style="font-size:{size};font-weight:700;color:{D["ink"]};line-height:{lh};'
            f'margin:{margin};{_kopf()}{extra}">{text}</h3>')


@_baustein
def img(name, alt="", caption=None, radius=None):
    """Bild in voller Breite, optional mit Unterschrift."""
    r = D["r"] if radius is None else radius
    pic = (f'<img src="@@PLUGINFILE@@/{name}" alt="{alt}" '
           f'style="width:100%;height:auto;border-radius:{r}px;display:block">')
    if not caption:
        return f'<p>{pic}</p>'
    return (f'<p style="margin:12px 0">{pic}'
            f'<span style="display:block;color:{D["muted"]};font-size:.92em;line-height:1.4;margin-top:6px">{caption}</span></p>')


@_baustein
def img_row(name, alt, html):
    """Bild und Text, eine Zeile pro Begriff; Anordnung nach formen.bildzeile: links (Bild 140 px links, Text rechts),
    rechts, oben (Bild über dem Text, bis 200 px breit), klein (Bild 90 px, Text kompakt daneben)."""
    def bild(w):
        return (f'<img src="@@PLUGINFILE@@/{name}" alt="{alt}" style="width:{w};height:auto;'
                f'border-radius:{_r("r_sm")};display:block">')
    match D["formen"]["bildzeile"]:
        case "oben":
            return (f'<div style="margin:6px 0 18px 0">{bild("100%;max-width:200px")}'
                    f'<div style="line-height:1.5;margin-top:8px">{html}</div></div>')
        case "rechts":
            return (f'<table style="width:100%;border-collapse:separate;border-spacing:0;margin:0 0 10px 0;border:0"><tr>'
                    f'<td style="border:0;vertical-align:middle;line-height:1.5">{html}</td>'
                    f'<td style="border:0;width:150px;padding:0 0 0 16px;vertical-align:middle">{bild("140px")}</td>'
                    f'</tr></table>')
        case "klein":
            return (f'<table style="width:100%;border-collapse:separate;border-spacing:0;margin:0 0 6px 0;border:0"><tr>'
                    f'<td style="border:0;width:98px;padding:0 12px 0 0;vertical-align:top">{bild("90px")}</td>'
                    f'<td style="border:0;vertical-align:top;line-height:1.4;font-size:.95em">{html}</td></tr></table>')
    return (f'<table style="width:100%;border-collapse:separate;border-spacing:0;margin:0 0 10px 0;border:0"><tr>'
            f'<td style="border:0;width:150px;padding:0 16px 0 0;vertical-align:middle">'
            f'<img src="@@PLUGINFILE@@/{name}" alt="{alt}" style="width:140px;height:auto;border-radius:{_r("r_sm")};display:block"></td>'
            f'<td style="border:0;vertical-align:middle;line-height:1.5">{html}</td></tr></table>')


@_baustein
def lead(text):
    return f'<p style="font-size:{D["lead"]};line-height:1.5;color:{D["ink"]};margin:14px 0 6px 0">{text}</p>'


@_baustein
def p(text):
    return f'<p style="line-height:{_lh(1.55)};margin:8px 0">{text}</p>'


@_baustein
def highlight(text, hue=None):
    """Hervorgehobener Satz (Kernaussage) – Akzentlinie links, getönt, ohne Titel."""
    hue = _a(hue)
    return (f'<p style="border-left:4px solid {hue};background:{_tint(hue)};padding:10px 16px;margin:14px 0;'
            f'border-radius:0 {_r("r_sm")} {_r("r_sm")} 0;font-size:1.05em;line-height:1.5;color:{D["ink"]}">{text}</p>')


@_baustein
def mark(text, hue=None):
    """Inline-Hervorhebung (==so==)."""
    return f'<span style="background:{_tint(_a(hue), 0.18)};padding:0 .25em;border-radius:3px">{text}</span>'


def _kasten_rahmen(hue, bg):
    """Rahmen und Fläche eines Kastens nach formen.kasten -> (style, titelfarbe)."""
    r = _r()
    match D["formen"]["kasten"]:
        case "linie_oben":
            return f'border-top:3px solid {hue};border-bottom:1px solid {D["line"]};background:{bg};', hue
        case "flaeche":
            if D["zweitfarbe"] == "pastell" and _N["kasten"] % 2:
                return f'background:{_zweit(hue)};border-radius:{r};', D["ink"]
            return f'background:{bg};border-radius:{r};', hue
        case "gestrichelt":
            z = _zweit(hue)
            return (f'border:2px dashed {hue};border-right:6px solid {z};border-bottom:6px solid {z};'
                    f'background:{D["flaeche_alt"]};border-radius:{r};'), hue
        case "haarlinie":
            return f'border-top:1px solid {D["line"]};border-bottom:1px solid {D["line"]};', hue
        case "offen":
            return '', hue
        case "einzug":
            return f'border-left:1px solid {D["ink"]};', D["ink"]
        case "papier":
            return (f'background:{D["flaeche_alt"]};border:1px solid {D["line"]};border-left:5px solid {D["line_card"]};'
                    f'border-radius:{r};'), hue
        case "rahmen":
            return f'border:1px solid {D["line_card"]};border-radius:{r};', D["ink"]
        case "rahmen_dick":
            return f'border:2px solid {D["ink"]};border-radius:{r};', D["ink"]
        case "links":
            return f'border-left:3px solid {hue};', hue
    return f'border-left:5px solid {hue};background:{bg};border-radius:0 {r} {r} 0;', hue


@_baustein
def box(title, html, hue=None, bg=None):
    hue = _a(hue)
    if D["formen"]["kasten"] == "zitat":
        return f'<blockquote style="margin:16px 0"><p><strong>{title}</strong></p>{html}</blockquote>'
    bg = bg or _tint(hue)
    frame, farbe = _kasten_rahmen(hue, bg)
    _N["kasten"] += 1
    kopf = _kopf()
    if D["formen"]["kasten"] == "offen":
        kopf = "font-size:.78em;letter-spacing:.14em;text-transform:uppercase;" + kopf
    return (f'<div style="{frame}padding:{D["pad"]};margin:16px 0">'
            f'<div style="font-weight:700;color:{farbe};margin-bottom:6px{";" + kopf.rstrip(";") if kopf else ""}">'
            f'{title}</div>{html}</div>')


@_baustein
def steps(items, hue=None):
    lis = "".join(
        f'<li style="margin:8px 0;padding-left:6px;line-height:1.5">{it}</li>' for it in items)
    return f'<ol style="padding-left:26px;margin:10px 0">{lis}</ol>'


def _nummer(i, hue):
    """Nummer eines Schritts nach formen.nummer -> (html, spaltenbreite)."""
    auf = _auf(hue)
    match D["formen"]["nummer"]:
        case "kreis" | "quadrat":
            r = "0" if D["formen"]["nummer"] == "quadrat" else "999px"
            return (f'<span style="display:inline-block;width:28px;height:28px;line-height:28px;text-align:center;'
                    f'border-radius:{r};background:{hue};color:{auf};font-weight:700">{i}</span>'), 40
        case "kreis_gross":
            return (f'<span style="display:inline-block;width:36px;height:36px;line-height:36px;text-align:center;'
                    f'border-radius:999px;background:{hue};color:{auf};font-weight:800;font-size:1.1em">{i}</span>'), 50
        case "sticker":
            return (f'<span style="display:inline-block;width:32px;height:32px;line-height:26px;text-align:center;'
                    f'border-radius:999px;background:{D["flaeche"]};border:3px solid {hue};color:{D["ink"]};'
                    f'font-weight:800">{i}</span>'), 46
        case "zahl":
            return f'<span style="font-weight:800;color:{hue};font-size:1.25em;line-height:1">{i}</span>', 34
        case "klammer":
            return f'<span style="font-weight:700;color:{hue}">{i})</span>', 34
        case "eckig":
            return (f'<span style="display:inline-block;width:28px;height:28px;line-height:28px;text-align:center;'
                    f'background:{D["ink"]};color:{_auf(D["ink"])};font-weight:700">{i}</span>'), 40
        case "kreis_ton":
            ton = D["line_card"]
            return (f'<span style="display:inline-block;width:28px;height:28px;line-height:28px;text-align:center;'
                    f'border-radius:999px;background:{ton};color:{_auf(ton)};font-weight:700">{i}</span>'), 40
    return f'{i}.', 30


@_baustein
def schritte(items, hue=None, title=""):
    """Schritt-für-Schritt-Anleitung: Nummer im Kreis links, Schritt rechts."""
    hue = _a(hue)
    head = f'<div style="font-weight:700;color:{D["ink"]};margin:14px 0 4px 0">{title}</div>' if title else ''
    if D["formen"]["nummer"] == "liste":
        return head + steps(items)
    trs = []
    for i, it in enumerate(items, 1):
        num, w = _nummer(i, hue)
        trs.append(f'<tr><td style="border:0;width:{w}px;padding:6px 10px 6px 0;vertical-align:top">{num}</td>'
                   f'<td style="border:0;border-bottom:1px solid {D["line"]};padding:8px 0 10px 0;line-height:1.5;vertical-align:top">{it}</td></tr>')
    return head + f'<table style="width:100%;border-collapse:collapse;margin:6px 0 14px 0;border:0">{"".join(trs)}</table>'


@_baustein
def bullets(items):
    lis = "".join(f'<li style="margin:6px 0;line-height:1.5">{it}</li>' for it in items)
    return f'<ul style="padding-left:22px;margin:10px 0">{lis}</ul>'


def _chip_form(text, hue, filled, r, pad, size, margin):
    """Ein Chip nach formen.chip; r, pad, size, margin sind die Maße der Stelle (Liste oder Karte)."""
    match D["formen"]["chip"]:
        case "pille_dick":
            farbe = f"background:{hue};color:{_auf(hue)};" if filled else f"color:{D['ink']};"
            return (f'<span style="display:inline-block;border:3px solid {hue};{farbe}'
                    f'border-radius:999px;padding:4px 14px;margin:{margin};font-size:{size};font-weight:700">{text}</span>')
        case "sticker":
            bg = hue if filled else _tint(hue)
            return (f'<span style="display:inline-block;background:{bg};border:2px solid {D["ink"]};'
                    f'color:{_auf(hue) if filled else D["ink"]};border-radius:999px;padding:3px 12px;margin:{margin};'
                    f'font-size:{size};font-weight:700">{text}</span>')
        case "punkt":
            return (f'<span style="display:inline-block;margin:{margin.replace(" 6px ", " 14px ")};font-size:{size};'
                    f'font-weight:{700 if filled else 600};color:{D["ink"]}"><span style="color:{hue}">●</span> {text}</span>')
        case "klammer" | "eckklammer":
            a, b = ("(", ")") if D["formen"]["chip"] == "klammer" else ("[", "]")
            return (f'<span style="display:inline-block;margin:{margin.replace(" 6px ", " 12px ")};font-size:{size};'
                    f'font-weight:{700 if filled else 400};color:{D["ink"]}">{a}{text}{b}</span>')
        case "papier":
            return (f'<span style="display:inline-block;background:{hue if filled else D["flaeche_alt"]};'
                    f'border:1px solid {D["line_card"]};color:{_auf(hue) if filled else D["ink"]};'
                    f'border-radius:{_r("r_sm")};padding:{pad};margin:{margin};font-size:{size};font-weight:600">{text}</span>')
        case "text":
            return f'<span style="margin:{margin}">{f"<strong>{text}</strong>" if filled else text}</span>'
    if filled:
        return (f'<span style="display:inline-block;background:{hue};color:{_auf(hue)};border-radius:{r};'
                f'padding:{pad.replace("2px", "3px", 1)};margin:{margin};font-size:{size};font-weight:600">{text}</span>')
    return (f'<span style="display:inline-block;border:1.5px solid {hue};color:{hue};border-radius:{r};'
            f'padding:{pad};margin:{margin};font-size:{size};font-weight:600">{text}</span>')


@_baustein
def chips(items, hue=None):
    hue = _a(hue)
    return "".join(_chip_form(it, hue, False, "999px", "3px 12px", ".92em", "4px 6px 4px 0") for it in items)


@_baustein
def two_col(left_title, left_html, right_title, right_html, hue_l="#BE123C", hue_r="#15803D"):
    hue_l, hue_r = _a(hue_l), _a(hue_r)
    cell = ('<td style="border:0;vertical-align:top;width:50%;padding:12px 14px;border-radius:{r};'
            'background:{bg};border-top:5px solid {hue}"><div style="font-weight:700;color:{hue};'
            'margin-bottom:6px">{t}</div>{h}</td>')
    return ('<table style="width:100%;border-spacing:10px 0;margin:14px -10px;border-collapse:separate;border:0"><tr>'
            + cell.format(bg=_tint(hue_l), hue=hue_l, t=left_title, h=left_html, r=_r())
            + cell.format(bg=_tint(hue_r), hue=hue_r, t=right_title, h=right_html, r=_r())
            + '</tr></table>')


@_baustein
def kv(rows, hue=None):
    """Zweispaltig: Begriff (farbig) | Erklärung."""
    hue = _a(hue)
    trs = "".join(
        f'<tr><td style="border:0;border-bottom:1px solid {D["line"]};padding:8px 12px;font-weight:700;color:{hue};'
        f'white-space:nowrap;vertical-align:top">{k}</td>'
        f'<td style="border:0;border-bottom:1px solid {D["line"]};padding:8px 12px;line-height:1.5">{v}</td></tr>'
        for k, v in rows)
    return f'<table style="width:100%;border-collapse:collapse;margin:12px 0;border:0">{trs}</table>'


@_baustein
def table(header, rows, hue=None):
    """Vergleichstabelle mit Kopfzeile und beliebig vielen Spalten; erste Spalte fett."""
    hue = _a(hue)
    th = "".join(
        f'<td style="border:0;border-bottom:2px solid {hue};padding:8px 8px 8px 0;font-weight:700;color:{hue};'
        f'vertical-align:bottom;line-height:1.3">{h}</td>' for h in header)
    trs = []
    for r in rows:
        tds = "".join(
            f'<td style="border:0;border-bottom:1px solid {D["line"]};padding:8px 8px 8px 0;line-height:1.45;vertical-align:top;'
            f'{"font-weight:700;color:" + D["ink"] if i == 0 else ""}">{c}</td>' for i, c in enumerate(r))
        trs.append(f'<tr>{tds}</tr>')
    # Spaltenbreite nach Inhalt (kein table-layout:fixed), damit vier Spalten auch auf dem Handy lesbar bleiben
    return (f'<table style="width:100%;border-collapse:collapse;margin:12px 0;border:0;font-size:.97em">'
            f'<tr>{th}</tr>{"".join(trs)}</table>')


@_baustein
def merk(text, hue=None):
    hue = _a(hue)
    label = (f'<span style="font-weight:700;letter-spacing:.08em;font-size:.8em;text-transform:uppercase;'
             f'opacity:.85">Merk dir</span><br>')
    farbig = label.replace("opacity:.85", f"color:{hue}")
    pad = D["pad"]
    match D["formen"]["merk"]:
        case "rahmen":
            return (f'<div style="border:2px solid {hue};color:{D["ink"]};padding:{pad};margin:18px 0;'
                    f'font-size:1.08em;line-height:1.5">{farbig}{text}</div>')
        case "rand_dick":
            bg, lab = D["flaeche_alt"], farbig
            return (f'<div style="border:3px solid {hue};background:{bg};color:{D["ink"]};'
                    f'border-radius:{_r()};padding:{pad};margin:20px 0;font-size:1.2em;line-height:1.5">{lab}{text}</div>')
        case "balken":
            return (f'<div style="border-left:2px solid {hue};color:{D["ink"]};padding:4px 0 4px 18px;margin:22px 0;'
                    f'font-size:1.12em;line-height:1.5">{farbig}{text}</div>')
        case "einzug":
            return (f'<div style="border-left:1px solid {D["ink"]};color:{D["ink"]};'
                    f'padding:2px 18px;margin:20px 0;font-size:1.08em;line-height:1.55">'
                    f'{_kicker("Merke", hue).replace("margin:12px 0 8px 0", "margin:0 0 4px 0")}{text}</div>')
        case "doppelt":
            bg = f"background:{_zweit(hue) if D['zweitfarbe'] == 'pastell' else D['flaeche_alt']};"
            return (f'<div style="border:4px double {D["line_card"]};{bg}color:{D["ink"]};border-radius:{_r("r_sm")};'
                    f'padding:{pad};margin:18px 0;font-size:1.08em;line-height:1.5">'
                    f'{label.replace("opacity:.85", "color:" + D["ink"])}{text}</div>')
        case "gestrichelt":
            return (f'<div style="border:2px dashed {hue};background:{_tint(hue)};color:{D["ink"]};'
                    f'border-radius:{_r()};padding:{pad};margin:18px 0;font-size:1.1em;line-height:1.5">{farbig}{text}</div>')
        case "zitat":
            return f'<blockquote style="margin:18px 0"><p><strong>Merk dir</strong><br>{text}</p></blockquote>'
        case "toenung":
            return (f'<div style="background:{_tint(hue)};color:{D["ink"]};border-radius:{_r("r_lg")};padding:{pad};'
                    f'margin:18px 0;font-size:1.08em;line-height:1.5"><span style="font-weight:700;color:{hue}">'
                    f'Merk dir</span><br>{text}</div>')
    auf = _auf(hue)
    return (f'<div style="background:{hue};color:{auf};border-radius:{_r()};padding:16px 20px;margin:18px 0;'
            f'font-size:1.08em;line-height:1.5">{label}{text}</div>')


@_baustein
def meta_line(parts, hue=None):
    hue = _a(hue)
    return (f'<p style="color:{D["muted"]};font-size:.95em;margin:6px 0 14px 0">'
            + f' <span style="color:{hue};font-weight:700">·</span> '.join(parts) + '</p>')


@_baustein
def banner(title, subtitle="", image=None, alt="", hue=None):
    """Kursbanner: großes Bild (optional) + Titel + ein Satz. Erstes Element in Abschnitt 0.
    Ohne Bild ein Block in Akzentfarbe (oder mit Linie, Rahmen), damit der Kurs auch vor der Bildlieferung fertig
    aussieht."""
    hue = _a(hue)
    form = D["formen"]["banner"]
    if form == "schlicht":
        pic = (f'<p><img src="@@PLUGINFILE@@/{image}" alt="{alt or title}" style="width:100%;height:auto;display:block">'
               f'</p>') if image else ''
        return pic + f'<h2>{title}</h2>' + (f'<p>{subtitle}</p>' if subtitle else '')
    if D["formen"]["titel"] != "block":
        return _titel(form, title, subtitle, image, alt, hue)
    sub = f'<div style="font-size:1.05em;margin-top:6px;line-height:1.45;color:{{c}}">{subtitle}</div>' if subtitle else ''
    r = _r("r_lg")
    kopf = _kopf()
    titel = (f'<div style="font-size:1.6em;font-weight:800;color:{D["ink"]};line-height:1.15{";" + kopf.rstrip(";") if kopf else ""}">'
             f'{title}</div>')
    if form in ("rund", "sticker"):
        z = _zweit(hue)
        if form == "rund":
            bild_st, zelle = f'border-radius:{r}', f'background:{z};border-radius:{r};'
            farbe_t, farbe_s = D["ink"], D["ink"]
        else:
            bild_st = f'border-radius:{_r("r_sm")}'
            zelle = f'background:{_tint(hue)};border:3px solid {D["ink"]};border-radius:{r};'
            farbe_t, farbe_s = D["ink"], D["muted"]
        rahmen = ''
        pic = (f'<p style="margin:0 0 10px 0;{rahmen}"><img src="@@PLUGINFILE@@/{image}" alt="{alt or title}" '
               f'style="width:100%;height:auto;display:block;{bild_st}"></p>') if image else ''
        cell = (f'<td style="border:0;{zelle}padding:20px 24px;vertical-align:top">'
                f'<div style="font-size:1.35em;font-weight:800;color:{farbe_t};line-height:1.15'
                f'{";" + kopf.rstrip(";") if kopf else ""}">{title}</div>' + sub.format(c=farbe_s) + '</td>')
    elif form == "papier":
        pic = (f'<p style="margin:0;border:1px solid {D["line_card"]};border-bottom:0;padding:6px 6px 0 6px;'
               f'background:{D["flaeche_alt"]};border-radius:{r} {r} 0 0"><img src="@@PLUGINFILE@@/{image}" '
               f'alt="{alt or title}" style="width:100%;height:auto;display:block;border-radius:{_r("r_sm")}"></p>'
               ) if image else ''
        cell = (f'<td style="border:1px solid {D["line_card"]};{"border-top:0;" if image else ""}'
                f'background:{D["flaeche_alt"]};border-radius:{f"0 0 {r} {r}" if image else r};padding:16px 22px;'
                f'vertical-align:top">' + titel.replace(f"color:{D['ink']}", f"color:{D['line_card']}")
                .replace("font-size:1.6em", "font-size:1.75em")
                + sub.format(c=D["muted"]) + '</td>')
    elif image or form in ("offen", "rahmen", "buch"):
        pic = (f'<p style="margin:0"><img src="@@PLUGINFILE@@/{image}" alt="{alt or title}" '
               f'style="width:100%;height:auto;display:block;border-radius:{r} {r} 0 0"></p>') if image else ''
        match form:
            case "linie":
                frame = f'border-top:4px solid {hue};border-bottom:1px solid {D["line"]};'
            case "offen":
                frame = f'border-bottom:1px solid {D["line"]};'
            case "buch":
                frame = f'border-bottom:3px double {D["ink"]};text-align:center;'
            case "rahmen":
                frame = f'border:3px double {D["ink"]};{"border-top:0;" if image else ""}'
            case _:
                frame = f'border-left:6px solid {hue};background:{_tint(hue)};border-radius:0 0 {r} {r};'
        if form == "offen":
            titel = titel.replace("font-size:1.6em", "font-size:1.75em")
        if form == "offen" and image:
            pic = pic.replace(f"border-radius:{r} {r} 0 0", "border-radius:0")
        cell = (f'<td style="border:0;{frame}padding:18px 22px;vertical-align:top">' + titel
                + sub.format(c=D["muted"]) + '</td>')
    else:
        pic = ''
        auf = _auf(hue)
        cell = (f'<td style="border:0;background:{hue};border-radius:{r};padding:30px 28px;vertical-align:top">'
                f'<div style="font-size:1.7em;font-weight:800;color:{auf};line-height:1.15'
                f'{";" + kopf.rstrip(";") if kopf else ""}">{title}</div>'
                + sub.format(c="#E4EAF6" if auf == "#fff" and not D["korrektur"] else auf) + '</td>')
    return (pic + f'<table style="width:100%;border-collapse:separate;border-spacing:0;margin:0 0 16px 0;border:0">'
            f'<tr>{cell}</tr></table>')


def _titelkasten(form, hue):
    """Kasten des Bannertitels nach formen.banner (ueberlagert, vorangestellt) -> (style, titelfarbe, untertitelfarbe)."""
    r, ink, muted = _r("r_lg"), D["ink"], D["muted"]
    match form:
        case "rund":
            return f'background:{_zweit(hue)};border-radius:{r};', ink, ink
        case "sticker":
            return f'background:{_tint(hue)};border:3px solid {ink};border-radius:{r};', ink, muted
        case "papier":
            return (f'background:{D["flaeche_alt"]};border:1px solid {D["line_card"]};border-radius:{r};',
                    D["line_card"], muted)
        case "linie":
            return (f'background:{D["flaeche"]};border-top:4px solid {_signal() or hue};'
                    f'border-bottom:1px solid {D["line"]};'), ink, muted
        case "offen":
            return f'background:{D["flaeche"]};border-bottom:1px solid {D["line"]};', ink, muted
        case "buch":
            return f'background:{D["flaeche"]};border-bottom:3px double {ink};text-align:center;', ink, muted
        case "rahmen":
            return f'background:{D["flaeche"]};border:3px double {ink};', ink, muted
    return f'background:{_tint(hue)};border-left:6px solid {hue};border-radius:{r};', ink, muted


def _titelzeile(form, hue):
    """Linie unter dem Bannertitel ohne Kasten (titel: zeile) nach formen.banner."""
    match form:
        case "linie":
            return f'border-bottom:3px solid {_signal() or hue};padding-bottom:10px;'
        case "buch":
            return f'border-bottom:3px double {D["ink"]};padding-bottom:10px;text-align:center;'
        case "rahmen":
            return f'border-bottom:3px solid {D["ink"]};padding-bottom:8px;'
    return ''


def _titel(form, title, subtitle, image, alt, hue):
    """Banner nach formen.titel: zeile (Überschrift ohne Kasten unter dem Bild), ueberlagert (Kasten ragt 24 px ins
    Bild; inline-block, weil position im Filter nicht wirkt und ein Block unter dem Bild läge), vorangestellt (Kasten
    über dem Bild)."""
    r, kopf = _r("r_lg"), _kopf()
    kf = ";" + kopf.rstrip(";") if kopf else ""

    def pic(margin):
        return (f'<p style="margin:{margin}"><img src="@@PLUGINFILE@@/{image}" alt="{alt or title}" '
                f'style="width:100%;height:auto;display:block;border-radius:{r}"></p>') if image else ''
    banner_form = D["formen"]["banner"]
    if D["formen"]["titel"] == "zeile":
        sub = (f'<div style="font-size:1.1em;line-height:1.45;margin-top:6px;color:{D["muted"]}">{subtitle}</div>'
               if subtitle else '')
        return (pic("0 0 14px 0") + f'<div style="{_titelzeile(banner_form, hue)}margin:0 0 18px 0">'
                f'<div style="font-size:1.75em;font-weight:800;color:{D["ink"]};line-height:1.1{kf}">{title}</div>{sub}</div>')
    stil, ft, fs = _titelkasten(banner_form, hue)
    sub = (f'<div style="font-size:1.05em;margin-top:6px;line-height:1.45;color:{fs}">{subtitle}</div>'
           if subtitle else '')
    kasten = (f'<table style="width:100%;table-layout:fixed;border-collapse:separate;border-spacing:0;margin:0;border:0"><tr>'
              f'<td style="border:0;{stil}padding:16px 22px;vertical-align:top">'
              f'<div style="font-size:1.5em;font-weight:800;color:{ft};line-height:1.15{kf}">{title}</div>{sub}'
              f'</td></tr></table>')
    if D["formen"]["titel"] == "vorangestellt" or not image:
        return f'<div style="margin:0 0 {10 if image else 16}px 0">{kasten}</div>' + pic("0 0 16px 0")
    return (pic("0") + f'<div style="margin:-24px 24px 16px 24px"><div style="display:inline-block;width:100%;'
            f'vertical-align:top">{kasten}</div></div>')


# ---------------------------------------------------------------- Karten für die Kursseite
def _chip(text, hue, filled=False):
    r = "0" if D["formen"]["chip"] == "eckig" else "999px"
    return _chip_form(text, hue, filled, r, "2px 11px", ".85em", "3px 6px 3px 0")


def _tile_td(inner, hue=None, top=False, left=False, width=None):
    """Eine Kachel der Schritt-, Fahrplan- und Themenfeldleisten – Form nach formen.karte."""
    hue = _a(hue)
    akz = top or left
    match D["formen"]["karte"]:
        case "bunt":
            style = f'background:{_zweit(hue)};border:0;'
        case "flaeche":
            style = f'background:{_tint(hue)};border:0;'
            if akz:
                style += f'border-top:4px solid {hue};'
        case "linie":
            style = f'background:{D["flaeche"]};border:0;border-top:2px solid {hue if akz else D["ink"]};'
        case "abstand":
            style = f'border:0;{f"border-top:2px solid {hue};" if akz else ""}'
        case "gestrichelt":
            style = f'background:{D["flaeche_alt"]};border:2px dashed {D["line_card"]};'
            if akz:
                style += f'border-top:4px solid {hue};'
        case "papier":
            style = f'background:{D["flaeche_alt"]};border:1px solid {D["line_card"]};'
            if akz:
                style += f'border-top:3px solid {hue};'
        case "rahmen":
            style = f'border:1px solid {D["line_card"]};'
            if akz:
                style += f'border-top:3px solid {D["line_card"]};'
        case "links":
            style = f'border:0;border-left:3px solid {hue if akz else D["line"]};'
        case "einzug":
            style = f'border:0;border-left:1px solid {D["ink"]};'
        case "ohne":
            style = 'border:0;'
        case _:
            style = f'background:{D["flaeche"]};border:1px solid {D["line_card"]};'
            if top:
                style += f'border-top:4px solid {hue};'
            if left:
                style += f'border-left:5px solid {hue};'
    w = f'width:{width};' if width else ''
    return (f'<td style="{w}vertical-align:top;{style}border-radius:{_r()};padding:{D["tile_pad"]};'
            f'line-height:1.3">{inner}</td>')


def _kicker(text, hue=None):
    farbe = _signal() or (_a(hue) if hue else D["muted"])
    match D["formen"]["kicker"]:
        case "klein":
            art = "font-size:.74em;letter-spacing:.16em;text-transform:uppercase"
        case "kapitaelchen":
            art = "font-size:1em;letter-spacing:.05em;font-variant:small-caps"
        case "etikett":
            z = _zweit(farbe)
            return (f'<div style="margin:12px 0 8px 0"><span style="display:inline-block;background:{z};color:{_auf(z)};'
                    f'font-weight:700;font-size:.9em;letter-spacing:.02em;border-radius:999px;padding:3px 12px">'
                    f'{text}</span></div>')
        case "invers":
            return (f'<div style="margin:12px 0 8px 0"><span style="display:inline-block;background:{D["ink"]};'
                    f'color:{_auf(D["ink"])};font-weight:700;font-size:.82em;letter-spacing:.08em;text-transform:uppercase;'
                    f'padding:2px 8px">{text}</span></div>')
        case "normal":
            art = "font-size:1em"
        case _:
            art = "font-size:.82em;letter-spacing:.08em;text-transform:uppercase"
    return f'<div style="color:{farbe};font-weight:700;{art};margin:12px 0 8px 0">{text}</div>'


ZAHLWORT = {2: "Zwei", 3: "Drei", 4: "Vier", 5: "Fünf", 6: "Sechs", 7: "Sieben", 8: "Acht", 9: "Neun", 10: "Zehn",
            11: "Elf", 12: "Zwölf"}


def _ablauf(eintraege, hue, wort=("Ein Schritt", "Schritte")):
    """Schritte des Überblicks oder Lerneinheiten des Fahrplans nach formen.ablauf (leiste baut _strip): liste
    (nummerierte Zeilen, Nummer nach formen.nummer), spalte (schmale Spalte mit Nummern links), satz (ein Satz).
    eintraege: (nummer, titel, detail)."""
    ink, muted, line = D["ink"], D["muted"], D["line"]
    match D["formen"]["ablauf"]:
        case "satz":
            n = len(eintraege)
            anfang = wort[0] if n == 1 else f'{ZAHLWORT.get(n, str(n))} {wort[1]}'
            teile = [f'<span style="font-weight:700">{t}</span>' + (f' – {d.rstrip(". ")}' if d else '')
                     for _, t, d in eintraege]
            return (f'<p style="line-height:{_lh(1.55)};margin:4px 0 14px 0;color:{ink}">{anfang}: '
                    f'{"; ".join(teile)}.</p>')
        case "spalte":
            weiss = D["flaeche_alt"].lower() in ("#fff", "#ffffff")
            spalte = _tint(hue) if weiss else D["flaeche_alt"]
            trs = "".join(
                f'<tr><td style="border:0;width:56px;background:{spalte};text-align:center;vertical-align:top;'
                f'padding:10px 0;font-size:1.5em;font-weight:800;color:{hue};line-height:1.1">{num}</td>'
                f'<td style="border:0;border-bottom:1px solid {line};padding:10px 0 10px 16px;vertical-align:top;'
                f'line-height:1.4"><div style="font-weight:700;color:{ink}">{t}</div>'
                + (f'<div style="color:{muted};font-size:.92em;margin-top:2px">{d}</div>' if d else '') + '</td></tr>'
                for num, t, d in eintraege)
            return f'<table style="width:100%;border-collapse:collapse;margin:4px 0 14px 0;border:0">{trs}</table>'
    if D["formen"]["nummer"] == "liste":
        lis = "".join(f'<li style="margin:6px 0;line-height:1.5"><strong>{t}</strong>{": " + d if d else ""}</li>'
                      for _, t, d in eintraege)
        return f'<ol style="padding-left:26px;margin:6px 0 14px 0">{lis}</ol>'
    trs = []
    for num, t, d in eintraege:
        nr, w = _nummer(num, hue)
        trs.append(f'<tr><td style="border:0;width:{w}px;padding:6px 10px 6px 0;vertical-align:middle">{nr}</td>'
                   f'<td style="border:0;border-bottom:1px solid {line};padding:8px 0;line-height:1.4;vertical-align:middle">'
                   f'<span style="font-weight:700;color:{ink}">{t}</span>'
                   + (f'<span style="color:{muted}"> – {d}</span>' if d else '') + '</td></tr>')
    return f'<table style="width:100%;border-collapse:collapse;margin:4px 0 14px 0;border:0">{"".join(trs)}</table>'


def _strip(cells):
    g = D["gap"]
    return f'<table {TBL.format(sp=f"{g}px 0", m=f"0 -{g}px 6px -{g}px")}><tr>{"".join(cells)}</tr></table>'


def _kopfkarte(hue):
    """Rahmen der Kopfkarte (Lerneinheit) und ihrer Nummernzelle nach formen.kasten -> (frame, numcell)."""
    r = _r("r_lg")
    match D["formen"]["kasten"]:
        case "linie_oben" | "haarlinie":
            dick = 4 if D["formen"]["kasten"] == "linie_oben" else 2
            return (f'border-top:{dick}px solid {hue};border-bottom:1px solid {D["line"]};',
                    'border:0;padding:14px 10px 14px 0;')
        case "einzug" | "links" | "zitat":
            return '', f'border:0;border-left:3px solid {hue};padding:14px 10px 14px 16px;'
        case "rahmen" | "rahmen_dick" | "papier" | "gestrichelt":
            bg = f'background:{D["flaeche_alt"]};' if D["formen"]["kasten"] not in ("rahmen", "rahmen_dick") else ''
            art = "dashed" if D["formen"]["kasten"] == "gestrichelt" else "solid"
            return (f'{bg}border:{2 if art == "dashed" else 1}px {art} {D["line_card"]};border-radius:{r};',
                    'border:0;padding:14px 10px 14px 20px;')
    return (f'background:{_tint(hue)};border-radius:{r};',
            f'border:0;border-left:6px solid {hue};border-radius:{r} 0 0 {r};padding:14px 10px 14px 20px;')


@_baustein
def le_card(num, title, subtitle, duration, steps, hue):
    """Kopfkarte einer Lerneinheit plus Schrittleiste. steps: (label, detail[, emoji]).
    title None: kompakte Karte nur mit Dauer und Phasen (wenn das Banner den Titel schon trägt)."""
    hue = _a(hue)
    cells, eintraege = [], []
    for i, (label, detail, *em) in enumerate(steps, 1):
        icon = f'<span style="font-size:1.25em;vertical-align:middle;margin-right:6px">{em[0]}</span>' if (em and em[0] and EMOJI) else ''
        eintraege.append((i, icon + label, detail))
        if D["formen"]["karte"] in ("flaeche", "bunt"):     # farbige Kachel: Nummer im Kreis über dem Schritt
            nr, _ = _nummer(i, hue)
            inner = (f'<div style="margin-bottom:8px">{nr}</div><div style="font-weight:700;color:{D["ink"]}">{icon}{label}</div>'
                     f'<div style="color:{D["muted"]};font-size:.88em;margin-top:3px">{detail}</div>')
        elif D["formen"]["nummer"] == "zahl":
            inner = (f'<div style="font-size:2em;font-weight:800;color:{hue};line-height:1;margin-bottom:6px">{i}</div>'
                     f'<div style="font-weight:700;color:{D["ink"]}">{icon}{label}</div>'
                     f'<div style="color:{D["muted"]};font-size:.88em;margin-top:3px">{detail}</div>')
        else:
            inner = (f'<div style="font-weight:700;color:{D["ink"]}">{icon}<span style="color:{hue};font-size:.85em;margin-right:5px">{i}</span>{label}</div>'
                     f'<div style="color:{D["muted"]};font-size:.88em;margin-top:3px">{detail}</div>')
        cells.append(_tile_td(inner, hue))
    strip = _strip(cells) if D["formen"]["ablauf"] == "leiste" else _ablauf(eintraege, hue)
    if title is None:
        head = _kicker(f'Ablauf{" · " + duration if duration else ""}', hue).replace("margin:12px 0 8px 0", "margin:4px 0 6px 0")
        return head + strip
    frame, numcell = _kopfkarte(hue)
    head = (
        f'<table style="width:100%;border-collapse:separate;border-spacing:0;{frame}margin:2px 0 10px 0;border:0"><tr>'
        f'<td style="{numcell}vertical-align:top;width:64px">'
        f'<div style="font-size:2.6em;font-weight:800;color:{hue};line-height:1">{num}</div></td>'
        f'<td style="border:0;padding:14px 20px 14px 8px;vertical-align:top">'
        f'<div style="font-size:1.3em;font-weight:700;color:{D["ink"]};line-height:1.2{";" + _kopf().rstrip(";") if _kopf() else ""}">{title}</div>'
        f'<div style="color:{D["muted"]};margin-top:4px;line-height:1.4">{subtitle}</div>'
        f'<div style="margin-top:8px">{_chip(duration, hue)}</div>'
        f'</td></tr></table>')
    return head + strip


@_baustein
def fahrplan(items, hue, heading="Dein Weg durch das Themenfeld"):
    """items: (num, title, duration, emoji)"""
    hue = _a(hue)
    if D["formen"]["ablauf"] != "leiste":
        return _kicker(heading) + _ablauf(
            [(num, (f'{icon} ' if (EMOJI and icon) else '') + title, dur) for num, title, dur, icon in items], hue,
            ("Eine Lerneinheit", "Lerneinheiten"))
    cells = []
    for num, title, dur, icon in items:
        ic = f'<span style="font-size:1.25em;vertical-align:middle">{icon}</span> ' if (EMOJI and icon) else ''
        inner = (f'<div>{ic}'
                 f'<span style="color:{hue};font-weight:700;font-size:.78em;letter-spacing:.08em;vertical-align:middle">LERNEINHEIT {num}</span></div>'
                 f'<div style="font-weight:700;color:{D["ink"]};margin-top:4px">{title}</div>'
                 f'<div style="color:{D["muted"]};font-size:.88em;margin-top:4px">{dur}</div>')
        cells.append(_tile_td(inner, hue, top=True))
    return _kicker(heading) + _strip(cells)


@_baustein
def tf_strip(tfs, heading="Die acht Themenfelder", per_row=4):
    """tfs: (num, title, hue, full, emoji) – Kacheln in Reihen zu je per_row."""
    cells = []
    for num, title, hue, full, icon in tfs:
        hue = _a(hue)
        tag = _chip("ausgearbeitet", hue, filled=True) if full else _chip("exemplarisch", _a("#9AA3B5"))
        ic = f'<span style="font-size:1.3em;vertical-align:middle">{icon}</span> ' if (EMOJI and icon) else ''
        inner = (f'<div>{ic}'
                 f'<span style="color:{hue};font-weight:800;vertical-align:middle">{num:02d}</span></div>'
                 f'<div style="font-weight:600;color:{D["ink"]};margin-top:3px;font-size:.95em">{title}</div>'
                 f'<div style="margin-top:4px">{tag}</div>')
        cells.append(_tile_td(inner, hue, left=True))
    rows = "".join(f'<tr>{"".join(cells[i:i + per_row])}</tr>' for i in range(0, len(cells), per_row))
    g = D["gap"]
    return _kicker(heading) + f'<table {TBL.format(sp=f"{g}px {g}px", m=f"0 -{g}px 0 -{g}px")}>{rows}</table>'


@_baustein
def tf_info(kompetenz, les, note, hue):
    """Leitkompetenz links, Lerneinheiten rechts, optionale Anmerkung darunter."""
    hue = _a(hue)
    rows = "".join(
        f'<tr><td style="border:0;border-bottom:1px solid {D["line"]};padding:7px 10px 7px 0;color:{hue};font-weight:700;'
        f'white-space:nowrap;vertical-align:top;width:48px">LE {i+1}</td>'
        f'<td style="border:0;border-bottom:1px solid {D["line"]};padding:7px 0;line-height:1.4">{t}</td></tr>'
        for i, t in enumerate(les))
    note_html = f'<div style="color:{D["muted"]};font-size:.9em;margin-top:8px">{note}</div>' if note else ""
    match D["formen"]["kasten"]:
        case "linie_oben" | "haarlinie":
            frame = f'border-top:3px solid {hue};padding:12px 0'
        case "einzug" | "links" | "zitat":
            frame = f'border-left:3px solid {hue};padding:4px 0 4px 14px'
        case "rahmen" | "rahmen_dick" | "papier" | "gestrichelt":
            frame = f'border:1px solid {D["line_card"]};border-radius:{_r()};padding:12px 16px'
        case _:
            frame = f'background:{_tint(hue)};border-radius:{_r()};padding:12px 16px;border-left:5px solid {hue}'
    return (f'<table style="width:100%;border-collapse:separate;border-spacing:0;margin:8px 0 4px 0;border:0"><tr>'
            f'<td style="border:0;vertical-align:top;width:40%;padding:0 16px 0 0">'
            f'<div style="{frame}">'
            f'{_kicker("Leitkompetenz", hue).replace("margin:12px 0 8px 0", "margin:0 0 4px 0")}'
            f'<div style="line-height:1.45">{kompetenz}</div></div></td>'
            f'<td style="border:0;vertical-align:top;padding:0">'
            f'<table style="width:100%;border-collapse:collapse;border:0">{rows}</table>{note_html}</td>'
            f'</tr></table>')


set_design()
