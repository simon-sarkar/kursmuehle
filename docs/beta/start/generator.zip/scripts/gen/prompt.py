"""Text für den Chat (AP11): aus `references/katalog.yaml` und dem Stand der Kursmappe, für CLI und Browser derselbe Text.

    chats()                                        Chat-Auswahl aus dem Katalog
    einheit(mappe, steckbrief, chat, material, nur_leere)  -> {teile, groessen, ids, typen}: Text „Diese Einheit“ oder
                                                   „Alle leeren Bausteine“, gestückelt über 14 KB oder nach Chat
    baustein(mappe, ids, kurs_md, steckbrief, chat)  -> Text „Nur dieser Baustein“ (etwa 1 KB, bisheriger Inhalt als Kontext)
    diagnose(text)                                 -> Karte und Satz, wenn eine Antwort keinen Baustein ergab (AP13.4)
    korrektur(pruefung)                            -> Sätze an den Chat, einer je Fehler (eigener Satz, wenn die Prüfung
                                                   einen mitgibt: `bitte`, etwa bei einer Zeit-Annahme)
    fragen(pruefung)                               -> Ansicht „Fragen und Lösungen“ (Fragen, Optionen, Lösungen, ohne Rückmeldung)
    fachcheck(pruefung, steckbrief, mappe)         -> Text für einen neuen Chat: Aufgaben ohne Lösungen
    vergleich(pruefung, antwort)                   -> Abweichungen zwischen Antwort des neuen Chats und Kursdatei

Der Text richtet sich an das Modell, nicht an die Lehrkraft; die Sätze stehen im Katalog unter `prompt`.
"""
import re

from . import api
from . import zielart as ZA
from . import design as DS
from . import kursdatei as K
from . import mappe as M

GRENZE = 14 * 1024          # Ziel je Text in Bytes (Plan §4; 14 KB seit AP13.3, damit sechs Karten in einen Teil passen; 68 KB
                            # liefen im Test in AIS-Chat und fobizz); darüber stückelt einheit() nach Abschnitten
_TEXTTYPEN = {"Textfeld", "Seite", "Lesebuch", "Buch", "Aufgabe", "Datei", "Geschichte"}
_FRAGETYPEN = {"Quiz", "Test", "Lesebuch"}


def _kat():
    return M.katalog()


def chats():
    return _kat()["chats"]


def chat(wert=None):
    """Eintrag der Chat-Auswahl; unbekannt oder leer = „anderer Chat“. Ein dict wird unverändert genommen (Tests)."""
    if isinstance(wert, dict):
        return wert
    liste = chats()
    return next((c for c in liste if c["wert"] == wert), next(c for c in liste if c["wert"] == "anderer"))


def _text_von(feld, wert):
    return next((w["text"] for w in _kat()["oberflaeche"][feld] if w["wert"] == wert), wert)


def _typ(typ):
    return next((e for e in _kat()["typen"] if e["typ"] == typ), None)


# ---------------------------------------------------------------- Teile des Textes
def einheit_thema(mappe, angaben):
    """AP13.30 §4b: Thema der laufenden Einheit (eine angehängte Einheit hat ihr eigenes), sonst das Thema des Kurses;
    Auftrag (lehrplan) und Gegenprüfen (fachcheck) wählen damit dieselben Erwartungen."""
    return ((mappe or {}).get("einheit") or {}).get("thema") or (angaben or {}).get("thema") or (mappe or {}).get("titel")


def _auftrag(mappe, angaben, minuten=None):
    """Zeile „Thema · Fach · … · N Minuten“; `minuten` (AP13.35 M2): die Zahl der Einheit aus einheit_zeit."""
    e = mappe.get("einheit") or {}
    teile = []
    thema = einheit_thema(mappe, angaben)
    if thema:
        teile.append(f"Thema: {thema}")
    if angaben.get("fach"):
        teile.append(f"Fach: {angaben['fach']}")
    if angaben.get("schulart"):
        teile.append(f"Schulart: {angaben['schulart']}")
    jg = e.get("jahrgang") or angaben.get("jahrgang")
    if angaben.get("lehrplanbezug") == "nein":       # AP13.6: Einheit ohne Lehrplan, das Feld heißt „Zielgruppe“
        if M.jahrgang_zahl(jg):                       # AP13.8: eine Zahl darin ist die Jahrgangsstufe
            teile.append(f"Jahrgangsstufe {M.jahrgang_zahl(jg)}")
        elif jg:
            teile.append(_kat()["prompt"]["zielgruppe"].format(text=jg))
    elif jg:
        teile.append(f"Jahrgangsstufe {jg}")
    elif _foerderschule(angaben) != M.FOERDERSCHWERPUNKTE["G"]:   # AP13.18: geistige Entwicklung arbeitet in Spannen
        teile.append(_kat()["prompt"]["jahrgang_fehlt"].format(jahrgang=_kat()["zeitbedarf"]["jahrgang_ohne"]))
    minuten = minuten or e.get("minuten") or angaben.get("minuten")
    if minuten:
        teile.append(f"{minuten} Minuten")
    return " · ".join(teile), thema or "Einheit", minuten


def _angenommen(angaben):
    website = "auf der Kursseite (formative Übungen als Block im Textfeld, Kursdatei-Angabe `website: textfeld` am " \
              "Abschnitt)" if angaben.get("website") == "textfeld" else "als eigene Aktivitäten"
    return [f"Angenommen: Kursformat {_text_von('format', angaben.get('format', 'themen'))}",
            f"Angenommen: Übungen erscheinen {website}",
            f"Angenommen: {_text_von('abschluss', angaben.get('abschluss', 'keiner'))}",
            f"Angenommen: {_text_von('portionierung', angaben.get('portionierung', 'keine'))}"]


_LESETYPEN = {"Textfeld", "Seite", "Buch", "Lesebuch"}
_AUFGABENTYPEN = {"Quiz", "Test", "Lückentext"}


def wortziel(e, jahrgang=None):
    """Länge, die ein Baustein für seine Soll-Minuten braucht, aus denselben Werten wie die Rechnung (katalog.yaml
    `zeitbedarf`): Lesetext nach Rolle und Jahrgangsstufe in Wörtern, Hefteintrag im Abschreibtempo, Quiz und Test in
    Aufgaben (Mittel aus einfach und rechnen), Zuordnen und Lernkarten in Elementen. Leer ohne Soll."""
    soll, typ = e.get("soll"), e.get("typ")
    if not soll or typ in M.struktur():
        return ""
    k = _kat()
    z, p = k["zeitbedarf"], k["prompt"]
    faktor = M._jahrgang_faktor(jahrgang)
    rolle = M.rolle_von(e)
    minuten = f"{soll} Minute" + ("" if soll == 1 else "n")
    if typ in _LESETYPEN:
        if rolle == "rahmen":
            return p["wortziel_kurz"]
        heft_ = "Hefteintrag" in (e.get("titel") or "") or "Hefteintrag" in (e.get("schritt") or "")
        art_ = _zahl_nomen(e.get("auftrag"), _ARTEN_LESEN)[1]
        if art_ == "Wörter" or (art_ == "Sätze" and not heft_):
            return ""                                # AP13.41 §2.1: Sätze oder Wörter der Lehrkraft gelten allein
        heft = "Hefteintrag" in (e.get("titel") or "") or "Hefteintrag" in (e.get("schritt") or "")
        einstieg = rolle == "einstieg" and typ == "Textfeld"
        wpm = z["abschreiben"] if heft else z["woerter_je_minute"].get(rolle, z["woerter_je_minute"]["rahmen"])
        lesen = max(0.5, soll - z["aufgabe_minuten"]["einfach"]) if einstieg else soll   # Denkaufgabe abziehen
        woerter = max(20, int(round(lesen * wpm * faktor / 10.0)) * 10)
        if rolle == "einstieg":                      # Einstieg kurz (AP13.1), mit Abstand zur Grenze der Prüfung
            woerter = min(woerter, k["pruefregeln"]["einstieg_woerter"] - 20)
        mindest = 0
        if heft:                                     # Wortziel nie unter dem Mindestmaß des Hefteintrags
            mindest = next((M.mindestzahl(t["mindest"], jahrgang) for t in k["typen"] if t["typ"] == typ
                            and t.get("mindest")), 0)
            woerter = max(woerter, mindest)
        # AP13.35 §2.4: liegt das Ziel nahe am Mindestmaß der Prüfung, sagt der Text „mindestens“ (wie die Zählregel)
        art = ("wortziel_heft_mindest" if mindest and woerter < mindest * 1.25 else "wortziel_heft") if heft \
            else "wortziel_einstieg" if einstieg else "wortziel_text"
        if art == "wortziel_heft_mindest":
            woerter = mindest
        return p[art].format(min=minuten, woerter=woerter)
    if typ in _AUFGABENTYPEN | {"Zuordnen", "Lernkarten"} and _zahl_nomen(e.get("auftrag"), _ARTEN_AUFGABEN)[0] is not None:
        return ""                                    # AP13.37 §2.2: die Zahl der Lehrkraft gilt, keine zweite daneben
    # AP13.37 §2.2: nie unter dem Mindestmaß des Typs, in dessen Einheit (Fragen, Lücken, Paare, Karten)
    mind = next((t["mindest"] for t in k["typen"] if t["typ"] == typ and t.get("mindest") and not t["mindest"].get("nur")),
                None)
    if typ in _AUFGABENTYPEN:
        mittel = (z["aufgabe_minuten"]["einfach"] + z["aufgabe_minuten"]["rechnen"]) / 2
        n = max(1, round(soll / mittel))
        if mind:
            return p["wortziel_aufgaben"].format(n=f"{max(n, M.mindestzahl(mind, jahrgang))} {mind['einheit']}", min=minuten)
        return p["wortziel_aufgaben"].format(n=f"{n} Aufgabe" + ("" if n == 1 else "n"), min=minuten)
    if typ in ("Zuordnen", "Lernkarten"):
        sek = z["sekunden"]["zuordnung" if typ == "Zuordnen" else "karte"]
        n = max(3, min(12, round(soll * 60 / sek / 2)))
        return p["wortziel_elemente"].format(n=max(n, M.mindestzahl(mind, jahrgang)) if mind else n)
    return ""


_ZAHLWOERTER = {"ein": 1, "eine": 1, "einen": 1, "zwei": 2, "drei": 3, "vier": 4, "fünf": 5, "sechs": 6, "sieben": 7,
                "acht": 8, "neun": 9, "zehn": 10, "elf": 11, "zwölf": 12, "fünfzehn": 15, "zwanzig": 20}
# AP13.41 §2.1: auch Zahlwörter am Satzanfang („Drei Lücken“); Sätze und Wörter zählen bei Lesetexten. Das Nomen
# beginnt mit dem Zählwort („Fachwörter“, „Absätzen“, „Landkarte“ zählen nicht); zusammengesetzt nur mit den Vorsilben
# aus _VORSILBEN („Beispielsätze“, „Lernkarten“, „Testfragen“)
_NOMEN = (("Fragen", "fragen?"), ("Lücken", "lücken?"), ("Paare", "paare?|zuordnungen?"), ("Karten", "karten?"),
          ("Elemente", "begriffe?|elemente?|fälle|fällen|fall|ereignisse?n?|items?"), ("Aufgaben", "aufgaben?"),
          ("Sätze", "sätzen?|satz"), ("Wörter", "wörtern?|wort"))
_VORSILBEN = "beispiel|merk|lern|übungs|test|quiz|kontroll"
_RE_ZAHL_AUFTRAG = re.compile(rf"(?<![\w-])({'|'.join(sorted(_ZAHLWOERTER, key=len, reverse=True))}|\d+)\s+(\w+)(?:\s+(\w+))?",
                              re.I)
# Zählwörter je Typ (Korrekturrunde AP13.41): bei Mischaufträgen gilt die erste Zahl, deren Nomen zum Typ passt
_ARTEN_LESEN = ("Sätze", "Wörter")
_ARTEN_AUFGABEN = ("Fragen", "Lücken", "Paare", "Karten", "Elemente", "Aufgaben")


def _zahl_nomen(auftrag, arten=None):
    """(Zahl, Art) der ersten Zahl im Auftrag, die Fragen, Lücken, Paare, Karten, Elemente, Aufgaben, Sätze oder Wörter
    zählt (das Nomen direkt dahinter oder nach einem Wort wie „kurze“); mit `arten` nur diese Arten; sonst (None, None)."""
    for m in _RE_ZAHL_AUFTRAG.finditer(" ".join(str(auftrag or "").split())):
        for wort in (m.group(2), m.group(3)):
            wort = (wort or "").lower()
            art = next((a for a, muster in _NOMEN if re.fullmatch(rf"(?:{_VORSILBEN})?(?:{muster})", wort)), None)
            if art and (arten is None or art in arten):
                w = m.group(1).lower()
                return (int(w) if w.isdigit() else _ZAHLWOERTER[w]), art
            if art:
                break
    return None, None


def zahl_im_auftrag(auftrag):
    """AP13.37 §2.2: Zahl von Aufgaben oder Elementen, die der Auftrag der Lehrkraft nennt („Vier Fragen zu …“ -> 4),
    sonst None. AP13.41 §2.1: auch „Drei Beispielsätze“, „etwa fünf Sätzen“, „200 Wörter“."""
    return _zahl_nomen(auftrag)[0]


def auftrag_unter_mindest(e, jahrgang=None):
    """AP13.41 §2.1: nennt der Auftrag eine Zahl unter dem Mindestmaß des Typs (in dessen Einheit), gilt die Zahl des
    Auftrags (Text und Prüfung); der Plan zeigt dazu einen gelben Hinweis. -> (Zahl, Mindestmaß, Einheit) oder None"""
    mind = next((t["mindest"] for t in _kat()["typen"] if t["typ"] == e.get("typ") and t.get("mindest")
                 and not t["mindest"].get("nur")), None)
    if not mind:
        return None
    n, art = _zahl_nomen(e.get("auftrag"), (mind["einheit"], "Aufgaben", "Elemente"))
    if n is None:
        return None
    soll = M.mindestzahl(mind, jahrgang)
    return (n, soll, mind["einheit"]) if n < soll else None


def plan_hinweise(mappe):
    """AP13.41 §2.1: gelbe Hinweise je Element im Plan („Ich steuere“): {id: Satz}, wenn der Auftrag weniger nennt als das
    Mindestmaß des Typs."""
    jahrgang = (mappe.get("einheit") or {}).get("jahrgang")
    out = {}
    for e in mappe.get("bausteine", []):
        u = auftrag_unter_mindest(e, jahrgang) if e.get("geplant") else None
        if u:
            out[e["id"]] = M.katalog()["oberflaeche"]["editor"]["plan_unter_mindest"].format(zahl=u[0], mindest=u[1],
                                                                                             einheit=u[2])
    return out


AUTO = "automatisch"           # Typ einer Karte, deren Typ das Modell wählt (AP13)


def zeit_selbst(mappe):
    """Hat die Lehrkraft die Zeit je Phase selbst eingestellt? Schalter `zeit_selbst` der Mappe (AP13); ohne Schlüssel
    (Kursdateien vor 2.0.0-b1) gelten die Soll-Minuten wie bisher."""
    return mappe.get("zeit_selbst", True) is not False


def leerer_titel(titel):
    """AP13.41 §2.3: kein Titel der Lehrkraft (leer oder „Neues Element“ aus Mappen vor AP13.41)."""
    t = " ".join(str(titel or "").split())
    return not t or t == _kat()["oberflaeche"]["editor"]["plan_neues_element"]


def _schritt_typen():
    """AP13.43: Teilschritt der Vorlagen -> Typ, für den er geschrieben ist (`Textfeld: Einstieg | Ein Text: …`)."""
    out = {}
    for v in _kat()["vorlagen"]:
        for ph in v["phasen"]:
            for b in ph.get("bausteine") or []:
                if " | " in b:
                    kopf, schritt = b.split(" | ", 1)
                    out.setdefault(" ".join(schritt.split()), kopf.split(":")[0].strip())
    return out


def schritt_passt(e):
    """AP13.43: der Teilschritt einer Karte gilt nur für den Typ, für den die Vorlage ihn schrieb; hat die Lehrkraft einen
    anderen festen Typ gewählt (Einstieg als Zuordnen statt Textfeld), fällt er weg, statt dem Typ zu widersprechen."""
    t = _schritt_typen().get(" ".join(str(e.get("schritt") or "").split()))
    return not t or t == AUTO or e.get("typ") in (AUTO, t, None, "")


def _zeile(e, nr, jahrgang=None, selbst=True):
    """Eine Zeile der Bausteinliste: id, Typ (oder „Typ frei“), Arbeitstitel, Phase, mit `selbst` die Soll-Minuten mit
    Wortziel, Teilschritt aus der Vorlage, Auftrag der Lehrkraft."""
    teile = [f"{nr}. id: {e['id']}", "Typ frei" if e.get("typ") == AUTO else e.get("typ", "")]
    if not leerer_titel(e.get("titel")):          # AP13.41 §2.3: ohne Titel wählt ihn der Chat
        teile.append(f"Arbeitstitel „{e['titel']}“")
    if e.get("typ") not in M.struktur():
        if e.get("phase"):
            teile.append(f"Phase {e['phase']}")
        ziel = wortziel(e, jahrgang) if selbst and e.get("typ") != AUTO else ""
        if ziel:
            teile.append(ziel)
        elif selbst and e.get("soll"):
            teile.append(f"{e['soll']} min")
        elif not selbst and M.rolle_von(e) == "einstieg":
            teile.append(_kat()["prompt"]["einstieg_dauer"].format(minuten=_kat()["zeitbedarf"]["einstieg_minuten"]))   # Prompttest AP13.3: sonst schrieb das Modell 1 min
    if (e.get("schritt") or "").strip() and schritt_passt(e):
        teile.append("Teilschritt: " + " ".join(e["schritt"].split()))
    if (e.get("auftrag") or "").strip():         # AP13.41 §2.1: liegt die Zahl unter dem Mindestmaß, gilt sie trotzdem
        teile.append("Auftrag: " + " ".join(e["auftrag"].split()))
    if (e.get("wunsch") or "").strip():            # AP13.35 §3.5: „Neu schreiben lassen“, neben dem Auftrag aus dem Plan
        teile.append(_kat()["prompt"]["wunsch"].format(text=" ".join(e["wunsch"].split())))
    if e.get("zusatzaufgabe"):                      # AP13.14: Karte „Zusatz“, Minuten außerhalb der Summe
        teile.append(_kat()["prompt"]["differenzierung"]["zusatz"])
    return " · ".join(teile)


def zaehlregeln(liste, typen, uebung=True, jahrgang=None):
    """Zählregeln für den Inhalt (AP13.1): Mindestmaße der Typen dieser Einheit (`mindest` im Katalog; der Hefteintrag
    nur, wenn eine Karte so heißt oder diesen Teilschritt hat), Einstieg kurz (wenn eine Karte die Rolle Einstieg hat),
    mit `uebung` die Regel, dass Denkaufgaben keine Übung sind (nur im Text für die ganze Einheit)."""
    k = _kat()
    p, regeln = k["prompt"], k["pruefregeln"]
    teile = []
    for e in k["typen"]:
        m = e.get("mindest")
        if not m or e["typ"] not in typen or m.get("nur"):
            continue
        teile.append(p["mindest_typ"].format(typ=e["typ"], zahl=M.mindestzahl(m, jahrgang), einheit=m["einheit"]))
    heft = next((e["mindest"] for e in k["typen"] if (e.get("mindest") or {}).get("nur") == "Hefteintrag"), None)
    if heft and any("Hefteintrag" in f"{x.get('titel', '')} {x.get('schritt', '')}" for x in liste):
        teile.append(p["mindest_hefteintrag"].format(zahl=M.mindestzahl(heft, jahrgang)))
    out = [p["mindest"].format(liste="; ".join(teile))] if teile else []
    if any(M.rolle_von(x) == "einstieg" for x in liste):
        out.append(p["einstieg"].format(woerter=regeln["einstieg_woerter"], minuten=_kat()["zeitbedarf"]["einstieg_minuten"]))
    if uebung:
        out.append(p["uebung"].format(typen=", ".join(regeln["uebung"][:-1]) + " oder " + regeln["uebung"][-1]))
        out.append(p["variation"])
    return out


def braucht_skizze(angaben, thema=""):
    """Fach aus `skizze_faecher` oder ein Stichwort aus `skizze_stichworte` im Thema (Geometrie, Brüche, Diagramme …)."""
    p = _kat()["prompt"]
    fach = (angaben.get("fach") or "").lower()
    text = f"{thema} {angaben.get('thema') or ''}".lower()
    # Korrekturrunde AP13.41: Stichworte als ganze Wörter mit Beugung („Kreise“, nicht „Wasserkreislauf“)
    return any(f.lower() in fach for f in p["skizze_faecher"]) or any(
        re.search(rf"(?<!\w){re.escape(w.lower())}(?:e|en|er|es|n|s|ns)?(?!\w)", text) for w in p["skizze_stichworte"])


def _regeln(e):
    """Regeln eines Typs für den Text: `kurzregeln`, wenn der Katalog welche hat (AP13.4), sonst `regeln`."""
    return ["- " + r for r in e.get("kurzregeln", e.get("regeln", []))]


def format_hilfe(typ):
    """AP13.11: Zeilen unter dem Feld „Bearbeiten“: dieselben Formatregeln wie im Text für den Chat für diesen Typ
    (Textbausteine, Fragen, Test, `kurzregeln` bzw. `regeln`), ohne Spiegelstrich. -> [Zeile]"""
    k = _kat()
    zeilen = []
    if typ in _TEXTTYPEN:
        zeilen.append(k["prompt"]["textbausteine"])
    if typ in _FRAGETYPEN:
        zeilen.append(k["prompt"]["fragen"])
    if typ == "Test":
        zeilen.append(k["prompt"]["fragen_test"])
    e = next((e for e in k["typen"] if e["typ"] == typ), None)
    if e:
        zeilen += [r[2:] for r in _regeln(e)]
    return zeilen


def _beispiel(e):
    """Formatbeispiel eines Typs für den Text: das kürzere `kurzbeispiel`, wenn der Katalog eins hat (AP13.4)."""
    return (e.get("kurzbeispiel") or e["beispiel"]).rstrip("\n").splitlines()


def bilder_saetze(angaben):
    """Regel zu Bildern nach der Stufe aus Schritt 3 (AP13.4): keine `Bild:`-Zeilen, mindestens/höchstens n oder genau
    n (Zahl, AP13.5g)."""
    p, st = _kat()["prompt"], M.bilder_stufe((angaben or {}).get("bilder", M.bilder_rueckfall()))
    if not st["max"] and st["max"] is not None:
        return None, p["bilder_keine"]
    if st["min"] == st["max"]:
        return st, p["bilder_genau"].format(n=st["min"], bilder="Bild" if st["min"] == 1 else "Bilder")
    wie = f"mindestens {st['min']}" + (f" und höchstens {st['max']}" if st["max"] else "")
    return st, p["bilder_stufe"].format(wie=wie)


def beschriftung(angaben):
    """Regel zur Beschriftung im Bild nach der Wahl in Schritt 3 (`kurs.bildbeschriftung`, AP13.5h a8): `ziffern`
    (Standard der Mühle) oder `woerter`; immer genau eine der beiden."""
    return _kat()["prompt"]["beschriftung"][M.bildbeschriftung((angaben or {}).get("bildbeschriftung"))]


def bildstil(angaben):
    """Ein Satz Bildstil aus der Designfamilie (familien.yaml `bildstil`, AP13.5 §5); optionale Zeile, zählt zur
    zweiten Stufe der Grenze. Sonst sieht der Chat nichts vom Design: Farben, Schrift und Formen setzt der Generator."""
    try:
        f = DS.familie((angaben or {}).get("familie"))
    except DS.DesignFehler:
        f = DS.familie(None)
    if f["formen"]["banner"] == "flaeche":     # AP13.5e §5: die Mühle setzt die Bannerfläche selbst
        return DS.BILDSTIL_FLAECHE.format(stil=f["bildstil"])
    return f"Stil der Bilder: {f['bildstil']}."


def _format(typen, ch, kopf=True, nur_typen=False, angaben=None, mappe=None):
    k = _kat()
    if nur_typen:                     # Teil 2 und folgende: nur die Formatzeilen neuer Typen (AP13.3)
        zeilen = ["Format der Typen, die neu dazukommen:", k["prompt"]["platzhalter"]]
        for e in k["typen"]:
            if e["typ"] in typen:
                zeilen += ["```"] + _beispiel(e) + ["```"] + _regeln(e)
        return zeilen + _hilfe_format(mappe, angaben, typen)
    zeilen = ["Format der Kursdatei"]
    if kopf:
        zeilen.append("- Erste Zeile `# Drehbuch v1 · Thema · N min`; darunter im Kopf nur Zeilen `Angenommen: …`, "
                      "`Bildprompt: …` und `Offen: …` (fachliche Zweifel für die Lehrkraft).")
        zeilen.append("- " + k["kopf"]["abschnitt"]["regeln"][0])
    zeilen += ["- " + r for r in k["gemeinsam"]["regeln"]]
    if set(typen) & _TEXTTYPEN:
        zeilen.append("- " + k["prompt"]["textbausteine"])
    if set(typen) & _FRAGETYPEN:
        zeilen.append("- " + k["prompt"]["fragen"])
    if "Test" in typen:
        zeilen.append("- " + k["prompt"]["fragen_test"])
    zeilen += _hilfe_format(mappe, angaben, typen)
    stufe, satz = bilder_saetze(angaben)
    if stufe:
        zeilen.append("- " + " ".join([k["prompt"]["bilder"], beschriftung(angaben)] + k["prompt"]["bildprompt"]
                                      + [bildstil(angaben)]
                                      + ([k["prompt"]["bilder_erzeugen"]] if ch.get("bilder") else [])))
    zeilen.append("- " + satz)
    zeilen.append("")
    zeilen.append("Beispiel und Regeln je Typ (nur die Typen dieser Einheit):")
    zeilen.append(k["prompt"]["platzhalter"])
    for e in k["typen"]:
        if e["typ"] not in typen:
            continue
        zeilen.append("```")
        zeilen += _beispiel(e)
        zeilen.append("```")
        zeilen += _regeln(e)
    return zeilen


def _ausgabe(ch):
    p = _kat()["prompt"]
    return [p["ausgabe_codeblock"] if ch.get("codeblock", True) else p["ausgabe_text"], p["ausgabe_ids"], p["abbruch"]]


def _gruppen(eintraege):
    """Bausteinliste nach Abschnitten: geplante Bausteine ohne Abschnitt gehören zum vorigen."""
    out, letzter = [], None
    for e in eintraege:
        a = e.get("abschnitt") or letzter
        if not out or a != out[-1][0]:
            out.append((a, []))
        out[-1][1].append(e)
        letzter = a
    return out


def kachel_text(mappe, titel, einheit=None):
    """AP13.31: „Was soll hier rein?“ der Kachel `titel` einer Einheit (Mappe `kacheln`, Plan in „Ich steuere“), Leerraum
    zusammengezogen wie beim Auftrag; leer, wenn die Kachel nichts trägt."""
    for k in (mappe or {}).get("kacheln") or []:
        if isinstance(k, dict) and k.get("titel") == titel and (k.get("einheit") or None) == (einheit or None):
            return " ".join(str(k.get("text") or "").split())
    return ""


def _zaehlt(e):
    """Karte, die Minuten der Einheit trägt (ohne Strukturbausteine und Zusatzaufgaben)."""
    return e.get("typ") not in M.struktur() and not e.get("zusatzaufgabe")


def einheit_zeit(mappe, liste, minuten=None):
    """AP13.35 §2.2 (Korrekturrunde M2): eine Zahl für die Einheit im ganzen Text und die Minuten je Karte. Hat die
    Lehrkraft mit „Zeit selbst einteilen“ jeder Karte Minuten gegeben, gilt deren Summe (der Plan warnt gelb, wenn sie
    von der Dauer abweicht). Sonst gilt die Dauer; Karten ohne eigene Minuten (ohne den Schalter alle) teilen sich den
    Rest nach ihrer Zahl, Reste an die ersten, mindestens eine Minute je Karte. Strukturbausteine und Zusatzaufgaben
    zählen nicht. `liste` = Karten des Textes. -> (Minuten der Einheit oder None, {id: Minuten})"""
    if minuten is None:
        minuten = ((mappe or {}).get("einheit") or {}).get("minuten")
    selbst = zeit_selbst(mappe or {})
    alle = [e for e in liste if _zaehlt(e)]
    eigen = {e["id"]: int(e["soll"]) for e in alle if selbst and e.get("soll")}
    frei = [e for e in alle if e["id"] not in eigen]
    if not frei:
        return (sum(eigen.values()) if eigen else (int(minuten) if minuten else None)), eigen
    if not minuten:
        return None, eigen
    fest = sum(eigen.values())
    rest = max(int(minuten) - fest, len(frei))
    je = dict(eigen)
    for i, e in enumerate(frei):
        je[e["id"]] = rest // len(frei) + (1 if i < rest % len(frei) else 0)
    return fest + rest, je


def pruef_minuten(mappe, liste):
    """AP13.41 §3.2: Minuten, mit denen Schritt 5 rechnet (Warnung „füllen etwa N von M“, Rand): die Zahl aus
    einheit_zeit, höchstens die Dauer der Einheit (liegt die Summe der Elemente darüber, sagt der Plan das gelb)."""
    n = einheit_zeit(mappe, liste)[0]
    dauer = ((mappe or {}).get("einheit") or {}).get("minuten")
    try:
        dauer = int(dauer) if dauer else None
    except (TypeError, ValueError):
        dauer = None
    return min(n, dauer) if n and dauer else (n or dauer)


def _skaliert(werte, ziel):
    """Ganze Zahlen im Verhältnis der `werte`, die zusammen `ziel` ergeben (größter Rest zuerst, je Wert mindestens 1)."""
    ges = sum(werte)
    if not ges or ges == ziel or ziel < len(werte):
        return list(werte)
    roh = [w * ziel / ges for w in werte]
    out = [max(1, int(r)) for r in roh]
    for i in sorted(range(len(werte)), key=lambda i: roh[i] - int(roh[i]), reverse=True):
        if sum(out) >= ziel:
            break
        out[i] += 1
    while sum(out) > ziel:
        out[out.index(max(out))] -= 1
    return out


def zeit_zahlen(mappe, liste, alle, dauer=None, nur_leere=False):
    """AP13.42 B5: die EINE Zahl, aus der Kopf, Gesamtsatz und Teilsätze des Textes entstehen.
    -> (Minuten der Einheit, {id: Minuten der Karte}, Minuten der Karten in `liste`, nur_leere).
    Vor der ersten Antwort gilt wie bisher die Summe der Minuten, die die Lehrkraft den Karten selbst gegeben hat
    (AP13.35 M2). Steht schon eine Antwort in der Einheit, gilt die Dauer der Einheit; die Soll-Minuten der Karten werden
    so skaliert, dass alle zusammen die Dauer ergeben. `nur_leere` (Text nur für die noch leeren Karten): sie behalten
    ihr Soll (höchstens die Dauer), die fertigen tragen den Rest."""
    n, je = einheit_zeit(mappe, alle, dauer)
    ids = [e["id"] for e in alle if e["id"] in je]
    leer_modus = False
    if str(dauer or "").isdigit() and any(not e.get("geplant") for e in alle):
        n = int(dauer)
        leer = [e["id"] for e in alle if e["id"] in je and e.get("geplant")]
        leer_modus = bool(nur_leere) and bool(liste) and len(leer) < len(ids)
        ziel = ids if not leer_modus else leer
        if not leer_modus or sum(je[i] for i in leer) > n:
            je = dict(je, **dict(zip(ziel, _skaliert([je[i] for i in ziel], n))))
    return n, je, sum(je.get(e["id"], 0) for e in liste), leer_modus


def teil_minuten(mappe, liste, teile, minuten, alle=None, nur_leere=False):
    """Minuten je Teil des Textes (AP13.3; seit AP13.35 §2.2 die Summe der Minuten seiner Karten, seit AP13.42 aus
    zeit_zahlen, damit Kopf, Gesamtsatz und Teilsätze nie auseinanderlaufen). -> ([Minuten je Teil], Minuten aller Teile)
    bzw. ([None …], None)"""
    gesamt, je, n_liste, leer = zeit_zahlen(mappe, liste, alle or liste, minuten, nur_leere)
    if not gesamt or not teile:
        return [None] * len(teile), None
    return [sum(je.get(e["id"], 0) for e in t) for t in teile], (n_liste if leer else gesamt)


def _ganze_abschnitte(liste, stueck):
    """Trägt der Teil nur ganze Abschnitte (etwa „Kachel für Kachel“)? Dann hat jeder seine eigene Überschrift."""
    gruppe = {}
    for i, (_, g) in enumerate(_gruppen(liste)):
        for e in g:
            gruppe[e["id"]] = i
    hier = {gruppe.get(e["id"]) for e in stueck}
    return all(sum(1 for e in stueck if gruppe.get(e["id"]) == g) == sum(1 for v in gruppe.values() if v == g) for g in hier)


def einheit_kontext(mappe, angaben):
    """AP13.35 §1.2: „Worum geht es in dieser Einheit?“ der laufenden Einheit. Die erste Einheit trägt ihn im Steckbrief
    (`kurs.kontext`, zugleich die Beschreibung des Kurses), eine angehängte in der Mappe (`einheit.kontext`); eine neue
    Einheit beginnt leer und erbt den Text der vorigen nicht. Leerraum zusammengezogen."""
    if M.laufende_einheit(mappe or {}):
        return " ".join(str(((mappe or {}).get("einheit") or {}).get("kontext") or "").split())
    return " ".join(str((angaben or {}).get("kontext") or "").split())


def _kontext(angaben, mappe=None):
    """„Worum geht es genau?“ (AP13.4) als Zeile „Auftrag der Einheit“ direkt unter dem Auftrag; in einer angehängten
    Einheit dazu die Beschreibung des Kurses als eine Zeile „Kurs: …“ (AP13.35 §1.2), nie als Auftrag."""
    p = _kat()["prompt"]
    t = einheit_kontext(mappe, angaben)
    z = [p["kontext"].format(text=t)] if t else []
    kurs = " ".join(str((angaben or {}).get("kontext") or "").split())
    if M.laufende_einheit(mappe or {}) and kurs:
        z.append(p["kontext_kurs"].format(text=kurs))
    return z


RICHTUNG_MAX = 400
LEHRPLAN_MAX = 1200


def _lehrplan_an(angaben):
    a = angaben or {}
    return a.get("lehrplanbezug") != "nein" and bool(a.get("lehrplan"))


_STOPP = {"eine", "einen", "einem", "einer", "eines", "dass", "auch", "oder", "ueber", "sich", "dies", "diese", "dieser",
          "dieses", "wird", "werden", "sind", "nach", "beim", "fuer", "dabei", "damit", "ihre", "ihren", "sowie", "kinder",
          "schueler", "klasse"}
_MIN_WORT = 4
_ENDUNGEN = ("ern", "en", "er", "es", "e", "n", "s")


def _faltung(t):
    return api._ascii(str(t or ""))


def _stamm(w):
    """Wort ohne Beugungsendung, solange vier Zeichen bleiben („lesen“ -> „lese“, „erschliessen“ -> „erschliess“)."""
    for e in _ENDUNGEN:
        if w.endswith(e) and len(w) - len(e) >= _MIN_WORT:
            return w[:-len(e)]
    return w


def _suchstaemme(thema, kontext):
    """Wortanfänge aus Thema und Kontextzeile: nach Faltung (ä -> ae) kleingeschrieben, ab vier Zeichen, ohne Füllwörter."""
    out = []
    for w in re.findall(r"[a-z]+", _faltung(f"{thema or ''} {kontext or ''}")):
        if len(w) >= _MIN_WORT and w not in _STOPP and _stamm(w) not in out:
            out.append(_stamm(w))
    return out


def _passung(staemme, *texte):
    """Zahl der Wortanfänge, die in einem Wort der Texte vorkommen (jeder Wortanfang je Text einmal)."""
    n = 0
    for t in texte:
        woerter = re.findall(r"[a-z]+", _faltung(t))
        n += sum(1 for s in staemme if any(w.startswith(s) for w in woerter))
    return n


def erwartungen_gewaehlt(angaben, thema=None, kontext=None):
    """AP13.29 §2: die Auswahl aus `kurs.lehrplan`, die Auftrag (lehrplan) und Gegenprüfen (fachcheck) gemeinsam
    nutzen. Mit angehakten Zielen: die Ziele wörtlich je Lernbereich. Ohne Ziele: die Erwartungen ALLER Lernbereiche,
    sortiert nach Passung zu Thema und Kontextzeile (Wortanfänge nach Faltung; je Erwartung zählen die Treffer im Text
    und im Titel ihres Teilbereichs; bei Gleichstand die Dateireihenfolge), bis 1 200 Bytes erreicht sind; Köpfe nur für
    Lernbereiche mit gewählten Erwartungen, Erwartungen im Lernbereich in Dateireihenfolge. Das Byte-Budget rechnet mit
    der längsten Minutenangabe („9999“), damit die Auswahl nicht von den Minuten abhängt.
    -> {zeilen (ohne Schlusszeilen), erwartungen (Texte, in Zeilenfolge), schluss (Zeilen mit {minuten}), gekuerzt,
    ziele (Zahl), mit_zielen}"""
    a = angaben or {}
    thema = a.get("thema") if thema is None else thema
    kontext = a.get("kontext") if kontext is None else kontext
    lp, t = a["lehrplan"], _kat()["prompt"]["lehrplan"]
    lbs = lp.get("lernbereiche") or []
    mit_zielen = any(z for lb in lbs for tb in lb.get("teilbereiche") or [] for z in tb.get("ziele") or [])
    schluss = [t["ausschnitt"]] + ([] if mit_zielen else [t["ohne_ziel"]])
    breit = [schluss[0].format(minuten="9999")] + schluss[1:]
    groesse = lambda zz: len("\n".join(zz).encode("utf-8"))
    zeilen, erw, gekuerzt, n_ziele = [], [], False, 0

    def kopf(lb):
        return t["kopf"].format(fach=lp.get("fach") or "", zusatz=f" ({lp['zusatz']})" if lp.get("zusatz") else "",
                                jahrgang=lp.get("jahrgangsstufe") or "",
                                kuerzel=lb.get("kuerzel") or "", titel=lb.get("titel") or "").replace("  ", " ")

    def dazu(zeile, liste=zeilen):
        neu = [zeile]
        if zeile.startswith("- ") and not any(z == t["sus"] for z in liste):
            neu = [t["sus"], zeile]           # einmal, vor der ersten Erwartung
        if groesse(liste + neu + breit) <= LEHRPLAN_MAX:
            liste.extend(neu)
            return True
        return False
    if mit_zielen:
        for lb in lbs:
            if not dazu(kopf(lb)):
                gekuerzt = True
                break
            tbs = lb.get("teilbereiche") or []
            ziele = [z for tb in tbs for z in tb.get("ziele") or []]
            if ziele:
                dazu(t["ziel"])
            for z in ziele:
                if dazu("- " + z):
                    n_ziele += 1
                    erw.append(z)
                else:
                    gekuerzt = True
            rahmen = [t["rahmen_eintrag"].format(titel=tb["titel"], n=len(tb.get("rahmen") or []),
                                                 en="" if len(tb.get("rahmen") or []) == 1 else "en")
                      for tb in tbs if tb.get("rahmen")]
            if rahmen:
                dazu(t["rahmen"].format(liste="; ".join(rahmen)))
    else:
        staemme = _suchstaemme(thema, kontext)
        kand = []                              # (Passung, Reihenfolge, Lernbereich, Text)
        for i, lb in enumerate(lbs):
            for tb in lb.get("teilbereiche") or []:
                for z in tb.get("rahmen") or []:
                    kand.append((_passung(staemme, z, tb.get("titel")), len(kand), i, z))
        gewaehlt = {}                          # Lernbereich -> Positionen der gewählten Erwartungen
        for passung, pos, i, z in sorted(kand, key=lambda k: (-k[0], k[1])):
            probe = {**gewaehlt, i: sorted(gewaehlt.get(i, []) + [pos])}
            neu = _lehrplan_zeilen(lbs, probe, {k[1]: k[3] for k in kand}, kopf, t["sus"])
            if groesse(neu + breit) > LEHRPLAN_MAX:
                gekuerzt = gekuerzt or i not in gewaehlt
                break
            gewaehlt = probe
        zeilen = _lehrplan_zeilen(lbs, gewaehlt, {k[1]: k[3] for k in kand}, kopf, t["sus"])
        erw = [z[2:] for z in zeilen if z.startswith("- ")]
    return {"zeilen": zeilen, "erwartungen": erw, "schluss": schluss, "gekuerzt": gekuerzt, "ziele": n_ziele,
            "mit_zielen": mit_zielen}


def _lehrplan_zeilen(lbs, gewaehlt, text, kopf, sus):
    """Zeilen für die gewählten Erwartungen (Lernbereich -> Positionen): Kopf je Lernbereich, einmal „Die Schülerinnen und
    Schüler …“, die Erwartungen in Dateireihenfolge."""
    z = []
    for i, lb in enumerate(lbs):
        if gewaehlt.get(i):
            z.append(kopf(lb))
            if sus not in z:
                z.append(sus)
            z += ["- " + text[p] for p in gewaehlt[i]]
    return z


def lehrplan(angaben, minuten=None, thema=None, kontext=None):
    """AP13.6: Block „Lehrplan (LehrplanPLUS, ISB)“ unter der Kontextzeile, je Lernbereich ein Kopf; zusammen höchstens
    1 200 Bytes. Mit angehakten Zielen: die Ziele wörtlich unter „Ziel dieser Einheit:“, die übrigen Teilbereiche nur als
    Titel mit der Zahl ihrer Erwartungen; ohne Ziele die zum Thema passenden Erwartungen wörtlich (AP13.29: Auswahl in
    `erwartungen_gewaehlt`, die auch der Fachcheck nutzt), und der Satz, dass das Modell den Aspekt wählt. „Die
    Schülerinnen und Schüler …“ steht einmal. Ohne Haken „Lehrplanbezug“ leer.
    -> {zeilen, bytes, gekuerzt (Ziele fielen weg), ziele (Zahl), ohne_ziele (bool)}"""
    leer = {"zeilen": [], "bytes": 0, "gekuerzt": False, "ziele": 0, "ohne_ziele": False}
    if not _lehrplan_an(angaben):
        return leer
    w = erwartungen_gewaehlt(angaben, thema, kontext)
    schluss = [w["schluss"][0].format(minuten=minuten or "?")] + w["schluss"][1:]
    zeilen = w["zeilen"] + schluss
    return {"zeilen": zeilen, "bytes": len("\n".join(zeilen).encode("utf-8")), "gekuerzt": w["gekuerzt"],
            "ziele": w["ziele"], "ohne_ziele": not w["mit_zielen"]}


def richtung(mappe, angaben, grundschule=False):
    """AP13.5b: Zeilen des Zweigs „Ich gebe die Richtung“ unter dem Auftrag (optional, zusammen höchstens 400 Bytes):
    Schwerpunkt und Sprache in „Ich gebe die Richtung“ und „Ich steuere“, bevorzugte Übungstypen nur in „Ich gebe die
    Richtung“ (in „Ich steuere“ tragen die Karten die Typen); in „Mach du“ keine. `einfach` fügt bei aktiver
    Grundschul-Regel nichts hinzu (dieselbe Forderung steht dort schon)."""
    zweig = (mappe or {}).get("zweig")
    if zweig not in ("richtung", "steuer"):
        return []
    r, a = _kat()["prompt"]["richtung"], angaben or {}
    z = []
    wort = ZA.fachwoerter_aus(a)             # AP13.24: {material} und {produkt} nach dem Fach
    sp = [{k: v.format(**wort) for k, v in r["schwerpunkte"][w].items()}
          for w in a.get("schwerpunkt") or [] if w in r["schwerpunkte"]]
    if sp:
        z.append(r["schwerpunkt"].format(was=" und ".join(x["was"] for x in sp),
                                         pruefen=" und ".join(x["pruefen"] for x in sp)))
    if zweig == "richtung" and a.get("uebungstypen"):
        z.append(r["uebungstypen"].format(typen=", ".join(a["uebungstypen"])))
    if a.get("sprache") in r["sprache"] and not (grundschule and a["sprache"] == "einfach"):
        z.append(r["sprache"][a["sprache"]])
    if sp and len("\n".join(z).encode()) > RICHTUNG_MAX:     # alles gewählt: Schwerpunkt ohne den Prüfsatz
        z[0] = f"Schwerpunkt: {' und '.join(x['was'] for x in sp)}."
    return z


_HILFE_TYPEN = {"Quiz", "Lückentext", "Zuordnen"}


def differenzierung(mappe, angaben):
    """AP13.14: Schalter „Hilfen und Zusatzaufgaben“ (`kurs.differenzierung`) wirkt nur in „Ich gebe die Richtung“ und
    „Ich steuere“; aus = Text wie bisher."""
    return bool((angaben or {}).get("differenzierung")) and (mappe or {}).get("zweig") in ("richtung", "steuer")


def hilfen_an(mappe, angaben, typen):
    """Hilfen im Text nur mit Schalter, Übungen auf der Kursseite (`website: textfeld`; als H5P-Aktivität zeigt keine
    Übung Hilfen) und einem Typ, der sie zeigt (Quiz, Lückentext, Zuordnen)."""
    return differenzierung(mappe, angaben) and (angaben or {}).get("website") == "textfeld" \
        and bool(set(typen) & _HILFE_TYPEN)


def _hilfe_format(mappe, angaben, typen):
    """Formatzeile zu `Hilfe:` (eine Stelle für Teil 1, Teil 2 ff. und „Nur dieser Baustein“)."""
    return ["- " + _kat()["prompt"]["differenzierung"]["hilfe_format"]] if hilfen_an(mappe, angaben, typen) else []


def satz_mittel(mappe, angaben):
    """AP13.14: Richtwert „Sätze im Mittel höchstens N Wörter“ für die Jahrgangsstufe der Einheit (`sprache_richtwerte`),
    mit Ab- oder Zuschlag für `kurs.sprache` nur in „Ich gebe die Richtung“ und „Ich steuere“, mit Lehrplan der
    Förderschule immer `einfach` (wie die Prüfung, `sprache.sprache_fuer`)."""
    from . import sprache as SP
    jahrgang = ((mappe or {}).get("einheit") or {}).get("jahrgang") or (angaben or {}).get("jahrgang")
    return SP.richtwert(jahrgang, SP.sprache_fuer(mappe, angaben))["satz_mittel"]


def bevorzugt(mappe, angaben):
    """Bevorzugte Übungstypen, die im Text bleiben (nur Zweig „Ich gebe die Richtung“)."""
    return (angaben or {}).get("uebungstypen") if (mappe or {}).get("zweig") == "richtung" else None


def _foerderschule(angaben):
    """AP13.18: Name des Förderschwerpunkts, wenn ein Lernbereich aus dem Lehrplan der Förderschule gewählt ist (erst
    der Förderschwerpunkt sagt das Niveau), sonst „“."""
    return M.foerderschwerpunkt(angaben.get("lehrplan")) if _lehrplan_an(angaben) else ""


def _grundschule(jahrgang, angaben):
    # AP13.5f: nur Jahrgangsstufe (auch im Feld „Zielgruppe“) oder Schulart, unabhängig vom Haken „Lehrplanbezug“
    jg = M.jahrgang_zahl(jahrgang)
    return (bool(jg) and int(jg) <= 4) or (angaben.get("schulart") or "") == "Grundschule"


def _einheit_text(mappe, angaben, ch, liste, alle, material, teil, von, nur_leere, anteil=None, erste=None, anhang=True):
    """Text eines Teils. `anteil` = (Minuten dieses Teils, Minuten aller Teile, nur ganze Abschnitte) aus teil_minuten,
    `erste` = Karten von Teil 1 (Teil 2
    und folgende wiederholen Format und Prüfliste nicht, nur die Formatzeilen der Typen, die Teil 1 nicht hatte). `anhang`:
    der Satz zu angehängten Dateien (AP13.24 §9) steht vor dem Format; im API-Weg ohne Anhänge entfällt er."""
    k = _kat()
    p = k["prompt"]
    # AP13.35 M2: eine Zahl für die Einheit (Kopf, Zeitregeln, Teile); Karten ohne eigene Minuten tragen ihren Anteil
    dauer = (mappe.get("einheit") or {}).get("minuten") or angaben.get("minuten")
    n_einheit, je, n_liste, nur_leere_ = zeit_zahlen(mappe, liste, alle, dauer, nur_leere)       # AP13.42 B5: eine Zahl für alles
    auftrag, thema, minuten = _auftrag(mappe, angaben, n_einheit)
    jahrgang = (mappe.get("einheit") or {}).get("jahrgang") or angaben.get("jahrgang")
    selbst = zeit_selbst(mappe)
    folge = von > 1 and teil > 1

    angebot = M.auto_typen(alle, bevorzugt(mappe, angaben), angaben)   # AP13.4: acht Typen, bei mehr als vier Karten sechs

    def typen_von(karten):
        # Typen zur Wahl auch ohne Karte „automatisch“, sobald die Zeitregel zum Ergänzen auffordert (Prompttest AP13.1, Lauf C)
        out, auto_ = [], any(e.get("typ") == AUTO for e in karten) or bool(minuten)
        for e in karten:
            if e.get("typ") and e["typ"] != AUTO and e["typ"] not in out:
                out.append(e["typ"])
        if auto_:
            out += [t for t in angebot if t not in out]
        return out, auto_
    typen, auto = typen_von(liste)
    if folge:
        schon = set(typen_von(erste or [])[0])
        z = [p["einheit_teil"], "", "Auftrag", auftrag, ""]
    else:
        fs = _foerderschule(angaben)
        z = ([p["einheit"], "", "Auftrag", auftrag] + _kontext(angaben, mappe) + _sequenz(mappe, angaben)
             + lehrplan(angaben, minuten, thema, einheit_kontext(mappe, angaben))["zeilen"]
             + richtung(mappe, angaben, bool(fs) or _grundschule(jahrgang, angaben)) + [p["lernende"]])
        if fs:                                        # AP13.18: statt der Grundschulzeile
            z.append(p["foerderschule"].format(name=fs))
        elif _grundschule(jahrgang, angaben):
            z.append(p["grundschule"])
        z.append("")
        z.append("Vorgaben, schon entschieden (übernimm diese Zeilen unverändert in den Kopf):")
        z += _angenommen(angaben)
        z.append(p["angenommen_nur"])
        z.append("")
    if nur_leere and not folge:
        fertig = [e for e in alle if not e.get("geplant") and e.get("typ") not in M.struktur()]
        if fertig:
            z.append("Diese Bausteine der Einheit gibt es schon, schreib sie nicht noch einmal: "
                     + "; ".join(f"„{e['titel']}“" for e in fertig) + ".")
    if von > 1:
        z.append(p["teil"].format(n=teil, von=von, weiter=p["teil_weiter"] if teil < von else p["teil_letzter"]))
    z.append("Bausteine (genau diese, in dieser Reihenfolge; Arbeitstitel ersetzt du durch einen Titel, der sagt, "
             "worum es geht):")
    nr = {e["id"]: i + 1 for i, e in enumerate(alle)}
    tag = M.laufende_einheit(mappe)
    for abschnitt, gruppe in _gruppen(liste):
        z.append(f"Abschnitt „{abschnitt or thema}“" + (f" · {minuten} min" if minuten and von == 1 and len(_gruppen(alle)) == 1 else ""))
        kt = kachel_text(mappe, abschnitt, tag) if abschnitt else ""
        if kt:                                        # AP13.31: „Was soll hier rein?“ der Kachel, wörtlich
            z.append(p["kachel"].format(text=kt))
        z += [_zeile(dict(e, soll=je[e["id"]]) if selbst and e["id"] in je else e, nr[e["id"]],
                     jahrgang, selbst) for e in gruppe]
    if auto and not folge:
        # AP13.35 §3.6: „Typ frei“ nur, wenn eine Karte so in der Liste steht; sonst gilt die Wahl nur für ergänzte
        frei = any(e.get("typ") == AUTO for e in liste)
        z += [p["automatisch" if frei else "automatisch_ergaenzt"]] \
            + [f"- {t}: {M.auto_text(t)}" for t in angebot] + [p["automatisch_zwei"]]
    n_teil, n_alle, ganz_ab = anteil if von > 1 and anteil and anteil[0] else (None, None, False)
    if not selbst and minuten and not folge:
        zb, f = k["zeitbedarf"], M._jahrgang_faktor(jahrgang)
        wpm = zb["woerter_je_minute"]
        zahl = lambda x: f"{x:g}".replace(".", ",")
        z.append(p["zeit_frei"].format(minuten=n_teil or (n_liste if nur_leere_ else minuten), lesen=int(round(wpm["lesen"] * f)),
                                       einstieg=int(round(wpm["einstieg"] * f)), heft=int(round(zb["abschreiben"] * f)),
                                       einfach=zahl(zb["aufgabe_minuten"]["einfach"]),
                                       rechnen=zahl(zb["aufgabe_minuten"]["rechnen"])))
    if minuten:
        if nur_leere_:      # AP13.42 B5: die fertigen Karten tragen den Rest der Dauer
            z.append(p["zeit_teil_leer"].format(minuten=minuten, leer=n_alle, n=n_teil) if n_teil
                     else p["zeit_leer"].format(minuten=minuten, leer=n_liste))
        else:
            z.append(p["zeit_teil_abschnitt" if ganz_ab else "zeit_teil"].format(minuten=n_alle, n=n_teil) if n_teil
                     else p["zeit_summe"].format(minuten=minuten))
        if not folge:
            z.append(p["zeit"].format(minuten=minuten))
    z.append("")
    if folge:
        neu = [t for t in typen if t not in schon]
        z.append(p["teil_format"])
        regeln = zaehlregeln(liste, neu, uebung=False, jahrgang=jahrgang)     # Mindestmaße der Typen, die neu dazukommen
        if neu or regeln:
            z.append("")
            z += _format(neu, ch, kopf=False, nur_typen=True, angaben=angaben, mappe=mappe) if neu else []
            z += ["- " + r for r in regeln]
        z += ["", p["ausgabe_teil"].format(als="als ein Codeblock" if ch.get("codeblock", True) else "als reiner Text"),
              p["abbruch"]]
        return "\n".join(z) + "\n", typen
    if material and teil == 1:
        z += ["Material der Lehrkraft (nutze es als Grundlage; Tatsachen daraus haben Vorrang vor deinen):",
              material.strip(), ""]
    if anhang:
        z += [p["anhang"], ""]
    z += _format(typen, ch, angaben=angaben, mappe=mappe)
    z += ["", "Vorgaben für den Inhalt (zähle nach, bevor du ausgibst):"] + ["- " + r for r in p["leitplanken"]]
    if hilfen_an(mappe, angaben, typen):
        z.append("- " + p["differenzierung"]["hilfen"])
    z += ["- " + r for r in zaehlregeln(liste, typen, jahrgang=jahrgang)]
    if braucht_skizze(angaben, thema) and bilder_saetze(angaben)[0]:
        z.append("- " + p["skizze"])
    z += ["", "Prüfe vor der Ausgabe:"] + ["- " + r.replace("{satz_mittel}", str(satz_mittel(mappe, angaben)))
                                           for r in p["checkliste"]]
    z += [""] + _ausgabe(ch)
    z = _sequenz_regeln(mappe, liste, z)
    return "\n".join(z) + "\n", typen


def _groesse(t):
    return len(t.encode("utf-8"))


def _sequenz(mappe, angaben):
    """AP13.40: in einer Sequenz mit Plan nennt der Text jeder Stunde die Sequenz in einer Zeile (Themen aller Stunden)
    und das Ziel der Stunde; ohne Sequenz nichts (der Text bleibt byte-gleich)."""
    sq = M.sequenz_stunde(mappe)
    if not sq or M.sequenz_offen(mappe):
        return []
    p = _kat()["prompt"]
    themen = "; ".join(f"{i} {t}" if t else str(i) for i, t in enumerate(sq["themen"], 1))
    reihe = (mappe or {}).get("titel") or (angaben or {}).get("thema") or ""
    z = [p["sequenz_stunde"].format(reihe=reihe, n=sq["n"], von=sq["von"], themen=themen)]
    if sq["ziel"]:
        z.append(p["sequenz_ziel"].format(ziel=" ".join(sq["ziel"].split())))
    return z


def _sequenz_regeln(mappe, liste, z):
    """AP13.40 (Korrekturrunde, Punkt 7): in einer Stunde einer Sequenz gelten Regeln nur für Bausteine, die in der Liste
    stehen. Fehlt der Stunde eine Rolle (Einstieg, Erarbeitung, Übung, Sicherung), fallen die Leitplanken weg, die sie
    voraussetzen (`sequenz_braucht`), und die Sätze zu Einstieg und Erarbeitung; mit einem Test im Plan fällt die Zeile
    „Kein Abschlusstest“ weg. Ohne Sequenz bleibt der Text, wie er ist."""
    if not M.sequenz_stunde(mappe) or M.sequenz_offen(mappe):
        return z
    p = _kat()["prompt"]
    rollen = {M.rolle_von(e) for e in liste}
    weg = {"- " + r for r in p["leitplanken"] for b in p["sequenz_braucht"]
           if r.startswith(b["anfang"]) and not set(b["rollen"]) <= rollen}
    saetze = ([p["sequenz_satz_erarbeitung"]] if "lesen" not in rollen else []) + \
        ([p["sequenz_satz_einstieg"]] if "einstieg" not in rollen else [])
    kein_test = "Angenommen: " + _text_von("abschluss", "keiner")
    test = any(e.get("typ") == "Test" for e in liste)
    # AP13.41 (Korrekturrunde, Punkt 8): Satzteile zu Rollen, die der Plan der Stunde nicht hat, und die Phasenfolge
    teile = [t["text"] for t in p["sequenz_teile"] if not set(t["rollen"]) <= rollen]
    folge = p["sequenz_phasenfolge"]
    alt = ", ".join(folge)
    neu = ", ".join(ph for ph, r in folge.items() if r in rollen)
    out = []
    for zeile in z:
        if zeile in weg or (test and zeile == kein_test):
            continue
        for satz in saetze:
            zeile = zeile.replace(" " + satz, "")
        for t in teile:
            zeile = zeile.replace(t, "")
        zeile = zeile.replace("kann: ;", "kann;")
        if neu:
            zeile = zeile.replace("Phasenfolge " + alt + ",", "Phasenfolge " + neu + ",")
        out.append(zeile)
    return out


def _sequenz_fest(mappe):
    """AP13.40 (Punkt 15): in „Ich steuere“ die Stunden, die die Lehrkraft schon geplant hat, je eine Zeile; der Chat
    übernimmt sie, sequenzplan_einsetzen behält ihre Karten."""
    if (mappe or {}).get("zweig") != "steuer":
        return []
    p = _kat()["prompt"]
    out = []
    for i, _ in enumerate((mappe.get("sequenz") or {}).get("stunden") or [], 1):
        tag = M.stunde_tag(i)
        els = [e for e in mappe.get("bausteine", []) if (e.get("einheit") or "") == tag and e.get("geplant")
               and not e.get("aus")]
        if els:
            out.append(p["sequenzplan_fest"].format(n=i, elemente="; ".join(
                (f"{e['phase']}: " if e.get("phase") else "") + ("Typ frei" if e.get("typ") == AUTO else e.get("typ", ""))
                + (f" | {e['titel']}" if e.get("titel") else "") for e in els)))
    return out


def sequenzplan(mappe, steckbrief=None, chat_wert=None, material=None, anhang=True):
    """AP13.40: erster Text einer Sequenz. Er holt nur den Sequenzplan: je Stunde Thema, ein Satz Ziel und die Phasen
    mit Typvorschlag (eine Formatzeile aus dem Katalog, kein Inhalt). Thema, Schulart, Jahrgang, Lehrplanbezug, Weg
    („Ich gebe die Richtung“: Schwerpunkt, Themen je Stunde) und Material gelten für die ganze Reihe.
    -> wie einheit(): {teile: [Text], groessen, ids: [[]], typen: [[]], minuten: [None]}"""
    ch = chat(chat_wert if chat_wert is not None else mappe.get("chat"))
    angaben = M.angaben_lesen(steckbrief or "")
    p = _kat()["prompt"]
    s = mappe.get("sequenz") or {}
    stunden = [x if isinstance(x, dict) else {} for x in s.get("stunden") or []]
    von = len(stunden)
    minuten = (mappe.get("einheit") or {}).get("minuten") or angaben.get("minuten") or 45
    auftrag, thema, _ = _auftrag(mappe, angaben, f"{von} Stunden zu je {minuten}")
    z = [p["sequenzplan"].format(stunden=von), "", "Auftrag", auftrag] + _kontext(angaben, mappe)
    z += lehrplan(angaben, int(minuten) * von, thema, einheit_kontext(mappe, angaben))["zeilen"]
    z += richtung(mappe, angaben)
    vorgabe = [str(x.get("thema") or "").strip() for x in stunden]
    if any(vorgabe):
        z.append(p["sequenzplan_themen"].format(themen="; ".join(f"{i} {t}" if t else f"{i} –"
                                                                   for i, t in enumerate(vorgabe, 1))))
    z += _sequenz_fest(mappe)
    v = M._vorlage(mappe)
    if v:
        z.append(p["sequenzplan_phasen"].format(phasen=", ".join(ph["phase"] for ph in v["phasen"]
                                                                 if not ph.get("optional"))))
    material = material if material is not None else mappe.get("material", "")
    if material and material.strip():
        z += ["", "Material der Lehrkraft (nutze es als Grundlage; Tatsachen daraus haben Vorrang vor deinen):",
              material.strip()]
    z.append("")
    if anhang:
        z.append(p["anhang"])
    z.append(p["sequenzplan_format"].format(minuten=minuten, typen=", ".join(M.sequenz_typen())))
    z.append(p["sequenzplan_ausgabe"].format(stunden=von, minuten=minuten, als="als ein Codeblock"
                                             if ch.get("codeblock", True) else "als reiner Text"))
    t = "\n".join(z) + "\n"
    return {"teile": [t], "groessen": [_groesse(t)], "ids": [[]], "typen": [[]], "minuten": [None]}


def einheit(mappe, steckbrief=None, chat_wert=None, material=None, nur_leere=False, grenze=GRENZE, anhang=True,
            je_kachel=False):
    """Text „Diese Einheit“ (oder mit nur_leere „Alle leeren Bausteine“). Sprengt der Text die Grenze oder hat er mehr
    Bausteine, als der Chat je Antwort schafft (`teil_bausteine`), stückelt die Seite nach Abschnitten, notfalls
    innerhalb eines Abschnitts; jeder Teil sagt „Teil n von m“ und nennt seinen Anteil an den Minuten. Nur Karten der
    laufenden Einheit (AP13.3). Steht in der Mappe eine eingefrorene Stückelung (`stueckelung`, gesetzt beim ersten
    Kopieren, gelöscht, wenn alle Teile eingefügt sind) für diese Einheit und Textart, gelten ihre Teile.
    `anhang=False` lässt den Satz zu angehängten Dateien weg (Weg über die API ohne Anhänge, AP13.24 §9).
    `je_kachel` (AP13.31, „Kachel für Kachel“): ein Teil je Abschnitt, sobald es mehr als einen gibt; dieselben Teile wie
    bei der Stückelung, eingefroren beim ersten Kopieren. `grenze=None` gilt als GRENZE (Aufruf aus dem Browser).
    -> {teile: [Text], groessen: [Bytes], ids: [[id]], typen: [[Typ]], minuten: [Minuten je Teil]}"""
    ch = chat(chat_wert if chat_wert is not None else mappe.get("chat"))
    angaben = M.angaben_lesen(steckbrief or "")
    material = material if material is not None else mappe.get("material", "")
    tag = M.laufende_einheit(mappe)
    alle = [e for e in mappe.get("bausteine", []) if e.get("typ") != "Badge" and not e.get("aus")
            and (e.get("einheit") or None) == tag]
    liste = [e for e in alle if e.get("geplant")] if nur_leere else alle
    st = mappe.get("stueckelung") or {}
    if st.get("ids") and (st.get("einheit") or None) == tag and bool(st.get("leer")) == bool(nur_leere):
        nach_id = {e["id"]: e for e in alle}
        teile = [[nach_id[i] for i in ids if i in nach_id] for ids in st["ids"]]
        liste = [e for t in teile for e in t]
        if liste:
            return _teile_texte(mappe, angaben, ch, liste, alle, material, nur_leere, teile, anhang)
    if not liste:
        return {"teile": [], "groessen": [], "ids": [], "typen": [], "minuten": []}
    grenze = GRENZE if grenze is None else grenze
    if je_kachel and len(_gruppen(liste)) > 1:
        return _teile_texte(mappe, angaben, ch, liste, alle, material, nur_leere, [g for _, g in _gruppen(liste)], anhang)
    n = ch.get("teil_bausteine") or len(liste)

    ganz, typen = _einheit_text(mappe, angaben, ch, liste, alle, material, 1, 1, nur_leere, anhang=anhang)
    if _groesse(ganz) <= grenze and len(liste) <= n:
        return {"teile": [ganz], "groessen": [_groesse(ganz)], "ids": [[e["id"] for e in liste]], "typen": [typen],
                "minuten": [(lambda z: z[2] if nur_leere else z[0])(zeit_zahlen(
                    mappe, liste, alle, (mappe.get("einheit") or {}).get("minuten") or angaben.get("minuten"), nur_leere))]}
    # Teile: ganze Abschnitte, solange sie passen; ein Abschnitt, der nicht passt, füllt den laufenden Teil Baustein für
    # Baustein auf (Grenze: Bytes und Bausteine je Teil; Teil 1 mit Format und Prüfliste, die übrigen ohne)
    teile = [[]]
    minuten_e = (mappe.get("einheit") or {}).get("minuten")          # nur für die Größe beim Probieren

    def passt(stueck):
        erster = len(teile) == 1
        t = _einheit_text(mappe, angaben, ch, stueck, alle, material, 1 if erster else 2, 2, nur_leere,
                          (minuten_e, minuten_e, False),
                          None if erster else teile[0], anhang)[0]
        return len(stueck) <= n and _groesse(t) <= grenze

    for _, gruppe in _gruppen(liste):
        if passt(teile[-1] + gruppe):
            teile[-1] += gruppe
            continue
        if teile[-1]:
            teile.append([])
            if passt(gruppe):
                teile[-1] += gruppe
                continue
        for e in gruppe:
            if teile[-1] and not passt(teile[-1] + [e]):
                teile.append([])
            teile[-1].append(e)
    return _teile_texte(mappe, angaben, ch, liste, alle, material, nur_leere, teile, anhang)


def _teile_texte(mappe, angaben, ch, liste, alle, material, nur_leere, teile, anhang=True):
    teile = [t for t in teile if t]
    von = len(teile)
    minuten = (mappe.get("einheit") or {}).get("minuten")
    ns, gesamt = teil_minuten(mappe, liste, teile, minuten, alle, nur_leere) if von > 1 else ([minuten], minuten)
    texte = [_einheit_text(mappe, angaben, ch, t, alle, material, i + 1, von, nur_leere,
                           (ns[i], gesamt, _ganze_abschnitte(liste, t)), teile[0], anhang)
             for i, t in enumerate(teile)]
    return {"teile": [t for t, _ in texte], "groessen": [_groesse(t) for t, _ in texte],
            "ids": [[e["id"] for e in t] for t in teile], "typen": [ty for _, ty in texte], "minuten": ns}


def baustein(mappe, ids, kurs_md="", steckbrief=None, chat_wert=None, kontext=900, pruefung=None, anhang=True,
             aussen=None):
    """Text „Nur dieser Baustein“ für eine oder mehrere markierte Karten: Auftrag, die Zeile der Bausteinliste, Format
    nur für diesen Typ, der bisherige Inhalt (gekürzt) als Kontext und, mit `pruefung`, die Fehler der Prüfung. Ziel
    etwa 1 KB je Baustein. `anhang=False` lässt den Satz zu angehängten Dateien weg (AP13.24 §9). `kontext`: Zeichen des
    bisherigen Inhalts, als Zahl für alle oder als {id: Zahl oder None (ungekürzt)} mit dem Schlüssel „_“ für die übrigen
    (AP13.11 §8.4: von Hand geänderte Bausteine gehen ungekürzt mit). `aussen` (AP13.35 §3.1): Punkte der Korrekturbitte
    ohne Baustein (korrektur(), etwa die Zeile `Angenommen:`); ihre Sätze stehen unter der Liste, und die eine
    Ausgabeanweisung am Ende nennt dann auch den Kopf der Kursdatei (oder die ganze Kursdatei)."""
    if isinstance(ids, str):
        ids = [ids]
    ch = chat(chat_wert if chat_wert is not None else mappe.get("chat"))
    p = _kat()["prompt"]
    angaben = M.angaben_lesen(steckbrief or "")
    alle = mappe.get("bausteine", [])
    nr = {e["id"]: i + 1 for i, e in enumerate(alle)}
    liste = [e for e in alle if e["id"] in ids]
    bisher = {}
    if (kurs_md or "").strip():
        bisher = {b["id"]: b["text"] for b in api.pruefe(kurs_md)["bausteine"]}
    tag = M.laufende_einheit(mappe)
    auftrag, _, _ = _auftrag(mappe, angaben, einheit_zeit(mappe, [e for e in alle if not e.get("aus") and
                                                                  (e.get("einheit") or None) == tag],
                                                           (mappe.get("einheit") or {}).get("minuten")
                                                           or angaben.get("minuten"))[0])
    z = [p["baustein"] if len(liste) == 1 else p["baustein"].replace("einen Baustein", "diese Bausteine")
         .replace("nur diesen Baustein", "nur diese Bausteine"), "", "Einheit: " + auftrag, p["lernende"], ""]
    typen = []
    jahrgang = (mappe.get("einheit") or {}).get("jahrgang") or angaben.get("jahrgang")
    kacheln = set()
    for e in liste:
        kt = kachel_text(mappe, e.get("abschnitt"), e.get("einheit")) if e.get("abschnitt") else ""
        if kt and e["abschnitt"] not in kacheln:      # AP13.31: „Was soll hier rein?“ der Kachel, einmal je Kachel
            kacheln.add(e["abschnitt"])
            z.append(f"Abschnitt „{e['abschnitt']}“. " + p["kachel"].format(text=kt))
        z.append(_zeile(e, nr[e["id"]], jahrgang, zeit_selbst(mappe)))
        for t in (M.auto_typen(alle, bevorzugt(mappe, angaben)) if e["typ"] == AUTO else [e["typ"]]):
            if t not in typen:
                typen.append(t)
        alt = bisher.get(e["id"])
        grenze = kontext.get(e["id"], kontext.get("_", 900)) if isinstance(kontext, dict) else kontext
        if alt and not e.get("geplant"):
            alt = alt.strip()
            if grenze is not None and len(alt) > grenze:
                alt = alt[:grenze].rsplit("\n", 1)[0] + "\n…"
            z += ["Bisheriger Inhalt (verbessern, nicht wiederholen):", "```", alt, "```"]
        meldungen = [d for d in (pruefung or {}).get("diagnosen", []) if d.get("baustein") == e["id"] and d["stufe"] == "fehler"]
        for d in meldungen:
            z.append("Die Prüfung meldet" + (f" in Zeile {d['zeile_im_baustein']}" if d.get("zeile_im_baustein") else "")
                     + f": {d['text'].rstrip('. ')}.")
    aussen = [x for x in aussen or [] if not x.get("baustein") and (x.get("kern") or x.get("satz"))]
    z += [x.get("kern") or x["satz"] for x in aussen]
    if any(e["typ"] == AUTO for e in liste):
        z += [p["automatisch"]] + [f"- {t}: {M.auto_text(t)}" for t in M.auto_typen(alle, bevorzugt(mappe, angaben), angaben)]
    z += ["- " + r for r in zaehlregeln(liste, typen, uebung=False, jahrgang=jahrgang)]
    z.append("")
    if anhang:
        z += [p["anhang"], ""]
    k = _kat()
    z += ["Format", p["platzhalter_kurz"]]
    z += ["- " + k["gemeinsam"]["regeln"][0], "- " + k["gemeinsam"]["regeln"][1]]
    if set(typen) & _TEXTTYPEN:
        z.append("- " + p["textbausteine"])
    if set(typen) & _FRAGETYPEN:
        z.append("- " + p["fragen"])
    if "Test" in typen:
        z.append("- " + p["fragen_test"])
    z += _hilfe_format(mappe, angaben, typen)
    for e in k["typen"]:
        if e["typ"] in typen:
            z += ["```"] + _beispiel(e) + ["```"] + _regeln(e)
    z.append("")
    arten = {x.get("ausgabe") for x in aussen}
    if "ganz" in arten:                               # ein Teil der Antwort war nicht zu lesen: die ganze Kursdatei
        z += _ausgabe(ch)[:2]
    else:
        vorn = p["korrektur_ausgabe"]["teil_kopf"] + " und " if arten & {"kopf", "bilder"} else ""
        z.append(("Ausgabe: " + vorn + "nur " + ("dieser Baustein" if len(liste) == 1 else "diese Bausteine")
                  + (" als ein Codeblock" if ch.get("codeblock", True) else " als reiner Text")
                  + ", ohne Text davor oder danach; in der Zeile unter der Überschrift `id:` genau wie oben."))
    return "\n".join(z) + "\n"


# ---------------------------------------------------------------- Korrekturbitte
# Meldung der Prüfung -> Satz aus `prompt.korrektursaetze` (AP13.4 §2). Reihenfolge zählt: das erste Muster gewinnt.
_SAETZE = [
    (r"^Zone „(?P<wert>[^“]*)“ nicht in zonen \((?P<zonen>.*)\)$", "zone"),
    (r"^Zuordnen: nur eine Liste", "zuordnen_liste"),
    (r"^id „(?P<wert>[^“]*)“ ist doppelt", "id_doppelt"),
    (r"^Zuordnen: `zonen", "zonen_fehlt"),
    (r"^(?:Quiz|Test) ohne Fragen$|^Zuordnen ohne Elemente$|^Lernkarten ohne Karten$|^Umfrage ohne Fragen$", "leer"),
    (r"^(?:Quiz|Test): jede Frage beginnt mit", "frage_anfang"),
    (r"^MC ohne ✔|^MC: keine Antwort mit ✔", "mc_haken"),
    (r"^MC: mindestens zwei Antworten", "mc_zwei"),
    (r"^RF: Aussage mit ✔", "rf_haken"),
    (r"^RF: Rückmeldung", "rf_rueck"),
    (r"^(?:Einsetzen|Markieren|Lückentext): Text mit \*", "luecken"),
    (r"^(?:Lückentext|Einsetzen): (?P<rest>Rückmeldungen gibt es hier nicht.*)$", "rueckmeldung"),
    (r"^Lückentext: `aufgabe", "lueckentext_aufgabe"),
    (r"^unbekannter Elementtyp „(?P<wert>[^“]*)“", "typ"),
    # AP13.43: eine Abgabe außerhalb von `Aufgabe` (fobizz 08.11.: `abgabe:` und `abschluss: abgeben` an einer Seite,
    # nach „Streiche sie“ eine neue erfundene Angabe) bekommt den Weg zum Typ Aufgabe statt nur „streiche“
    (r"^unbekannte Angabe „(?P<wert>abgabe|abgeben|einreichen)“", "angabe_abgabe"),
    (r"^abschluss „(?P<wert>abgabe|abgeben|einreichen)“", "angabe_abgabe"),
    (r"^unbekannte Angabe „(?P<wert>[^“]*)“ \(erlaubt: (?P<erlaubt>.*)\)$", "angabe"),
    (r"^website am Element", "website"),
    (r"ohne Inhalt – Inhalt um zwei", "kasten_leer"),
    (r"^Nur (?P<ist>\d+) (?P<einheit_ist>\S+), nötig sind mindestens (?P<soll>\d+)", "mindest"),
    (r"keinen Merksatz", "heft_merke"),
    (r"keine fett gesetzten", "heft_fett"),
    (r"^Lernkarten?: ", "lernkarte"),
    (r"^Lesebuch: Seite „(?P<seite>.*)“ ohne Frage$", "lesebuch_frage"),
    (r"Tipp hinter der Lücke „.*`\*(?P<wort>[^`]*):Tipp\*`$", "luecke_tipp"),
    (r"Bruch „\*(?P<wert>[^“]*)\*“ als ganze Lücke", "luecke_bruch"),
    (r"Fett mit `\*\*` gibt es hier nicht", "luecke_fett"),
    (r"die Antwort „(?P<wert>[^“]*)“ steht zweimal in der Frage$", "mc_doppelt"),
    (r"mehr als eine (?:Antwort|Aussage) mit ✔", "mc_einmal"),
    (r"^Bildname „(?P<wert>[^“]*)“", "bild_name"),
]
_SAETZE = [(re.compile(m), k) for m, k in _SAETZE]
_MEHRZAHL = {"Frage": "Fragen", "Paar": "Paare", "Lücke": "Lücken", "Karte": "Karten", "Wort": "Wörter"}
_EINZAHL = {v: k for k, v in _MEHRZAHL.items()}
# Wörter, die nur die Kursdatei-Doku erklärt: im Satz an den Chat nie außerhalb von `…` (test_check.py prüft das)
SPERRLISTE = ("zonen", "Parser", "Element", "Schlüssel", "Feld", "ungültig")
_ERSATZ = [(r"\bElement(?:e|en)?\b", "Eintrag"), (r"\bzonen\b", "Gruppen"), (r"\bParser\b", "Kursmühle"),
           (r"\bSchlüssel\b", "Kennung"), (r"\bFeld\b", "Zeile"), (r"\bungültig\b", "nicht lesbar")]


def _klartext(text):
    """Meldung des Parsers ohne Wörter der Sperrliste (außerhalb von `…`)."""
    teile = text.split("`")
    for i in range(0, len(teile), 2):
        for muster, ersatz in _ERSATZ:
            teile[i] = re.sub(muster, ersatz, teile[i], flags=re.I if muster.endswith("zonen\\b") else 0)
    return "`".join(teile)


def _zitat(b, d):
    zeilen = (b or {}).get("text", "").splitlines()
    n = d.get("zeile_im_baustein")
    z = zeilen[n - 1].strip() if n and 0 < n <= len(zeilen) else ""
    return z[:59] + "…" if len(z) > 60 else z


def _was(d, b):
    """Satz aus `korrektursaetze` für eine Meldung an einem Baustein."""
    saetze = _kat()["prompt"]["korrektursaetze"]
    text = d["text"].rstrip(". ")
    werte = {"typ": (b or {}).get("typ") or "diesen Typ", "titel": d.get("titel") or (b or {}).get("titel") or "",
             "z": d.get("zeile_im_baustein") or "", "zitat": _zitat(b, d), "text": _klartext(text)}
    for muster, kennung in _SAETZE:
        m = muster.search(text)
        if not m:
            continue
        werte.update({k: v for k, v in m.groupdict().items() if v is not None})
        if kennung == "zone":
            zonen = [z.strip() for z in werte["zonen"].split(",") if z.strip()]
            werte["zonen"] = ", ".join(zonen)
            werte["oder"] = " oder ".join([", ".join(zonen[:-1]), zonen[-1]]) if len(zonen) > 1 else zonen[0]
            werte["n"] = sum(1 for z in (b or {}).get("text", "").splitlines() if z.strip().startswith("- ") and "→" in z) or "alle"
        if kennung == "mindest":
            ist, soll = int(werte["ist"]), int(werte["soll"])
            mehr = _MEHRZAHL.get(werte["einheit_ist"], werte["einheit_ist"])
            werte["einheit_ist"] = _EINZAHL.get(mehr, mehr) if ist == 1 else mehr
            werte["fehlt"] = soll - ist
            werte["einheit_fehlt"] = _EINZAHL.get(mehr, mehr) if soll - ist == 1 else mehr
        if kennung in ("frage_anfang", "mc_haken", "mc_zwei", "rf_haken", "rf_rueck", "luecken", "kasten_leer",
                       "zuordnen_liste", "lernkarte", "luecke_tipp", "luecke_bruch", "luecke_fett", "mc_doppelt",
                       "mc_einmal", "bild_name") and not werte["zitat"]:
            break                            # ohne Zeile lieber der allgemeine Satz
        return saetze[kennung].format(**werte)
    return saetze["sonst"].format(**werte)


def korrektur(pruefung, gelb=None, hand=None, mappe=None):
    """Je Fehler ein Satz an den Chat (AP13.4 §2): Baustein und `id:`, was falsch ist, wie es richtig aussieht, mit dem
    Beispiel aus der Antwort, und ein Satz im Imperativ; Fehler außerhalb eines Bausteins bitten um die ganze Kursdatei.
    Eine Prüfregel mit eigenem Satz gibt ihn als `bitte` mit. `gelb` = ids der Bausteine, deren gelbe Hinweise mit
    `bitte` die Lehrkraft dazu nimmt (AP13.14, „Sprache anpassen lassen“; AP13.35 §2.3: für Hinweise der ganzen Einheit
    steht ihre Regel in `gelb`, etwa `zeit.kurz` mit „Verlängern lassen“); ohne `gelb` nur Fehler. `hand` = ids der von Hand geänderten Bausteine
    (AP13.11 §8.9): ihre gelben Hinweise fehlen in der Bitte, rote Fehler bleiben (sonst bliebe „Weiter“ ohne Ausweg
    gesperrt). `mappe` (AP13.30): je geplanter Karte, die nach der Antwort leer blieb (`leer_antwort`), ein Satz, der
    genau sie mit ihrer `id:` anfordert (gelb). AP13.35 §3.1: `kern` ist der Satz ohne Ausgabeanweisung, `ausgabe` deren
    Art (baustein, fehlt, kopf, bilder, ganz); `satz` = kern und Anweisung, wie ihn ein einzelner Punkt an den Chat gibt.
    -> [{baustein, titel, satz, kern, ausgabe, regel, stufe}]"""
    p = _kat()["prompt"]
    bausteine = {b["id"]: b for b in (pruefung or {}).get("bausteine", [])}
    gelb = set(gelb or ()) - set(hand or ())
    out = []

    def dazu(d, kern, art, stufe, baustein=None):
        x = {"baustein": baustein, "titel": d.get("titel"), "kern": kern, "ausgabe": art, "regel": api.regel(d),
             "stufe": stufe, "satz": kern + " " + _ausgabe_satz(art, [baustein] if baustein else [])}
        if d.get("ergaenzen"):
            x["ergaenzen"] = True
        if _intern(baustein):            # Korrekturrunde AP13.41: Hilfs-id des Parsers nicht nennen, Titel und Zeile
            kopf = ((bausteine.get(baustein) or {}).get("text") or "").split("\n")[0].strip()
            x["kern"] = kern.replace(f" (`id: {baustein}`)", f" (Überschrift `{kopf}`)" if kopf else "")
            x["satz"] = x["kern"] + " " + _kat()["prompt"]["korrektur_ausgabe"]["baustein_ohne_id"]
            x["anzeige"] = f"„{d.get('titel') or ''}“"
        out.append(x)
    for d in (pruefung or {}).get("diagnosen", []):
        if d.get("stufe") == "warnung" and d.get("bitte") and (d.get("baustein") in gelb if d.get("baustein")
                                                                else d.get("regel") in gelb):
            dazu(d, d["bitte"], d.get("ausgabe") or ("baustein" if d.get("baustein") else "ganz"), "warnung",
                 d.get("baustein"))
            continue
        if d.get("stufe") != "fehler":
            continue
        b = bausteine.get(d.get("baustein"))
        if d.get("bitte"):
            dazu(d, d["bitte"], d.get("ausgabe") or ("baustein" if d.get("baustein") else "ganz"), "fehler",
                 d.get("baustein"))
        elif d.get("baustein"):
            dazu(d, p["korrektur"].format(titel=d.get("titel") or (b or {}).get("titel", ""), id=d["baustein"],
                                          was=_was(d, b).rstrip() + ("" if _was(d, b).rstrip().endswith(".") else ".")),
                 "baustein", "fehler", d["baustein"])
        else:
            from . import api as _api
            text = next((t for m, t in _api._DIAGNOSE_TEXT if m.search(d["text"])), None)
            was = (text[0].upper() + text[1:] + ".") if text else _klartext(d["text"].rstrip(". ")) + "."
            dazu(d, p["korrektur_ohne"].format(zeile=f" (Zeile {d['zeile']})" if d.get("zeile") else "", was=was),
                 "ganz", "fehler")
    # AP13.30 §4a: geplanter Baustein blieb nach der Antwort leer: genau ihn mit seiner `id:` anfordern
    for e in (mappe or {}).get("bausteine", []):
        if e.get("geplant") and e.get("leer_antwort") and not e.get("aus"):
            dazu({"titel": e.get("titel"), "regel": "leer.antwort"},
                 p["korrektursaetze"]["leer_geplant"].format(
                     titel=e.get("typ", "") if leerer_titel(e.get("titel")) else e.get("titel", ""), id=e["id"]), "fehlt", "warnung",
                 e["id"])
    return out


_RE_INTERN = re.compile(r"b-[0-9a-f]{8}")


def _intern(i):
    """Hilfs-id des Parsers für einen Baustein ohne eigene `id:` (kursdatei._id); der Chat kennt sie nicht."""
    return bool(i) and bool(_RE_INTERN.fullmatch(str(i)))


def _ids_text(ids, namen=None):
    t = [(namen or {}).get(i) or f"`id: {i}`" for i in ids]
    return t[0] if len(t) == 1 else ", ".join(t[:-1]) + " und " + t[-1]


def _ausgabe_satz(art, ids):
    """Ausgabeanweisung für einen einzelnen Punkt der Korrekturbitte."""
    a = _kat()["prompt"]["korrektur_ausgabe"]
    if art in ("baustein", "fehlt") and ids:
        return a[art].format(id=ids[0])
    return a["bilder"] if art == "bilder" else a["ganz"]


def korrektur_bitte(korrekturen):
    """AP13.35 §3.1: die Korrekturbitte aus den Punkten von korrektur(), mit genau einer Ausgabeanweisung. Ein Punkt:
    sein Satz. Mehrere: die Kerne, danach eine Anweisung, die alles nennt, was zurückkommen soll: die Bausteine mit ihrer
    `id:`, den Kopf der Kursdatei (Zeilen `Angenommen:`), ergänzte Bausteine, die Bausteine mit Bild; die ganze
    Kursdatei nur, wenn ein Teil nicht zu lesen war oder die Einheit als Ganzes länger werden soll."""
    k = [x for x in korrekturen or [] if x.get("satz")]
    if len(k) <= 1:
        return k[0]["satz"] if k else ""
    if any("kern" not in x for x in k):                 # Punkte ohne Kern (ältere Seite): wie bisher je Satz
        return "\n".join(x["satz"] for x in k)
    a = _kat()["prompt"]["korrektur_ausgabe"]
    arten = {x["ausgabe"] for x in k}
    ids = []
    for x in k:
        if x["ausgabe"] in ("baustein", "fehlt") and x.get("baustein") and x["baustein"] not in ids:
            ids.append(x["baustein"])
    kopf, bilder = "kopf" in arten, "bilder" in arten
    namen = {x["baustein"]: x["anzeige"] for x in k if x.get("anzeige")}
    if "ganz" in arten or (kopf and bilder and not ids) or (kopf and not ids):
        schluss = a["ganz"]
    elif not kopf and not bilder:
        schluss = a["bausteine"].format(ids=_ids_text(ids, namen)) if len(ids) > 1 else \
            a["baustein_ohne_id"] if _intern(ids[0]) else a["baustein"].format(id=ids[0])
    elif bilder and not kopf and not ids:
        schluss = a["bilder"]
    else:
        teile = ([a["teil_kopf"]] if kopf else []) + ([a["teil_bausteine"].format(ids=_ids_text(ids, namen))] if ids else []) \
            + ([a["teil_ergaenzt"]] if any(x.get("ergaenzen") for x in k) else []) + ([a["teil_bilder"]] if bilder else [])
        schluss = a["teile"].format(teile="; ".join(teile))
    return "\n".join(x["kern"] for x in k) + "\n" + schluss


# ---------------------------------------------------------------- Antwort ohne Bausteine (AP13.4)
def fortsetzung(mappe, ids=None):
    """AP13.8: Bitte um den Rest, wenn die Antwort mit „Fortsetzung folgt“ endete: die Bausteine aus `ids` (Teil oder
    Einheit), die noch keinen Inhalt haben, mit Titel und `id:`; ohne solche der allgemeine Satz. Die Abbruchregel steht
    wieder dabei."""
    p = _kat()["prompt"]
    nach_id = {e["id"]: e for e in (mappe or {}).get("bausteine", [])}
    offen = [nach_id[i] for i in (ids or []) if i in nach_id and nach_id[i].get("geplant") and not nach_id[i].get("aus")
             and nach_id[i].get("typ") not in M.struktur()]
    satz = p["fortsetzung"].format(liste="; ".join(f"„{e['titel']}“ (`id: {e['id']}`)" for e in offen)) if offen \
        else p["fortsetzung_ohne"]
    return satz + " " + p["abbruch"]


def diagnose(text):
    """Karte unter dem Einfügefeld, wenn die Antwort keinen Baustein ergab: die ersten drei Meldungen aus
    `api.diagnose` und derselbe Inhalt als Satz für den Chat. -> {leer, meldungen, tipp, satz}"""
    d = api.diagnose(text, pr=M.antwort(text))
    if d["leer"]:
        return dict(d, satz="")
    teile = [f"Zeile {m['zeile']}" + (f" („{m['zitat']}“)" if m["zitat"] else "") + f": {m['text']}"
             for m in d["meldungen"]]
    return dict(d, satz=_kat()["prompt"]["diagnose"].format(meldungen="; ".join(teile) or "kein Baustein erkannt"))


# ---------------------------------------------------------------- Fragen und Lösungen, Fachcheck
_RE_ART = re.compile(r"^(?:\d+\.\s+)?(MC|RF|Kurzantwort|Einsetzen|Markieren|Lückentext|Schnellquiz|Aussagen)"
                     r"(?:\s*\([^)]*\))?:\s*(.*)$")
_RE_NUM = re.compile(r"^\d+\.\s+(.*)$")
_RE_STERN = re.compile(r"(?<!\*)\*(?!\*)([^*\n]+?)(?<!\*)\*(?!\*)")


def _sauber(t):
    t = re.sub(r"<br\s*/?>", " ", t)
    t = re.sub(r"<[^<>]*>", "", t)
    t = t.replace("**", "").replace("==", "")
    return " ".join(t.split())


def _option(o):
    o = o.split(" → ")[0].strip()
    richtig = o.startswith("✔")
    return richtig, _sauber(o.lstrip("✔").strip())


def _luecken(zeilen):
    """Text mit *Lücken*: (Text mit ___, Lösungen je Lücke als Liste der Alternativen)."""
    loes, text = [], []
    for z in zeilen:
        z = re.sub(r"\*\*([^*]+)\*\*", r"\1", K.luecken_sterne(z)[0])

        def ersetze(m):
            teile = m.group(1).split(":")[0].split("/")
            loes.append([t.strip().replace(K.STERN, "*") for t in teile if t.strip()])
            return "___"
        text.append(_RE_STERN.sub(ersetze, z).replace(K.STERN, "*"))
    return _sauber(" ".join(text)), loes


_RE_KASTEN = re.compile(r"^(?:Hinweis|Merke|Beispiel|Kasten|Bild|Hilfe):")      # Hilfe: AP13.14, verrät oft die Lösung


def _ohne_kaesten(zeilen):
    """Zeilen einer Übung ohne Kästen, Bilder und Hilfen: ein Hinweis nennt oft je Lücke das falsche Wort und verrät so
    die Lösung. Ein Kasten reicht über die eingerückten Zeilen, ohne Einrückung bis zur Leerzeile; Merke, Bild und Hilfe
    sind einzeilig."""
    out, i = [], 0
    while i < len(zeilen):
        if not _RE_KASTEN.match(zeilen[i]):
            out.append(zeilen[i])
            i += 1
            continue
        einzeilig = zeilen[i].startswith(("Merke:", "Bild:", "Hilfe:"))
        i += 1
        eingerueckt = i < len(zeilen) and zeilen[i].startswith("  ")
        while not einzeilig and i < len(zeilen) and zeilen[i].strip() and (zeilen[i].startswith("  ") or not eingerueckt) \
                and not _RE_ART.match(zeilen[i].strip()) and not zeilen[i].startswith("- "):
            i += 1
    return out


def _fragen_baustein(b):
    typ, out = b.get("typ"), []
    zeilen = _ohne_kaesten((b.get("text") or "").splitlines()[1:])
    zeilen = [z for z in zeilen if not K.RE_RUECKMELDUNG.match(z.strip())]    # a1: Fehler der Prüfung, keine Lücken
    def angabe(name):
        m = next((re.match(rf"^{name}:\s*(.+)$", z) for z in zeilen if z.startswith(name + ":")), None)
        return m.group(1).strip() if m else ""
    if typ == "Zuordnen":
        zonen = [z.strip() for z in angabe("zonen").split("|") if z.strip()]
        for z in zeilen:
            if z.startswith("- "):
                teil = z[2:].rsplit(" → ", 1)          # der letzte Pfeil trennt die Zone (AP13.3)
                zone = _sauber(teil[1]) if len(teil) > 1 else ""
                # AP13.29 §6: ohne Pfeil oder mit Zone „–“ / „-“ ist es ein Ablenker, wie im Parser (kursdatei)
                out.append({"art": "zuordnen", "frage": _sauber(teil[0]), "optionen": zonen + ["keine"],
                            "loesung": [[zone if zone not in ("", "–", "-") else "keine"]]})
        return out
    if typ == "Lückentext":
        aufgabe = angabe("aufgabe")
        text = [z for z in zeilen if z.strip() and not re.match(r"^[a-zäöüß ]+:\s", z)]
        t, loes = _luecken(text)
        if loes:
            out.append({"art": "luecken", "frage": (aufgabe + " " if aufgabe else "") + t, "optionen": [], "loesung": loes})
        return out
    if typ not in _FRAGETYPEN:
        return out
    aktuell, gruppe = None, None

    def abschliessen():
        if aktuell and aktuell["art"] == "luecken":
            t, loes = _luecken(aktuell.pop("_text"))
            if loes:
                aktuell["frage"] = (aktuell["frage"] + " " + t).strip()
                aktuell["loesung"] = loes
                out.append(aktuell)
        elif aktuell and aktuell["art"] == "auswahl" and aktuell["optionen"]:
            out.append(aktuell)

    for roh in zeilen:
        z = roh.strip()
        m = _RE_ART.match(z)
        num = _RE_NUM.match(z)
        if m or (num and " · " in z and "✔" in z) or z.startswith(("Seite:", "Kapitel:")):
            abschliessen()
            aktuell, gruppe = None, None
            if not m and num:
                m = re.match(r"^()(.*)$", num.group(1))
                art = "MC"
            elif m:
                art = m.group(1)
            else:
                continue
            rest = m.group(2).strip()
            if art == "MC":
                if " · " in rest and any(c in rest for c in K.OK):  # sonst Antworten als Liste darunter
                    frage, teile = K.frage_teilen(rest)          # AP13.41 §1.1: Malpunkt in der Frage
                    opts = [_option(o) for o in teile]
                    out.append({"art": "auswahl", "frage": _sauber(frage), "optionen": [o for _, o in opts],
                                "loesung": [[o] for r, o in opts if r], "mehrfach": sum(r for r, _ in opts) > 1})
                else:
                    aktuell = {"art": "auswahl", "frage": _sauber(rest), "optionen": [], "loesung": []}
            elif art == "RF":
                vor = re.split(r"[✔✘]", rest)[0]
                wert = "richtig" if "✔" in rest.split("→")[0] else "falsch"
                out.append({"art": "rf", "frage": _sauber(vor), "optionen": ["richtig", "falsch"], "loesung": [[wert]]})
            elif art == "Kurzantwort":
                frage, teile = K.frage_teilen(rest)
                out.append({"art": "kurz", "frage": _sauber(frage), "optionen": [],
                            "loesung": [[_sauber(t) for t in teile]]})
            elif art in ("Einsetzen", "Markieren", "Lückentext"):
                aktuell = {"art": "luecken", "frage": _sauber(rest), "optionen": [], "loesung": [], "_text": []}
                if art == "Markieren":          # AP13.5h a9: markierte Wörter bekommen keine weitere Lösung
                    aktuell["markieren"] = True
            else:
                gruppe = (art, _sauber(rest))
            continue
        if z.startswith("- ") and gruppe:
            teile = z[2:].split(" · ")
            if gruppe[0] == "Schnellquiz":
                frage, teile = K.frage_teilen(z[2:])
                opts = [_option(o) for o in teile]
                frage = _sauber(frage)
            else:
                opts = [_option(o) for o in teile]
                frage = gruppe[1] or "Welche Aussage stimmt?"
            out.append({"art": "auswahl", "frage": frage, "optionen": [o for _, o in opts],
                        "loesung": [[o] for r, o in opts if r], "mehrfach": False})
            continue
        if aktuell and aktuell["art"] == "auswahl" and z.startswith("- "):
            r, o = _option(z[2:])
            aktuell["optionen"].append(o)
            if r:
                aktuell["loesung"].append([o])
            aktuell["mehrfach"] = len(aktuell["loesung"]) > 1
            continue
        if aktuell and aktuell["art"] == "luecken" and z:
            aktuell["_text"].append(z)
            continue
        if z and aktuell and aktuell["art"] == "auswahl" and not aktuell["optionen"]:
            continue
        if z:
            abschliessen()
            aktuell = None
    abschliessen()
    return out


def fragen(pruefung):
    """Ansicht „Fragen und Lösungen“: je Frage Baustein, Art, Frage, Optionen und Lösung (Liste je Lücke mit
    Alternativen), ohne Rückmeldungen; nummeriert über die Einheit."""
    out = []
    for b in (pruefung or {}).get("bausteine", []):
        for f in _fragen_baustein(b):
            f.pop("_text", None)
            f.setdefault("mehrfach", False)
            out.append(dict(f, nr=len(out) + 1, baustein=b["id"], titel=b["titel"]))
    return out


_BUCHST = "ABCDEFGHIJ"


def fachcheck(pruefung, steckbrief=None, mappe=None):
    """Text für einen NEUEN Chat: alle Aufgaben der Einheit ohne Lösungen und ohne Rückmeldungen. Mit `mappe` gilt das
    Thema der laufenden Einheit wie im Auftrag (AP13.30 §4b, `einheit_thema`)."""
    liste = fragen(pruefung)
    if not liste:
        return {"text": "", "fragen": 0}
    a = M.angaben_lesen(steckbrief or "")
    # im Kopf nur ein gesetztes Thema; die Auswahl der Erwartungen rechnet wie lehrplan() mit „Einheit“ als Rückfall
    thema = einheit_thema(mappe, a) if mappe is not None else a.get("thema")
    z = [_kat()["prompt"]["fachcheck"]]
    ohne = a.get("lehrplanbezug") == "nein" and not M.jahrgang_zahl(a.get("jahrgang"))
    jg = M.jahrgang_zahl(a.get("jahrgang")) if a.get("lehrplanbezug") == "nein" else a.get("jahrgang")
    kopf = " · ".join(x for x in (a.get("fach"), a.get("schulart"),
                                  (f"Zielgruppe: {a['jahrgang']}" if ohne else f"Jahrgangsstufe {jg}")
                                  if a.get("jahrgang") else "", thema) if x)
    if kopf:
        z.append(kopf)
    # AP13.6/AP13.29: dieselben Erwartungen wie im Auftrag (erwartungen_gewaehlt), nicht ein eigener Weg
    if _lehrplan_an(a):
        erw = erwartungen_gewaehlt(a, (thema or "Einheit") if mappe is not None else thema,
                                   einheit_kontext(mappe, a) if mappe is not None else None)["erwartungen"]
        z += ([_kat()["prompt"]["lehrplan"]["fachcheck"]] + ["- " + x for x in erw]) if erw else []
    z.append("")
    for f in liste:
        if f["art"] == "auswahl":
            z.append(f"{f['nr']}. {f['frage']}" + (" (mehrere richtig)" if f["mehrfach"] else ""))
            z += [f"   {_BUCHST[i]}) {o}" for i, o in enumerate(f["optionen"][:len(_BUCHST)])]
        elif f["art"] == "rf":
            z.append(f"{f['nr']}. Richtig oder falsch: {f['frage']}")
        elif f["art"] == "luecken":
            z.append(f"{f['nr']}. Lücken ({len(f['loesung'])}): {f['frage']}")
        elif f["art"] == "zuordnen":
            z.append(f"{f['nr']}. Ordne zu (Gruppen: {', '.join(f['optionen'])}): {f['frage']}")
        else:
            z.append(f"{f['nr']}. {f['frage']}")
    return {"text": "\n".join(z) + "\n", "fragen": len(liste)}


def _norm(t):
    t = str(t).lower().replace("^2", "²").replace("^3", "³").replace(",", ".")
    t = re.sub(r"[\s]+", " ", t).strip().strip(".;:")
    return t.replace(" ", "")


def _anzeige(f):
    if f["art"] == "auswahl":
        return ", ".join(_BUCHST[f["optionen"].index(l[0])] + ") " + l[0] for l in f["loesung"] if l[0] in f["optionen"])
    return "; ".join(l[0] if l else "" for l in f["loesung"])


def vergleich(pruefung, antwort):
    """Antwort des neuen Chats („3: B“) mechanisch mit den Lösungen der Kursdatei vergleichen; nur Abweichungen und
    fehlende Nummern zurück. -> {geprueft, abweichungen: [{nr, aufgabe, titel, baustein, frage, chat, chat_anzeige,
    kursdatei, luecken, zulassen, satz}],
    gleich: [{nr, titel, baustein, frage, kursdatei}], fehlend, bitte: {baustein: {anfang, ende}}}. `aufgabe` zählt im
    Baustein (Schlüssel der Entscheidungen in Schritt 6, Nummer im Satz an den Chat); die Korrekturbitte je Baustein ist anfang + Sätze der gewählten
    Abweichungen (`; `) + ende (AP13.5g). AP13.5h a9: bei Lücken mit passender Zahl `luecken` = nur die abweichenden
    ({nr, kursdatei: [Alternativen], chat}), sonst None; `zulassen`: die Antwort kann als weitere Lösung in die Kursdatei
    (Lücken außer Markieren, Kurzantwort)."""
    alle = fragen(pruefung)
    liste = {f["nr"]: f for f in alle}
    im_baustein, zaehler = {}, {}
    for f in alle:
        zaehler[f["baustein"]] = zaehler.get(f["baustein"], 0) + 1
        im_baustein[f["nr"]] = zaehler[f["baustein"]]
    gesehen, abw, gleich_liste = set(), [], []
    p = _kat()["prompt"]
    for z in (antwort or "").replace("\r", "").splitlines():
        m = re.match(r"^\s*[*#>\-\s]*(?:Aufgabe\s*)?(\d+)\s*[:.)\-–]\s*(.+?)\s*$", z)
        if not m or int(m.group(1)) not in liste:
            continue
        nr, wert = int(m.group(1)), m.group(2).replace("**", "").strip()
        anzeige, luecken = None, None
        f = liste[nr]
        gesehen.add(nr)
        if f["art"] == "auswahl":
            mb = re.match(r"^([A-J](?:\s*(?:,|;|und|&|\s)\s*[A-J])*)(?![A-Za-zäöü])", wert.strip().upper())
            chat_l = set(re.findall(r"[A-J]", mb.group(1))) if mb else set()
            soll = {_BUCHST[f["optionen"].index(l[0])] for l in f["loesung"] if l[0] in f["optionen"]}
            gleich = chat_l == soll
            anzeige = ", ".join(b + ") " + f["optionen"][_BUCHST.index(b)] for b in sorted(chat_l)
                                if _BUCHST.index(b) < len(f["optionen"])) or wert
        elif f["art"] == "rf":
            w = wert.lower()
            chat_w = "falsch" if re.search(r"falsch|unwahr|false", w) else ("richtig" if re.search(r"richtig|wahr|true|stimmt", w) else "")
            gleich = chat_w == f["loesung"][0][0]
        elif f["art"] == "luecken":
            teile = [t for t in re.split(r"\s*;\s*", wert)]
            # AP13.5h a9: je Lücke gegen alle Alternativen; bei gleicher Zahl zählen nur die abweichenden Lücken
            if len(teile) == len(f["loesung"]):
                luecken = [{"nr": i + 1, "kursdatei": alt, "chat": t} for i, (t, alt) in enumerate(zip(teile, f["loesung"]))
                           if _norm(t) not in {_norm(x) for x in alt}]
            gleich = len(teile) == len(f["loesung"]) and not luecken
        else:
            gleich = _norm(wert) in {_norm(x) for x in f["loesung"][0]}
        if not gleich:
            a = {"nr": nr, "aufgabe": im_baustein[nr], "titel": f["titel"], "baustein": f["baustein"],
                 "frage": f["frage"], "chat": wert, "chat_anzeige": anzeige or wert, "kursdatei": _anzeige(f),
                 "luecken": luecken, "zulassen": f["art"] == "kurz" or (luecken is not None and not f.get("markieren")),
                 "satz": p["gegen_aufgabe"].format(nr=im_baustein[nr], kursdatei=_anzeige(f), chat=anzeige or wert)}
            if luecken:
                a["satz"] = "; ".join(p["gegen_luecke"].format(nr=im_baustein[nr], luecke=l["nr"],
                                                               kursdatei=" oder ".join(l["kursdatei"]), chat=l["chat"])
                                      for l in luecken)
            abw.append(a)
        else:
            gleich_liste.append({"nr": nr, "titel": f["titel"], "baustein": f["baustein"], "frage": f["frage"],
                                 "kursdatei": _anzeige(f)})
    bitte = {}
    for a in abw:
        anfang, ende = p["gegen_korrektur"].format(titel=a["titel"], id=a["baustein"], aufgaben="\0").split("\0")
        bitte[a["baustein"]] = {"anfang": anfang, "ende": ende}
    return {"geprueft": len(liste), "abweichungen": abw, "gleich": sorted(gleich_liste, key=lambda g: g["nr"]),
            "fehlend": sorted(set(liste) - gesehen), "bitte": bitte}
