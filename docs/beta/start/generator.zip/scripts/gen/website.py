"""Website-Modus (AP7): ein Abschnitt als eine HTML-Datei (mod_resource) mit Startseite, Kapitelnavigation,
Textbausteinen aus gen/html.py und kleinen JS-Übungen mit Rückmeldung, ohne Bewertung.
Textfeld-Modus (AP7b): eine Übung als Block in einem Textfeld (mod_label), ohne iframe. CSS und Skript der Übungen
(templates/uebungen.css, uebungen.js) teilen sich beide Modi; im Block gilt jede CSS-Regel nur unter der id des Blocks,
das Skript läuft in einer eigenen Funktion ohne globale Namen, Bilder liegen als Dateien im Textfeld (@@PLUGINFILE@@).

Der Parser (gen/kursdatei.py) liefert je Element die Daten, die er auch für H5P nutzt (frage_daten, _story_daten);
hier wird daraus HTML. Seite und Skript stehen in templates/website.html, ohne externe Quellen (läuft auch offline,
als Vorschau neben der .mbz). Bilder liegen einmal als data-URI im Bilderverzeichnis der Seite und werden über
data-km-img gesetzt, wenn dasselbe Bild mehrfach vorkommt; ein Bild, das einmal vorkommt, steht direkt im src (AP13.16,
dann zeigt die Seite es auch ohne Skript).
AP13.16: Übungen ohne Skript lesbar. Python schreibt die Fassung ohne Skript (Aufgabe, Felder, Lösung und Rückmeldungen
in <details class="km-loes">, Lernkarten als <details>, Geschichte als Szenen mit Verweisen); uebungen.js baut daraus beim
Start die Oberfläche (Prüfen, Rückmeldung, Zähler, Karten, Geschichte) mit demselben DOM wie zuvor.
"""
import base64
import html as _html
import json
import os
import random
import re

from . import html as T
from .h5p import STERN
from . import motiv as M
from . import schrift as S

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(HERE, "..", "templates", "website.html")
UEB_CSS = os.path.join(HERE, "..", "templates", "uebungen.css")
UEB_JS = os.path.join(HERE, "..", "templates", "uebungen.js")

# Elementtypen, die im Website-Modus Kapitel werden; alle anderen bleiben Aktivitäten der Plattform.
WEB_TYPEN = {"Banner", "Textfeld", "Seite", "Überblick", "Link", "Video", "Lesebuch", "Quiz", "Zuordnen", "Lernkarten",
             "Geschichte", "Lückentext"}
ART = {"Textfeld": "Lesen", "Seite": "Lesen", "Lesebuch": "Lesen", "Quiz": "Üben", "Zuordnen": "Üben",
       "Lückentext": "Üben", "Lernkarten": "Wiederholen", "Geschichte": "Entscheiden", "Video": "Video", "Link": "Link",
       "Überblick": "Überblick"}
# Textfeld-Modus: nur Übungen werden Blöcke; Lesetexte, Lesebuch, Banner, Überblick, Video bleiben, wie sie sind.
BLOCK_TYPEN = {"Quiz", "Zuordnen", "Lernkarten", "Lückentext", "Geschichte"}
# AP13.14: gestufte Hilfen (verschachtelte <details>); nur in Blöcken und Websites, die Hilfen haben, damit alle
# anderen byteidentisch bleiben. Eine Regel je Zeile wie uebungen.css
HILFE_CSS = """.km-hilfe{margin-top:10px;font-size:15px}
.km-hilfe-text{margin-top:6px;padding:8px 12px;border-radius:var(--r-sm);background:var(--tint)}
"""


def _ueb_css(html):
    return _lies(UEB_CSS) + (HILFE_CSS if 'class="km-hilfe"' in html else "")


# Nur im Block: Rahmen, Abstände, Farben (Website: Seiten-CSS in website.html)
# Rahmen des Blocks nach formen.uebung der Familie (gen/design.py)
UEBUNG_RAHMEN = {
    "oben": "border:1px solid var(--line);border-top:4px solid var(--hue);border-radius:var(--r)",
    "rand_dick": "border:3px solid var(--hue);border-radius:var(--r)",
    "gestrichelt": "border:2px dashed var(--hue);border-radius:var(--r)",
    "linie_oben": "border:0;border-top:2px solid var(--ink);border-radius:0",
    "rahmen": "border:1px solid var(--line);border-radius:var(--r)",
    "papier": "border:1px solid var(--line);border-radius:var(--r)",
}
BLOCK_CSS = """
{margin:16px 0;padding:16px 18px 18px;@rahmen;background:@flaeche;color:var(--ink);font-size:@pxpx;line-height:@lh@schrift}
*{box-sizing:border-box}
img{max-width:100%;height:auto}
.km-bt{font-size:1.2em;line-height:1.25;margin:2px 0 8px;color:var(--ink)}
.km-kicker{margin:0}
.km-q{border:0;border-top:1px solid var(--line);border-radius:0;padding:14px 0 0;margin:14px 0 0;background:none}
.km-nojs{padding:8px 12px;border-radius:8px;background:var(--tint);font-size:14px}
"""
# Kopf des Blocks nach formen.uebung_kopf (AP13.5c): Zusatzregeln (@flaeche wie im Block); kopf baut wie bis b7
UEBUNG_KOPF_CSS = {
    "kopf": "",
    "ohne": ".km-kopf{margin:0 0 10px;font-weight:700;line-height:1.4;color:var(--ink)}\n"
            ".km-chip{display:inline-block;border:1px solid var(--hue);color:var(--hue);border-radius:var(--r-lg);"
            "padding:1px 10px;margin:0 10px 0 0;font-size:13px;font-weight:700;letter-spacing:.03em}\n"
            ".km-typ{margin:0 8px 0 0;font-size:.9em;font-weight:700;color:var(--hue)}",
    "titel_im_rahmen": ".km-bt{display:inline-block;max-width:calc(100% - 32px);margin:calc(-18px - .63em) 0 8px -8px;"
                       "padding:0 8px;"
                       "background:@flaeche;font-size:1.15em}\n"
                       ".km-art{margin-left:10px;font-size:12px;font-weight:700;letter-spacing:.06em;"
                       "text-transform:uppercase;color:var(--muted)}",
    "streifen": "{border-left:6px solid var(--hue);border-top:1px solid var(--line)}\n.km-bt{margin:0 0 2px}\n"
                ".km-art{margin:0 0 10px;font-size:13px;color:var(--muted)}",
}
# Kapitelnummer der Startseite im Website-Modus nach formen.nummer (AP13.9), Farben wie _nummer in gen/html.py;
# kreis und quadrat bleiben wie bis b8 (Tönung, Akzent aus website.html), damit sachlich, freundlich, magazin gleich bauen
NUMMER_CSS = {
    "kreis": "", "quadrat": "",
    "kreis_gross": ".km-num{width:36px;height:36px;background:@grund;color:@schrift;font-weight:800;font-size:16px}",
    "sticker": ".km-num{width:32px;height:32px;background:@grund;border:3px solid @hue;color:@schrift;font-weight:800}",
    "zahl": ".km-num{width:auto;min-width:22px;height:auto;border-radius:0;background:none;color:@schrift;"
            "font-weight:800;font-size:1.25em;line-height:1}",
    "klammer": ".km-num{width:auto;min-width:22px;border-radius:0;background:none;color:@schrift}\n"
               ".km-num::after{content:\")\"}",
    "eckig": ".km-num{border-radius:0;background:@grund;color:@schrift}",
    "kreis_ton": ".km-num{background:@grund;color:@schrift}",
    "liste": ".km-num{width:auto;min-width:22px;border-radius:0;background:none;color:@schrift;font-size:1em}\n"
             ".km-num::after{content:\".\"}",
}
_RE_SRC = re.compile(r'src="@@PLUGINFILE@@/([^"]+)"')
_RE_GAP = re.compile(r"\*([^*]+)\*")
_RE_IMG = re.compile(r'data-km-img="([^"]+)"')


def _luecke(s):
    """Inhalt einer *Lücke* -> (antwort, alternativen, tipp): Antwort vor dem ersten „:“, Alternativen mit „/“ getrennt.
    Felder und Lösung lesen die Lücke nur hier (AP13.16), damit beide nie auseinanderlaufen."""
    ans, _, tipp = s.replace(STERN, "*").partition(":")
    return ans.strip(), [a.strip() for a in ans.split("/") if a.strip()], tipp.strip()


def _nummern(n):
    """AP13.45 B8: Namen der Lücken einer Aufgabe für Vorlesegeräte, „Lücke 2 von 5“ (wie H5P.Blanks)."""
    z = iter(range(1, n + 1))
    return lambda: f"Lücke {next(z, n)} von {n}"


def _paar_name(t, i, n):
    """AP13.45 B8: Name der Auswahl je Paar beim Zuordnen, „Zuordnung für „Wort““; ein Element ohne Text (Bild) zählt."""
    w = re.sub(r"\s+", " ", _html.unescape(_strip_tags(t))).strip()
    return f"Zuordnung für „{w}“" if w else f"Zuordnung {i} von {n}"


def esc(s):
    return _html.escape(str(s), quote=True)


def _lies(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def uebung_vars(hue):
    """CSS-Variablen der Übungen aus der Familie (Block: style am Block; Website: :root)."""
    D, u = T.D, T.D["uebung"]
    hue = T._a(hue)
    flaeche = D["flaeche_alt"] if D["formen"]["uebung"] == "papier" else D["flaeche"]
    knopf = {"gefuellt": (hue, T._auf(hue), hue), "pille": (hue, T._auf(hue), hue), "rahmen": (flaeche, hue, hue),
             "text": ("transparent", hue, "transparent")}[u["knopf"]]
    r = D["r_sm"]
    feldrand = "#B8C0CC" if not D["dunkel"] else D["muted"]
    if D["formen"]["uebung"] in ("rahmen",) and not D["dunkel"]:
        feldrand = D["ink"] if D["name"] == "druck" else feldrand
    return (f"--hue:{hue};--tint:{T._tint(hue)};--ink:{D['ink']};--muted:{D['muted']};--line:{D['line']};"
            f"--r:{D['r']}px;--flaeche:{flaeche};--feld:{u['feld']};--feldrand:{feldrand};"
            f"--r-xs:{max(r - 2, 0)}px;--r-sm:{r}px;--r-md:{r + 2 if r else 0}px;--r-lg:{r + 4 if r else 0}px;"
            f"--knopf:{knopf[0]};--knopf-text:{knopf[1]};--knopf-rand:{knopf[2]};"
            f"--ok:{u['ok']};--okbg:{u['okbg']};--bad:{u['bad']};--badbg:{u['badbg']}")


def seiten_vars(hue):
    """Variablen der Website (Hintergrund, Kopf, Navigation, Schrift) zusätzlich zu uebung_vars (AP13.5 §6)."""
    D = T.D
    hue = T._a(hue)
    weiss = D["flaeche"].lower() in ("#fff", "#ffffff")
    bg = "#121318" if D["dunkel"] else D["flaeche_alt"] if weiss and D["flaeche_alt"].lower() not in ("#fff", "#ffffff") \
        else "#fff" if D["name"] == "druck" else "#F6F7F9"
    standard = 'system-ui,-apple-system,"Segoe UI",Roboto,sans-serif'
    return (f";--bg:{bg};--kopf:{D['flaeche']};--kopf-text:{D['ink']};--nav:{D['flaeche']};"
            f"--knopf-text-voll:{T._auf(hue)};--schrift:{D['schrift_grund'] or standard};"
            f"--schrift-kopf:{D['schrift_kopf'] or D['schrift_grund'] or standard}")


def ohne_kommentare(text):
    """CSS-, HTML- und ganze JavaScript-Kommentarzeilen entfernen (die Ausgabe nennt weder Projekt noch Herkunft)."""
    text = re.sub(r"<!--.*?-->\n?", "", re.sub(r"/\*.*?\*/\n?", "", text, flags=re.S), flags=re.S)
    return "\n".join(z for z in text.split("\n") if not z.strip().startswith("//"))


def block_css():
    """BLOCK_CSS mit den Werten der Familie (für sachlich wie bis b6)."""
    D = T.D
    flaeche = D["flaeche_alt"] if D["formen"]["uebung"] == "papier" else D["flaeche"]
    werte = {"@rahmen": UEBUNG_RAHMEN[D["formen"]["uebung"]], "@flaeche": flaeche, "@px": str(D["grund_px"] or 16),
             "@lh": str(D["zeilenhoehe"] or 1.55),
             "@schrift": (f";font-family:{D['schrift_grund']}" if D["schrift_grund"] else "")
             + (";color-scheme:dark" if D["dunkel"] else "")}
    kopf = f".km-bt,.km-kicker,.km-kopf{{font-family:{D['schrift_kopf']}}}" if D["schrift_datei"] else ""
    css = BLOCK_CSS + "".join(z + "\n" for z in (UEBUNG_KOPF_CSS[D["formen"]["uebung_kopf"]], knopf_css(), kopf) if z)
    for k, v in werte.items():
        css = css.replace(k, v)
    return css


def knopf_css():
    """Mindesthöhe der Knöpfe (uebung.knopf_hoehe, Grundschule) und runde Knöpfe (knopf: pille), sonst leer."""
    h, pille = T.D["uebung"]["knopf_hoehe"], T.D["uebung"]["knopf"] == "pille"
    return "".join(([f".km-btn{{min-height:{h}px}}"] if h else []) + ([".km-btn{border-radius:999px}"] if pille else []))


def nummer_farben(hue):
    """Schrift- und Grundfarbe der Kapitelnummer nach formen.nummer -> (schrift, grund); grund None = ohne Fläche
    (dann steht die Nummer auf der Fläche der Seite). liste (klassisch, ohne) in Textfarbe."""
    D, hue = T.D, T._a(hue)
    match D["formen"]["nummer"]:
        case "kreis_gross":
            return T._auf(hue), hue
        case "sticker":
            return D["ink"], D["flaeche"]
        case "zahl" | "klammer":
            return hue, None
        case "eckig":
            return T._auf(D["ink"]), D["ink"]
        case "kreis_ton":
            return T._auf(D["line_card"]), D["line_card"]
        case "liste":
            return D["ink"], None
    return hue, T._tint(hue)


def nummer_css(hue):
    """Regel für .km-num nach formen.nummer (steht im <style> hinter der Regel aus website.html), leer bei kreis und
    quadrat."""
    css = NUMMER_CSS[T.D["formen"]["nummer"]]
    schrift, grund = nummer_farben(hue)
    return css.replace("@schrift", schrift).replace("@grund", grund or "none").replace("@hue", T._a(hue))


def block_kopf(art, name):
    """Kopf des Übungsblocks nach formen.uebung_kopf: kopf (Kicker, Titel), ohne (Typ vor dem Titel in der ersten
    Zeile, gezeichnet nach formen.chip: Rahmen, Klammer, Punkt oder Text), titel_im_rahmen (Titel auf der Rahmenlinie,
    Typ dahinter), streifen (Streifen links, Titel zuerst)."""
    match T.D["formen"]["uebung_kopf"]:
        case "ohne":
            typ = {"klammer": f"({esc(art)})", "eckklammer": f"[{esc(art)}]", "punkt": f"● {esc(art)}",
                   "text": f"{esc(art)}:"}.get(T.D["formen"]["chip"])
            zeichen = f'<span class="km-typ">{typ}</span>' if typ else f'<span class="km-chip">{esc(art)}</span>'
            return f'<p class="km-kopf">{zeichen}{name}</p>'
        case "titel_im_rahmen":
            return f'<h3 class="km-bt">{name}<span class="km-art">{esc(art)}</span></h3>'
        case "streifen":
            return f'<h3 class="km-bt">{name}</h3><div class="km-art">{esc(art)}</div>'
    return f'<div class="km-kicker">{esc(art)}</div><h3 class="km-bt">{name}</h3>'



def css_block(css, bid):
    """Jede Regel (eine je Zeile) nur unter #bid; Zeilen von @media und Kommentare bleiben bzw. fallen weg."""
    out = []
    for line in re.sub(r"/\*.*?\*/", "", css, flags=re.S).splitlines():
        s = line.strip()
        if not s:
            continue
        m = re.match(r"^([^@{}]*)\{(.*)\}$", s)
        if m:
            sel = ",".join(f"#{bid} {x.strip()}".rstrip() for x in m.group(1).split(",")) if m.group(1).strip() \
                else f"#{bid}"
            out.append(sel + "{" + m.group(2) + "}")
        else:
            out.append(s)
    return "\n".join(out)


def js_kompakt(js):
    """Einrückung und ganze Kommentarzeilen weg (Textfeld wird kleiner, Inhalt gleich)."""
    return "\n".join(z.strip() for z in js.splitlines() if z.strip() and not z.strip().startswith("//"))


class Website:
    def __init__(self, name, hue, anzeige="eingebettet", prefix=""):
        self.name, self.hue, self.anzeige = name, hue, anzeige
        self.prefix = prefix    # vor jedem name/id einer Übung: Blöcke auf einer Kursseite dürfen sich nicht berühren
        self.kapitel = []       # dict(titel, gruppe, html, minuten, art)
        self.kopf = None        # (titel, untertitel, bildname | None)
        self.start = []         # HTML-Teile der Startseite unter dem Kopf (Überblick)
        self.bilder = {}        # dateiname -> lokaler Pfad
        self.gruppe = None      # aktueller Unterabschnitt (Gruppe in der Navigation)
        self.pos = None         # Stelle der Website unter den Elementen des Abschnitts
        self.titel = set()      # Elementtitel, die in der Website aufgehen (Badge-Prüfung)
        self._n = 0

    # ----- Sammeln
    def dateien(self, files):
        for path, name in files:
            self.bilder[name] = path

    def bild(self, ref):
        """ImageRef (gen.h5p) -> Dateiname, registriert."""
        self.bilder[ref.name] = ref.local_path
        return ref.name

    def kapitel_neu(self, titel, html, art, minuten=None):
        self.kapitel.append(dict(titel=titel, gruppe=self.gruppe, html=html, minuten=minuten, art=art))

    def uid(self, p="q"):
        self._n += 1
        return f"{self.prefix}{p}{self._n}"

    # ----- Übungen (Markup ohne Skript; Prüfen, Rückmeldung und Knöpfe setzt das Skript der Vorlage)
    def _frage(self, typ, inner, titel=None, fb_ok="", fb_bad="", loesung=""):
        """Aufgabe mit der Lösung und den Rückmeldungen im <details class="km-loes">; gleiche Rückmeldung für richtig
        und falsch steht einmal da (das Skript macht daraus .km-fb-ok und .km-fb-bad)."""
        head = f'<div class="km-qt">{titel}</div>' if titel else ""
        if fb_ok and fb_ok == fb_bad:
            extra = f'<div class="km-fb-ok km-fb-bad">{fb_ok}</div>'
        else:
            extra = (f'<div class="km-fb-ok">{fb_ok}</div>' if fb_ok else "") + \
                    (f'<div class="km-fb-bad">{fb_bad}</div>' if fb_bad else "")
        return (f'<div class="km-q" data-typ="{typ}">{head}{inner}'
                f'<details class="km-loes"><summary>Lösung</summary>{loesung}{extra}</details></div>')

    def mc(self, frage, antworten, titel=None, mischen=False):
        """antworten: [(html, richtig, rückmeldung)]."""
        multi = sum(1 for _, c, _ in antworten if c) != 1
        name, kind = self.uid(), "checkbox" if multi else "radio"
        if mischen:
            antworten = list(antworten)
            random.Random(frage).shuffle(antworten)
        opts = "".join(
            f'<label class="km-opt" data-ok="{1 if c else 0}"><input type="{kind}" name="{name}"><span>{a}</span>'
            '</label>' for a, c, fb in antworten)
        # Lösung: richtige Antworten, dann je Antwort ihre Rückmeldung (data-i: Stelle nach dem Mischen)
        loes = "".join(f'<p>Richtig: {a}</p>' for a, c, _ in antworten if c) + \
            "".join(f'<p>{a}: <span class="km-ofb" data-i="{i}">{fb}</span></p>' for i, (a, _, fb) in enumerate(antworten) if fb)
        hint = '<div class="km-hint">Mehrere Antworten sind richtig.</div>' if multi else ""
        return self._frage("mc", f'<div class="km-qq">{frage}</div>{hint}<div class="km-opts">{opts}</div>', titel,
                           loesung=loes)

    def rf(self, aussage, richtig, fb_ok="", fb_bad="", titel=None):
        name = self.uid()
        opts = "".join(f'<label class="km-opt" data-ok="{1 if v == richtig else 0}"><input type="radio" name="{name}">'
                       f'<span>{t}</span></label>' for t, v in (("Richtig", True), ("Falsch", False)))
        loes = "<p>Die Aussage stimmt.</p>" if richtig else "<p>Die Aussage stimmt nicht.</p>"
        return self._frage("mc", f'<div class="km-qq">{aussage}</div><div class="km-opts km-row">{opts}</div>', titel,
                           fb_ok, fb_bad, loes)

    def einsetzen(self, aufgabe, text, titel=None):
        """Drag the Words als Auswahllisten: jede *Lücke* wählt aus allen Wörtern der Aufgabe."""
        woerter = [_luecke(g)[0] for g in _RE_GAP.findall(text)]
        auswahl = sorted(set(woerter), key=lambda w: random.Random(aufgabe + w).random())
        opts = '<option value="">…</option>' + "".join(f'<option>{esc(w)}</option>' for w in auswahl)
        nr = _nummern(len(woerter))

        def sel(m):
            return (f'<select class="km-gap" data-ok="{esc(_luecke(m.group(1))[0])}" aria-label="{nr()}">'
                    f'{opts}</select>')

        def wort(m):
            return f'<b>{esc(_luecke(m.group(1))[0])}</b>'
        zeilen = "<br>".join(_RE_GAP.sub(sel, z) for z in text.split("\n")).replace(STERN, "*")
        loes = ("<p>" + "<br>".join(_RE_GAP.sub(wort, z) for z in text.split("\n")) + "</p>").replace(STERN, "*")
        return self._frage("gaps", f'<div class="km-qq">{aufgabe}</div><p class="km-text">{zeilen}</p>', titel,
                           loesung=loes)

    def lueckentext(self, aufgabe, absaetze, titel=None, rueckmeldung=""):
        nr = _nummern(sum(len(_RE_GAP.findall(a)) for a in absaetze))

        def inp(m):
            _, alts, tipp = _luecke(m.group(1))
            w = max(4, max((len(a) for a in alts), default=0) + 1)   # leere Lücke: die Prüfung meldet sie
            tip = f' title="{esc(tipp)}" placeholder="{esc(tipp)}"' if tipp else ""
            return (f'<input class="km-gap" type="text" data-ok="{esc("|".join(alts))}" size="{w}" autocomplete="off" '
                    f'spellcheck="false" aria-label="{nr()}"{tip}>')

        def wort(m):
            return f'<b>{esc(" / ".join(_luecke(m.group(1))[1]))}</b>'
        text = "".join(f'<p class="km-text">{_RE_GAP.sub(inp, a)}</p>' for a in absaetze).replace(STERN, "*")
        loes = "".join(f'<p>{_RE_GAP.sub(wort, a)}</p>' for a in absaetze).replace(STERN, "*")
        return self._frage("gaps", f'<div class="km-qq">{aufgabe}</div>{text}', titel, rueckmeldung, rueckmeldung, loes)

    def markieren(self, aufgabe, text, titel=None):
        """Wörter als <span class="km-word">; das Skript macht daraus Knöpfe (ohne Skript bleibt Fließtext)."""
        teile = re.split(r"(\*[^*]+\*|\s+)", text)
        out, ziel = [], []
        for t in teile:
            if not t:
                continue
            if t.isspace():
                out.append(" ")
            elif t.startswith("*") and t.endswith("*"):
                out.append(f'<span class="km-word" data-ok="1">{t[1:-1]}</span>')
                ziel.append(t[1:-1])
            else:
                m = re.match(r"^(\W*)(.+?)(\W*)$", t)
                pre, w, post = m.groups() if m else ("", t, "")
                out.append(f'{pre}<span class="km-word" data-ok="0">{w}</span>{post}' if w else t)
        return self._frage("mark", f'<div class="km-qq">{aufgabe}</div><p class="km-text">{"".join(out)}</p>'.replace(STERN, "*"),
                           titel, loesung=f'<p>Zu markieren: {", ".join(ziel)}</p>'.replace(STERN, "*"))

    def aussagen(self, einleitung, gruppen, titel=None):
        parts = [f'<p>{einleitung}</p>'] if einleitung else []
        for g in gruppen:
            parts.append(self.mc("Welche Aussage stimmt?", [(g[0], True, "")] + [(x, False, "") for x in g[1:]],
                                 mischen=True))
        return "".join(parts)

    def schnellquiz(self, fragen):
        return "".join(self.mc(q, [(a[0], True, "")] + [(x, False, "") for x in a[1:]], mischen=True) for q, a in fragen)

    def hilfen(self, html, hilfen):
        """AP13.14: gestufte Hilfen unter der Aufgabe, vor „Prüfen“, als verschachtelte <details> („Hilfe“, darin „Noch
        eine Hilfe“); gehen ohne Skript, mit Tastatur und Screenreader. Ohne Knopfzeile (Aussagen, Schnellquiz) am Ende."""
        if not hilfen:
            return html
        teile = ""
        for i, h in reversed(list(enumerate(hilfen))):
            teile = (f'<details class="km-hilfe"><summary>{"Hilfe" if i == 0 else "Noch eine Hilfe"}</summary>'
                     f'<div class="km-hilfe-text">{h}</div>{teile}</details>')
        marke = '<details class="km-loes">'
        return html.replace(marke, teile + marke, 1) if marke in html else html + teile

    def frage(self, typ, titel, d, hilfen=None):
        """Frage aus kursdatei.frage_daten -> Markup; `hilfen` = bis zu zwei Texte (HTML) für die Hilfe-Stufen."""
        return self.hilfen(self._frage_markup(typ, titel, d), hilfen)

    def _frage_markup(self, typ, titel, d):
        t = None if titel in ("Frage", "Richtig oder falsch?") else titel
        if typ == "MC":
            return self.mc(d[0], d[1], t, mischen=True)     # wie randomAnswers in H5P und shuffle im Test
        if typ == "RF":
            return self.rf(*d, titel=t)
        if typ == "Einsetzen":
            return self.einsetzen(*d, titel=t)
        if typ == "Markieren":
            return self.markieren(*d, titel=t)
        if typ == "Lückentext":
            return self.lueckentext(*d, titel=t)
        if typ == "Aussagen":
            return self.aussagen(*d, titel=t)
        return self.schnellquiz(d)

    def quiz(self, fragen_html, einleitung="", rueckmeldung=""):
        intro = f'<p class="km-lead">{einleitung}</p>' if einleitung else ""
        fb = (f'<details class="km-loes"><summary>Hinweis</summary><div class="km-quiz-fb">{rueckmeldung}</div></details>'
              if rueckmeldung else "")
        return f'<div class="km-quiz">{intro}{"".join(fragen_html)}{fb}</div>'

    def zuordnen(self, zonen, elemente, aufgabe="", rueckmeldung=""):
        """elemente: [(html, zonen-index | None)]; None = Ablenker („passt nirgends“)."""
        ablenker = any(z is None for _, z in elemente)
        opts = '<option value="">Bitte wählen …</option>' + "".join(f'<option>{esc(_strip_tags(z))}</option>' for z in zonen)
        if ablenker:
            opts += '<option value="–">passt nirgends</option>'
        rows = "".join(
            f'<div class="km-pair"><span>{t}</span><select class="km-gap" '
            f'aria-label="{esc(_paar_name(t, i + 1, len(elemente)))}" '
            f'data-ok="{esc(_strip_tags(zonen[z]) if z is not None else "–")}">{opts}</select></div>'
            for i, (t, z) in enumerate(elemente))
        head = f'<div class="km-qq">{aufgabe or "Ordne jedes Element zu."}</div>'
        loes = "<ul>" + "".join(f'<li>{t} → {zonen[z] if z is not None else "passt nirgends"}</li>' for t, z in elemente) + "</ul>"
        return self._frage("gaps", head + f'<div class="km-pairs">{rows}</div>', None, rueckmeldung, rueckmeldung, loes)

    def lernkarten(self, karten, beschreibung=""):
        """karten: [(vorne, hinten, tipp, ImageRef | None)]. Ohne Skript klappt <details> die Rückseite auf; das Skript
        macht aus jeder Karte einen Knopf zum Umdrehen."""
        out = []
        for vorne, hinten, tipp, img in karten:
            pic = f'<img data-km-img="{esc(self.bild(img))}" alt="">' if img else ""
            tip = f'<span class="km-tip">{tipp}</span>' if tipp else ""
            out.append(f'<details><summary><span class="km-front">{pic}<span>{vorne}</span></span></summary>'
                       f'<span class="km-back"><span>{hinten}</span>{tip}</span></details>')
        intro = f'<p>{beschreibung}</p>' if beschreibung else ""
        return intro + '<p class="km-hint">Tippe auf eine Karte, um sie umzudrehen.</p>' + \
            f'<div class="km-cards">{"".join(out)}</div>'

    def geschichte(self, start_titel, start_sub, img, knoten, enden):
        """Geschichte als Szenen mit Verweisen (AP13.16, ohne JSON): je Knoten ein .km-sz mit id über den Index (Start
        0, dann Szenen und Fragen, dann Enden), Ziele als href und data-ziel; das Skript liest daraus die Geschichte."""
        uid = self.uid("g")
        nr = {k[0]: i for i, k in enumerate(knoten, 1)}
        nr.update({key: i for i, key in enumerate(enden, len(knoten) + 1)})

        def weiter(ziel, text):
            return f'<a href="#{uid}-{nr[ziel]}" data-ziel="{nr[ziel]}">{text}</a>'

        def sz(i, art, inhalt):
            return f'<div class="km-sz" id="{uid}-{i}" data-art="{art}">{inhalt}</div>'
        pic = f'<img data-km-img="{esc(self.bild(img[1]))}" alt="">' if img else ""
        teile = [sz(0, "start", f'{pic}<h3>{start_titel}</h3>'
                    + (f'<p class="km-sz-text">{start_sub}</p>' if start_sub else "")
                    + f'<p>{weiter(knoten[0][0], "Los geht’s")}</p>')]
        for k in knoten:
            if k[1] == "szene":
                teile.append(sz(nr[k[0]], "szene", f'<h3>{k[2]}</h3><div class="km-sz-text">{k[3]}</div>'
                                                   f'<p>{weiter(k[4], "Weiter")}</p>'))
            else:
                teile.append(sz(nr[k[0]], "frage", f'<h3>{k[2]}</h3><ul>'
                                                   + "".join(f"<li>{weiter(z, t)}</li>" for t, z in k[3]) + "</ul>"))
        for key, (t, sub) in enden.items():
            teile.append(sz(nr[key], "ende", f'<div class="km-kicker">Ende</div><h3>{t}</h3>'
                                             + (f'<p class="km-sz-text">{sub}</p>' if sub else "")
                                             + f'<p>{weiter(knoten[0][0], "Noch einmal von vorn")}</p>'))
        return f'<div class="km-story"><div class="km-story-daten">{"".join(teile)}</div></div>'

    def video(self, url):
        m = re.search(r"(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/)([\w-]{6,})", url)
        if m:
            src = f"https://www.youtube-nocookie.com/embed/{m.group(1)}"
        else:
            m = re.search(r"vimeo\.com/(?:video/)?(\d+)", url)
            src = f"https://player.vimeo.com/video/{m.group(1)}" if m else None
        if not src:
            return self.link(url)
        return (f'<div class="km-video"><iframe src="{esc(src)}" title="Video" loading="lazy" allowfullscreen '
                f'allow="encrypted-media; picture-in-picture"></iframe></div>'
                f'<p class="km-hint"><a href="{esc(url)}" target="_blank" rel="noopener">Video in neuem Fenster öffnen</a></p>')

    def link(self, url):
        return (f'<p><a class="km-btn" href="{esc(url)}" target="_blank" rel="noopener">Seite öffnen</a></p>'
                f'<p class="km-hint">{esc(url)}</p>')

    # ----- Ausgabe
    def block(self, bid, art, schrift=False):
        """Textfeld-Modus: Kapitel als ein Block für ein Textfeld -> (html, [(pfad, dateiname)]). schrift: der Block
        trägt die Titelschrift der Familie als @font-face (einer je Seite; Titel und Kicker der Bausteine nutzen sie)."""
        inhalt = "".join(k["html"] for k in self.kapitel)
        inhalt = _RE_IMG.sub(lambda m: f'src="@@PLUGINFILE@@/{m.group(1)}"', inhalt)
        namen = set(_RE_SRC.findall(inhalt))
        files = [(self.bilder[n], n) for n in sorted(namen) if n in self.bilder]
        stil = uebung_vars(self.hue)
        css = css_block(_ueb_css(inhalt) + block_css(), bid)
        if schrift and T.D["schrift_datei"]:
            css = S.font_face(T.D["schrift_datei"]) + "\n" + css
        js = (f'(function () {{\n"use strict";\nvar R = document.getElementById("{bid}");\n'
              f'if (!R || R.getAttribute("data-km-an")) return;\nR.setAttribute("data-km-an", "1");\n'
              f'var IMG = {{}};\n{js_kompakt(_lies(UEB_JS))}\n}})();')
        # Hinweis nur in Blöcken mit Lösung zum Aufklappen; Lernkarten und Geschichte gehen ohne Skript
        nojs = ('<p class="km-nojs">Prüfen geht hier nicht. Löse die Aufgaben und klappe dann die Lösung auf.</p>'
                if 'class="km-loes"' in inhalt else "")
        html = (f'<div class="kmb" id="{bid}" style="{stil}"><style>\n{css}\n</style>'
                f'{block_kopf(art, self.name)}{nojs}{inhalt}<script>\n{js}\n</script></div>')
        return html, files

    def _bilder_setzen(self, html):
        return _RE_SRC.sub(lambda m: f'data-km-img="{esc(m.group(1))}"', html)

    def render(self):
        hue = self.hue
        kopf_t, kopf_u, kopf_b = self.kopf or (self.name, "", None)
        pic = f'<img class="km-hero-img" data-km-img="{esc(kopf_b)}" alt="">' if kopf_b else ""
        stil, motiv = "", ""
        if not kopf_b and T.D["motiv"]["banner"]:
            # Bannerfläche der Familie als Grund des Kopfes (AP13.5e §2): das Motiv rechts, der Titel links frei;
            # beim Papier ist der Grund das Blatt, damit der Titel auf hellem Papier steht
            grund, mfarbe, tfarbe, _ = M.farben(T.D, T._a(hue))
            papier = T.D["motiv"]["name"] == "papier"
            stil = (f' style="--motiv:{M.css_url(M.bild_svg(T.D, T._a(hue), 1000, 250, 7))};'
                    f'background-color:{mfarbe if papier else grund};color:{tfarbe}"')
            motiv = " km-hero-motiv"
        hero = (f'<div class="km-hero{" km-hero-pic" if kopf_b else ""}{motiv}"{stil}>{pic}<div class="km-hero-text">'
                f'<h1>{kopf_t}</h1>' + (f'<p>{kopf_u}</p>' if kopf_u else "") + '</div></div>')
        nav, karten, secs = [], [], []
        gruppe = None
        for i, k in enumerate(self.kapitel, 1):
            if k["gruppe"] != gruppe:
                gruppe = k["gruppe"]
                if gruppe:
                    nav.append(f'<div class="km-grp">{gruppe}</div>')
                    karten.append(f'<h2 class="km-grp-h">{gruppe}</h2>')
            meta = " · ".join(x for x in (k["art"], f'{k["minuten"]} min' if k["minuten"] else "") if x)
            nav.append(f'<a href="#k{i}" data-k="k{i}"><span class="km-dot"></span><span>{k["titel"]}</span></a>')
            karten.append(f'<a class="km-tile" href="#k{i}" data-k="k{i}"><span class="km-num">{i}</span>'
                          f'<span class="km-tile-t">{k["titel"]}<small>{meta}</small></span><span class="km-dot"></span></a>')
            prev = f'<a class="km-btn km-ghost" href="#k{i - 1}">Zurück</a>' if i > 1 else \
                '<a class="km-btn km-ghost" href="#start">Start</a>'
            nxt = (f'<a class="km-btn" href="#k{i + 1}">Weiter: {_strip_tags(self.kapitel[i]["titel"])}</a>'
                   if i < len(self.kapitel) else '<a class="km-btn" href="#start">Fertig: zur Übersicht</a>')
            kick = " · ".join(x for x in (_strip_tags(k["gruppe"] or ""), meta) if x)
            secs.append(f'<section class="km-ch" id="k{i}" hidden><div class="km-kicker">{kick}</div>'
                        f'<h1>{k["titel"]}</h1>{k["html"]}<nav class="km-pager">{prev}{nxt}</nav></section>')
        start = (f'<section class="km-ch" id="start">{hero}{"".join(self.start)}'
                 f'<h2 class="km-grp-h">Kapitel</h2><div class="km-tiles">{"".join(karten)}</div>'
                 f'<nav class="km-pager"><span></span><a class="km-btn" href="#k1">Los geht’s</a></nav></section>')
        main = self._bilder_setzen(start + "".join(secs))
        # Bilder, die einmal vorkommen, direkt ins src (auch ohne Skript sichtbar); mehrfach genutzte einmal in IMG
        zahl = {}
        for n in _RE_IMG.findall(main):
            zahl[n] = zahl.get(n, 0) + 1
        bilder = {}
        for name, path in self.bilder.items():
            if esc(name) not in zahl:
                continue
            with open(path, "rb") as f:
                mime = "image/png" if name.lower().endswith(".png") else "image/jpeg"
                uri = f"data:{mime};base64," + base64.b64encode(f.read()).decode()
            if zahl[esc(name)] == 1:
                main = main.replace(f'data-km-img="{esc(name)}"', f'src="{uri}"', 1)
            else:
                bilder[name] = uri
        tpl = ohne_kommentare(_lies(TEMPLATE))
        ids = {
            "{{TITEL}}": esc(_strip_tags(self.name)),
            "{{SCHRIFT}}": S.font_face(T.D["schrift_datei"]) + "\n" if T.D["schrift_datei"] else "",
            "{{VARS}}": uebung_vars(hue) + seiten_vars(hue),
            "{{NAV}}": '<a href="#start" data-k="start"><span class="km-dot"></span><span>Start</span></a>' + "".join(nav),
            "{{NAME}}": esc(_strip_tags(self.name)),
            "{{MAIN}}": main,
            "{{SCHLUESSEL}}": esc("km:" + re.sub(r"\W+", "-", _strip_tags(self.name).lower())[:60]),
            "{{BILDER}}": json.dumps(bilder).replace("</", "<\\/"),
            "{{UEBUNGEN_CSS}}": "\n".join(x for x in (ohne_kommentare(_ueb_css(main)).strip(), knopf_css(),
                                                     nummer_css(hue)) if x),
            "{{UEBUNGEN_JS}}": ohne_kommentare(_lies(UEB_JS)).strip(),
        }
        for k, v in ids.items():
            tpl = tpl.replace(k, v)
        return tpl


def vorschau_textfeld(bloecke, titel):
    """Vorschau aller Textfeld-Blöcke eines Kurses als eine HTML-Seite (Bilder als data-URI), wie auf der Kursseite
    untereinander. bloecke: [(titel, html, [(pfad, dateiname)])]."""
    teile = []
    for _, html, files in bloecke:
        for path, name in files:
            with open(path, "rb") as f:
                mime = "image/png" if name.lower().endswith(".png") else "image/jpeg"
                html = html.replace(f"@@PLUGINFILE@@/{name}", f"data:{mime};base64," + base64.b64encode(f.read()).decode())
        teile.append(f'<div class="activity">{html}</div>')
    return ('<!doctype html>\n<html lang="de">\n<head>\n<meta charset="utf-8">\n'
            '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
            f'<title>{esc(_strip_tags(titel))} – Übungen im Textfeld</title>\n'
            '<style>body{margin:0;background:#F6F7F9;font:16px/1.5 system-ui,sans-serif;color:#1F2937}'
            'main{max-width:820px;margin:0 auto;padding:16px}</style>\n</head>\n<body>\n<main>\n'
            + "\n".join(teile) + '\n</main>\n</body>\n</html>\n')


def _strip_tags(s):
    return re.sub(r"<[^>]+>", "", s or "")
