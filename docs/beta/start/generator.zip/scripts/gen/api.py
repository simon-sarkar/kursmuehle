"""Schnittstelle des Generators für CLI (build.py) und Browser (web/worker.js, Pyodide): aus Text und Bytes prüfen
und bauen, ohne Annahmen über Dateisystem, Prozess oder Konsole.

    pruefe(text, assets, steckbrief, mappe)   -> dict mit bausteine, diagnosen, adressen, bildwuensche (nachsichtig, je
                                                 ### erholt); mit `mappe` dazu die Prüfregeln der Mühle (einheit_pruefen)
    baue(kurs_md, steckbrief, assets)         -> (mbz_bytes | None, diagnosen)
    baue_voll(kurs_md, steckbrief, assets)    -> Ergebnis (Bytes, Dateiname, Glossar-XML, Vorschauen, Prüfbericht)
    steckbrief_lesen(text) / steckbrief_schreiben(dict)   YAML nur hier (JavaScript liest kein YAML)
    lehrplan_vorschlag(lehrplan, fach)        -> {schwerpunkt, uebungstypen, vorlage, grund} aus den Kompetenzerwartungen
                                                 (gen.zielart, AP13.24)
    extrahiere_kursdatei(text)                -> (kursdatei, hinweise): ganze Chat-Antwort mit Vorrede und ``` annehmen
    material_lesen(name, daten)               -> {ok, format, abschnitte, zeichen, hinweis}: eigenes Material aus einer
                                                 Datei (txt, md, docx, odt, pptx, odp, pdf; gen.material, AP13.13)

`assets` ist ein dict Dateiname -> Bytes (Browser) oder der Pfad eines Ordners (CLI). Jeder Lauf setzt den Modulzustand
zurück (Designfamilie, Emoji, Akzentfarbe, Zufall), arbeitet in einem eigenen Temp-Ordner und löscht ihn danach.
Mit `zeit` (Unix-Sekunden) und `seed` ist die Sicherung reproduzierbar: gleiche Eingabe, gleiche Bytes (CI vergleicht
Pyodide mit CPython). Bildgrößen kommen aus dem Dateikopf (gen.bildkopf), nicht aus Pillow.
"""
import datetime
import os
import re
import shutil
import tempfile
import time

import yaml

from . import design as DS
from . import h5p as H
from . import html as T
from . import kursdatei as K
from . import schrift as S
from . import tzdaten
from .bildkopf import groesse, ist_bild
from .h5p import ImageRef
from .kursdatei import Diagnosen, KursdateiFehler
from .mbz import Course, Label, Section, Writer, glossary_import_xml, moodle_format
from .website import vorschau_textfeld

VERSION = "2.0.0-b19"


def _version_schluessel(v):
    """„2.0.0-b12“ -> (2, 0, 0, 1, 12); Stufe a = 0, b = 1, ohne Zusatz = 2. Nicht lesbar: None."""
    m = re.fullmatch(r"\s*(\d+)\.(\d+)(?:\.(\d+))?(?:-([ab])(\d+))?\s*", str(v or ""))
    if not m:
        return None
    return (int(m.group(1)), int(m.group(2)), int(m.group(3) or 0), {"a": 0, "b": 1, None: 2}[m.group(4)],
            int(m.group(5) or 0))


def version_neuer(a, b):
    """Ist Version a neuer als b? 1.0.3 < 2.0.0-a4 < 2.0.0-b1 < 2.0.0-b12 < 2.0.0 < 2.0.1; was sich nicht lesen lässt,
    gilt als nicht neuer (AP13.15, Hinweis beim Öffnen)."""
    ka, kb = _version_schluessel(a), _version_schluessel(b)
    return ka is not None and kb is not None and ka > kb


class Ergebnis:
    def __init__(self):
        self.mbz = None             # Bytes der Sicherung oder None bei Fehlern
        self.diagnosen = Diagnosen()
        self.dateiname = None       # Name der .mbz (steht auch in moodle_backup.xml)
        self.titel = None
        self.glossare = []          # (Dateiname, XML) je Glossar mit Einträgen
        self.websites = []          # (Titel, HTML) je Website-Abschnitt
        self.textfeld_html = None   # Vorschau aller Textfeld-Blöcke
        self.pruefung = None        # (errors, info, warnings) aus check.py
        self.bausteine = []
        self.dauer_s = 0.0

    def ok(self):
        return self.mbz is not None and not self.diagnosen.hat_fehler()


# ---------------------------------------------------------------- Steckbrief (YAML nur in Python)
def _json_sicher(v):
    if isinstance(v, dict):
        return {str(k): _json_sicher(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_json_sicher(x) for x in v]
    if isinstance(v, (datetime.date, datetime.datetime)):
        return v.isoformat()[:10]
    return v


def lehrplan_vorschlag(lehrplan, fach=""):
    """AP13.24: Vorschlag für Schwerpunkt, Übungstypen und Art der Einheit aus `kurs.lehrplan` (gen.zielart.vorschlag);
    ohne Lernbereich None. -> {schwerpunkt, uebungstypen, vorlage, grund}"""
    from . import mappe as M
    from . import zielart
    lp = M.lehrplan_sauber(lehrplan)
    return zielart.vorschlag(lp, fach) if lp else None


def steckbrief_lesen(text):
    """YAML-Text -> dict ohne Datums- und Zeitobjekte (Datum als 'JJJJ-MM-TT'). Leer -> {}."""
    if not text or not str(text).strip():
        return {}
    sb = yaml.safe_load(text)
    if sb is None:
        return {}
    if not isinstance(sb, dict):
        raise ValueError("Steckbrief: oberste Ebene muss ein Mapping sein (kurs:, teile:)")
    return _json_sicher(sb)


class _Steckbrief(yaml.SafeDumper):
    """Strings, die ein YAML-Leser als Zahl, Datum oder Wahrheitswert lesen könnte (09, 2026-11-01, no), in Anführungszeichen."""


_RE_ZWEIDEUTIG = re.compile(r"^[0-9][0-9_.,:\-eE+]*$|^[+-]?\.?[0-9]")
_WORTE = {"yes", "no", "on", "off", "true", "false", "null", "y", "n", "~"}


def _str(dumper, v):
    if _RE_ZWEIDEUTIG.match(v) or v.strip().lower() in _WORTE or v == "":
        return dumper.represent_scalar("tag:yaml.org,2002:str", v, style="'")
    return dumper.represent_scalar("tag:yaml.org,2002:str", v)


_Steckbrief.add_representer(str, _str)


def steckbrief_schreiben(sb):
    """dict -> YAML-Text, Reihenfolge der Schlüssel bleibt, Umlaute bleiben, Strings mit Zahlenform werden zitiert."""
    return yaml.dump(_json_sicher(sb or {}), Dumper=_Steckbrief, allow_unicode=True, sort_keys=False,
                     default_flow_style=False, width=100)


# ---------------------------------------------------------------- Material aus Dateien (AP13.13)
def material_lesen(name, daten):
    """Text einer Datei als Abschnitte in schlichtem Markdown; Meldungen in `hinweis` (siehe gen.material)."""
    from . import material
    return material.lesen(name, daten)


# ---------------------------------------------------------------- Chat-Antwort -> Kursdatei
_RE_FENCE = re.compile(r"^[ \t]*(`{3,}|~{3,})[^\n]*\n(.*?)^[ \t]*\1[ \t]*$", re.S | re.M)
_RE_KOPF = re.compile(r"^#{1,2} ", re.M)


def extrahiere_kursdatei(text):
    """Die ganze Antwort eines Chats annehmen: Codeblock-Zeichen und Vorrede entfernen, mehrere Codeblöcke
    zusammensetzen, gerenderten Text (ohne #-Überschriften) erkennen. Gibt (kursdatei, [hinweise])."""
    hinweise = []
    t = text.replace("\r\n", "\n").replace("\r", "\n").lstrip("﻿")
    bloecke = [m.group(2) for m in _RE_FENCE.finditer(t)]
    passend = [b for b in bloecke if _RE_KOPF.search(b)]
    if passend:
        t = "\n\n".join(b.rstrip("\n") for b in passend) + "\n"
        hinweise.append(f"Codeblock übernommen ({len(passend)} von {len(bloecke)}), Text davor und danach weggelassen"
                        if len(bloecke) > 1 else "Codeblock-Zeichen und Text davor und danach weggelassen")
    elif bloecke:
        t = "\n\n".join(b.rstrip("\n") for b in bloecke) + "\n"
        hinweise.append("Codeblock ohne Abschnittsüberschriften übernommen")
    else:
        m = _RE_KOPF.search(t)
        if m and m.start() > 0:
            vorrede = t[:m.start()].count("\n")
            if t[:m.start()].strip():
                hinweise.append(f"{vorrede} Zeile{'n' if vorrede != 1 else ''} Vorrede vor der Kursdatei weggelassen")
            t = t[m.start():]
        elif not m and re.search(rf"^({'|'.join(K.ELEMENTE)}): ", t, re.M):
            hinweise.append("Der Text sieht gerendert aus (keine Überschriften mit #). Kopiere die Antwort mit dem "
                            "Kopierknopf des Chats, nicht mit der Maus")
    if not t.endswith("\n"):
        t += "\n"
    return t, hinweise


# ---------------------------------------------------------------- Hilfen
def _dateiname(short):
    """Kurzname als Dateiname: ASCII, Kleinbuchstaben, Umlaute ausgeschrieben, Sonderzeichen zu „-“."""
    import unicodedata
    s = short.lower()
    for a, b in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("ß", "ss")):
        s = s.replace(a, b)
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-") or "kurs"


def _zeitstempel(zeit):
    return datetime.datetime.fromtimestamp(zeit, tzdaten.berlin()).strftime("%Y%m%d-%H%M%S")


class _Arbeit:
    """Temp-Ordner für einen Lauf; Website-Dateien und Platzhalter landen darin (tempfile.tempdir) und verschwinden
    mit ihm."""

    def __enter__(self):
        self.dir = tempfile.mkdtemp(prefix="kursmuehle_")
        self.alt = tempfile.tempdir
        tempfile.tempdir = self.dir
        return self.dir

    def __exit__(self, *a):
        tempfile.tempdir = self.alt
        shutil.rmtree(self.dir, ignore_errors=True)


def _assets(assets, work, diag):
    """assets (dict Name -> Bytes oder Ordnerpfad) -> (A, assets_dir). A: Bildname -> (Pfad, ImageRef)."""
    if assets is None:
        assets = {}
    if isinstance(assets, str):
        assets_dir = assets
        namen = sorted(os.listdir(assets_dir)) if os.path.isdir(assets_dir) else []
        lesen = lambda n: open(os.path.join(assets_dir, n), "rb").read()  # noqa: E731
    else:
        assets_dir = os.path.join(work, "assets")
        os.makedirs(assets_dir, exist_ok=True)
        namen = []
        for name, data in assets.items():
            name = os.path.basename(str(name).replace("\\", "/"))
            if not name:
                continue
            if isinstance(data, memoryview):
                data = data.tobytes()
            with open(os.path.join(assets_dir, name), "wb") as f:
                f.write(bytes(data))
            namen.append(name)
        namen.sort()
        lesen = lambda n: open(os.path.join(assets_dir, n), "rb").read()  # noqa: E731
    A = {}
    for name in namen:
        if not ist_bild(name):
            continue
        path = os.path.join(assets_dir, name)
        try:
            w, h = groesse(lesen(name)[:65536] if name.lower().endswith(".png") else lesen(name))
        except ValueError as e:
            diag.warnung(f"Bild „{name}“ nicht lesbar ({e}); wird wie fehlend behandelt", art="bild")["regel"] = "bild.lesbar"
            continue
        A[name] = (path, ImageRef(path, w, h))
    return A, assets_dir


def design_angaben(sb):
    """Familie und Hebel aus dem Steckbrief: design.familie (bis b6 design.vorlage, migriert), design.dichte,
    design.kasten."""
    design = (sb.get("kurs") or {}).get("design") or {}
    return (DS.migriere(design.get("familie") or design.get("vorlage")), design.get("dichte"), design.get("kasten"))


def _design_option(sb, wert):
    """build.py --design familie[,akzent,dichte,kasten] -> Steckbrief (überschreibt design.* und farbe)."""
    teile = [t.strip() for t in str(wert).split(",")]
    k = dict(sb.get("kurs") or {})
    d = dict(k.get("design") or {})
    d.pop("vorlage", None)
    for key, v in zip(("familie", "akzent", "dichte", "kasten"), teile):
        if not v:
            continue
        if key == "akzent":
            k["farbe"] = K.FARBEN.get(v.lower(), v)
        else:
            d[key] = v
    k["design"] = d
    sb["kurs"] = k


def _zuruecksetzen(sb, seed):
    design = (sb.get("kurs") or {}).get("design") or {}
    T.EMOJI = bool(design.get("emoji_marker", False))
    T.set_design(*design_angaben(sb))
    K._HUE = T.HUE
    H.setze_zufall(seed)


def _steckbrief(sb):
    if sb is None:
        return {}
    if isinstance(sb, str):
        return steckbrief_lesen(sb)
    return _json_sicher(dict(sb))


# ---------------------------------------------------------------- Vorschau der Designfamilien (AP13.5 §4)
def design_vorschau(familie=None, hebel=None):
    """HTML einer festen Mini-Einheit (Kicker, Überschrift, zwei Sätze, Merksatz, zwei Chips, Kopf eines Quizblocks
    mit einem Knopf) bei 500 px Breite, gebaut mit gen/html.py und dem CSS der Übungsblöcke. hebel: {akzent (Name oder
    Hex), dichte, kasten, titel, phasen}. Titel (Thema der Lehrkraft) und Namen der geplanten Abschnitte (erster im
    Kicker, letzter über dem Quizblock) kommen aus den Angaben, alles andere ist neutraler Platzhaltertext ohne
    Fachinhalt (AP13.34 §4). Der Modulzustand (Familie, Akzent der Inline-Markierung) ist danach wie vorher."""
    from .website import UEB_CSS, _lies, block_css, css_block, uebung_vars
    h = dict(hebel or {})
    alt_d, alt_hue, alt_k, alt_n = T.D, T.HUE, K._HUE, dict(T._N)
    try:
        T.set_design(familie, h.get("dichte"), h.get("kasten"))
        T.WELLE_KACHELN = (9, 1)        # AP13.19 §4: „Sehr wellig“ ohne Kachelung, die Vorschau ist verkleinert
        akzent = str(h.get("akzent") or "")
        hue = K.FARBEN.get(akzent.lower(), akzent) if akzent else T.HUE
        bid = "kmv-" + T.D["name"]
        titel = str(h.get("titel") or "").strip()[:80] or "Überschrift"
        phasen = [str(x).strip()[:40] for x in (h.get("phasen") or []) if str(x).strip()]
        erste, letzte = (phasen[0] if phasen else "Einstieg"), (phasen[-1] if len(phasen) > 1 else "Üben")
        titel, erste = _esc(titel), _esc(erste)
        schrift = S.font_face(T.D["schrift_datei"]) + "\n" if T.D["schrift_datei"] else ""
        quiz = (f'<div class="kmb" id="{bid}" style="{uebung_vars(hue)}"><style>\n{schrift}{css_block(_lies(UEB_CSS) + block_css(), bid)}'
                f'\n</style><div class="km-kicker">{_esc(letzte)}</div><h3 class="km-bt">Kurzer Check</h3>'
                '<div class="km-q"><div class="km-qq">Hier steht eine Frage an die Lernenden.</div>'
                '<div class="km-act"><button type="button" class="km-btn">Prüfen</button></div></div></div>')
        inhalt = (T._kicker(f"{erste} · 5 min", hue) + T.h2(titel, hue)
                  + T.p("Hier steht ein Satz der Einheit. Hier steht ein zweiter Satz.")
                  + T.merk("Hier steht der Merksatz.", hue)
                  + f'<p style="margin:8px 0">{T.chips(["Begriff", "Begriff"], hue)}</p>')
        if T.D["name"] == "ohne":
            inhalt = T._semantisch(inhalt)
        return f'<div class="km-vorschau" style="width:500px">{T.huelle(inhalt)}{quiz}</div>'
    finally:
        T.D, T.HUE, K._HUE = alt_d, alt_hue, alt_k
        T.WELLE_KACHELN = None
        T._N.update(alt_n)
        T._FARBE.clear()


def design_vorschauen(hebel=None):
    """design_vorschau für alle Familien: {name: html} (ein Aufruf aus dem Worker für alle Kacheln)."""
    return {n: design_vorschau(n, hebel) for n in DS.namen()}


# ---------------------------------------------------------------- Vorschau der Einheit im Editor (AP13.11)
# Das HTML kommt nur aus dem Generator (KI-Text dort escaped). Für die Ansicht in der Mühle fallen Skripte und
# Ereignis-Attribute weg, ein iframe wird ein Platzhalter (keine Anfragen an Videodienste), Links verlieren ihre
# Adresse und Bedienelemente den Tabulator-Halt. Bilder bleiben `@@PLUGINFILE@@/name`; die Seite setzt Adressen ein.
_RE_V_SKRIPT = re.compile(r"<script\b[^>]*>.*?</script\s*>", re.I | re.S)
_RE_V_IFRAME = re.compile(r"<iframe\b[^>]*>.*?</iframe\s*>|<iframe\b[^>]*/?>", re.I | re.S)
# nur in echten Tags (`<name …>`), nie in Textknoten: maskierter Text („&lt;img onerror=…“, „target = 5“) bleibt
_RE_V_TAG = re.compile(r"<([A-Za-z][A-Za-z0-9-]*)((?:\s+[^\s=<>/\"']+(?:\s*=\s*(?:\"[^\"]*\"|'[^']*'|[^\s<>\"']+))?)*)(\s*/?)>")
_RE_V_ATTR = re.compile(r"""\s+([^\s=<>/"']+)(\s*=\s*(?:"[^"]*"|'[^']*'|[^\s<>"']+))?""")
_V_BEDIEN = {"button", "input", "select", "textarea", "summary"}
_RE_V_ID = re.compile(r"^id:\s*\S+\s*$")
# Einheit, in der ein Platzhalter die Menge einer Übung nennt (wie die Mindestmaße)
_V_MENGE = {"Quiz": "Fragen", "Test": "Fragen", "Lesebuch": "Fragen", "Zuordnen": "Paare", "Lernkarten": "Karten",
            "Lückentext": "Lücken"}


def _editor_texte():
    from . import mappe as M
    return M.katalog()["oberflaeche"]["editor"]


def vorschau_sicher(html):
    """HTML des Generators für die Vorschau in der Mühle (siehe oben); test_api vergleicht damit die Sicherung."""
    t = _editor_texte()
    html = _RE_V_SKRIPT.sub("", html or "")
    html = _RE_V_IFRAME.sub(f'<div class="km-vorschau-video">{_esc(t["platzhalter_video"])}</div>', html)
    return _RE_V_ROH.sub(_v_roh, html)


# Alles, was ein Browser als Start-Tag lesen würde (Anführungszeichen dürfen `>` enthalten). Was davon nicht in das
# strenge Muster `_RE_V_TAG` passt (z. B. `<img/src=x/onerror=…>`), wird als Text gezeigt, nicht als Tag: der Filter
# lässt nichts durch, das er nicht versteht.
_RE_V_ROH = re.compile(r"""<[A-Za-z](?:"[^"]*"|'[^']*'|[^'">]|["'])*>""")


def _v_roh(m):
    t = _RE_V_TAG.fullmatch(m.group(0))
    return _v_tag(t) if t else m.group(0).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _v_tag(m):
    """Ein Tag ohne Ereignis-Attribute, href und target; Bedienelemente ohne Tabulator-Halt."""
    name, attrs, zu = m.group(1), m.group(2) or "", m.group(3)
    behalten = "".join(a.group(0) for a in _RE_V_ATTR.finditer(attrs)
                       if not (a.group(1).lower().startswith("on") or a.group(1).lower() in ("href", "target")))
    vorn = ' tabindex="-1"' if name.lower() in _V_BEDIEN else ""
    return f"<{name}{vorn}{behalten}{zu}>"


def _esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def editor_text(text):
    """Text eines Bausteins für das Feld im Editor: ohne die Zeile `id:` unter der Überschrift (die Mühle setzt sie beim
    Übernehmen wieder, mappe._mit_id)."""
    zeilen = (text or "").splitlines()
    for i in range(1, min(len(zeilen), 8)):
        if _RE_V_ID.match(zeilen[i]):
            del zeilen[i]
            break
    return "\n".join(zeilen).rstrip() + "\n" if zeilen else ""


def _menge(b):
    einheit = _V_MENGE.get(b["typ"])
    if not einheit:
        return ""
    try:
        n = _zaehle(b, einheit)
    except Exception:      # Zählen ist Anschauung; ein fehlerhafter Baustein zeigt dann keine Zahl
        return ""
    return f", {n} {_EINZAHL.get(einheit, einheit) if n == 1 else einheit}"


_RE_V_MARKE = re.compile(r' data-km-z="(\d+)"')


def _marken_im_editor(html, b):
    """MF5: `data-km-z` (Zeile der Kursdatei, kursdatei.MARKEN) -> Zeile im Feld des Editors (ohne `id:`, wie
    `_zeilen_im_editor`); Marken außerhalb des Bausteins fallen weg."""
    if not html or "data-km-z" not in html:
        return html
    zeilen = (b.get("text") or "").splitlines()
    kopf = next((i for i in range(1, min(len(zeilen), 8)) if _RE_V_ID.match(zeilen[i])), None)

    def um(m):
        n = int(m.group(1)) - b["zeile"] + 1
        if not 1 <= n <= len(zeilen) or (kopf is not None and n == kopf + 1):
            return ""
        return f' data-km-z="{n - 1 if kopf is not None and n > kopf + 1 else n}"'
    return _RE_V_MARKE.sub(um, html)


def _stellen(b, text):
    """MF5: Stellen für das Feld im Editor (gen/stelle.py); ein Baustein, den es nicht lesen kann, hat keine."""
    from . import stelle as ST
    try:
        return ST.oeffentlich(ST.stellen(text, b["typ"]))
    except Exception:          # Hilfe zum Ändern; der Weg über „Erweitert“ bleibt
        return []


def _vorschau_eintrag(b, item, k, web_ids, t):
    e = {"id": b["id"], "typ": b["typ"], "titel": b["titel"], "abschnitt": b.get("abschnitt"),
         "unterabschnitt": b.get("unterabschnitt"), "ebene": b.get("ebene"), "status": b["status"],
         "text": editor_text(b.get("text")), "html": None, "platzhalter": None}
    e["stellen"] = _stellen(b, e["text"]) if b["typ"] != "Unterabschnitt" else []
    e = _vorschau_inhalt(b, item, k, web_ids, t, e)
    e["html"] = _marken_im_editor(e["html"], b)
    return e


def _vorschau_inhalt(b, item, k, web_ids, t, e):
    if b["typ"] == "Unterabschnitt":
        e["platzhalter"] = {"art": "unterabschnitt", "text": t["unterabschnitt"]}
        return e
    if b["id"] in web_ids:
        e["platzhalter"] = {"art": "website", "text": t["platzhalter_website"].format(abschnitt=b.get("abschnitt") or "")}
        return e
    if b["status"] == "fehler" or item is None:
        meldungen = [("Zeile " + str(d.get("zeile_editor") or d["zeile_im_baustein"]) + " im Feld: "
                      if d.get("zeile_im_baustein") else "") + d["text"]
                     for d in k["diagnosen"] if d.get("baustein") == b["id"] and d["stufe"] == "fehler"]
        if b["status"] == "fehler" or meldungen:
            e["platzhalter"] = {"art": "fehler", "text": t["platzhalter_fehler"], "meldungen": meldungen}
        else:
            e["platzhalter"] = {"art": "aktivitaet", "text": t["platzhalter_weg"]}
        return e
    name = type(item).__name__
    heft = getattr(item, "heft", None)
    if heft and heft.get("heft"):          # AP13.47: Seite eines Arbeitshefts
        e["platzhalter"] = {"art": "h5p", "text": t["platzhalter_heft"].format(seite=heft["seite"], heft=heft["heft"],
                                                                             menge=_menge(b))}
        return e
    if name == "Label":
        e["html"] = vorschau_sicher(item.intro)
    elif name == "Page":
        e["html"] = vorschau_sicher(item.content)
    elif name in ("HvpItem", "Quiz"):
        e["platzhalter"] = {"art": "h5p" if name == "HvpItem" else "test",
                            "text": t["platzhalter_h5p" if name == "HvpItem" else "platzhalter_test"].format(menge=_menge(b))}
    elif name == "Url":
        e["platzhalter"] = {"art": "link", "text": t["platzhalter_link"].format(adresse=item.externalurl)}
    elif name == "Book":
        e["html"] = vorschau_sicher("".join(f"<h3>{c[0]}</h3>{c[1]}" for c in item.chapters))
        e["platzhalter"] = {"art": "aktivitaet", "text": t["platzhalter_aktivitaet"]}
    else:
        e["html"] = vorschau_sicher(item.intro or "")
        e["platzhalter"] = {"art": "aktivitaet", "text": t["platzhalter_aktivitaet"]}
    return e


def einheit_vorschau(kurs_md, steckbrief=None, assets=None):
    """AP13.11: Vorschau der ganzen Einheit für den Editor, je Baustein das HTML, das die Sicherung trägt (Textfeld,
    Seite, Übungsblock im Textfeld, Intro der übrigen Aktivitäten), sonst ein Platzhalter (H5P, Test, Link, Kapitel einer
    Website, fehlerhafter Baustein, Unterabschnitt). Liest immer die ganze Kursdatei nachsichtig wie `pruefe` (die Blöcke
    im Textfeld zählen über den Kurs, die Titelschrift steht nur im ersten Block); der Modulzustand ist danach wie vorher.
    MF5: je Baustein die Stellen für das Feld im Editor (gen/stelle.py), im HTML `data-km-z` mit ihrer Zeile im Feld.
    -> {titel, banner (id des Banner-Bausteins oder None), schrift_css, bausteine: [{id, typ, titel, abschnitt,
    unterabschnitt, ebene, status, text, html, platzhalter, stellen}], abschnitte: [{titel, bausteine, teil}]}"""
    t = _editor_texte()
    kurs, _ = extrahiere_kursdatei(kurs_md or "")
    kurs = K.normalisiere(kurs, [])
    sb = _steckbrief(steckbrief)
    alt = (T.D, T.HUE, K._HUE, dict(T._N), T.EMOJI, dict(T._FARBE))
    try:
        with _Arbeit() as work:
            diag = Diagnosen()
            try:
                _zuruecksetzen(sb, None)
            except ValueError:
                T.set_design(None)
                K._HUE = T.HUE
            A, assets_dir = _assets(assets, work, diag)
            K.MARKEN = True              # MF5: Zeilen der Stellen im HTML der Vorschau
            try:
                k = K.parse_text(kurs, A, sb, nachsichtig=True, assets_dir=assets_dir)
            except KursdateiFehler:
                return {"titel": None, "banner": None, "schrift_css": "", "bausteine": [], "abschnitte": [],
                        "uebersicht": None}
            finally:
                K.MARKEN = False
            schrift = S.font_face(T.D["schrift_datei"]) if T.D.get("schrift_datei") else ""
            _zeilen_im_editor(k["diagnosen"], k["bausteine"])
            bausteine = [_vorschau_eintrag(b, k["items"].get(b["id"]), k, k["web_ids"], t) for b in k["bausteine"]]
            uebersicht = _uebersicht(k, sb, t)
    finally:
        T.D, T.HUE, K._HUE, T.EMOJI = alt[0], alt[1], alt[2], alt[4]
        T._N.update(alt[3])
        T._FARBE.clear()
        T._FARBE.update(alt[5])
    banner = next((b["id"] for b in bausteine if b["typ"] == "Banner"), None)
    return {"titel": k["titel"], "banner": banner, "schrift_css": schrift, "bausteine": bausteine,
            "abschnitte": [{"titel": a["titel"], "bausteine": a["bausteine"],
                            "teil": str((a.get("angaben") or {}).get("teil") or "")} for a in k["abschnitte"]],
            "uebersicht": uebersicht}


def _uebersicht(k, sb, t):
    """§9: Kursübersicht im Format des Steckbriefs (gen/uebersicht.py) mit den Angaben je Abschnitt für die Formulare."""
    from . import uebersicht as U
    from .mbz import FORMATE
    meta = sb.get("kurs") or {}
    try:
        moodle = moodle_format(meta.get("format") or "themen")
    except ValueError:
        moodle = "topics"
    fmt = next((w for w, m in FORMATE.items() if m == moodle), "themen")
    titel = meta.get("titel") or k.get("titel") or "Kurs"
    from . import mappe as M
    namen = {x["typ"]: x.get("formularname") or x["typ"] for x in M.katalog()["typen"]}
    html = U.html(k, sb, fmt, titel, t, lambda it: vorschau_sicher(it.intro), namen)
    abschnitte = [{"nr": nr, "titel": a["titel"], "allgemein": s.name is None,
                   "einheit": M.einheit_teil(str((a.get("angaben") or {}).get("teil") or "")),
                   "angaben": {x: str((a.get("angaben") or {}).get(x) or "") for x in ("kachelbild", "kachelicon", "farbe")}}
                  for nr, a, s in U.abschnitte(k)]
    return {"format": fmt, "titel": titel, "html": vorschau_sicher(html), "abschnitte": abschnitte}


# ---------------------------------------------------------------- Regel-Kennungen (AP13.3)
# Stabile Kennung je Prüfregel, die Korrektursatz, Karte und das Ereignis in der Kursmappe (`korrekturen`) mitführen;
# `protokolle/korrekturen.md` nennt dieselben Kennungen. Die Prüfung setzt `regel` selbst, wo sie die Regel kennt
# (einheit_pruefen); sonst ordnet `regel()` die Meldung des Parsers über Art und Wortlaut zu.
REGELN = {
    "zeit.annahme": "Zeile `Angenommen:` nimmt Zeit außerhalb des Kurses an",
    "zeit.kurz": "die Bausteine füllen weniger als `zeit_mindestanteil` % der Dauer (gelb, mit Korrektursatz)",
    "mindest.quiz": "Quiz unter dem Mindestmaß (Fragen)", "mindest.zuordnen": "Zuordnen unter dem Mindestmaß (Paare)",
    "mindest.lueckentext": "Lückentext unter dem Mindestmaß (Lücken)",
    "mindest.lernkarten": "Lernkarten unter dem Mindestmaß (Karten)", "mindest.test": "Test unter dem Mindestmaß",
    "mindest.hefteintrag": "Hefteintrag unter dem Mindestmaß (Wörter, Merksatz, fette Fachbegriffe)",
    "einstieg.lang": "Einstieg über der Wortgrenze", "phase.fehlt": "eine Phase der Vorlage hat keine Karte mehr",
    "vorgriff": "Aufgabe verwendet, was erst später eingeführt wird (nur im Protokoll, keine Prüfung)",
    "format.frage": "Frage nicht im Format", "typ.unbekannt": "unbekannter Typ in der Überschrift",
    "angabe.unbekannt": "unbekannte Angabe unter der Überschrift", "zone.unbekannt": "Zone nicht in `zonen`",
    "website.element": "`website:` am Element mit anderem Wert als im Abschnitt",
    "hinweis.leer": "Kasten, Beispiel oder Hinweis ohne Inhalt",
    "hinweis.einrueckung": "Inhalt von Kasten, Beispiel oder Hinweis nicht eingerückt (angenommen)",
    "hinweis.uebung": "Hinweis in einer Übung, deren Typ keine Gesamtrückmeldung hat (gelb)",
    "format.ebene": "Baustein-Überschrift mit abweichender Zahl von Rauten (angenommen)",
    "jahrgang.fehlt": "Jahrgangsstufe nicht angegeben, die Mühle rechnet mit 7",
    "lehrplan.fehlt": "Haken „Lehrplanbezug“ gesetzt, aber kein Lernbereich gewählt (gelb, nur am Rand)",
    "lesebuch.frage": "Lesebuch-Seite ohne Frage (gelb, mit Korrektursatz)",
    "frage.malpunkt": "Frage ohne „?“, Antwort beginnt mit Zahl oder Rechenzeichen: Malpunkt? (gelb, mit Korrektursatz)",
    "frage.roh": "Zeile einer Frage (`MC:`, `RF:`, ✔ mit Antworten) als Text im Baustein (rot)",
    "luecke.stern": "Stern in einer Lückenzeile ohne Gegenstück (gelb, mit Korrektursatz)",
    "luecke.tipp": "Tipp hinter der Lücke statt in ihr, `*Wort*:Tipp` (rot, mit Korrektursatz)",
    "luecke.bruch": "Bruch als ganze Lücke, `*1/2*` (rot, mit Korrektursatz)",
    "luecke.fett": "Fett mit `**` in einer Lückenzeile, verschiebt die Lücken (rot, mit Korrektursatz)",
    "mc.doppelt": "zwei gleiche Antworten in einer Frage (rot, mit Korrektursatz)",
    "mc.einmal": "mehr als ein ✔, wo genau eine Antwort richtig ist: Schnellquiz, Aussagen (rot, mit Korrektursatz)",
    "bild.name": "Bildname nicht lesbar: leer, ohne Endung .png/.jpg oder mit Ordner (rot, mit Korrektursatz)",
    "leer.antwort": "geplanter Baustein blieb nach der Antwort leer (gelb, Korrektursatz mit seiner id)",
    "antwort.abgeschnitten": "Antwort vermutlich abgeschnitten: die leeren Karten sind das Ende der Planfolge, dazu offener "
                             "Codeblock, Fehler im letzten Baustein oder zwei fehlende (Stand-Karte, mappe.abgeschnitten)",
    "bilder-zahl": "weniger `Bild:`-Zeilen als die Stufe aus Schritt 3 verlangt (gelb, Korrektursatz nur auf Wunsch; mehr: gelb)",
    "teilschritt.echo": "Baustein kündigt die Teilschritte der Vorlage an (gelb)",
    "variation": "Übungstypen wiederholen sich (gelb, nur am Rand)",
    "wunschtyp": "bevorzugter Übungstyp (Ich gebe die Richtung) fehlt in der Antwort (gelb, nur am Rand)",
    "sprache.lang": "Lesetext über dem Richtwert für Satzlänge oder LIX (gelb, Korrektursatz nur auf Wunsch)",
    "hilfe.ort": "Zeile `Hilfe:` in einer Übung, die keine Hilfen zeigt (gelb)",
    "hilfe.zahl": "mehr als zwei Zeilen `Hilfe:` je Aufgabe (gelb)",
    "zusatz.abschluss": "Zusatzaufgabe mit Abschluss bestehen oder als Voraussetzung eines Abzeichens (gelb)",
    "heft.aussen": "Übung bleibt außerhalb des Arbeitshefts (grau): Geschichte, Zusatzaufgabe, Voraussetzung eines Abzeichens",
    "heft.hilfe": "Zeile `Hilfe:` in einer Übung im Arbeitsheft (grau, die Hilfe fällt weg)",
    "bild.fehlt": "Bild nicht hochgeladen", "bild.alt": "`Bild:` ohne Alt-Text (gelb, mit Korrektursatz)", "bild.lesbar": "Bilddatei nicht lesbar (gelb, zählt wie fehlend)", "bilder.groesse": "Bilder der Einheit über 3 MB (gelb am Rand)", "id.ungueltig": "`id:` ungültig oder doppelt",
    "format.abschnitt": "Abschnitt fehlt oder Text außerhalb eines Elements",
    # AP13.46: Kennungen für die übrigen Meldungen des Parsers und des Baus (vorher Art als Kennung oder format.sonst)
    "format.ueberschrift": "Überschrift auf falscher Ebene oder an falscher Stelle (`####` ohne Unterabschnitt)",
    "format.kopf": "Überschrift vor dem ersten Abschnitt außer `# Titel`", "typ.fehlt": "Baustein-Überschrift ohne `Typ:`",
    "abschnitt.allgemeines": "„Allgemeines“ nicht als erster Abschnitt",
    "abschnitt.teil": "`teil:` zweimal im Abschnitt oder schon vergeben",
    "angabe.wert": "Wert einer Angabe nicht erlaubt: Datum, Farbe, Zahl, Prozent, Auswahl",
    "format.zeile": "Zeile `Seite:`, `Kapitel:` oder eines anderen Typs an dieser Stelle nicht erlaubt",
    "inhalt.leer": "Baustein ohne Fragen, Karten, Einträge, Seiten, Kapitel, Szenen oder Dateien; Seite oder Kapitel leer",
    "format.tabelle": "Tabelle mit ungleich vielen Spalten oder ohne Kopfzeile mit mehr als zwei Spalten",
    "format.schritte": "`Schritte:` ohne Liste", "format.vergleich": "`Vergleich:` nicht zwei Punkte mit Unterliste",
    "format.bildzeile": "`Bildzeile:` ohne Alt-Text oder Text", "format.ueberblick": "Überblick nicht als Liste",
    "format.zuordnen": "Zuordnen ohne `zonen:` oder nicht als Liste `- Element → Zone`",
    "format.lernkarten": "Lernkarte nicht `Vorderseite → Rückseite` oder mit unbekanntem Zusatz",
    "format.umfrage": "Umfrage nicht als Liste", "format.abstimmung": "Abstimmung mit weniger als zwei Optionen",
    "format.glossar": "Glossar-Eintrag nicht `- Begriff → Erklärung` oder Tabelle ohne Kopf",
    "format.lesebuch": "Lesebuch beginnt nicht mit `Seite:`", "format.buch": "Buch: Kapitel fehlt, ohne Titel oder zu spät",
    "format.geschichte": "Geschichte: Szene, Frage, Ende oder Ziel nicht im Format",
    "format.badge": "Badge ohne `bild:` oder `voraussetzung:`, oder Voraussetzung nicht eindeutig",
    "format.datei": "Datei ohne Zeile `datei:`", "datei.fehlt": "Datei (`datei:`, Verzeichnis) nicht hochgeladen",
    "adresse.fehlt": "Link oder Website ohne https-Adresse in der Zeile unter der Überschrift",
    "adresse.http": "Adresse mit http statt https (grau)", "kopf.ignoriert": "Zeile vor dem ersten Abschnitt ignoriert (grau)",
    "eingabe.codeblock": "Codeblock-Zeichen und Text davor und danach weggelassen (grau)",
    "eingabe.vorrede": "Vorrede vor der Kursdatei weggelassen (grau)",
    "eingabe.gerendert": "Antwort sieht gerendert aus, ohne Überschriften mit `#` (grau)",
    "eingabe.html": "HTML außer den erlaubten Tags entfernt (grau)",
    "eingabe.liefertext": "Hinweis für die Lehrkraft in der Kursdatei, ignoriert (grau)",
    "latex.umgesetzt": "LaTeX in Klartext umgesetzt (grau)", "latex.offen": "LaTeX-Befehl nicht umgesetzt (grau)",
    "kachel.doppelt": "Kachelformat: `Kacheln:` oder Überblick in Allgemeines weggelassen (grau)",
    "glossar.import": "Glossar: Einträge nach dem Import als XML einlesen (grau)",
    "steckbrief.wert": "Angabe im Steckbrief nicht lesbar: Designfamilie, Format, Start, Formatoptionen",
    "steckbrief.delta": "`--delta` ohne passenden Teil (nur CLI)", "bau.fehler": "Bau der Sicherung abgebrochen",
    "sicherung.pruefung": "Prüfung der fertigen Sicherung (check.py) meldet Fehler oder Warnung",
    "format.sonst": "übriges Format (letzter Auffang; in den Tests nie)",
}
_REGEL_TEXT = [
    (re.compile(r"unbekannter Elementtyp"), "typ.unbekannt"),
    (re.compile(r"unbekannte Angabe"), "angabe.unbekannt"),
    (re.compile(r"^Zone „"), "zone.unbekannt"),
    (re.compile(r"website am Element"), "website.element"),
    (re.compile(r"ohne Inhalt – Inhalt um zwei"), "hinweis.leer"),
    (re.compile(r"^Lesebuch: Seite „.*“ ohne Frage$"), "lesebuch.frage"),
    (re.compile(r"^Frage als Text im Baustein"), "frage.roh"),
    (re.compile(r"Tipp hinter der Lücke „"), "luecke.tipp"),
    (re.compile(r"Bruch „.*“ als ganze Lücke"), "luecke.bruch"),
    (re.compile(r"Fett mit `\*\*` gibt es hier nicht"), "luecke.fett"),
    (re.compile(r"steht zweimal in der Frage$"), "mc.doppelt"),
    (re.compile(r"mehr als eine (?:Antwort|Aussage) mit ✔"), "mc.einmal"),
    (re.compile(r"^Bildname „"), "bild.name"),
    (re.compile(r"^(?:MC|RF|Einsetzen|Markieren|Lückentext|Aussagen|Schnellquiz|Kurzantwort)\b|jede Frage beginnt mit"),
     "format.frage"),
    (re.compile(r"Abschnitt \(`## Titel`\)|außerhalb eines Elements|kein Abschnitt"), "format.abschnitt"),
    (re.compile(r"^Überschrift (?:an dieser Stelle nicht erlaubt|der Ebene)|^Unterabschnitte nur direkt"),
     "format.ueberschrift"),
    (re.compile(r"^Element ohne Typ"), "typ.fehlt"),
    (re.compile(r"^Typ \S+ nicht umgesetzt$"), "typ.unbekannt"),
    (re.compile(r"^Vor dem ersten Abschnitt"), "format.kopf"),
    (re.compile(r"^„Allgemeines“ \(Abschnitt 0\)"), "abschnitt.allgemeines"),
    (re.compile(r"^zwei Zeilen teil:|^teil „.*“ ist schon vergeben$"), "abschnitt.teil"),
    (re.compile(r"^Bild „.*“(?: nicht in assets/|: externe Bilder)"), "bild.fehlt"),     # Bau ohne Platzhalter
    (re.compile(r"^Datei „.*“ nicht in assets/"), "datei.fehlt"),
    (re.compile(r"^Adresse \(https://…\) in der Zeile unter"), "adresse.fehlt"),
    (re.compile(r"^„(?:Seite|Kapitel|Unterkapitel):“ ist nur im|^\S+ ist hier nicht erlaubt$"), "format.zeile"),
    (re.compile(r": kein Fragetyp$|^\S+: im Test nur "), "format.frage"),
    (re.compile(r"^(?:Quiz|Test|Umfrage) ohne Fragen$|^Zuordnen ohne Elemente$|^Lernkarten ohne Karten$|^Glossar ohne "
                r"Einträge|^Verzeichnis ohne Dateien|^Lesebuch ohne Seiten|^Buch ohne Kapitel|^Geschichte ohne Szenen$"
                r"|^(?:Seite|Kapitel) „.*“ ist leer$"), "inhalt.leer"),
    (re.compile(r"^Tabelle: "), "format.tabelle"),
    (re.compile(r"^Schritte: "), "format.schritte"),
    (re.compile(r"^Vergleich braucht"), "format.vergleich"),
    (re.compile(r"^Bildzeile: "), "format.bildzeile"),
    (re.compile(r"^Überblick: "), "format.ueberblick"),
    (re.compile(r"^Zuordnen: "), "format.zuordnen"),
    (re.compile(r"^Lernkarten?: "), "format.lernkarten"),
    (re.compile(r"^Umfrage: "), "format.umfrage"),
    (re.compile(r"^Abstimmung: "), "format.abstimmung"),
    (re.compile(r"^Glossar-(?:Tabelle|Eintrag): "), "format.glossar"),
    (re.compile(r"^Lesebuch: erste Zeile"), "format.lesebuch"),
    (re.compile(r"^Buch: |^Unterkapitel vor dem ersten Kapitel$|^(?:Kapitel|Unterkapitel) ohne Titel$"), "format.buch"),
    (re.compile(r"^Geschichte: |^(?:Szene|Frage|Ende): Schlüssel fehlt|^Ziel „.*“ unbekannt|^Szene: |^Szene ohne Text$"
                r"|^Antwort: `- Text → ziel`|^Frage ohne Antworten$"), "format.geschichte"),
    (re.compile(r"^`bild: datei\.png` fehlt$|^`voraussetzung: |^voraussetzung „"), "format.badge"),
    (re.compile(r"^Datei: `datei:"), "format.datei"),
    (re.compile(r"^(?:website|farbe|abschluss|sichtbar ab|kachelicon|anzeige|rückmeldung|abgabe|bestehen|fällig|typ"
                r"|ergebnisse) „|„[^“]*“: ganze Zahl erwartet$"), "angabe.wert"),
    (re.compile(r"^Codeblock"), "eingabe.codeblock"),
    (re.compile(r"Vorrede vor der Kursdatei weggelassen$"), "eingabe.vorrede"),
    (re.compile(r"^Der Text sieht gerendert aus"), "eingabe.gerendert"),
    (re.compile(r"^--delta: "), "steckbrief.delta"),
]
# Art -> Kennung, wenn weder `regel` gesetzt ist noch ein Wortlaut passt. Kein Eintrag für `bild`: jede Bild-Meldung
# setzt ihre Kennung selbst (bild.fehlt, bild.alt, bild.lesbar), eine fremde Warnung landet so nie bei bild.fehlt
_REGEL_ART = {"ebene": "format.ebene", "zeit": "zeit.annahme", "einstieg": "einstieg.lang", "einrueckung": "hinweis.einrueckung",
              "id": "id.ungueltig", "phase": "phase.fehlt", "uebung": "hinweis.uebung", "eingabe": "eingabe.codeblock",
              "steckbrief": "steckbrief.wert", "bau": "bau.fehler", "pruefung": "sicherung.pruefung"}


def _ascii(t):
    return t.lower().replace("ü", "ue").replace("ä", "ae").replace("ö", "oe").replace("ß", "ss")


def regel(d):
    """Kennung der Regel einer Diagnose (siehe REGELN)."""
    if d.get("regel"):
        return d["regel"]
    for muster, kennung in _REGEL_TEXT:
        if muster.search(d.get("text") or ""):
            return kennung
    return _REGEL_ART.get(d.get("art"), "format.sonst")


def _diagnose_dicts(diag):
    return [dict(d, satz=diag.satz(d), regel=regel(d)) for d in diag]


# ---------------------------------------------------------------- Bildwünsche (AP13.1)
_RE_BILDZEILE = re.compile(r"^(Bildwunsch|Bildprompt):\s*(.*)$")
_RE_DATEI = re.compile(r"^([^\s|]+\.(?:png|jpe?g))\s*(?:\|\s*(.*))?$", re.I)
_RE_BILD_GENANNT = re.compile(r"(?:^|[·|]\s*|\s)(?:Bild|Bildzeile|bild|kachelbild):\s*([^\s|·]+\.(?:png|jpe?g))", re.I | re.M)


def bildwuensche(kursdatei, bausteine=()):
    """Zeilen `Bildwunsch:` (ein Satz, was zu sehen ist) und `Bildprompt:` (Auftrag für einen Bildgenerator) der
    Kursdatei, je Bild mit dem Baustein, dessen `Bild:` die Datei nennt. Ein `Bildprompt:` ohne Dateinamen gehört zum
    `Bildwunsch:` davor; ein Wunsch ohne Dateinamen bekommt die erste genannte Bilddatei ohne Wunsch.
    -> [{datei, wunsch, prompt, baustein, titel, zeile}]"""
    out = []
    for i, z in enumerate((kursdatei or "").splitlines(), 1):
        m = _RE_BILDZEILE.match(z)
        if not m:
            continue
        d = _RE_DATEI.match(m.group(2).strip())
        datei, text = (d.group(1), (d.group(2) or "").strip()) if d else (None, m.group(2).strip())
        if m.group(1) == "Bildwunsch":
            # ein neuer Wunsch zum gleichen Dateinamen ersetzt den alten (AP13.3)
            out = [w for w in out if not (datei and w["datei"] == datei)]
            out.append({"datei": datei, "wunsch": text, "prompt": "", "zeile": i})
            continue
        ziel = next((w for w in reversed(out) if datei and w["datei"] == datei), None) \
            or (out[-1] if out and not out[-1]["prompt"] and (not datei or not out[-1]["datei"]) else None)
        if ziel is None:
            out.append({"datei": datei, "wunsch": "", "prompt": text, "zeile": i})
        else:
            ziel["prompt"] = text
            ziel["datei"] = ziel["datei"] or datei
    genannt = []
    for b in bausteine:
        for name in _RE_BILD_GENANNT.findall(b.get("text") or ""):
            if all(n != name for n, _ in genannt):
                genannt.append((name, b))
    frei = [n for n, _ in genannt if n not in {w["datei"] for w in out}]
    for w in out:
        if not w["datei"] and frei:
            w["datei"] = frei.pop(0)
        b = next((b for n, b in genannt if n == w["datei"]), None)
        w["baustein"], w["titel"] = (b["id"], b["titel"]) if b else (None, None)
    return out


_RE_OFFEN = re.compile(r"^Offen:\s*(.*?)\s*$")


def offen(kursdatei, bausteine=()):
    """Zeilen `Offen:` der Kursdatei (fachliche Zweifel der KI, AP13.12 a10), im Kopf und unter Bausteinen; eine Zeile
    unter einem Baustein trägt dessen id und Titel. Gleiche Zeilen am selben Ort zählen einmal.
    -> [{text, baustein, titel, zeile, frage (MF6: Nummer der Frage im Baustein oder None)}]"""
    out, gesehen, kurs = [], set(), (kursdatei or "").splitlines()
    for i, z in enumerate(kurs, 1):
        m = _RE_OFFEN.match(z)
        if not m or not m.group(1):
            continue
        b = next((b for b in bausteine if b["zeile"] <= i < b["zeile"] + b["zeilen"]), None)
        schluessel = (m.group(1), b["id"] if b else None)
        if schluessel in gesehen:
            continue
        gesehen.add(schluessel)
        out.append({"text": m.group(1), "baustein": b["id"] if b else None, "titel": b["titel"] if b else None,
                    "zeile": i, "frage": _offen_frage(b, i, kurs) if b else None})
    return out


def _offen_frage(b, i, kurs):
    """MF6: Nummer der Frage im Baustein (wie „Fragen und Lösungen“ zählt), unter der die Zeile `Offen:` (Zeile i der
    Kursdatei, `kurs` = ihre Zeilen) ohne Leerzeile steht; sonst None (dann steht sie oben im Kasten). Im Text des
    Bausteins stehen die Zeilen `Offen:` als Leerzeilen, die Zählung bleibt gleich."""
    from . import stelle as ST
    zeilen = (b.get("text") or "").splitlines()
    kopf = next((k for k in range(1, min(len(zeilen), 8)) if _RE_V_ID.match(zeilen[k])), None)
    try:
        st = ST.stellen(editor_text(b.get("text")), b["typ"])
    except Exception:          # Hilfe zum Zuordnen; ohne Nummer bleibt die Zeile oben im Kasten
        return None

    def in_kurs(e):            # Zeile im Feld des Editors (ohne `id:`) -> Zeile der Kursdatei
        return b["zeile"] + e - 1 + (1 if kopf is not None and e > kopf else 0)
    vor = [s for s in st if s["zeilen"] and in_kurs(max(s["zeilen"])) < i]
    if not vor:
        return None
    s = max(vor, key=lambda x: max(x["zeilen"]))
    dazwischen = kurs[in_kurs(max(s["zeilen"])):i - 1]
    if not s.get("frage") or any(not _RE_OFFEN.match(z) for z in dazwischen):
        return None
    return s["frage"]


# ---------------------------------------------------------------- Prüfregeln der Mühle (AP13.1)
_RE_MINUTEN = re.compile(r"\b\d+\s*(?:Minuten\b|Min\.|min\b)")
_RE_ID_IM_TEXT = re.compile(r"\bb\d+(?:-\d+)*\b")
_RE_ANGABE = re.compile(r"^[a-zäöüß ]+:\s")
_EINZAHL = {"Fragen": "Frage", "Paare": "Paar", "Lücken": "Lücke", "Karten": "Karte", "Wörter": "Wort"}


def woerter(b):
    """Wörter eines Bausteins ohne Überschrift, Angaben (`schlüssel: wert`) und Bildzeilen; Präfixe wie `Vorspann:` und
    HTML zählen nicht."""
    from . import mappe as M
    n = 0
    for z in (b.get("text") or "").splitlines()[1:]:
        t = z.strip()
        if not t or _RE_ANGABE.match(t) or t.startswith(("Bild:", "Bildzeile:")):
            continue
        # Rückmeldung nach „→“ zählt nicht, aber nur in Antwort- und Rückmeldungszeilen; in Text und Merksätzen sind
        # Paare wie „play → played“ Inhalt (Regressionsprobe b10: Hefteintrag Simple past blieb bei 78 Wörtern)
        if t.startswith("→"):
            continue
        if t.startswith(("- ", "✔", "✘")) or "✔" in t or "✘" in t:
            t = t.split(" → ")[0]
        t = M._RE_PRAEFIX.sub("", M._RE_HTML.sub(" ", t))
        n += len(M._RE_WORT.findall(t.replace("✔", " ").replace("✘", " ")))
    return n


def _zaehle(b, einheit):
    from . import mappe as M
    text = b.get("text") or ""
    zeilen = [z.strip() for z in text.splitlines()[1:]]
    if einheit == "Fragen":
        return M.fragen(b)[0]
    if einheit == "Paare":
        return sum(1 for z in zeilen if z.startswith("- ") and " → " in z)
    if einheit == "Karten":
        return sum(1 for z in zeilen if z.startswith("- "))
    if einheit == "Lücken":
        return len(M._RE_LUECKE.findall(re.sub(r"\*\*[^*]+\*\*", " ", K.luecken_text(text))))
    return woerter(b)


_RE_BILDZEILE_IM_TEXT = re.compile(r"^\s*(?:Bild|Bildzeile):", re.M)
_RE_SCHRITTE_ANGEKUENDIGT = re.compile(r"\bin (?:\d+|zwei|drei|vier|fünf|sechs) Schritten\b|\bSchritt 1\b", re.I)


def einheit_bausteine(ergebnis, mappe):
    """Bausteine der laufenden Einheit (AP13.4): Karte der Einheit, ergänzte (b7-2) nach ihrer Basis-id."""
    from . import mappe as M
    tag = M.laufende_einheit(mappe)
    eigene = {e["id"] for e in mappe.get("bausteine", []) if (e.get("einheit") or None) == tag}
    return [b for b in ergebnis.get("bausteine", []) if b["id"] in eigene or re.sub(r"(?:-\d+)+$", "", b["id"]) in eigene]


def bilder_bytes(bausteine, groessen):
    """Bytes der Bilder, die die Bausteine nennen (je Datei einmal); groessen: Name -> Bytes."""
    namen = {n for b in bausteine for n in _RE_BILD_GENANNT.findall(b.get("text") or "")}
    return sum(groessen.get(n, 0) for n in namen)


def bilder_zahl(bausteine):
    """Zeilen `Bild:` und `Bildzeile:` in den Bausteinen (AP13.4, Stufe aus Schritt 3)."""
    return sum(len(_RE_BILDZEILE_IM_TEXT.findall(b.get("text") or "")) for b in bausteine)


def _teilschritt_echo(text, schritt):
    """Kündigt der Baustein seine Teilschritte an („in vier Schritten“, „Schritt 1“) oder übernimmt er fünf Wörter am
    Stück aus dem Teilschritt der Vorlage? -> das Zitat oder None (AP13.4, Hefeteig)."""
    zeilen = [z for z in (text or "").splitlines()[1:] if z.strip() and not _RE_ANGABE.match(z.strip())]
    vorn = " ".join(zeilen[:6])
    m = _RE_SCHRITTE_ANGEKUENDIGT.search(vorn)
    if m:
        return m.group(0)
    wort = lambda t: re.findall(r"[A-Za-zÄÖÜäöüß]+", t.lower())     # noqa: E731
    plan, inhalt = wort(schritt or ""), " " + " ".join(wort(text or "")) + " "
    for i in range(len(plan) - 4):
        kette = " ".join(plan[i:i + 5])
        if " " + kette + " " in inhalt:
            return kette
    return None


_KEIN = {"Quiz": "keins", "Zuordnen": "keins", "Lernkarten": "keine", "Lückentext": "keinen", "Geschichte": "keine",
         "Lesebuch": "keins"}


def _zeit_aussen(zeile, minuten, woerter):
    """AP13.29 §4: Nimmt eine Zeile `Angenommen:` mit Minuten Zeit außerhalb des Kurses an? Nein, wenn die genannten
    Minuten zusammen höchstens 10 % neben den geplanten Minuten der Einheit liegen (Einteilung der Bausteine), oder wenn
    die Zeile keine Tätigkeit außerhalb des Kurses nennt (`pruefregeln.zeit_aussen`, Teilwörter nach Faltung)."""
    falt = _ascii(zeile)
    if not any(_ascii(w) in falt for w in woerter):
        return False
    summe = sum(int(n) for n in re.findall(r"(\d+)\s*(?:Minuten\b|Min\.|min\b)", zeile))
    try:
        soll = int(minuten)
    except (TypeError, ValueError):
        return True
    return not (soll > 0 and abs(summe - soll) <= soll * 0.1)


def einheit_pruefen(ergebnis, mappe, steckbrief=None):
    """Prüfregeln der Mühle für eine Einheit, deren Text für den Chat kopiert wurde (`mappe.kopiert`; Kursdateien aus
    1.x und Testkurse bleiben unberührt): eine Zeile `Angenommen:`, die Minuten nennt, ist ein Fehler mit eigenem
    Korrektursatz (`bitte`); Mindestmaße je Typ (`mindest` im Katalog) als roter Baustein; ein Einstieg über
    `pruefregeln.einstieg_woerter` Wörtern als gelber Hinweis (Stufe warnung). Eine Annahme mit Minuten, die Bausteine
    der Antwort nennt (ergänzte Bausteine), zählt nicht als Zeit-Annahme. Ändert `ergebnis` und gibt es zurück."""
    from . import mappe as M
    if not mappe or not mappe.get("kopiert"):
        return ergebnis
    angaben = M.angaben_lesen(steckbrief or "")
    kat = M.katalog()
    regeln, prompt = kat["pruefregeln"], kat["prompt"]
    typen = {t["typ"]: t for t in kat["typen"]}
    plan = {e["id"]: e for e in mappe.get("bausteine", [])}
    from . import prompt as P
    # AP13.37 §2.2: Minuten der Einheit wie im Text für den Chat (mit eigenen Minuten je Karte deren Summe)
    # AP13.41 §3.2: liegt die Summe über der Dauer, rechnet Schritt 5 mit der Dauer
    minuten = P.pruef_minuten(mappe, [e for e in mappe.get("bausteine", []) if (e.get("einheit") or None)
                                      == M.laufende_einheit(mappe) and not e.get("aus")]) \
        or (mappe.get("einheit") or {}).get("minuten")
    jahrgang = (mappe.get("einheit") or {}).get("jahrgang")
    diag = Diagnosen()
    ids = {b["id"] for b in ergebnis.get("bausteine", [])}
    unit = einheit_bausteine(ergebnis, mappe)
    # AP13.35 §3.1: füllen die Minuten in den Überschriften die Dauer schon, bittet die Korrektur nicht ums Ergänzen
    kopf_minuten = sum(int(b.get("minuten") or 0) for b in unit if b.get("typ") not in M.struktur()
                       and not M.ist_zusatzaufgabe(plan.get(b["id"]) or {}, b))
    for i, z in enumerate((ergebnis.get("kursdatei") or "").splitlines(), 1):
        # Minuten in einer Annahme sind Zeit außerhalb des Kurses; nennt die Zeile Bausteine der Antwort (ergänzte
        # Bausteine „zur Füllung der 45 Minuten“), ist es keine; AP13.29: auch keine bloße Einteilung der Minuten
        if z.startswith("Angenommen:") and _RE_MINUTEN.search(z) and not (set(_RE_ID_IM_TEXT.findall(z)) & ids) \
                and _zeit_aussen(z, minuten, regeln["zeit_aussen"]):
            d = diag.fehler("Der Chat nimmt Zeit außerhalb des Kurses an (Zeile „Angenommen:“); die Minuten gehören "
                            "in die Bausteine", i, art="zeit")
            zeile = z.strip() if len(z.strip()) <= 120 else z.strip()[:119] + "…"
            d["bitte"] = prompt["korrektur_zeit"].format(zeile=zeile)
            d["ausgabe"] = "kopf"           # AP13.35 §3.1: die Zeile steht im Kopf der Kursdatei
            if not minuten or kopf_minuten < int(minuten) * 0.9:
                d["bitte"] += " " + prompt["korrektur_zeit_ergaenzen"].format(minuten=minuten or "geplanten")
                d["ergaenzen"] = True
            d["regel"] = "zeit.annahme"

    def melde(stufe, b, text, art, kennung):
        d = diag.add(stufe, art, text, b["zeile"], f"{b['typ']} „{b['titel']}“")
        d["baustein"], d["titel"], d["zeile_im_baustein"], d["regel"] = b["id"], b["titel"], 1, kennung

    # AP13.4: Bilder in Stufen – zu wenige `Bild:`-Zeilen gelb mit eigenem Satz (MF3, Konzept §7 Punkt 4: fehlende Bilder
    # sind nie ein Fehler; der Satz geht nur auf Wunsch in die Korrekturbitte), zu viele oder Bilder bei „keine“ gelb ohne
    # Satz; nur, wenn die Einheit schon Inhalt hat
    if unit and (_steckbrief(steckbrief).get("kurs") or {}).get("bilder") is not None:   # Einheiten vor b5: keine Stufe
        stufe = M.bilder_stufe(angaben.get("bilder"))
        n = bilder_zahl(unit)
        bilder = lambda x: f"{x} Bild" if x == 1 else f"{x} Bilder"     # noqa: E731
        # AP13.5g: gewählte Zahl (min gleich max) als „genau 12 Bilder“, Stufen wie bisher
        genau = stufe["min"] == stufe["max"] and stufe["min"] > 0
        gewaehlt = f"genau {bilder(stufe['min'])}" if genau else stufe["satz"]
        sind = "ist" if genau and stufe["min"] == 1 else "sind"
        if n < stufe["min"]:
            d = diag.warnung(f"Die Einheit hat {bilder(n)}, gewählt {sind} {gewaehlt}", art="bilder")
            d["regel"] = "bilder-zahl"
            d["ausgabe"] = "bilder"
            d["bitte"] = prompt["korrektur_bilder"].format(ist=n, bilder="Bild" if n == 1 else "Bilder", sind=sind,
                                                           stufe=gewaehlt, fehlt=bilder(stufe["min"] - n))
        elif stufe["max"] is not None and n > stufe["max"]:
            diag.warnung(f"Die Einheit hat {bilder(n)}, gewählt {sind} {gewaehlt}", art="bilder")["regel"] = "bilder-zahl"

    # AP13.35 §2.3: füllen die Bausteine die Dauer nicht (geschätzte Minuten wie am Rand unter `zeit_mindestanteil` %),
    # gelbe Warnung der Einheit mit Korrektursatz; nur, wenn jede Karte der Einheit in der Kursdatei steht (die Mappe ist
    # hier noch nicht abgeglichen: eine eben eingesetzte Karte trägt noch `geplant`)
    karten = [e for e in mappe.get("bausteine", []) if (e.get("einheit") or None) == M.laufende_einheit(mappe)
              and not e.get("aus") and e.get("typ") not in M.struktur() and not e.get("zusatzaufgabe")]
    da = {b["id"] for b in unit}
    if unit and minuten and karten and all(e["id"] in da for e in karten):
        ist = 0
        for b in unit:
            e = plan.get(b["id"]) or b
            if b.get("typ") in M.struktur() or M.ist_zusatzaufgabe(e, b):
                continue
            genau = M.zeitbedarf(b, jahrgang, M.rolle_von(e))
            ist += round(genau) if genau is not None else int(b.get("minuten") or 0)
        soll = int(minuten)
        if ist < soll * regeln["zeit_mindestanteil"] / 100:
            d = diag.warnung(prompt["zeit_kurz"].format(ist=ist, minuten=soll), art="dauer")
            d["regel"] = "zeit.kurz"
            d["bitte"] = prompt["korrektur_zeit_kurz"].format(ist=ist, minuten=soll)
            d["ausgabe"] = "ganz"

    # AP13.14: Sprachmessung je Lesetext; Richtwert nach Jahrgangsstufe, `kurs.sprache` nur in „Ich gebe die Richtung“
    # und „Ich steuere“. Über dem Richtwert gelb an der Karte, Zeile = Anfang des längsten Satzes; der Korrektursatz
    # hängt als `bitte` an der Warnung und geht nur auf Wunsch in die Korrekturbitte (prompt.korrektur `gelb`)
    from . import sprache as SP
    rw = SP.richtwert(jahrgang or angaben.get("jahrgang"), SP.sprache_fuer(mappe, angaben))
    for b in ergebnis.get("bausteine", []):
        werte = SP.messen(b) if b.get("status") != "fehler" else None
        if not werte:
            continue
        satz = SP.hinweis(werte, rw)
        b["sprache"] = dict(werte, richtwert={k: rw[k] for k in ("satz_mittel", "satz_max", "lix")}, ueber=bool(satz))
        if satz:
            d = diag.warnung(satz, b["zeile"] + werte["satz_max_zeile"] - 1, f"{b['typ']} „{b['titel']}“", art="sprache")
            d["baustein"], d["titel"], d["zeile_im_baustein"], d["regel"] = b["id"], b["titel"], werte["satz_max_zeile"], \
                "sprache.lang"
            lix = prompt["korrektursaetze"]["sprache_lix"] if SP.bewerten(werte, rw)["art"] == "lix" else ""
            d["bitte"] = prompt["korrektur"].format(titel=b["titel"], id=b["id"], was=prompt["korrektursaetze"]["sprache"]
                                                    .format(mittel=rw["satz_mittel"], max=rw["satz_max"], lix=lix))

    for b in ergebnis.get("bausteine", []):
        if b.get("status") == "fehler":
            continue
        e = plan.get(b["id"]) or b
        echo = _teilschritt_echo(b.get("text"), e.get("schritt")) if e.get("schritt") else None
        if echo:
            melde("warnung", b, f"Der Baustein kündigt seine Teilschritte an („{echo}“); sie sind Bauplan, nicht Kurstext",
                  "teilschritt", "teilschritt.echo")
        mind = typen.get(b["typ"], {}).get("mindest")
        heft = "Hefteintrag" in " ".join(str(x or "") for x in (e.get("titel"), e.get("schritt"), b["titel"]))
        if mind and (not mind.get("nur") or heft):
            n, soll, ein = _zaehle(b, mind["einheit"]), M.mindestzahl(mind, jahrgang), mind["einheit"]
            kennung = "mindest.hefteintrag" if mind.get("nur") == "Hefteintrag" else "mindest." + _ascii(b["typ"])
            # AP13.41 §2.1: nennt der Auftrag eine kleinere Zahl, gilt sie auch hier (keine rote Karte, wenn der Chat ihm
            # folgt); beim Hefteintrag zählen nur Wörter des Auftrags (Sätze nicht: der Text nennt dann das Wortziel)
            unter = P.auftrag_unter_mindest(dict(e, typ=b["typ"]), jahrgang)
            zahl, art = P._zahl_nomen(e.get("auftrag"), ("Wörter",))
            if unter:
                soll = unter[0]
            elif mind.get("nur") and zahl:              # Hefteintrag: Wörter des Auftrags, nie unter 1
                soll = max(1, min(soll, zahl))
            if n < soll:
                melde("fehler", b, f"Nur {n} {_EINZAHL.get(ein, ein) if n == 1 else ein}, nötig sind mindestens {soll}",
                      "mindest", kennung)
            if mind.get("nur") == "Hefteintrag":
                if not re.search(r"^\s*Merke:", b.get("text") or "", re.M):
                    melde("fehler", b, "Der Hefteintrag hat keinen Merksatz (Zeile „Merke:“)", "mindest", kennung)
                if not re.search(r"\*\*[^*]+\*\*|<(?:b|strong)>", b.get("text") or ""):
                    melde("fehler", b, "Der Hefteintrag hat keine fett gesetzten Fachbegriffe", "mindest", kennung)
        if M.rolle_von(e) == "einstieg" and b["typ"] in ("Textfeld", "Seite"):
            n, grenze = woerter(b), regeln["einstieg_woerter"]
            if n > grenze:
                melde("warnung", b, f"Der Einstieg hat {n} Wörter, vorgesehen sind höchstens {grenze}; das Neue gehört in "
                                    "die Erarbeitung",
                      "einstieg", "einstieg.lang")
    # AP13.5b: im Zweig „Ich gebe die Richtung“ gelb, wenn ein bevorzugter Übungstyp in der Antwort fehlt (keine rote Karte)
    if mappe.get("zweig") == "richtung" and unit:
        da = {b["typ"] for b in unit}
        for t in angaben.get("uebungstypen") or []:
            if t not in da:
                d = diag.warnung(f"Du wolltest {t}; die Antwort hat {_KEIN.get(t, 'keins')}", art="wunschtyp")
                d["regel"] = "wunschtyp"
    if not diag:
        return ergebnis
    status = {b["id"]: b for b in ergebnis.get("bausteine", [])}
    for d in diag:
        b = status.get(d["baustein"])
        if b is not None and d["stufe"] == "fehler":
            b["status"] = "fehler"
        elif b is not None and d["stufe"] == "warnung" and b["status"] == "ok":
            b["status"] = "warnung"
    ergebnis["diagnosen"] = ergebnis.get("diagnosen", []) + _diagnose_dicts(diag)
    ergebnis["ok"] = not any(d["stufe"] == "fehler" for d in ergebnis["diagnosen"])
    return ergebnis


def _form_melden(d, form, bausteine):
    """Meldungen aus `normalisiere` (Überschriftenebene) als Diagnosen am Baustein; gelb färbt die Karte."""
    for zeile, text, stufe in form:
        d.add(stufe, "ebene", text, zeile)
    d.zuordnen(bausteine)
    for b in bausteine:
        if b["status"] == "ok" and any(x["baustein"] == b["id"] and x["stufe"] == "warnung" for x in d):
            b["status"] = "warnung"


# ---------------------------------------------------------------- Diagnose einer Antwort ohne Bausteine (AP13.4)
_RE_TYPZEILE = re.compile(r"^[*_\s]*(" + "|".join(K.ELEMENTE) + r")\s*:", re.I | re.M)
# Meldungen des Parsers, die ohne Bausteine vorkommen, in der Sprache der Lehrkraft (und des Chats)
_DIAGNOSE_TEXT = [
    (re.compile(r"außerhalb eines Elements"), "Bausteine beginnen mit einer Überschrift `### Typ: Titel`"),
    (re.compile(r"kein Abschnitt|Abschnitt \(`## Titel`\) erwartet"), "die Einheit beginnt mit einer Zeile `## Titel`"),
    (re.compile(r"Vor dem ersten Abschnitt"), "vor der ersten Zeile `## Titel` stehen nur `# Titel` und Zeilen wie "
                                               "`Angenommen: …`"),
    (re.compile(r"Element ohne Typ"), "nach den Rauten steht ein Typ mit Doppelpunkt, etwa `### Seite: Titel`"),
]


def diagnose(text, assets=None, steckbrief=None, pr=None):
    """Warum eine Antwort keinen Baustein ergab: `leer` = der Text hat weder eine Überschrift (`#`) noch eine Zeile, die
    mit einem Typ beginnt (dann bleibt der Satz „Im Text stehen keine Bausteine“); sonst die ersten drei Meldungen des
    Parsers mit Zeile (in der eingefügten Antwort, wenn die Zeile dort steht) und Zitat der Zeile (höchstens 60 Zeichen).
    `pr` = schon vorliegendes Ergebnis von `pruefe` (etwa aus `mappe.antwort`). -> {leer, meldungen: [{zeile, zitat,
    text}], tipp}"""
    roh = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    pr = pr or pruefe(roh, assets, steckbrief)
    tipp = next((d["text"] for d in pr["diagnosen"] if d["art"] == "eingabe"), "")
    if not re.search(r"^\s*#", roh, re.M) and not _RE_TYPZEILE.search(roh):
        return {"leer": True, "meldungen": [], "tipp": tipp}
    zeilen, original = pr["kursdatei"].splitlines(), roh.splitlines()
    out = []
    # eine Zeile, die mit einem Typ beginnt, aber ohne Rauten: das ist die Ursache, alles andere folgt daraus
    ohne = next((i for i, z in enumerate(original) if _RE_TYPZEILE.match(z) and not z.lstrip().startswith("#")), None)
    if ohne is not None:
        z = original[ohne].strip().strip("*_ ")
        out.append({"zeile": ohne + 1, "zitat": z[:59] + "…" if len(z) > 60 else z,
                    "text": f"vor dem Typ stehen drei Rauten, also `### {z[:40]}`"})
        return {"leer": False, "meldungen": out, "tipp": tipp}
    for d in pr["diagnosen"]:
        if d["stufe"] == "hinweis" or len(out) >= 3:
            continue
        zitat, zeile = "", d.get("zeile")
        if zeile and 0 < zeile <= len(zeilen):
            zitat = zeilen[zeile - 1].strip()
            zeile = next((i + 1 for i, z in enumerate(original) if z.strip() == zitat and zitat), zeile)
        if len(zitat) > 60:
            zitat = zitat[:59] + "…"
        satz = next((t for m, t in _DIAGNOSE_TEXT if m.search(d["text"])), d["text"])
        out.append({"zeile": zeile, "zitat": zitat, "text": satz})
    return {"leer": False, "meldungen": out, "tipp": tipp}


# ---------------------------------------------------------------- prüfen
def pruefe(text, assets=None, steckbrief=None, mappe=None):
    """Kursdatei (oder ganze Chat-Antwort) nachsichtig lesen. Ergebnis: ok, titel, farbe, bausteine (id, typ, titel,
    abschnitt, zeile, zeilen, minuten, angaben, status, text), abschnitte, diagnosen (mit Bausteintitel und
    zeile_im_baustein), adressen (alle externen Adressen), bildwuensche, offen (Zeilen `Offen:`), kursdatei (der
    übernommene Text). Mit `mappe`
    (Kursmappe der Mühle) zusätzlich die Prüfregeln aus `einheit_pruefen`."""
    t0 = time.time()
    kurs, hinweise = extrahiere_kursdatei(text or "")
    form = []
    kurs = K.normalisiere(kurs, form)
    sb = _steckbrief(steckbrief)
    with _Arbeit() as work:
        diag = Diagnosen()
        try:
            _zuruecksetzen(sb, None)
        except ValueError as e:
            diag.fehler(str(e), art="steckbrief")
        A, assets_dir = _assets(assets, work, diag)
        groessen = {n: os.path.getsize(p) for n, (p, _) in A.items()}
        try:
            k = K.parse_text(kurs, A, sb, nachsichtig=True, assets_dir=assets_dir)
        except KursdateiFehler as e:     # bleibt nur bei Fehlern außerhalb jedes Elements
            k = {"titel": None, "farbe": T.HUE, "bausteine": [], "abschnitte": [], "diagnosen": Diagnosen(), "adressen": []}
            m = re.match(r"^\S+ Zeile (\d+)(?: \([^)]*\))?: (.*)$", str(e), re.S)
            k["diagnosen"].fehler(m.group(2) if m else str(e), int(m.group(1)) if m else None)
    d = k["diagnosen"]
    for h in hinweise:
        d.hinweis(h, art="eingabe")
    _form_melden(d, form, k["bausteine"])
    d[:] = list(diag) + list(d)
    adressen = [{"zeile": ln, "adresse": a, "https": a.startswith("https://"),
                 "baustein": next((b["id"] for b in k["bausteine"] if b["zeile"] <= ln < b["zeile"] + b["zeilen"]), None)}
                for ln, a in k["adressen"]]
    ergebnis = {"ok": not d.hat_fehler(), "titel": k["titel"], "farbe": k["farbe"], "bausteine": k["bausteine"],
                "abschnitte": k["abschnitte"], "diagnosen": _diagnose_dicts(d), "adressen": adressen,
                "bildwuensche": bildwuensche(kurs, k["bausteine"]), "offen": offen(kurs, k["bausteine"]),
                "kursdatei": kurs,
                "hefte": k.get("hefte") or [],          # AP13.47: je Arbeitsheft Name, Punkte, Übungen, außerhalb
                "bild_bytes": groessen,
                "dauer_s": round(time.time() - t0, 3), "version": VERSION}
    _seiten_bitten(ergebnis["diagnosen"], ergebnis["bausteine"])
    _zeilen_im_editor(ergebnis["diagnosen"], ergebnis["bausteine"])
    return einheit_pruefen(ergebnis, mappe, sb) if mappe else ergebnis


def _zeilen_im_editor(diagnosen, bausteine):
    """AP13.34 §3.4: der Editor zeigt die Zeile `id:` eines Bausteins nicht. `zeile_editor` ist die Zeilennummer der Meldung
    ohne sie (`zeile_im_baustein` zählt sie mit, wie die Karte in Schritt 5 und der Text für den Chat)."""
    nach_id = {b["id"]: b for b in bausteine}
    for d in diagnosen:
        n, b = d.get("zeile_im_baustein"), nach_id.get(d.get("baustein"))
        if not n or not b:
            continue
        zeilen = (b.get("text") or "").splitlines()
        kopf = next((i for i in range(1, min(len(zeilen), 8)) if _RE_V_ID.match(zeilen[i])), None)
        d["zeile_editor"] = n - 1 if kopf is not None and n > kopf + 1 else n


def _seiten_bitten(diagnosen, bausteine):
    """AP13.29 §5: der Korrektursatz zur Warnung „Lesebuch-Seite ohne Frage“ (Katalog) hängt als `bitte` an ihr."""
    from . import mappe as M
    p = M.katalog()["prompt"]
    nach_id = {b["id"]: b for b in bausteine}
    for d in diagnosen:
        s = d.get("regel") == "luecke.stern" and d.get("baustein") and re.search(r"in „(.*)“ zählt nicht als Lücke$", d["text"])
        if s:
            d["bitte"] = p["korrektur"].format(titel=d.get("titel") or nach_id[d["baustein"]]["titel"], id=d["baustein"],
                                               was=p["korrektursaetze"]["luecke_stern"].format(zitat=s.group(1)))
        if d.get("regel") == "frage.malpunkt" and d.get("baustein"):
            zeilen = (nach_id[d["baustein"]].get("text") or "").splitlines()
            n = d.get("zeile_im_baustein") or 0
            z = zeilen[n - 1].strip() if 0 < n <= len(zeilen) else ""
            d["bitte"] = p["korrektur"].format(titel=d.get("titel") or nach_id[d["baustein"]]["titel"], id=d["baustein"],
                                               was=p["korrektursaetze"]["malpunkt"].format(
                                                   z=n, zitat=z[:59] + "…" if len(z) > 60 else z))
        m = d.get("regel") == "lesebuch.frage" and d.get("baustein") and re.search(r"Seite „(.*)“ ohne Frage$", d["text"])
        if m:
            d["bitte"] = p["korrektur"].format(titel=d.get("titel") or nach_id[d["baustein"]]["titel"], id=d["baustein"],
                                               was=p["korrektursaetze"]["lesebuch_frage"].format(seite=m.group(1)))


# ---------------------------------------------------------------- bauen
def baue_voll(kurs_md, steckbrief=None, assets=None, zeit=None, seed=None, optionen=None):
    """Sicherung bauen. optionen: proto, delta ('pending' oder 'a,b'), design ('familie[,akzent,dichte,kasten]'), format,
    website, arbeitsheft (ja | nein | Prozent), mit_nutzerdaten,
    dateiname, pruefen (check.py, Standard ja), nachsichtig (fehlende Bilder als Platzhalter, Standard ja).
    zeit: Unix-Sekunden für alle Zeitstempel (Standard jetzt); seed: für die H5P-IDs (Standard Zufall)."""
    t0 = time.time()
    o = dict(optionen or {})
    e = Ergebnis()
    diag = e.diagnosen
    zeit = int(zeit if zeit is not None else time.time())
    sb = _steckbrief(steckbrief)
    teile = sb.get("teile", {}) or {}
    if o.get("website"):
        sb["kurs"] = dict(sb.get("kurs") or {}, website=o["website"])
    if o.get("format"):
        sb["kurs"] = dict(sb.get("kurs") or {}, format=o["format"])
    if o.get("arbeitsheft"):            # AP13.47: ja, nein oder Prozent für den Abschluss
        a = str(o["arbeitsheft"]).strip().lower()
        sb["kurs"] = dict(sb.get("kurs") or {}, arbeitsheft="nein" if a in K.NEIN else "ja")
        if a.rstrip("%").strip().isdigit():
            sb["kurs"]["arbeitsheft_bestehen"] = int(a.rstrip("%").strip())
    if o.get("design"):
        _design_option(sb, o["design"])
    try:
        _zuruecksetzen(sb, seed)
    except ValueError as ex:
        diag.fehler(str(ex), art="steckbrief")
        return e
    form = []
    kurs_md = K.normalisiere(kurs_md or "", form)
    for zeile, text, stufe in form:
        diag.add(stufe, "ebene", text, zeile)
    with _Arbeit() as work:
        A, assets_dir = _assets(assets, work, diag)
        try:
            k = K.parse_text(kurs_md, A, sb, proto=bool(o.get("proto")), nachsichtig=False, assets_dir=assets_dir,
                             platzhalter=o.get("nachsichtig", True))
        except KursdateiFehler as ex:
            diag.fehler(str(ex).split(": ", 1)[-1] if str(ex).startswith("kurs.md Zeile") else str(ex),
                        _zeile_aus(str(ex)))
            return e
        diag[:] = list(diag) + list(k["diagnosen"])
        e.bausteine = k["bausteine"]
        meta = sb.get("kurs", {}) or {}
        name = meta.get("titel") or k.get("titel") or "Kurs"
        short = meta.get("kurzname") or name[:20]
        summary = meta.get("beschreibung", "")
        try:
            fmt = moodle_format(o.get("format") or meta.get("format") or "themen")
        except ValueError as ex:
            diag.fehler(str(ex), art="steckbrief")
            return e
        fmt_opts = meta.get("formatoptionen") or {}
        if not isinstance(fmt_opts, dict):
            diag.fehler("Steckbrief: formatoptionen muss ein Mapping name: wert sein", art="steckbrief")
            return e
        if fmt == "tiles" and "basecolour" not in fmt_opts and (meta.get("farbe") or k.get("farbe")):
            fmt_opts["basecolour"] = meta.get("farbe") or k.get("farbe")
        try:
            startdate = K.ts_sichtbar_ab(meta.get("start")) if meta.get("start") else zeit
        except ValueError:
            diag.fehler(f"Steckbrief: start „{meta.get('start')}“: Datum als JJJJ-MM-TT", art="steckbrief")
            return e
        kurs = dict(format=fmt, format_options=fmt_opts, startdate=startdate,
                    glossar_nutzerdaten=bool(o.get("mit_nutzerdaten")))
        delta = o.get("delta")
        if delta:
            keys = [x for x, v in teile.items() if (v or {}).get("status") == "pending"] if delta == "pending" \
                else [x.strip() for x in str(delta).split(",")]
            if not keys:
                diag.fehler("--delta: keine Teile mit status: pending im Steckbrief", art="steckbrief")
                return e
            sections = [Section(None)]
            for key in keys:
                if key not in k["parts"]:
                    diag.fehler(f"--delta: Teil „{key}“ nicht in der Kursdatei (teil: {key} fehlt); "
                                f"vorhanden: {', '.join(k['parts']) or 'keine'}", art="steckbrief")
                    return e
                for part in k["parts"][key]:          # AP13.30: ein Teil kann mehrere Abschnitte haben
                    if isinstance(part, Section):
                        sections.append(part)
                    else:
                        sections.append(Section(part.name, items=part.items, available_from=part.available_from))
            course = Course(name, short, summary=summary, sections=sections, badges=[], image_path=None, **kurs)
            fname = f"{_dateiname(short)}_delta_{'-'.join(keys)}_{_zeitstempel(zeit)}.mbz"
        else:
            fname = f"{_dateiname(short)}_{'prototyp' if o.get('proto') else 'kurs'}_{_zeitstempel(zeit)}.mbz"
            if o.get("proto"):
                name, short = f"{short} – Prototyp", f"{short}-Proto"
            course = Course(name, short, summary=summary, sections=k["sections"], badges=k.get("badges", []),
                            image_path=k.get("image_path"), **kurs)
        e.dateiname = o.get("dateiname") or fname
        e.titel = name
        if fmt != "singleactivity":     # Einzelaktivität: genau ein Element, keine Zeile
            _fusszeile_anhaengen(course, sb)
        try:
            w = Writer(course, None, now=zeit, dateiname=e.dateiname)
            w.build()
        except ValueError as ex:
            diag.fehler(str(ex), art="bau")
            return e
        e.mbz = w.bytes
        n = len(w.glossare)
        stamm = os.path.splitext(e.dateiname)[0]
        for i, g in enumerate(w.glossare, 1):
            e.glossare.append((f"{stamm}_glossar{i if n > 1 else ''}.xml", glossary_import_xml(g)))
            diag.hinweis(f"Glossar „{g.name}“: {len(g.entries)} Einträge, nach dem Import als XML einlesen "
                         "(Glossar → Mehr → Einträge importieren)", art="glossar")["regel"] = "glossar.import"
        for titel, path in k.get("websites", []):
            with open(path, encoding="utf-8") as f:
                e.websites.append((titel, f.read()))
        if k.get("textfelder"):
            e.textfeld_html = vorschau_textfeld(k["textfelder"], name)
        if o.get("pruefen", True):
            from check import check_mbz
            pfad = os.path.join(work, e.dateiname)
            with open(pfad, "wb") as f:
                f.write(e.mbz)
            e.pruefung = check_mbz(pfad)
            errors, info, warnings = e.pruefung
            for wo, was in errors:
                diag.fehler(f"{wo} {was}", art="pruefung")
            for wo, was in warnings:
                diag.warnung(f"{wo} {was}", art="pruefung")
            if errors:
                e.mbz = None
    e.dauer_s = round(time.time() - t0, 3)
    return e


def _fusszeile_anhaengen(course, sb):
    """AP13.15: Lizenz und KI-Hinweis als Textfeld am Ende jedes benannten Abschnitts mit Inhalt (voller Bau, Prototyp
    und Nachlieferung); Abschnitt 0 bekommt keine. Neue Liste statt append: bei einer Nachlieferung aus einem
    Unterabschnitt teilt sich der Abschnitt die Liste mit dem Parser."""
    from .mappe import fusszeile
    zeile = fusszeile(sb)
    if not zeile:
        return
    for sec in course.sections:
        if sec.name is not None and sec.items:
            sec.items = sec.items + [Label(zeile, name="Hinweis zum Kurs")]


def _zeile_aus(msg):
    m = re.search(r"Zeile (\d+)", msg)
    return int(m.group(1)) if m else None


def baue(kurs_md, steckbrief=None, assets=None, zeit=None, seed=None, optionen=None):
    """(mbz_bytes | None, diagnosen als Liste von dicts)."""
    e = baue_voll(kurs_md, steckbrief, assets, zeit, seed, optionen)
    return e.mbz, _diagnose_dicts(e.diagnosen)
