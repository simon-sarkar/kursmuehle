"""Kursmappe: die Datei, die der Lehrkraft gehört (Formatversion 2).

Ein ZIP mit `mappe.json` (Formatversion, Titel, je Baustein ID, Typ, Titel, Abschnitt, Auftrag, Phase, Soll-Minuten),
`kurs.md`, `steckbrief.yaml` und `assets/`. kurs.md und steckbrief.yaml bleiben das 1.x-Format; die Metadaten stehen nur
in mappe.json, geschlüsselt über die stabile Baustein-ID aus dem Parser. Ein 1.x-Kursordner (kurs.md, steckbrief.yaml,
assets/) wird mit `aus_dateien()` zur Mappe; die Baustein-Liste kommt dann aus `gen.api.pruefe`.
ZIP-Einträge tragen einen festen Zeitstempel, damit dieselbe Mappe dieselben Bytes ergibt (Autosave-Vergleich).

Seit 2.0.0-a2 (AP10): `einheit` (Thema, Jahrgangsstufe, Minuten, Vorlage) und geplante Bausteine (`geplant: true`, noch
ohne Inhalt in kurs.md, etwa aus einer Einheitsvorlage). Der Abgleich ordnet Bausteine über die ID zu (explizit mit
`id:` oder berechnet), sonst nach Position. Textoperationen auf kurs.md (verschieben, entfernen, umbenennen),
Kennzahlen für die Diagnosen am Rand und die Kursangaben der Oberfläche (Steckbrief nur hier, nie in JavaScript).

Seit 2.0.0-a3 (AP11): `chat`, `material`, `durchsicht` in mappe.json; Ist-Minuten aus dem Inhalt gerechnet
(`zeitbedarf`); Strukturbausteine (`minuten: false` im Katalog) zählen in den Kennzahlen nicht; Antwort des Chats nur
für einzelne Bausteine einsetzen (`einsetzen`, Abgleich über `id:`) oder als weitere Einheit anhängen (`anhaengen`),
Vorschlag des Modus aus dem Text (`modus`).
"""
import datetime
import io
import json
import os
import re
import zipfile

import yaml

from . import api
from . import design as DS
from . import kursdatei as K

FORMAT = 2
_ZEIT = (1980, 1, 1, 0, 0, 0)
# seit 2.0.0-a3 (AP11): gewählter Chat, Material der Lehrkraft, Fragen und Lösungen durchgesehen; seit 2.0.0-b1 (AP13)
# die Schrittfolge: erreichter Schritt, Zweig („mach“, „steuer“), Aussehen gewählt, Text kopiert, importierte Einheiten,
# Zahl der Einheiten und der Teil der Einheit, die gerade angehängt wird
ZUSATZ = ("chat", "material", "durchsicht", "zeitplanung", "schritt", "zweig", "aussehen", "kopiert", "importiert",
          "einheiten", "anhaengen", "zeit_selbst", "laufend", "stueckelung", "korrekturen", "schleife", "bildpruefung",
          "modellhinweis", "durchsicht_weg", "durchsicht_entschieden", "bildformat")
# seit 2.0.0-b10 (AP13.5g): `durchsicht_weg` = gewählter Weg in Schritt 6 (ki, chat, selbst), `durchsicht_entschieden` =
# je Abweichung des Gegenprüfens („Baustein-id|Nummer der Aufgabe im Baustein“) {wert: gilt | uebergangen, hash: Hash des
# Bausteins beim Entscheid}, `bildformat` = Format der Bilder im Bilder-Schritt (Teil c)
# seit 2.0.0-b4 (AP13.3): `laufend` = Teil der Einheit, an der gerade gearbeitet wird („e2“ …; fehlt = erste Einheit),
# `stueckelung` = beim ersten Kopieren eingefrorene Teile des Textes ({einheit, leer, ids: [[id]], eingefuegt: [Teil]}),
# `korrekturen` = Ereignisse je Korrekturbitte ({version, chat, typ, regel, runde}, keine Inhalte),
# `bildpruefung` = je Bilddatei true, wenn die Lehrkraft im Schritt Bilder „Passt“ geklickt hat (ältere Mappen: [bool, …])
# Schlüssel je Baustein, die neben den Feldern des Parsers in der Mappe bleiben (AP13): Einheit der Nachlieferung,
# ausgeschaltete Karte (optionale Phase der Vorlage); seit 2.0.0-b5 (AP13.4) `weggelassen` = {minuten}: die Lehrkraft hat den
# Baustein nach einer Korrekturschleife weggelassen (Karte gestrichen, Minuten als Hinweis am Rand).
# `schleife` (Mappe) = je id {hash, gleich, rot}: Hash des zuletzt eingefügten Texts, gleiche und rote Korrekturrunden
# `modellhinweis` (AP13.8) = Einheiten („“ = erste), unter deren Korrekturbitte der Hinweis zum Modell schon stand
BLEIBT = ("einheit", "aus", "weggelassen")
AUTO = "automatisch"
# AP13.5f: Haken „Lehrplanbezug“ an, aber kein Lernbereich (gelb am Rand; derselbe Satz unter dem Picker, lehrplan.js)
LEHRPLAN_FEHLT = "Noch kein Lernbereich gewählt – der Text für den Chat enthält dann keine Kompetenzerwartungen"
# AP13.8 §9: Phasennamen der Vorlagen bis 2.0.0-b8 -> Namen aus dem Artikulationsschema (migriere; sonst verlöre eine
# ältere Kursmappe die Rolle ihrer Karten)
PHASEN_ALT = {"Aufwärmen": "Einstieg", "Kurz erinnern": "Vorwissensaktivierung", "Üben in Stufen": "Übung",
              "Selbstkontrolle": "Lernzielkontrolle", "Überblick": "Zielangabe", "Erinnern": "Wiederholung",
              "Üben nach Teilthemen": "Übung", "Probelauf": "Lernzielkontrolle", "Lesen": "Erarbeitung", "Üben": "Übung",
              "Sichern": "Sicherung", "Anwendung": "Transfer"}


class MappenFehler(Exception):
    pass


def neu(titel=None, bausteine=None, einheit=None):
    m = {"format": FORMAT, "kursmuehle": api.VERSION, "titel": titel or "", "erzeugt": _heute(),
         "bausteine": [_eintrag(b) for b in (bausteine or [])]}
    if einheit:
        m["einheit"] = dict(einheit)
    return m


def _heute():
    return datetime.date.today().isoformat()


def _eintrag(b, alt=None):
    """Metadaten eines Bausteins aus dem Parser-AST; `alt` = bisheriger Eintrag mit Auftrag, Phase, Soll."""
    alt = alt or {}
    e = {"id": b["id"], "typ": b["typ"], "titel": b["titel"], "abschnitt": b.get("abschnitt"),
         "minuten": b.get("minuten"), "auftrag": alt.get("auftrag", ""), "phase": alt.get("phase", ""),
         "soll": alt.get("soll", b.get("minuten")), "geplant": False, "neu": bool(alt.get("neu", False))}
    if alt.get("schritt") and alt.get("typ") in (b["typ"], AUTO):   # Teilschritt gilt nur für den geplanten Typ
        e["schritt"] = alt["schritt"]
    for k in BLEIBT:
        if alt.get(k):
            e[k] = alt[k]
    if alt.get("herkunft") and alt.get("titel") == b["titel"]:  # Titel von der Lehrkraft, bis der Chat ihn ersetzt
        e["herkunft"] = dict(alt["herkunft"])
    return e


def geplant(id, typ, titel, phase="", soll=None, auftrag="", schritt=""):
    """Eintrag für einen Baustein ohne Inhalt (Einheitsvorlage, „Baustein hinzufügen“); `schritt` = Teilschritt aus der
    Vorlage (steht im Text für den Chat, nicht auf der Karte)."""
    e = {"id": id, "typ": typ, "titel": titel, "abschnitt": None, "minuten": None, "auftrag": auftrag,
         "phase": phase, "soll": soll, "geplant": True, "neu": False}
    if schritt:
        e["schritt"] = schritt
    return e


def abgleich(mappe, bausteine):
    """mappe.json nach einer neuen Prüfung aktualisieren. Zuordnung zuerst über die ID (explizit mit `id:` oder
    berechnet), dann nach Position als Rückfall (gleicher Platz und Typ, sonst der nächste freie Eintrag gleichen Typs):
    so behält ein umbenannter Baustein Auftrag, Phase und Soll. Neue Bausteine kommen dazu, verschwundene fallen weg;
    geplante Bausteine ohne Gegenstück bleiben an ihrem Platz stehen. Reihenfolge wie in der Kursdatei."""
    alt = list(mappe.get("bausteine", []))
    nach_id = {e["id"]: i for i, e in enumerate(alt)}
    paar, genutzt = {}, set()
    for j, b in enumerate(bausteine):
        i = nach_id.get(b["id"])
        if i is not None and i not in genutzt:
            paar[j] = i
            genutzt.add(i)
    letzter, abschnitt = -1, None
    for j, b in enumerate(bausteine):
        if j in paar:
            letzter, abschnitt = paar[j], b.get("abschnitt")
            continue
        # eine geplante Karte füllt nur ein Baustein aus demselben Abschnitt (angehängte Einheit nimmt sie nicht); ein vom
        # Chat ergänzter Baustein (b2-2 zu b2) nimmt keine geplante Karte (AP13.8: sonst fehlt b3, wenn die Antwort
        # nach „Fortsetzung folgt“ den Rest bringt)
        zusatz = b.get("id_explizit") and re.match(r"^(.+)-\d+$", b["id"])
        zusatz = bool(zusatz) and zusatz.group(1) in nach_id
        frei = [i for i in range(letzter + 1, len(alt)) if i not in genutzt and not (zusatz and alt[i].get("geplant"))
                and (alt[i].get("typ") == b["typ"] or (alt[i].get("geplant") and alt[i].get("typ") == AUTO))
                and not (alt[i].get("geplant") and alt[i].get("aus"))   # ausgeschaltete Karte bleibt leer (AP13.1)
                and not (alt[i].get("geplant") and abschnitt is not None and b.get("abschnitt") != abschnitt)]
        kandidat = j if j in frei else (frei[0] if frei else None)
        if kandidat is not None:
            paar[j] = kandidat
            genutzt.add(kandidat)
            letzter, abschnitt = kandidat, b.get("abschnitt")
    neu_liste = [_eintrag(b, alt[paar[j]] if j in paar else None) for j, b in enumerate(bausteine)]
    # ein Baustein ohne Karte (vom Chat ergänzt, b7-2) gehört zur Einheit seines Abschnitts (AP13.3): wie der Nachbar
    for j, b in enumerate(bausteine):
        if j in paar:
            continue
        nachbar = next((neu_liste[k] for k in list(range(j - 1, -1, -1)) + list(range(j + 1, len(bausteine)))
                        if k in paar and bausteine[k].get("abschnitt") == b.get("abschnitt")), None)
        if nachbar is not None and nachbar.get("einheit"):
            neu_liste[j]["einheit"] = nachbar["einheit"]
    platz = {paar[j]: neu_liste[j] for j in paar}          # alter Index -> Eintrag in der neuen Liste
    for i, e in enumerate(alt):
        if i in genutzt or not e.get("geplant"):
            continue
        vor = next((platz[k] for k in range(i - 1, -1, -1) if k in platz), None)
        pos = neu_liste.index(vor) + 1 if vor is not None else 0
        while vor is not None and pos < len(neu_liste) and re.fullmatch(re.escape(vor["id"]) + r"-\d+", neu_liste[pos]["id"]):
            pos += 1                                       # hinter die Zusatzbausteine der Karte davor (b2-2)
        eintrag = dict(geplant(e["id"], e.get("typ", ""), e.get("titel", "")), **{k: e.get(k) for k in
                       ("auftrag", "phase", "soll", "schritt") + BLEIBT if e.get(k) is not None}, neu=bool(e.get("neu")))
        neu_liste.insert(pos, eintrag)
        platz[i] = eintrag
    mappe["bausteine"] = neu_liste
    mappe["format"] = FORMAT
    mappe["kursmuehle"] = api.VERSION
    return mappe


def migriere(mappe):
    """Ältere oder unvollständige mappe.json auf Formatversion 2 heben."""
    if not isinstance(mappe, dict):
        raise MappenFehler("mappe.json: Mapping erwartet")
    f = mappe.get("format", 1)
    if not isinstance(f, int) or f > FORMAT:
        raise MappenFehler(f"mappe.json: Formatversion {f} ist neuer als diese Kursmühle ({FORMAT}); Seite aktualisieren")
    out = neu(mappe.get("titel"), einheit=mappe.get("einheit") if isinstance(mappe.get("einheit"), dict) else None)
    out["erzeugt"] = mappe.get("erzeugt", out["erzeugt"])
    for k in ZUSATZ:
        if mappe.get(k) not in (None, ""):
            out[k] = mappe[k]
    if out.get("zweig") not in (None, "mach", "richtung", "steuer"):
        out["zweig"] = "steuer"        # AP13.5b: unbekannter Zweig (neuere Mühle) öffnet „Ich steuere“
    for e in mappe.get("bausteine", []) or []:
        if isinstance(e, dict) and e.get("id"):
            out["bausteine"].append({"id": e["id"], "typ": e.get("typ", ""), "titel": e.get("titel", ""),
                                     "abschnitt": e.get("abschnitt"), "minuten": e.get("minuten"),
                                     "auftrag": e.get("auftrag", ""),
                                     "phase": PHASEN_ALT.get(e.get("phase"), e.get("phase", "")), "soll": e.get("soll"),
                                     "geplant": bool(e.get("geplant", False)), "neu": bool(e.get("neu", False)),
                                     **({"schritt": e["schritt"]} if e.get("schritt") else {}),
                                     **({"herkunft": e["herkunft"]} if isinstance(e.get("herkunft"), dict) else {}),
                                     **{k: e[k] for k in BLEIBT if e.get(k)}})
    return out


def dateiname(mappe, datum=None):
    """<kurstitel>_<JJJJ-MM-TT>.kursmappe.zip"""
    titel = api._dateiname(mappe.get("titel") or "kurs")[:40]
    return f"{titel}_{datum or _heute()}.kursmappe.zip"


def schreiben(mappe, kurs_md, steckbrief, assets=None):
    """-> Bytes des ZIP. steckbrief: dict oder YAML-Text; assets: dict Name -> Bytes."""
    sb_text = steckbrief if isinstance(steckbrief, str) else api.steckbrief_schreiben(steckbrief or {})
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        def add(name, data):
            zi = zipfile.ZipInfo(name, date_time=_ZEIT)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            z.writestr(zi, data if isinstance(data, bytes) else str(data).encode("utf-8"))
        add("mappe.json", json.dumps(mappe, ensure_ascii=False, indent=1, sort_keys=True) + "\n")
        add("kurs.md", kurs_md or "")
        add("steckbrief.yaml", sb_text)
        for name in sorted(assets or {}):
            data = assets[name]
            add(f"assets/{os.path.basename(name)}", bytes(data.tobytes() if isinstance(data, memoryview) else data))
    return buf.getvalue()


def lesen(zip_bytes):
    """ZIP-Bytes -> dict(mappe, kurs_md, steckbrief (dict), steckbrief_text, assets {Name: Bytes})."""
    try:
        z = zipfile.ZipFile(io.BytesIO(bytes(zip_bytes)))
    except zipfile.BadZipFile:
        raise MappenFehler("Die Datei ist keine Kursmappe (kein ZIP)")
    namen = z.namelist()
    # auch Mappen akzeptieren, die in einem Unterordner gepackt wurden
    praefix = ""
    if "mappe.json" not in namen and "kurs.md" not in namen:
        for n in namen:
            if n.endswith("/kurs.md") or n.endswith("/mappe.json"):
                praefix = n.rsplit("/", 1)[0] + "/"
                break
    dateien = {n[len(praefix):]: z.read(n) for n in namen if n.startswith(praefix) and not n.endswith("/")}
    return aus_dateien(dateien)


def aus_dateien(dateien):
    """Dateien eines Ordners oder ZIPs (Pfad relativ -> Bytes): Kursmappe oder 1.x-Kursordner (kurs.md,
    steckbrief.yaml, assets/). Ohne mappe.json wird die Baustein-Liste aus der Kursdatei gelesen."""
    norm = {}
    for pfad, data in dateien.items():
        p = str(pfad).replace("\\", "/").lstrip("./")
        teile = p.split("/")
        # Ordnername davor (Import eines ganzen Ordners) abschneiden
        if len(teile) >= 2 and teile[-2] == "assets":
            p = "assets/" + teile[-1]
        elif teile[-1] in ("kurs.md", "steckbrief.yaml", "mappe.json"):
            p = teile[-1]
        else:
            continue
        norm[p] = bytes(data.tobytes() if isinstance(data, memoryview) else data)
    if "kurs.md" not in norm:
        raise MappenFehler("kurs.md fehlt (Kursmappe oder Kursordner mit kurs.md, steckbrief.yaml, assets/ erwartet)")
    kurs_md = norm["kurs.md"].decode("utf-8-sig")
    sb_text = norm.get("steckbrief.yaml", b"").decode("utf-8-sig")
    try:
        sb = api.steckbrief_lesen(sb_text)
    except Exception as e:     # yaml-Fehler als Mappenfehler melden
        raise MappenFehler(f"steckbrief.yaml: {e}")
    assets = {k[len("assets/"):]: v for k, v in norm.items() if k.startswith("assets/") and k != "assets/"}
    if "mappe.json" in norm:
        try:
            mappe = migriere(json.loads(norm["mappe.json"].decode("utf-8-sig")))
        except json.JSONDecodeError as e:
            raise MappenFehler(f"mappe.json: {e}")
    else:
        titel = (sb.get("kurs") or {}).get("titel")
        m = re.search(r"^# (?:Drehbuch\s*v?\d*\s*·\s*)?(.+?)(?:\s*·\s*\d+.*)?$", kurs_md, re.M)
        mappe = neu(titel or (m.group(1).strip() if m else ""))
        pr = api.pruefe(kurs_md, assets, sb)
        abgleich(mappe, pr["bausteine"])
    return {"mappe": mappe, "kurs_md": kurs_md, "steckbrief": sb, "steckbrief_text": sb_text, "assets": assets}


# ---------------------------------------------------------------- Katalog
_KATALOG = None


def katalog():
    """references/katalog.yaml (liegt neben scripts/, auch im generator.zip der Browser-Fassung)."""
    global _KATALOG
    if _KATALOG is None:
        pfad = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "references", "katalog.yaml")
        with open(pfad, encoding="utf-8") as f:
            _KATALOG = yaml.safe_load(f)
    return _KATALOG


# ---------------------------------------------------------------- Textoperationen auf kurs.md
def _bereiche(kurs_md):
    pr = api.pruefe(kurs_md)
    return pr["kursdatei"].splitlines(), pr["bausteine"]


def _text(lines):
    while lines and not lines[-1].strip():
        lines.pop()
    return "\n".join(lines) + "\n" if lines else ""


def _finde(bausteine, id):
    b = next((b for b in bausteine if b["id"] == id), None)
    if b is None:
        raise MappenFehler(f"Baustein {id} steht nicht in der Kursdatei")
    return b


def entferne(kurs_md, id):
    """Baustein (samt Unterbausteinen eines Unterabschnitts) aus der Kursdatei nehmen."""
    lines, bs = _bereiche(kurs_md)
    b = _finde(bs, id)
    del lines[b["zeile"] - 1:b["zeile"] - 1 + b["zeilen"]]
    return _text(lines)


_RE_MARKE = re.compile(r"§(\d+)§")


def loesung_zulassen(kurs_md, id, aufgabe, luecke, wert):
    """Antwort aus dem Gegenprüfen als weitere Lösung (AP13.5h a9): an Lücke `luecke` der Aufgabe `aufgabe` (gezählt im
    Baustein `id` wie `prompt.fragen`) `/wert` anhängen (`*Quellen/Glücksquellen:…*`), bei einer Kurzantwort ` · wert`.
    Steht der Wert schon unter den Lösungen, bleibt die Kursdatei, wie sie ist."""
    from . import prompt as P             # prompt importiert mappe; hier erst beim Aufruf
    wert = " ".join(str(wert or "").replace("*", "").replace("/", " ").replace(":", " ").split())
    if not wert:
        raise MappenFehler("Die Antwort ist leer")
    lines, bs = _bereiche(kurs_md)
    b = _finde(bs, id)
    a, e = b["zeile"] - 1, b["zeile"] - 1 + b["zeilen"]
    # jede Lücke und jede Kurzantwort-Zeile bekommt eine Marke; die Fragen des markierten Bausteins zeigen, welche
    # Stelle zu Aufgabe und Lücke gehört
    stellen, markiert = [], []
    for i in range(a, e):
        def marke(m, i=i):
            stellen.append(("luecke", i, m.start(1), m.end(1)))
            kopf, _, tipp = m.group(1).partition(":")
            return "*" + kopf + f"§{len(stellen) - 1}§" + (":" + tipp if tipp else "") + "*"
        z = P._RE_STERN.sub(marke, lines[i])
        mk = P._RE_ART.match(z.strip())
        if mk and mk.group(1) == "Kurzantwort":
            stellen.append(("kurz", i, None, None))
            z += f"§{len(stellen) - 1}§"
        markiert.append(z)
    fragen = P._fragen_baustein({"typ": b["typ"], "text": "\n".join(markiert)})
    if not 1 <= aufgabe <= len(fragen):
        raise MappenFehler(f"Aufgabe {aufgabe} steht nicht in Baustein {id}")
    f = fragen[aufgabe - 1]
    alt = (f["loesung"] or [[]])[luecke - 1] if f["art"] in ("luecken", "kurz") and 1 <= luecke <= len(f["loesung"]) \
        else None
    m = _RE_MARKE.search(" ".join(alt or []))
    if not m or f.get("markieren"):
        raise MappenFehler(f"Aufgabe {aufgabe} in Baustein {id} hat keine Lücke {luecke} für eine weitere Lösung")
    if P._norm(wert) in {P._norm(_RE_MARKE.sub("", x)) for x in alt}:
        return _text(lines)
    art, i, von, bis = stellen[int(m.group(1))]
    if art == "kurz":
        lines[i] = lines[i].rstrip() + " · " + wert
    else:
        kopf, trenner, tipp = lines[i][von:bis].partition(":")
        lines[i] = lines[i][:von] + kopf.rstrip() + "/" + wert + trenner + tipp + lines[i][bis:]
    return _text(lines)


def verschiebe(kurs_md, id, richtung):
    """Baustein um einen Platz nach oben (richtung < 0) oder unten verschieben, unter Bausteinen derselben Ebene. Am Rand
    seines Abschnitts (oder Unterabschnitts) wechselt er in den Nachbarn: ans Ende des vorigen, an den Anfang des
    nächsten. Gibt die Kursdatei unverändert zurück, wenn es keinen Nachbarn gibt."""
    lines, bs = _bereiche(kurs_md)
    x = _finde(bs, id)
    gleich = [b for b in bs if b["ebene"] == x["ebene"]]
    k = gleich.index(x) + (-1 if richtung < 0 else 1)
    if not 0 <= k < len(gleich):
        return _text(lines)
    ziel = gleich[k]
    eltern = (ziel["abschnitt"], ziel["unterabschnitt"]) == (x["abschnitt"], x["unterabschnitt"])
    davor = eltern if richtung < 0 else not eltern
    a, e = x["zeile"] - 1, x["zeile"] - 1 + x["zeilen"]
    block = lines[a:e]
    if not x.get("id_explizit"):        # die berechnete ID hängt am Abschnitt: festschreiben, damit sie bleibt
        block.insert(1, f"id: {x['id']}")
    if block and block[-1].strip():
        block.append("")
    rest = lines[:a] + lines[e:]
    za = ziel["zeile"] - 1 - (x["zeilen"] if ziel["zeile"] > x["zeile"] else 0)
    ze = za + ziel["zeilen"]
    pos = za if davor else ze
    if not davor and ze > 0 and rest[ze - 1].strip():
        block.insert(0, "")
    return _text(rest[:pos] + block + rest[pos:])


def umbenennen(kurs_md, id, titel):
    """Titel in der Überschrift des Bausteins ersetzen; Minuten und Drehbuch-Marker bleiben stehen. Die bisherige ID
    wird als `id:` festgeschrieben, damit Auftrag, Phase und Soll am Baustein bleiben."""
    titel = " ".join(str(titel).split())
    if not titel:
        raise MappenFehler("Der Titel ist leer")
    lines, bs = _bereiche(kurs_md)
    b = _finde(bs, id)
    kopf = lines[b["zeile"] - 1]
    m = re.match(r"^(#{3,4}\s+[^:]+:\s*)(.*)$", kopf)
    if not m or b["titel"] not in m.group(2):
        raise MappenFehler(f"Überschrift von „{b['titel']}“ nicht gefunden")
    lines[b["zeile"] - 1] = m.group(1) + m.group(2).replace(b["titel"], titel, 1)
    if not b.get("id_explizit"):
        lines.insert(b["zeile"], f"id: {b['id']}")
    return _text(lines)


# ---------------------------------------------------------------- Kennzahlen für die Diagnosen am Rand
_RE_FRAGE = re.compile(r"^(?:\d+\.\s+)?(MC|RF|Einsetzen|Markieren|Lückentext|Kurzantwort|Schnellquiz|Aussagen)\b")
_RE_NUM_MC = re.compile(r"^\d+\.\s+.*\s·\s.*[✔✓]")
_FRAGE_TYPEN = {"Quiz", "Test", "Lesebuch"}
ROLLEN = ["einstieg", "lesen", "üben", "sichern"]


def fragen(b):
    """Fragen eines Bausteins zählen: (alle, Multiple Choice, Auswahlfragen MC/RF, davon mit Rückmeldung)."""
    if b.get("typ") not in _FRAGE_TYPEN:
        return 0, 0, 0, 0
    alle = mc = auswahl = mit = 0
    offen = None            # laufende MC-Frage in Listenform: hat sie schon eine Rückmeldung?
    gruppe = None           # Schnellquiz/Aussagen: jede Listenzeile eine Frage
    for s in (b.get("text") or "").splitlines()[1:]:
        t = s.strip()
        m = _RE_FRAGE.match(t)
        if m or _RE_NUM_MC.match(t):
            art = m.group(1) if m else "MC"
            offen, gruppe = None, None
            if art in ("Schnellquiz", "Aussagen"):
                gruppe = art
                continue
            alle += 1
            if art in ("MC", "RF"):
                auswahl += 1
                mc += art == "MC"
                if "→" in t:
                    mit += 1
                elif art == "MC" and " · " not in t:
                    offen = "wartet"
            continue
        if t.startswith("- ") and gruppe:
            alle += 1
            mc += 1
            auswahl += 1
            continue
        if t.startswith("- ") and offen == "wartet" and "→" in t:
            mit += 1
            offen = "fertig"
        elif t and not t.startswith("- "):
            offen, gruppe = None, None
    return alle, mc, auswahl, mit


def _rollen():
    kat = katalog()
    typ = {e["typ"]: e.get("rolle", "rahmen") for e in kat["typen"]}
    phase = {}
    for v in kat.get("vorlagen", []):
        for p in v["phasen"]:
            phase.setdefault(p["phase"], p.get("rolle", "rahmen"))
    return typ, phase


def struktur():
    """Typen ohne Zeitbedarf (`minuten: false` im Katalog): Kursbanner, Überblick, Unterabschnitt, Abzeichen, Datei …"""
    return {e["typ"] for e in katalog()["typen"] if e.get("minuten") is False}


# ---------------------------------------------------------------- Zeitbedarf aus dem Inhalt
_RE_WORT = re.compile(r"[0-9A-Za-zÄÖÜäöüßÀ-ÿ²³√π]+")
_RE_HTML = re.compile(r"<[^<>]*>")
_RE_LUECKE = re.compile(r"(?<!\*)\*(?!\*)[^*\n]+?(?<!\*)\*(?!\*)")
_RE_PRAEFIX = re.compile(r"^(?:\d+\.\s+|- |(?:Vorspann|Überschrift|Hervorhebung|Merke|Kasten|Beispiel|Hinweis|Schritte|Seite|"
                         r"Kapitel|Unterkapitel|Text|MC|RF|Einsetzen|Markieren|Lückentext|Kurzantwort|Aussagen|Schnellquiz|"
                         r"Szene|Frage|Ende)(?:\s*\([^)]*\))?:\s*)+")
_RE_ABSCHREIBEN = re.compile(r"\b(?:Übernimm|Übertrag\w*)\b[^.\n]*\bins Heft")
_RE_FRAGEZEILE = re.compile(r"^(?:\d+\.\s+)?(?:MC|RF|Einsetzen|Markieren|Lückentext|Kurzantwort)\b|^\d+\.\s+.*\s·\s")


def _jahrgang_faktor(jahrgang):
    tab = katalog()["zeitbedarf"]["jahrgang_faktor"]
    try:
        jg = int(re.match(r"\d+", str(jahrgang)).group(0))
    except (AttributeError, TypeError, ValueError):
        jg = katalog()["zeitbedarf"]["jahrgang_ohne"]     # AP13.4: ohne Angabe rechnet die Mühle mit Stufe 7
    stufen = sorted(int(k) for k in tab)
    return tab[max([k for k in stufen if jg >= k] or [stufen[0]])]


def mindestzahl(m, jahrgang=None):
    """Mindestmaß eines Typs (`mindest` im Katalog) für eine Jahrgangsstufe: `ab_jahrgang` staffelt (AP13.3, Hefteintrag
    bis 6 mindestens 50 Wörter, ab 7 mindestens 80); ohne Stufe oder Staffel gilt `zahl`."""
    stufen = m.get("ab_jahrgang") or {}
    jg = re.match(r"\d+", str(jahrgang or ""))
    if not stufen or not jg:
        return m["zahl"]
    passend = [int(k) for k in stufen if int(jg.group(0)) >= int(k)]
    return stufen[max(passend)] if passend else stufen[min(stufen, key=int)]


def rolle_von(e):
    """Rolle eines Mappen-Eintrags: Phase aus der Vorlage vor Rolle des Typs (einstieg, lesen, üben, sichern, rahmen)."""
    typ_rolle, phase_rolle = _rollen()
    return phase_rolle.get(e.get("phase")) or typ_rolle.get(e.get("typ"), "rahmen")


def zeitbedarf(b, jahrgang=None, rolle=None):
    """Minuten (Kommazahl), die ein Baustein braucht, aus dem Inhalt gerechnet (Werte in katalog.yaml `zeitbedarf`):
    Lesetext nach Rolle (Einstieg 120, Erarbeitung 60 Wörter je Minute für Jahrgangsstufe 9, Faktor je Stufe),
    Hefteintrag mit Abschreibtempo, jede Aufgabe 1,5 oder mit Rechenausdruck 3 Minuten (ihre Wörter zählen nicht noch
    einmal), dazu Sekunden je Lernkarte, Aussage, Szene und Bild. None für Strukturbausteine und Typen, deren Zeit der
    Inhalt nicht zeigt (Video, Link, Abgabe)."""
    z = katalog()["zeitbedarf"]
    typ = b.get("typ")
    if typ in struktur() or typ in z["ohne_rechnung"] or typ == "Unterabschnitt":
        return None
    sek, auf = z["sekunden"], z["aufgabe_minuten"]
    rechnen = re.compile(z["rechnen_muster"])
    rolle = rolle or _rollen()[0].get(typ, "rahmen")
    faktor = _jahrgang_faktor(jahrgang)
    kat = next((e for e in katalog()["typen"] if e["typ"] == typ), {})
    angaben = set(kat.get("angaben", [])) | set(katalog()["gemeinsam"]["angaben"])
    zeilen = (b.get("text") or "").splitlines()[1:]
    woerter, sekunden, kopf = 0, 0.0, True
    aufgaben = []                 # Text je Aufgabe (Frage und ihre Zeilen), für den Rechenaufwand
    in_aufgabe, gruppe, kasten = False, False, None
    for roh in zeilen:
        t = roh.strip()
        if not t:
            continue
        # Kasten mit einer Frage (Denkaufgabe, „Denk kurz nach“) zählt einmal als einfache Aufgabe
        if t.startswith("Kasten:"):
            kasten = "offen"
        elif kasten and roh.startswith("  "):
            if kasten == "offen" and "?" in t:
                aufgaben.append("Denkaufgabe")
                kasten = "gezaehlt"
        else:
            kasten = None
        if kopf:
            m = re.match(r"^([a-zäöüß ]+):\s", t)
            if m and m.group(1) in angaben:
                continue
            kopf = False
        if t.startswith(("Bild:", "Bildzeile:")):
            sekunden += sek["bild"]
            teile = t.split("|")
            if not (t.startswith("Bildzeile:") and len(teile) > 2):
                continue
            t = teile[2]
        if _RE_FRAGEZEILE.match(t):
            aufgaben.append(t)
            in_aufgabe, gruppe = True, False
            continue
        if re.match(r"^(?:\d+\.\s+)?(Schnellquiz|Aussagen)\b", t):
            in_aufgabe, gruppe = False, True
            continue
        if gruppe and t.startswith("- "):
            sekunden += sek["aussage"]
            continue
        if in_aufgabe and not re.match(r"^(Seite|Kapitel|Unterkapitel|Überschrift|Vorspann|Merke|Kasten|Beispiel|Hinweis|"
                                       r"Hervorhebung|Schritte|Text)\b", t):
            aufgaben[-1] += " " + t          # Optionen, Einsetzen- und Lückentext-Zeilen gehören zur Aufgabe
            continue
        in_aufgabe = gruppe = False
        if typ == "Zuordnen" and t.startswith("- "):
            sekunden += sek["zuordnung"]
            continue
        if typ == "Lernkarten" and t.startswith("- "):
            sekunden += sek["karte"]
            continue
        if typ == "Umfrage" and t.startswith("- "):
            sekunden += sek["umfrage"]
            continue
        if typ == "Geschichte" and re.match(r"^(Szene|Frage|Ende)\b", t):
            sekunden += sek["szene"]
        if typ == "Lückentext":
            sekunden += sek["luecke"] * len(_RE_LUECKE.findall(re.sub(r"\*\*[^*]+\*\*", " ", t)))
        t = t.split(" → ")[0]
        t = _RE_PRAEFIX.sub("", _RE_HTML.sub(" ", t))
        woerter += len(_RE_WORT.findall(t.replace("✔", " ").replace("✘", " ")))
    minuten = sum(auf["rechnen"] if rechnen.search(a) else auf["einfach"] for a in aufgaben)
    if typ in ("Zuordnen", "Lückentext") and not aufgaben:
        text = b.get("text") or ""
        minuten += auf["rechnen"] if rechnen.search(text) else auf["einfach"]
        sekunden = max(0.0, sekunden - auf["einfach"] * 60) if typ == "Zuordnen" else sekunden
    heft = "Hefteintrag" in (b.get("titel") or "") or bool(_RE_ABSCHREIBEN.search(b.get("text") or ""))
    wpm = (z["abschreiben"] if heft else z["woerter_je_minute"].get(rolle, z["woerter_je_minute"]["rahmen"])) * faktor
    return max(1.0, minuten + woerter / wpm + sekunden / 60)


def _luecke(e, genau, ziel):
    """Hinweis an der Karte, was fehlt: „Erarbeitung für 4 Minuten statt 15“ (`ziel` = Soll, sonst Angabe)."""
    name = re.sub(r"\s+\d+$", "", e.get("phase") or "") or next(
        (t["formularname"] for t in katalog()["typen"] if t["typ"] == e.get("typ")), e.get("typ", "Baustein"))
    n = round(genau)
    return f"{name} für {n} Minute{'' if n == 1 else 'n'} statt {ziel}"


# ---------------------------------------------------------------- Plan der Einheit: reichen die Karten? (AP13.1)
def laufende_einheit(mappe):
    """Teil der Einheit, an der gerade gearbeitet wird: beim Anhängen die neue (`anhaengen`), danach `laufend`; None =
    die erste Einheit (Karten ohne `einheit`)."""
    return mappe.get("anhaengen") or mappe.get("laufend") or None


def _einheit_karten(mappe):
    """Eingeschaltete Karten der laufenden Einheit ohne Strukturbausteine: beim Anhängen und danach nur die neue
    Einheit, sonst die Karten ohne `einheit`."""
    teil = laufende_einheit(mappe)
    return [e for e in mappe.get("bausteine", []) if not e.get("aus") and e.get("typ") not in struktur()
            and (e.get("einheit") == teil if teil else not e.get("einheit"))]


def _rolle_im_plan(e, uebung):
    """Rolle einer Karte für den Plan: Phase vor Typ; eine Karte mit Inhalt zählt nur als Übung, wenn ihr Typ eine Übung
    ist (ein Kasten mit Fragen im Lesetext ist keine Übung)."""
    r = rolle_von(e)
    if r == "üben" and not e.get("geplant") and e.get("typ") not in uebung:
        return _rollen()[0].get(e.get("typ"), "rahmen")
    return r


def _vorlage(mappe):
    name = (mappe.get("einheit") or {}).get("vorlage")
    return next((v for v in katalog().get("vorlagen", []) if v["name"] == name), None)


def planung(mappe):
    """Reicht der Plan für die Minuten? Summe der Richtwerte je Karte nach Rolle (`zeitbedarf.karte_minuten`) gegen die
    Minuten der Einheit, dazu die Rollen der Vorlage, die keine eingeschaltete Karte mehr trägt. Nur für Einheiten aus
    einer Vorlage. -> {karten, minuten, traegt, zu_wenig, fehlen: [Warnung], text}"""
    kat = katalog()
    v = _vorlage(mappe)
    karten = _einheit_karten(mappe)
    minuten = (mappe.get("einheit") or {}).get("minuten")
    richt = kat["zeitbedarf"]["karte_minuten"]
    regeln = kat["pruefregeln"]
    rollen = [_rolle_im_plan(e, regeln["uebung"]) for e in karten]
    traegt = sum(richt.get(r, richt["rahmen"]) for r in rollen)
    soll = [] if v is None else list(dict.fromkeys(p.get("rolle") for p in v["phasen"] if not p.get("optional")))
    fehlen = [regeln["fehlt"][r] for r in soll if r in regeln["fehlt"] and r not in rollen]
    zu_wenig = bool(v is not None and minuten and traegt < int(minuten))
    n = len(karten)
    text = f"{n} {'Karte' if n == 1 else 'Karten'} für {minuten} Minuten" if zu_wenig else ""
    return {"karten": n, "minuten": minuten, "traegt": traegt, "zu_wenig": zu_wenig, "fehlen": fehlen, "text": text}


def _vorlage_karte(b, phase, soll, id):
    """Karte aus einem Eintrag der Vorlage („Typ: Titel | Teilschritt“) mit Typ automatisch."""
    kopf, _, schritt = b.partition(" | ")
    titel = kopf.split(":", 1)[1].strip() if ":" in kopf else phase["phase"]
    return geplant(id, AUTO, titel, phase["phase"], soll, schritt=schritt.strip())


def auffuellen(mappe):
    """„Vorlage auffüllen“: fehlende Rollen der Vorlage als Karten mit Typ automatisch an ihren Platz in der Phasenfolge
    (nach der letzten Karte einer früheren oder gleichen Rolle); tragen die Karten die Minuten dann noch nicht, je eine
    weitere Karte in den dehnbaren Phasen, bis sie reichen (höchstens sechs neue Karten). Nur die laufende Einheit."""
    v = _vorlage(mappe)
    if v is None:
        return mappe
    liste = mappe.setdefault("bausteine", [])
    minuten = int((mappe.get("einheit") or {}).get("minuten") or 45)
    uebung = katalog()["pruefregeln"]["uebung"]
    reihe = {r: i for i, r in enumerate(ROLLEN)}
    teil = laufende_einheit(mappe)
    ids = {e["id"] for e in liste}

    def neue_id():
        n = 1
        while f"b{n}" in ids:
            n += 1
        ids.add(f"b{n}")
        return f"b{n}"

    def einsetzen_nach_rolle(karte, rolle):
        eigene = _einheit_karten(mappe)
        frueher = [e for e in eigene if reihe.get(_rolle_im_plan(e, uebung), -1) <= reihe.get(rolle, -1)]
        if frueher:
            pos = liste.index(frueher[-1]) + 1
        else:
            pos = liste.index(eigene[0]) if eigene else len(liste)
        if teil:
            karte["einheit"] = teil
        liste.insert(pos, karte)

    neu = 0
    vorhanden = {_rolle_im_plan(e, uebung) for e in _einheit_karten(mappe)}
    for p in v["phasen"]:
        if p.get("optional") or p.get("rolle") in vorhanden:
            continue
        vorhanden.add(p.get("rolle"))
        soll = max(1, round(p["anteil"] / 100 * minuten / len(p["bausteine"])))
        for b in p["bausteine"]:
            einsetzen_nach_rolle(_vorlage_karte(b, p, soll, neue_id()), p.get("rolle"))
            neu += 1
    dehnbar = [p for p in v["phasen"] if p.get("dehnbar") and not p.get("optional")]
    k = 0
    while dehnbar and planung(mappe)["zu_wenig"] and neu < 6:
        p = dehnbar[k % len(dehnbar)]
        k += 1
        karte = _vorlage_karte(p["bausteine"][0], p, max(1, round(p["anteil"] / 100 * minuten / 2)), neue_id())
        karte["titel"] = f"{karte['titel']} {k // len(dehnbar) + 2}"
        einsetzen_nach_rolle(karte, p.get("rolle"))
        neu += 1
    return mappe


def kennzahlen(mappe, pruefung=None, minuten=None, steckbrief=None):
    """Zahlen für den Rand: Minuten (gerechnet) gegen Soll, Folge Lesen → Üben → Sichern, Anteil Multiple Choice,
    Rückmeldungen, und Hinweise je Baustein (Fehler, Bild fehlt, Rückmeldung fehlt, ohne Inhalt). `zeit` je Baustein:
    gerechnete Minuten, Angabe aus der Überschrift und ob sie um mehr als 20 % abweicht. Strukturbausteine (Kursbanner,
    Überblick, Abzeichen, Datei …) zählen nicht. Nummern = Platz in der Bausteinliste."""
    pruefung = pruefung or {}
    nach_id = {b["id"]: b for b in pruefung.get("bausteine", [])}
    typ_rolle, phase_rolle = _rollen()
    ohne = struktur()
    # AP13.3: nur die laufende Einheit (beim Anhängen und danach die neue, sonst die Karten ohne `einheit`)
    tag = laufende_einheit(mappe)
    eigene = {e["id"] for e in mappe.get("bausteine", []) if (e.get("einheit") or None) == tag}
    eintraege = [e for e in mappe.get("bausteine", []) if e.get("typ") not in ohne and not e.get("aus") and e["id"] in eigene]
    # Zeit je Phase selbst eingestellt (AP13)? Sonst verteilt das Modell, Soll der Karten zählt nicht
    selbst = mappe.get("zeit_selbst", True) is not False
    soll_von = (lambda e: e.get("soll")) if selbst else (lambda e: None)
    nummer = {e["id"]: i + 1 for i, e in enumerate(mappe.get("bausteine", []))}
    einheit = mappe.get("einheit") or {}
    jahrgang = einheit.get("jahrgang") or ((api._steckbrief(steckbrief).get("kurs") or {}).get("jahrgangsstufe")
                                           if steckbrief else None)
    soll = minuten or einheit.get("minuten") or sum(int(soll_von(e) or 0) for e in eintraege) or None
    grenze = katalog()["zeitbedarf"]["abweichung"] / 100
    ist = 0
    zeit = {}
    folge, zaehl = [], {"fragen": 0, "mc": 0, "auswahl": 0, "rueckmeldung": 0}
    hinweise = []
    for e in eintraege:
        b = nach_id.get(e["id"])
        if b is not None and not e.get("geplant"):
            genau = zeitbedarf(b, jahrgang, rolle_von(e))
            gerechnet = round(genau) if genau is not None else None
            angabe = b.get("minuten")
            ziel = soll_von(e) or angabe
            # mehr als 20 % und mindestens eine ganze Minute neben dem Soll (sonst der Angabe des Chats)
            ab = bool(genau and ziel and abs(ziel - genau) > max(grenze * genau, 1))
            zeit[e["id"]] = {"gerechnet": gerechnet, "angabe": angabe, "soll": soll_von(e), "abweichung": ab,
                             "text": _luecke(e, genau, ziel) if ab else ""}
            if ab:
                hinweise.append({"art": "zeit", "stufe": "hinweis", "baustein": e["id"], "nummer": nummer[e["id"]],
                                 "text": f"Baustein {nummer[e['id']]}: {zeit[e['id']]['text']}"})
            ist += gerechnet if gerechnet is not None else int(angabe or soll_von(e) or 0)
        else:
            ist += int(soll_von(e) or 0)
        rolle = phase_rolle.get(e.get("phase")) or typ_rolle.get(e.get("typ"), "rahmen")
        if rolle in ROLLEN[1:] and (not folge or folge[-1] != rolle):
            folge.append(rolle)
        if b is None:
            continue
        alle, mc, auswahl, mit = fragen(b)
        zaehl["fragen"] += alle
        zaehl["mc"] += mc
        zaehl["auswahl"] += auswahl
        zaehl["rueckmeldung"] += mit
        if auswahl > mit and b["typ"] in ("Quiz", "Lesebuch") and rolle != "sichern":
            hinweise.append({"art": "rueckmeldung", "stufe": "hinweis", "baustein": e["id"], "nummer": nummer[e["id"]],
                             "text": f"Rückmeldung fehlt bei {auswahl - mit} von {auswahl} Auswahlfragen in Baustein "
                                     f"{nummer[e['id']]}"})
    for d in pruefung.get("diagnosen", []):
        if d.get("baustein") and d["baustein"] not in eigene and d["baustein"] in nummer:
            continue
        n = nummer.get(d.get("baustein"))
        if d["stufe"] == "fehler":
            hinweise.append({"art": "fehler", "stufe": "fehler", "baustein": d.get("baustein"), "nummer": n,
                             "text": (f"Baustein {n}: " if n else "") + d["text"]})
        elif d.get("art") == "bild" and n:
            hinweise.append({"art": "bild", "stufe": "warnung", "baustein": d["baustein"], "nummer": n,
                             "text": f"Bild fehlt in Baustein {n}"})
        elif d.get("regel") == "wunschtyp":      # AP13.5b: bevorzugter Übungstyp fehlt, gelb am Rand
            hinweise.append({"art": "wunschtyp", "stufe": "warnung", "baustein": None, "nummer": None,
                             "regel": "wunschtyp", "text": d["text"]})
    ohne_lehrplan = bool(steckbrief) and lehrplanbezug(api._steckbrief(steckbrief).get("kurs") or {}) == "nein"
    if einheit and not str(einheit.get("jahrgang") or "").strip() and not jahrgang and not ohne_lehrplan:
        hinweise.append({"art": "jahrgang", "stufe": "warnung", "baustein": None, "nummer": None, "regel": "jahrgang.fehlt",
                         "text": f"Jahrgangsstufe fehlt, die Mühle rechnet mit {katalog()['zeitbedarf']['jahrgang_ohne']}"})
    if steckbrief and lehrplan_fehlt(api._steckbrief(steckbrief).get("kurs") or {}):
        hinweise.append({"art": "lehrplan", "stufe": "warnung", "baustein": None, "nummer": None, "regel": "lehrplan.fehlt",
                         "text": LEHRPLAN_FEHLT})
    # AP13.4: Variation der Übungstypen (gelb, keine Korrektur) und Typen, die der Text nicht mehr anbietet
    kat = katalog()
    variation = kat["pruefregeln"]["variation"]
    karten = [e for e in mappe.get("bausteine", []) if e["id"] in eigene and not e.get("aus")]
    angebot = [t for t in auto_typen(karten) if t in variation]
    voll = [e for e in eintraege if not e.get("geplant") and e["id"] in nach_id]
    uebungen = [e for e in voll if nach_id[e["id"]]["typ"] in variation]
    arten = {nach_id[e["id"]]["typ"] for e in uebungen}
    warn_var = False
    for a, b in zip(voll, voll[1:]):
        ta, tb = nach_id[a["id"]]["typ"], nach_id[b["id"]]["typ"]
        if ta == tb and ta in variation:
            warn_var = True
            hinweise.append({"art": "variation", "stufe": "warnung", "baustein": b["id"], "nummer": nummer[b["id"]],
                             "regel": "variation", "text": f"Baustein {nummer[a['id']]} und {nummer[b['id']]}: zweimal "
                                                           f"{nach_id[a['id']]['typ']} hintereinander"})
    if len(uebungen) >= 4 and len(arten) < 3:
        warn_var = True
        hinweise.append({"art": "variation", "stufe": "warnung", "baustein": None, "nummer": None, "regel": "variation",
                         "text": f"{len(uebungen)} Übungen mit nur {len(arten)} Typen; ab vier Übungen sind drei vorgesehen"})
    zusatz = [t for t in kat["automatisch"].get("zusatz", []) if t not in auto_typen(karten)]
    if zusatz:
        hinweise.append({"art": "typen", "stufe": "hinweis", "baustein": None, "nummer": None,
                         "text": f"{' und '.join(zusatz)} stehen nicht im Text (mehr als "
                                 f"{kat['automatisch']['zusatz_bis']} Karten mit Typ automatisch)"})
    stufe = bilder_stufe(angaben_lesen(steckbrief or "").get("bilder"))
    bilder = {"zahl": api.bilder_zahl([nach_id[e["id"]] for e in voll]), "stufe": stufe["satz"], "wert": stufe["wert"],
              "bytes": api.bilder_bytes([nach_id[e["id"]] for e in voll], pruefung.get("bild_bytes") or {})}
    grenze_mb = kat["pruefregeln"]["bilder_mb"]
    if bilder["bytes"] > grenze_mb * 1024 * 1024:
        hinweise.append({"art": "bilder", "stufe": "warnung", "baustein": None, "nummer": None, "regel": "bilder.groesse",
                         "text": f"Die Bilder dieser Einheit haben zusammen {groesse_text(bilder['bytes'])}, mehr als "
                                 f"{grenze_mb} MB"})
    for e in mappe.get("bausteine", []):
        if e.get("weggelassen") and e["id"] in eigene:
            n = int((e["weggelassen"] or {}).get("minuten") or 0)
            hinweise.append({"art": "weggelassen", "stufe": "warnung", "baustein": e["id"], "nummer": nummer[e["id"]],
                             "text": f"„{e.get('titel', '')}“ weggelassen" + (f", {n} Minuten fehlen" if n else "")})
    plan = planung(mappe)
    for text in plan["fehlen"]:
        hinweise.append({"art": "phase", "stufe": "warnung", "baustein": None, "nummer": None, "text": text,
                         "regel": "phase.fehlt"})
    leer = [e for e in mappe.get("bausteine", []) if e.get("geplant") and not e.get("aus") and e["id"] in eigene]
    if leer:
        hinweise.append({"art": "leer", "stufe": "hinweis", "baustein": leer[0]["id"], "nummer": nummer[leer[0]["id"]],
                         "text": f"{len(leer)} {'Baustein' if len(leer) == 1 else 'Bausteine'} noch ohne Inhalt"})
    rang = {"fehler": 0, "warnung": 1, "hinweis": 2}
    hinweise.sort(key=lambda h: (rang[h["stufe"]], h["nummer"] or 0))
    # Brüche der Folge: Schritte zurück nach dem Sichern und Übungen vor dem ersten Lesetext (Lesen nach Üben ist der
    # Normalfall bei mehreren Lesetexten und zählt nicht)
    rueck = sum(1 for a in folge[:-1] if a == "sichern")
    vor_lesen = len(folge) if "lesen" not in folge else folge.index("lesen")
    return {"minuten": {"ist": ist, "soll": soll}, "folge": [r.capitalize() for r in folge],
            "folge_brueche": rueck + vor_lesen, "fragen": zaehl,
            "mc_anteil": round(100 * zaehl["mc"] / zaehl["fragen"]) if zaehl["fragen"] else None,
            "bausteine": len(eintraege), "geplant": len(leer), "hinweise": hinweise, "zeit": zeit,
            "inhalt": any(not e.get("geplant") for e in eintraege), "zeit_selbst": selbst, "planung": plan,
            "uebungstypen": {"zahl": len(arten), "von": len(angebot), "warn": warn_var}, "bilder": bilder}


# ---------------------------------------------------------------- Antwort des Chats einsetzen
_FORTSETZUNG = re.compile(r"^[\W_]*fortsetzung folgt[\W_]*$", re.I)


def _ohne_fortsetzung(text):
    """AP13.8: endet die Antwort mit der Zeile „Fortsetzung folgt“ (Abbruchregel im Text für den Chat), fällt die Zeile
    weg, auch innerhalb des Codeblocks. -> (Text, bool)"""
    zeilen = (text or "").splitlines()
    for i in range(len(zeilen) - 1, -1, -1):
        z = zeilen[i].strip()
        if not z or z.startswith("```"):
            continue
        if _FORTSETZUNG.match(z):
            return "\n".join(zeilen[:i] + zeilen[i + 1:]) + "\n", True
        break
    return text or "", False


def fortsetzung(text):
    """True, wenn die Antwort mit „Fortsetzung folgt“ endet: die Bausteine gelten, der Rest kommt noch."""
    return _ohne_fortsetzung(text)[1]


def jahrgang_zahl(wert):
    """AP13.8: erste Zahl 1 bis 13 im Feld Jahrgangsstufe oder Zielgruppe („9“, „Klasse 9b“, „Q12“), sonst „“."""
    m = re.search(r"(?<!\d)(1[0-3]|[1-9])(?!\d)", str(wert or ""))
    return m.group(1) if m else ""


def antwort(text):
    """Antwort des Chats lesen; einzelne Bausteine ohne Abschnitt (`## `) bekommen einen, damit der Parser sie annimmt.
    Eine Schlusszeile „Fortsetzung folgt“ zählt nicht zum letzten Baustein.
    -> Ergebnis von gen.api.pruefe"""
    md, _ = api.extrahiere_kursdatei(_ohne_fortsetzung(text)[0])
    if not re.search(r"^## ", md, re.M) and re.search(r"^#{3,6} ", md, re.M):
        kopf, rest = [], []
        for z in md.splitlines():
            (rest if rest or re.match(r"^#{3,6} ", z) else kopf).append(z)
        kopf = [z for z in kopf if not z.startswith("```")]
        if not kopf or not kopf[0].startswith("# "):
            kopf.insert(0, "# Drehbuch v1 · Antwort")
        rest = ["###" + z.lstrip("#") if z.startswith("####") and not any(r.startswith("### Unterabschnitt") for r in rest)
                else z for z in rest if not z.startswith("```")]
        md = "\n".join(kopf + ["", "## Antwort"] + rest) + "\n"
    return api.pruefe(md)


def _bloecke(kursdatei, bausteine):
    """Oberste Bausteine einer Antwort mit ihren Zeilen (Unterbausteine eines Unterabschnitts gehören zum Block)."""
    lines = kursdatei.splitlines()
    out, ende = [], 0
    for b in bausteine:
        if b["zeile"] <= ende:
            continue
        block = lines[b["zeile"] - 1:b["zeile"] - 1 + b["zeilen"]]
        while block and not block[-1].strip():
            block.pop()
        out.append((b, block))
        ende = b["zeile"] + b["zeilen"] - 1
    return out


def _kopfzeilen(kursdatei):
    """Zeilen `Bildwunsch:`, `Bildprompt:`, `Angenommen:`, `Offen:`, `Abweichung:` vor dem ersten Abschnitt."""
    out = []
    for z in kursdatei.splitlines():
        if z.startswith("## "):
            break
        if re.match(r"^(Bildwunsch|Bildprompt|Angenommen|Offen|Abweichung):", z):
            out.append(z)
    return out


def _ebene(block, ebene):
    if block and re.match(r"^#{3,4}\s", block[0]):
        block = ["#" * ebene + block[0].lstrip("#")] + block[1:]
    return block


def _mit_id(block, id):
    if any(re.match(rf"^id:\s*{re.escape(id)}\s*$", z) for z in block[1:6]):
        return block
    rest = [z for z in block[1:] if not re.match(r"^id:\s", z)]
    return [block[0], f"id: {id}"] + rest


def _skelett(mappe, antwort_md):
    e = mappe.get("einheit") or {}
    titel = e.get("thema") or mappe.get("titel") or "Einheit"
    m = re.search(r"^## .+$", antwort_md, re.M)
    kopf = m.group(0) if m and "Allgemeines" not in m.group(0) else f"## {titel}"
    if e.get("minuten"):
        # ein Teil der Stückelung schreibt oft seine eigenen Minuten in die Abschnittsüberschrift; es gilt die Einheit
        kopf = re.sub(r"\s*·\s*\d+\s*min\s*$", "", kopf) + f" · {e['minuten']} min"
    return f"# Drehbuch v1 · {titel}\n\n{kopf}\n"


def modus(mappe, text):
    """Vorschlag, wie die Antwort des Chats eingesetzt wird: `baustein`, wenn ein einzelner Baustein kam oder alle
    Bausteine eine `id:` tragen, die es in der Einheit gibt, und es weniger sind als die Einheit hat; sonst `ersetzen`;
    `keine`, wenn der Text keine Bausteine enthält. Anhängen wählt die Lehrkraft selbst. AP13.8: endet die Antwort mit
    „Fortsetzung folgt“ (`fortsetzung`), gilt `baustein`, sobald eine id passt (eine halbe Einheit ersetzt nie die ganze),
    und `rest` ist die Bitte um die Karten des Teils (sonst der laufenden Einheit), die danach noch leer sind
    (`rest_ids`)."""
    pa = antwort(text)
    bl = _bloecke(pa["kursdatei"], pa["bausteine"])
    bekannt = {e["id"] for e in mappe.get("bausteine", [])}
    n = len(bl)
    treffer = [b["id"] for b, _ in bl if b.get("id_explizit") and b["id"] in bekannt]
    gesamt = len([e for e in mappe.get("bausteine", []) if e.get("typ") not in struktur() and not e.get("aus")]) or len(bekannt)
    weiter = fortsetzung(text)
    if not n:
        art = "keine"
    elif n == 1 or (len(treffer) == n and n < gesamt) or (weiter and treffer):
        art = "baustein"
    else:
        art = "ersetzen"
    ids = [b["id"] for b, _ in bl]
    rest_ids = _rest(mappe, ids) if weiter and n else []
    rest = ""
    if rest_ids:
        from . import prompt as P             # prompt importiert mappe; hier erst beim Aufruf
        rest = P.fortsetzung(mappe, rest_ids)
    return {"modus": art, "bausteine": n, "treffer": len(treffer), "ids": ids, "fortsetzung": weiter,
            "rest": rest, "rest_ids": rest_ids}


def _rest(mappe, ids):
    """Karten, die nach einer Antwort mit „Fortsetzung folgt“ noch fehlen: im gestückelten Text die des Teils mit den
    meisten ids der Antwort (b7-2 zählt zu b7), sonst alle der laufenden Einheit; ohne Inhalt, eingeschaltet."""
    basis = {re.sub(r"-\d+$", "", i) for i in ids} | set(ids)
    tag = laufende_einheit(mappe)
    st = mappe.get("stueckelung") or {}
    teile = st.get("ids") if (st.get("einheit") or None) == tag else None
    if teile:
        kreis = max(teile, key=lambda t: len(basis & set(t)))
    else:
        kreis = [e["id"] for e in mappe.get("bausteine", []) if (e.get("einheit") or None) == tag]
    nach_id = {e["id"]: e for e in mappe.get("bausteine", [])}
    return [i for i in kreis if i not in basis and i in nach_id and nach_id[i].get("geplant")
            and not nach_id[i].get("aus") and nach_id[i].get("typ") not in struktur() | {"Badge"}]


def einsetzen(mappe, kurs_md, text, nur=None, kopf=False):
    """Nur die Bausteine der Antwort in die Kursdatei setzen, Abgleich über `id:`: steht die ID in der Kursdatei, ersetzt
    der Block den alten (Ebene wie dort); ist sie ein geplanter Baustein der Mappe, kommt der Block an seinen Platz in der
    Reihenfolge der Mappe. Ein einzelner Baustein ohne `id:` geht an die markierte Karte (`neu`), wenn genau eine
    markiert ist. Sonst eine Fehlermeldung mit Vorschlag; die Kursdatei bleibt dann für diesen Baustein unverändert.
    `nur` (AP13.1, seit AP13.3 der Korrekturblock mit genau einer Karte): ein einzelner Baustein der Antwort ohne `id:`
    (oder mit einer, die es nicht gibt) geht an diese Karte; eine bekannte `id:` der Antwort geht vor (Protokoll
    24.10.: die Antwort mit `id: b4` landete in b3-3). `kopf` (Korrekturblock): bringt die Antwort eigene Zeilen
    `Angenommen:` mit, ersetzen sie die bisherigen (die Zeit-Annahme verschwindet mit der Korrektur).
    -> {kurs_md, ersetzt, eingefuegt, fehler}"""
    pa = antwort(text)
    antwort_md = pa["kursdatei"]
    bl = _bloecke(antwort_md, pa["bausteine"])
    plan = mappe.get("bausteine", [])
    nach_id = {e["id"]: e for e in plan}
    markiert = [e for e in plan if e.get("neu")]
    md = kurs_md if (kurs_md or "").strip() else ""
    ersetzt, eingefuegt, fehler_ = [], [], []
    for b, block in bl:
        id = b["id"] if b.get("id_explizit") else None
        if nur and len(bl) == 1 and (id is None or id not in nach_id):
            id = nur
        elif id is None and len(bl) == 1 and len(markiert) == 1:
            id = markiert[0]["id"]
        basis = re.match(r"^(.+)-\d+$", id or "")
        zweiter = id is not None and id not in nach_id and basis is not None and basis.group(1) in nach_id
        if id is None or (id not in nach_id and not zweiter):
            gleich = [e for e in plan if e.get("titel") == b["titel"] or (e.get("neu") and e.get("typ") == b["typ"])]
            vorschlag = (f" Meinst du „{gleich[0]['titel']}“? Bitte den Chat, den Baustein mit der Zeile `id: "
                         f"{gleich[0]['id']}` noch einmal auszugeben.") if gleich else \
                " Markiere die Karte, die er ersetzen soll, mit „Diesen Baustein neu beauftragen“, oder wähle „Einheit ersetzen“."
            fehler_.append((f"„{b['titel']}“ hat keine id:." if id is None else
                            f"„{b['titel']}“ trägt id: {id}, die es in dieser Einheit nicht gibt.") + vorschlag)
            continue
        if not md:
            md = _skelett(mappe, antwort_md)
        lines, bs = _bereiche(md)
        alt = next((x for x in bs if x["id"] == id), None)
        if alt is not None:
            neu_block = _mit_id(_ebene(block, alt["ebene"]), id)
            lines[alt["zeile"] - 1:alt["zeile"] - 1 + alt["zeilen"]] = neu_block + [""]
            ersetzt.append(id)
        else:
            reihe = [e["id"] for e in plan]
            if id not in reihe:                       # zweiter Baustein zu einer Karte: direkt dahinter
                reihe.insert(reihe.index(basis.group(1)) + 1, id)
            i = reihe.index(id)
            vorher = next((x for k in range(i - 1, -1, -1) for x in bs if x["id"] == reihe[k]), None)
            nachher = next((x for k in range(i + 1, len(reihe)) for x in bs if x["id"] == reihe[k]), None)
            if vorher is not None:
                # nach dem vorigen Baustein (samt Unterbausteinen) einfügen, auf seiner Ebene
                ende = max(x["zeile"] + x["zeilen"] - 1 for x in bs if x is vorher or
                           (vorher["typ"] == "Unterabschnitt" and x.get("unterabschnitt") == vorher["titel"]
                            and x["abschnitt"] == vorher["abschnitt"]))
                pos, ebene = ende, vorher["ebene"]
            elif nachher is not None:
                pos, ebene = nachher["zeile"] - 1, nachher["ebene"]
            else:
                pos, ebene = len(lines), 3
            neu_block = _mit_id(_ebene(block, ebene), id)
            if pos > 0 and lines[pos - 1].strip():
                neu_block = [""] + neu_block
            lines[pos:pos] = neu_block + [""]
            eingefuegt.append(id)
        md = _text(lines)
    if (ersetzt or eingefuegt) and kopf:
        neu_annahmen = [z for z in _kopfzeilen(antwort_md) if z.startswith("Angenommen:")]
        ganz = re.search(r"^# ", api.extrahiere_kursdatei(text or "")[0], re.M)    # ganze Kursdatei mit eigenem Kopf
        if neu_annahmen or ganz:
            lines, im_kopf = [], True
            for z in md.splitlines():
                im_kopf = im_kopf and not z.startswith("## ")
                if not (im_kopf and z.startswith("Angenommen:")):
                    lines.append(z)
            md = _text(lines)
    if ersetzt or eingefuegt:
        kopf = [z for z in _kopfzeilen(antwort_md) if z not in md]
        if kopf:
            lines = md.splitlines()
            pos = 1 if lines and lines[0].startswith("# ") else 0
            lines[pos:pos] = kopf
            md = _text(lines)
    return {"kurs_md": md if (ersetzt or eingefuegt) else kurs_md, "ersetzt": ersetzt, "eingefuegt": eingefuegt,
            "fehler": fehler_}


def anhaengen(kurs_md, text, teil=None):
    """Antwort als weitere Einheit hinten an die Kursdatei hängen: ihre Abschnitte ab dem ersten `## ` (ein zweites
    „Allgemeines“ fällt weg, wenn die Kursdatei schon eins hat), Kopfzeilen nach vorn, doppelte `id:` mit Endung -2.
    `teil` (AP13, etwa „e2“): jeder angehängte Abschnitt bekommt die Zeile `teil: e2`, damit die Seite nur diese Einheit
    als Nachlieferung bauen kann (Bau mit `delta`, Wiederherstellen mit „zusammenführen“)."""
    pa = antwort(text)
    antwort_md = pa["kursdatei"]
    if not (kurs_md or "").strip():
        return antwort_md
    vorhanden = {b["id"] for b in api.pruefe(kurs_md)["bausteine"]}
    lines = antwort_md.splitlines()
    start = next((i for i, z in enumerate(lines) if z.startswith("## ")), len(lines))
    teil_name, teile, weg = teil, [], False
    hat_allgemein = re.search(r"^## Allgemeines\s*$", kurs_md, re.M) is not None
    for z in lines[start:]:
        if z.startswith("## "):
            weg = hat_allgemein and z.strip() == "## Allgemeines"
        if weg:
            continue
        m = re.match(r"^id:\s*(\S+)\s*$", z)
        if m and m.group(1) in vorhanden:
            n = 2
            while f"{m.group(1)}-{n}" in vorhanden:
                n += 1
            z = f"id: {m.group(1)}-{n}"
            vorhanden.add(z[4:])
        if teil_name and re.match(r"^teil:\s*", z) and teile and teile[-1] == f"teil: {teil_name}":
            continue                                  # eigene teil:-Zeile des Chats weicht der Einheit
        teile.append(z)
        if teil_name and z.startswith("## ") and z.strip() != "## Allgemeines":
            teile.append(f"teil: {teil_name}")
    md = kurs_md.rstrip("\n").splitlines()
    kopf = [z for z in _kopfzeilen(antwort_md) if z not in kurs_md]
    if kopf:
        pos = 1 if md and md[0].startswith("# ") else 0
        md[pos:pos] = kopf
    return _text(md + [""] + teile)


# ---------------------------------------------------------------- Bilder-Stufe und Typen „automatisch“ (AP13.4)
def groesse_text(n):
    """Bytes als „2,4 MB“ oder „160 KB“ (Karte im Schritt Bilder, Rand)."""
    if n >= 1024 * 1024:
        return f"{n / 1024 / 1024:.1f} MB".replace(".", ",")
    return f"{max(1, round(n / 1024))} KB"


def bild_verkleinert(vorher, nachher):
    """Satz an der Karte nach dem Hochladen: „2,4 MB → 160 KB“."""
    return f"{groesse_text(vorher)} → {groesse_text(nachher)}"


BILDER_MAX = 30          # AP13.5g a2: größte Zahl für `kurs.bilder` als Zahl


def bilder_standard():
    return next((w["wert"] for w in katalog()["oberflaeche"]["bilder"] if w.get("standard")), "2-3")


def bilder_stufe(wert):
    """Eintrag der Bilder-Stufe (`kurs.bilder`: 0, 2-3, 4-7, 8+) -> {wert, text, min, max, satz}; seit AP13.5g auch eine
    Zahl von 1 bis 30 (genau so viele, `satz` ist die Zahl); unbekannt = Standard."""
    t = str(wert).strip() if wert is not None else ""
    if re.fullmatch(r"[0-9]{1,2}", t) and 1 <= int(t) <= BILDER_MAX:
        n = int(t)
        return {"wert": str(n), "text": str(n), "min": n, "max": n, "satz": str(n)}
    liste = katalog()["oberflaeche"]["bilder"]
    w = dict(next((w for w in liste if w["wert"] == str(wert)), next(w for w in liste if w["wert"] == bilder_standard())))
    w["satz"] = "keine" if w["max"] == 0 else str(w["min"]) if w["min"] == w["max"] \
        else f"{w['min']} bis {w['max']}" if w["max"] else f"mindestens {w['min']}"
    return w


def bildbeschriftung(wert):
    """Beschriftung im Bild (`kurs.bildbeschriftung`, AP13.5h a8): `woerter` oder `ziffern`; unbekannt oder leer = der
    Standard aus dem Katalog."""
    liste = katalog()["oberflaeche"]["bildbeschriftung"]
    t = str(wert or "").strip().lower()
    return t if any(w["wert"] == t for w in liste) else next(w["wert"] for w in liste if w.get("standard"))


def auto_typen(karten, bevorzugt=None):
    """Typen, die der Text für „Typ frei“ anbietet: alle aus `automatisch.typen`; hat die Einheit mehr als `zusatz_bis`
    Karten vom Typ automatisch, ohne die Zusatztypen (Geschichte, Lesebuch), damit der Text unter der Grenze bleibt.
    Ein bevorzugter Zusatztyp (AP13.5b, `kurs.uebungstypen`) bleibt."""
    a = katalog()["automatisch"]
    n = sum(1 for e in karten if e.get("typ") == AUTO and not e.get("aus"))
    return [t for t in a["typen"] if not (n > a.get("zusatz_bis", 99) and t in a.get("zusatz", [])
                                          and t not in (bevorzugt or []))]


# ---------------------------------------------------------------- Kursangaben der Oberfläche
def _liste(v):
    return [str(x) for x in v] if isinstance(v, list) else [str(v)] if v else []


RICHTUNG = {"schwerpunkt": ("begriffe", "verfahren", "faelle"), "sprache": ("einfach", "normal", "anspruchsvoll")}


def uebungstypen_wahl():
    """Übungstypen für „Übungen bevorzugt“ (AP13.5b): automatisch.typen ohne Textfeld und Seite."""
    return [t for t in katalog()["automatisch"]["typen"] if t not in ("Textfeld", "Seite")]


def lehrplanbezug(k):
    """`kurs.lehrplanbezug` (AP13.6): „nein“ für Einheiten ohne Lehrplaninhalt, sonst „ja“ (fehlt die Zeile: „ja“, so
    lesen CLI und Steckbriefe von vor AP13.5f weiter wie bisher)."""
    v = k.get("lehrplanbezug", "ja")
    return "nein" if v is False or str(v).strip().lower() in ("nein", "no", "false", "0") else "ja"


def lehrplanbezug_gesetzt(k):
    """Wie `lehrplanbezug`, aber „“, wenn der Steckbrief den Haken nicht nennt und keinen Lehrplan trägt (AP13.5f: die
    Mühle setzt ihn dann nach der letzten Wahl im Browser, Standard aus)."""
    if "lehrplanbezug" not in k and not k.get("lehrplan"):
        return ""
    return lehrplanbezug(k)


def lehrplan_fehlt(k):
    """Haken ausdrücklich gesetzt, aber kein Lernbereich gewählt (Regel lehrplan.fehlt, gelb am Rand)."""
    return "lehrplanbezug" in k and lehrplanbezug(k) == "ja" and \
        not (lehrplan_sauber(k.get("lehrplan")) or {}).get("lernbereiche")


def _texte(v, n=None):
    return [str(x).strip() for x in (v if isinstance(v, list) else []) if str(x).strip()][:n]


def lehrplan_sauber(lp):
    """`kurs.lehrplan` aus dem Picker (AP13.6) auf die bekannten Felder gebracht; ohne Lernbereich None. Die Texte
    bleiben wörtlich (amtliches Werk, Änderungsverbot), nur Leerraum am Rand fällt weg."""
    if not isinstance(lp, dict):
        return None
    lbs = []
    for lb in lp.get("lernbereiche") if isinstance(lp.get("lernbereiche"), list) else []:
        if not isinstance(lb, dict) or not str(lb.get("titel") or "").strip():
            continue
        tbs = [{"titel": str(tb.get("titel") or "").strip(), "ziele": _texte(tb.get("ziele")),
                "rahmen": _texte(tb.get("rahmen"))}
               for tb in (lb.get("teilbereiche") if isinstance(lb.get("teilbereiche"), list) else [])
               if isinstance(tb, dict)]
        lbs.append({"kuerzel": str(lb.get("kuerzel") or "").strip(), "titel": str(lb["titel"]).strip(),
                    "teilbereiche": tbs})
    if not lbs:
        return None
    out = {f: str(lp.get(f) or "").strip() for f in ("quelle", "stand", "schulart", "fach", "zug", "variante",
                                                    "jahrgangsstufe")}
    out["lernbereiche"] = lbs
    return out


def angaben_lesen(steckbrief):
    """Steckbrief (YAML-Text oder dict) -> Werte der Formularfelder."""
    sb = api._steckbrief(steckbrief)
    k = sb.get("kurs") or {}
    design = k.get("design") or {}
    farbe = str(k.get("farbe") or "")
    name = next((n for n, h in K.FARBEN.items() if h.lower() == farbe.lower() and "ue" not in n), "")
    if not name and re.match(r"^#[0-9A-Fa-f]{6}$", farbe):
        name = farbe.upper()            # eigene Farbe (AP13.5): Hex bleibt Hex
    familie, dichte, kasten = api.design_angaben(sb)
    website = str(k.get("website", "nein")).lower()
    bilder = str(k.get("bilder") if k.get("bilder") is not None else bilder_standard())
    return {"thema": k.get("titel", ""), "jahrgang": str(k.get("jahrgangsstufe") or ""),
            "minuten": k.get("umfang_min"), "fach": k.get("fach", ""), "schulart": k.get("schulart", ""),
            "kontext": str(k.get("kontext") or ""), "bilder": bilder,
            "bildbeschriftung": bildbeschriftung(k.get("bildbeschriftung")),
            "lehrplanbezug": lehrplanbezug_gesetzt(k),
            "lehrplan": lehrplan_sauber(k.get("lehrplan")) if lehrplanbezug(k) == "ja" else None,
            "format": k.get("format", "themen"), "start": str(k.get("start") or ""),
            "familie": familie, "dichte": str(dichte or "normal"), "kasten": str(kasten or "familie"),
            "schwerpunkt": _liste(k.get("schwerpunkt")), "uebungstypen": _liste(k.get("uebungstypen")),
            "sprache": str(k.get("sprache") or "normal"),
            "farbe": name,
            "website": "nein" if website in K.NEIN else "textfeld",
            "abschluss": k.get("abschluss", "keiner"), "portionierung": k.get("portionierung", "keine")}


def angaben_schreiben(steckbrief, angaben):
    """Formularwerte in den Steckbrief schreiben (andere Schlüssel bleiben). Gibt den YAML-Text zurück."""
    sb = api._steckbrief(steckbrief)
    k = dict(sb.get("kurs") or {})
    a = angaben or {}
    if "thema" in a:
        k["titel"] = str(a["thema"]).strip()
    if "jahrgang" in a:
        k["jahrgangsstufe"] = str(a["jahrgang"]).strip()
    if a.get("minuten") not in (None, ""):
        k["umfang_min"] = int(a["minuten"])
    for feld in ("fach", "schulart", "format", "abschluss", "portionierung", "bilder"):
        if feld in a:
            k[feld] = str(a[feld]).strip()
    if "start" in a:                   # AP13.5d: Kursbeginn für das Format Wochen, JJJJ-MM-TT; leer = Tag des Baus
        wert = str(a["start"] or "").strip()
        if wert and not re.match(r"^\d{4}-\d{2}-\d{2}$", wert):
            raise ValueError(f"start „{wert}“: Datum als JJJJ-MM-TT")
        if wert:
            k["start"] = wert
        else:
            k.pop("start", None)
    if "kontext" in a:                 # AP13.4: „Worum geht es genau?“, nur für den Text für den Chat, nie in der Sicherung
        if str(a["kontext"]).strip():
            k["kontext"] = str(a["kontext"]).strip()
        else:
            k.pop("kontext", None)
    # AP13.6: Haken „Lehrplanbezug“ und der gewählte Lehrplan mit den Texten; wie kurs.kontext nie in der Sicherung
    if "lehrplanbezug" in a:           # AP13.5f: ausdrücklich ja oder nein (Standard der Mühle ist aus)
        k["lehrplanbezug"] = lehrplanbezug({"lehrplanbezug": a["lehrplanbezug"]})
    if "lehrplan" in a:
        lp = lehrplan_sauber(a["lehrplan"])
        if lp:
            k["lehrplan"] = lp
        else:
            k.pop("lehrplan", None)
    if lehrplanbezug(k) == "nein":     # Haken weg löst den Lehrplan
        k.pop("lehrplan", None)
    design = dict(k.get("design") or {})
    if "vorlage" in design:             # bis b6: design.vorlage, beim Schreiben migriert
        design.setdefault("familie", DS.migriere(design.pop("vorlage")))
    if "familie" in a or "vorlage" in a:
        design["familie"] = DS.familie(a.get("familie") or a.get("vorlage"))["name"]   # unbekannt: DesignFehler
    for feld, erlaubt, std in (("dichte", DS.DICHTE, "normal"), ("kasten", DS.KASTEN, "familie")):
        if feld in a:
            wert = str(a[feld] or std).strip().lower()
            if wert not in erlaubt:
                raise DS.DesignFehler(f"{feld} „{wert}“ unbekannt (erlaubt: {', '.join(erlaubt)})")
            if wert == std:
                design.pop(feld, None)
            else:
                design[feld] = wert
    if design or "design" in k:
        k["design"] = design
    # AP13.5b: Felder des dritten Zweigs; wie kurs.kontext nur für den Text für den Chat, nie in der Sicherung
    if "schwerpunkt" in a:
        werte = [w for w in _liste(a["schwerpunkt"]) if w in RICHTUNG["schwerpunkt"]]
        k["schwerpunkt"] = werte
        if not werte:
            k.pop("schwerpunkt")
    if "uebungstypen" in a:
        werte = [w for w in _liste(a["uebungstypen"]) if w in uebungstypen_wahl()]
        k["uebungstypen"] = werte
        if not werte:
            k.pop("uebungstypen")
    if "sprache" in a:
        wert = str(a["sprache"] or "normal")
        if wert not in RICHTUNG["sprache"]:
            raise ValueError(f"sprache „{wert}“ unbekannt (erlaubt: {', '.join(RICHTUNG['sprache'])})")
        if wert == "normal":
            k.pop("sprache", None)
        else:
            k["sprache"] = wert
    if "farbe" in a:
        wert = str(a["farbe"] or "").strip()
        if not wert:
            k.pop("farbe", None)
        elif re.match(r"^#[0-9A-Fa-f]{6}$", wert):
            k["farbe"] = wert.upper()
        else:
            k["farbe"] = K.FARBEN[wert.lower()]
    if "website" in a:
        k["website"] = "textfeld" if a["website"] == "textfeld" else "nein"
    if "bildbeschriftung" in a:        # AP13.5h a8: wie kurs.kontext nur für den Text für den Chat
        k["bildbeschriftung"] = bildbeschriftung(a["bildbeschriftung"])
    if not k.get("kurzname") and k.get("titel"):
        k["kurzname"] = k["titel"][:20].strip()
    sb["kurs"] = k
    return api.steckbrief_schreiben(sb)
