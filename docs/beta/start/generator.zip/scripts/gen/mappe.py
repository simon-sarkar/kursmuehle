"""Kursmappe: die Datei, die der Lehrkraft gehört (Formatversion 2).

Ein ZIP mit `mappe.json` (Formatversion, Titel, je Baustein ID, Typ, Titel, Abschnitt, Auftrag, Phase, Soll-Minuten),
`kurs.md`, `steckbrief.yaml` und `assets/`. kurs.md und steckbrief.yaml bleiben das 1.x-Format; die Metadaten stehen nur
in mappe.json, geschlüsselt über die stabile Baustein-ID aus dem Parser. Ein 1.x-Kursordner (kurs.md, steckbrief.yaml,
assets/) wird mit `aus_dateien()` zur Mappe; die Baustein-Liste kommt dann aus `gen.api.pruefe`.
ZIP-Einträge tragen einen festen Zeitstempel, damit dieselbe Mappe dieselben Bytes ergibt (Autosave-Vergleich).

Seit 2.0.0-a2 (AP10): `einheit` (Thema, Jahrgangsstufe, Minuten, Vorlage) und geplante Bausteine (`geplant: true`, noch
ohne Inhalt in kurs.md, etwa aus einer Einheitsvorlage). Der Abgleich ordnet Bausteine über die ID zu (explizit mit
`id:` oder berechnet), sonst nach Position. Textoperationen auf kurs.md (verschieben, entfernen, umbenennen),
Kennzahlen für die Diagnosen am Rand und die Kursangaben der Oberfläche (Steckbrief nur hier, nie in JavaScript).

Seit 2.0.0-a3 (AP11): `chat`, `material`, `durchsicht` in mappe.json; Ist-Minuten aus dem Inhalt gerechnet
(`zeitbedarf`); Strukturbausteine (`minuten: false` im Katalog) zählen in den Kennzahlen nicht; Antwort des Chats nur
für einzelne Bausteine einsetzen (`einsetzen`, Abgleich über `id:`) oder als weitere Einheit anhängen (`anhaengen`),
Vorschlag des Modus aus dem Text (`modus`).
"""
import copy
import datetime
import html
import io
import json
import os
import re
import zipfile

import yaml

from . import api
from . import design as DS
from . import kursdatei as K

FORMAT = 2
_ZEIT = (1980, 1, 1, 0, 0, 0)
# seit 2.0.0-a3 (AP11): gewählter Chat, Material der Lehrkraft, Fragen und Lösungen durchgesehen; seit 2.0.0-b1 (AP13)
# die Schrittfolge: erreichter Schritt, Zweig („mach“, „steuer“), Aussehen gewählt, Text kopiert, importierte Einheiten,
# Zahl der Einheiten und der Teil der Einheit, die gerade angehängt wird
ZUSATZ = ("chat", "material", "durchsicht", "zeitplanung", "schritt", "zweig", "aussehen", "kopiert", "importiert",
          "einheiten", "anhaengen", "zeit_selbst", "laufend", "stueckelung", "korrekturen", "schleife", "bildpruefung",
          "modellhinweis", "durchsicht_weg", "durchsicht_entschieden", "bildformat", "zeit_start", "zeit_download",
          "kanal", "aussehen_bis", "hand", "durchsicht_neu", "kacheln", "themen", "sequenz", "importiert_stand",
          "durchsicht_antwort")
# seit MF4: `durchsicht` = true, wenn das Ende der Fragenliste im Blick war („Lösungen angesehen“; „ohne“ aus älteren
# Mappen zählt als nicht angesehen); `durchsicht_weg` = „chat“ nach „Prüfauftrag kopieren“, „ki“ nach „Mit meiner KI
# prüfen“; `durchsicht_antwort` = die eingefügte Antwort des Prüfgesprächs (nach dem Öffnen wird sie wieder verglichen)
# seit AP13.40: `sequenz` = {stunden: [{thema, ziel}], plan: bool}: die Mappe ist eine Sequenz; Stunde n ist die Einheit
# „e<n>“ (Stunde 1 die erste, Karten ohne `einheit`), `plan` = der Sequenzplan ist eingesetzt
# seit AP13.42: `importiert_stand` = je importierter Einheit eine Prüfsumme ihrer Bausteine zum Zeitpunkt „Ja, die Einheit ist
# im Kurs“ (Schritt 7 erkennt daran Änderungen nach dem Import)
# seit AP13.41: `durchsicht` = true (durchgesehen) oder „ohne“ („Ohne Durchsicht weiter“; gilt beim Download wie true)
# seit AP13.35: `themen` = Thema je Einheit ({"e1": …, "e2": …}), damit Listen nach Einheit gliedern; ältere Mappen ohne:
# die erste heißt nach dem Titel, die laufende nach `einheit.thema`. `einheit.kontext` = „Worum geht es in dieser
# Einheit?“ einer angehängten Einheit (die erste trägt ihn als `kurs.kontext` im Steckbrief)
# seit AP13.31: `kacheln` = Kacheln des Plans in „Ich steuere“ ({titel, text, einheit, aufbau}): Reihenfolge, Titel und
# „Was soll hier rein?“; die geplanten Bausteine einer Kachel tragen ihren Titel als `abschnitt`; `aufbau` = aus einer
# Vorlage oder älteren Mappe entstanden (die Warnungen der Vorlage gelten weiter)
# seit AP13.11: `hand` = je Baustein-id {vorher: Text vor der ersten Handänderung, zeit: ms}: von der Lehrkraft im
# Editor oder mit „Selbst anpassen“ geändert; eine neue Antwort fragt vorher, ob die Handfassung bleibt. Seit AP13.33
# `art: "neu"` = über „Neu schreiben lassen“ eingesetzt (dieselbe Frage); `vorher` ist die Fassung der zuletzt
# eingesetzten Antwort. `durchsicht_neu` = Bausteine, deren Fragen sich nach der Durchsicht geändert haben
# seit AP13.19: `aussehen_bis` = wie weit die Gruppen in Schritt 3 eingeblendet sind (Stelle in schritte.js FOLGE:
# 0 Design und Bilder, 1 Farbe … 5 Übungen); fehlt = noch keine eigene Wahl
# seit AP13.15: `kanal` = „beta“, wenn die Mappe in der Beta-Vorschau (/beta/) geschrieben wurde (kern.js mappeSchreiben);
# fehlt im stabilen Stand
# seit 2.0.0-b12 (AP13.12 a11): `zeit_start` = Einheit in Schritt 1 angelegt, `zeit_download` = erster Download der Datei
# (ISO-Zeit, nur für die Minuten in der Rückmeldung)
# seit 2.0.0-b10 (AP13.5g): `durchsicht_weg` = gewählter Weg in Schritt 6 (ki, chat, selbst), `durchsicht_entschieden` =
# je Abweichung des Gegenprüfens („Baustein-id|Nummer der Aufgabe im Baustein“) {wert: gilt | uebergangen, hash: Hash des
# Bausteins beim Entscheid}, `bildformat` = Format der Bilder im Bilder-Schritt (Teil c)
# seit 2.0.0-b4 (AP13.3): `laufend` = Teil der Einheit, an der gerade gearbeitet wird („e2“ …; fehlt = erste Einheit),
# `stueckelung` = beim ersten Kopieren eingefrorene Teile des Textes ({einheit, leer, ids: [[id]], eingefuegt: [Teil]}),
# `korrekturen` = Ereignisse je Korrekturbitte ({version, chat, typ, regel, runde}, keine Inhalte),
# `bildpruefung` = je Bilddatei true, wenn die Lehrkraft im Schritt Bilder „Passt“ geklickt hat (ältere Mappen: [bool, …])
# Schlüssel je Baustein, die neben den Feldern des Parsers in der Mappe bleiben (AP13): Einheit der Nachlieferung,
# ausgeschaltete Karte (optionale Phase der Vorlage); seit 2.0.0-b5 (AP13.4) `weggelassen` = {minuten}: die Lehrkraft hat den
# Baustein nach einer Korrekturschleife weggelassen (Karte gestrichen, Minuten als Hinweis am Rand).
# `schleife` (Mappe) = je id {hash, gleich, rot}: Hash des zuletzt eingefügten Texts, gleiche und rote Korrekturrunden
# `modellhinweis` (AP13.8) = Einheiten („“ = erste), unter deren Korrekturbitte der Hinweis zum Modell schon stand
# seit AP13.14 `zusatzaufgabe` = Karte „Zusatz“ (Schalter „Hilfen und Zusatzaufgaben“): Minuten außerhalb der Summe
# seit AP13.34 `typ_fest` = die Lehrkraft hat den Typ der Karte gewählt (nicht „automatisch“); bleibt, wenn der Baustein da ist
BLEIBT = ("einheit", "aus", "weggelassen", "zusatzaufgabe", "typ_fest", "id_ergaenzt", "wunsch")
# AP13.35 §3.5: `wunsch` = „Was soll anders sein?“ aus „Neu schreiben lassen“, neben dem Auftrag aus dem Plan; gilt, bis
# die Neufassung eingesetzt ist
# AP13.30: `id_ergaenzt` = die ID kam über Typ und Titel aus der geplanten Karte (grauer Hinweis bis zur nächsten Antwort);
# `leer_antwort` (nur an geplanten Karten) = nach dem Einsetzen einer Antwort noch leer (Rand und Korrekturbitte)
NUR_GEPLANT = ("leer_antwort",)
AUTO = "automatisch"
# AP13.5f: Haken „Lehrplanbezug“ an, aber kein Lernbereich (gelb am Rand; derselbe Satz unter dem Picker, lehrplan.js)
LEHRPLAN_FEHLT = "Noch kein Lernbereich gewählt – der Text für den Chat enthält dann keine Kompetenzerwartungen"
# AP13.8 §9: Phasennamen der Vorlagen bis 2.0.0-b8 -> Namen aus dem Artikulationsschema (migriere; sonst verlöre eine
# ältere Kursmappe die Rolle ihrer Karten)
PHASEN_ALT = {"Aufwärmen": "Einstieg", "Kurz erinnern": "Vorwissensaktivierung", "Üben in Stufen": "Übung",
              "Selbstkontrolle": "Lernzielkontrolle", "Überblick": "Zielangabe", "Erinnern": "Wiederholung",
              "Üben nach Teilthemen": "Übung", "Probelauf": "Lernzielkontrolle", "Lesen": "Erarbeitung", "Üben": "Übung",
              "Sichern": "Sicherung", "Anwendung": "Transfer"}


class MappenFehler(Exception):
    pass


def neu(titel=None, bausteine=None, einheit=None):
    m = {"format": FORMAT, "kursmuehle": api.VERSION, "titel": titel or "", "erzeugt": _heute(),
         "bausteine": [_eintrag(b) for b in (bausteine or [])]}
    if einheit:
        m["einheit"] = dict(einheit)
    return m


def _heute():
    return datetime.date.today().isoformat()


def _eintrag(b, alt=None):
    """Metadaten eines Bausteins aus dem Parser-AST; `alt` = bisheriger Eintrag mit Auftrag, Phase, Soll."""
    alt = alt or {}
    e = {"id": b["id"], "typ": b["typ"], "titel": b["titel"], "abschnitt": b.get("abschnitt"),
         "minuten": b.get("minuten"), "auftrag": alt.get("auftrag", ""), "phase": alt.get("phase", ""),
         "soll": alt.get("soll", b.get("minuten")), "geplant": False, "neu": bool(alt.get("neu", False))}
    if alt.get("schritt") and alt.get("typ") in (b["typ"], AUTO):   # Teilschritt gilt nur für den geplanten Typ
        e["schritt"] = alt["schritt"]
    for k in BLEIBT:
        if alt.get(k):
            e[k] = alt[k]
    if alt.get("typ") in (None, "", AUTO) or alt.get("typ") != b["typ"]:
        e.pop("typ_fest", None)     # auf „automatisch“ zurückgestellt oder anderer Typ im Baustein: keine Vorgabe mehr
    if alt.get("geplant") and alt.get("typ") not in (None, "", AUTO) and alt.get("typ") == b["typ"]:
        e["typ_fest"] = True
    if alt.get("herkunft") and alt.get("titel") == b["titel"]:  # Titel von der Lehrkraft, bis der Chat ihn ersetzt
        e["herkunft"] = dict(alt["herkunft"])
    return e


def geplant(id, typ, titel, phase="", soll=None, auftrag="", schritt=""):
    """Eintrag für einen Baustein ohne Inhalt (Einheitsvorlage, „Baustein hinzufügen“); `schritt` = Teilschritt aus der
    Vorlage (steht im Text für den Chat, nicht auf der Karte)."""
    e = {"id": id, "typ": typ, "titel": titel, "abschnitt": None, "minuten": None, "auftrag": auftrag,
         "phase": phase, "soll": soll, "geplant": True, "neu": False}
    if schritt:
        e["schritt"] = schritt
    return e


def abgleich(mappe, bausteine):
    """mappe.json nach einer neuen Prüfung aktualisieren. Zuordnung zuerst über die ID (explizit mit `id:` oder
    berechnet), dann nach Position als Rückfall (gleicher Platz und Typ, sonst der nächste freie Eintrag gleichen Typs):
    so behält ein umbenannter Baustein Auftrag, Phase und Soll. Neue Bausteine kommen dazu, verschwundene fallen weg;
    geplante Bausteine ohne Gegenstück bleiben an ihrem Platz stehen. Reihenfolge wie in der Kursdatei."""
    alt = list(mappe.get("bausteine", []))
    nach_id = {e["id"]: i for i, e in enumerate(alt)}
    paar, genutzt = {}, set()
    for j, b in enumerate(bausteine):
        i = nach_id.get(b["id"])
        if i is not None and i not in genutzt:
            paar[j] = i
            genutzt.add(i)
    letzter, abschnitt = -1, None
    # AP13.40 (S2-1): Einheiten der Mappe; ein Baustein ohne Gegenstück nimmt nur eine Karte seiner eigenen Einheit (sonst
    # verdrängte ein zusätzlicher Baustein von Stunde 2 den geplanten Einstieg von Stunde 4)
    einh_vorher = _mappe_einheiten(mappe)
    for j, b in enumerate(bausteine):
        if j in paar:
            letzter, abschnitt = paar[j], b.get("abschnitt")
            continue
        # eine geplante Karte füllt nur ein Baustein aus demselben Abschnitt (angehängte Einheit nimmt sie nicht); ein vom
        # Chat ergänzter Baustein (b2-2 zu b2) nimmt keine geplante Karte (AP13.8: sonst fehlt b3, wenn die Antwort
        # nach „Fortsetzung folgt“ den Rest bringt)
        zusatz = b.get("id_explizit") and re.match(r"^(.+)-\d+$", b["id"])
        zusatz = bool(zusatz) and zusatz.group(1) in nach_id
        frei = [i for i in range(letzter + 1, len(alt)) if i not in genutzt and not (zusatz and alt[i].get("geplant"))
                and (alt[i].get("typ") == b["typ"] or (alt[i].get("geplant") and alt[i].get("typ") == AUTO))
                and not (alt[i].get("geplant") and alt[i].get("aus"))   # ausgeschaltete Karte bleibt leer (AP13.1)
                and not (alt[i].get("geplant") and abschnitt is not None and b.get("abschnitt") != abschnitt)
                and (alt[i].get("einheit") or "") == _tn(b.get("teil"), einh_vorher)]
        kandidat = j if j in frei else (frei[0] if frei else None)
        if kandidat is not None:
            paar[j] = kandidat
            genutzt.add(kandidat)
            letzter, abschnitt = kandidat, b.get("abschnitt")
    neu_liste = [_eintrag(b, alt[paar[j]] if j in paar else None) for j, b in enumerate(bausteine)]
    # Einheiten der Mappe (angehängte; `teil:` aus Kursdateien 1.x mit Nachlieferungen ist keine)
    einheiten = {e.get("einheit") for e in alt if e.get("einheit")} | {mappe.get("anhaengen"), mappe.get("laufend")}
    einheiten.discard(None)
    # ein Baustein ohne Karte (vom Chat ergänzt, b7-2) gehört zur Einheit seines Abschnitts (AP13.3): wie der Nachbar
    for j, b in enumerate(bausteine):
        if j in paar:
            continue
        if b.get("teil") and b["teil"] in einheiten:   # AP13.37: Kachel mit `teil:` einer Einheit der Mappe
            neu_liste[j]["einheit"] = b["teil"]
            continue
        nachbar = next((neu_liste[k] for k in list(range(j - 1, -1, -1)) + list(range(j + 1, len(bausteine)))
                        if k in paar and bausteine[k].get("abschnitt") == b.get("abschnitt")), None)
        if nachbar is not None and nachbar.get("einheit"):
            neu_liste[j]["einheit"] = nachbar["einheit"]
    platz = {paar[j]: neu_liste[j] for j in paar}          # alter Index -> Eintrag in der neuen Liste
    for i, e in enumerate(alt):
        if i in genutzt or not e.get("geplant"):
            continue
        vor = next((platz[k] for k in range(i - 1, -1, -1) if k in platz), None)
        pos = neu_liste.index(vor) + 1 if vor is not None else 0
        while vor is not None and pos < len(neu_liste) and re.fullmatch(re.escape(vor["id"]) + r"-\d+", neu_liste[pos]["id"]):
            pos += 1                                       # hinter die Zusatzbausteine der Karte davor (b2-2)
        # Korrekturrunde AP13.41: gehört die geplante Karte zu einer anderen Einheit, auch hinter die übrigen neuen
        # Bausteine der Einheit davor (Zusatzbaustein ohne id in Stunde 2 bleibt bei Stunde 2)
        gesetzt = [id(x) for x in platz.values()]
        while vor is not None and pos < len(neu_liste) and (e.get("einheit") or "") != (vor.get("einheit") or "") \
                and id(neu_liste[pos]) not in gesetzt and (neu_liste[pos].get("einheit") or "") == (vor.get("einheit") or ""):
            pos += 1
        eintrag = dict(geplant(e["id"], e.get("typ", ""), e.get("titel", "")), **{k: e.get(k) for k in
                       ("auftrag", "phase", "soll", "schritt", "abschnitt") + BLEIBT + NUR_GEPLANT
                                                    if e.get(k) is not None},
                       neu=bool(e.get("neu")))
        neu_liste.insert(pos, eintrag)
        platz[i] = eintrag
    mappe["bausteine"] = neu_liste
    mappe["format"] = FORMAT
    mappe["kursmuehle"] = api.VERSION
    if mappe.get("hand"):                      # AP13.11: Handänderung ohne Baustein oder Abschnitt fällt weg
        da = {b["id"] for b in bausteine}
        titel = {_falte(b.get("abschnitt")) for b in bausteine}
        mappe["hand"] = {k: v for k, v in mappe["hand"].items() if k in da or k == "kopf"
                         or (str(k).startswith("abschnitt:") and _falte(_kopf_titel((v or {}).get("nachher"))) in titel)}
    return mappe


def _hand_kopf(k):
    """Schlüssel in `hand`, die keine Bausteine sind (Kopf und Abschnitte der Kursübersicht, AP13.11 §9)."""
    return k == "kopf" or str(k).startswith("abschnitt:")


def _falte(t):
    """Titel zum Vergleichen: ohne Minuten, Leerraum vereinheitlicht, klein."""
    t = re.sub(r"\s*·\s*(?:ca\.\s*)?\d+\s*min\.?\s*$", "", str(t or ""))
    return re.sub(r"\s+", " ", t).strip().lower()


def _kopf_titel(block):
    """Titel aus dem Kopfblock eines Abschnitts („## Titel · N min“ und Angaben)."""
    z = (block or "").splitlines()
    return z[0][3:] if z and z[0].startswith("## ") else ""


# ---------------------------------------------------------------- ältere Mappen (AP13.15)
# Die Formatversion steht nur in mappe.json (`format`) und gilt für die ganze Mappe (mappe.json, kurs.md,
# steckbrief.yaml, assets/). FORMAT steigt nur, wenn eine ältere Mühle die Mappe still falsch lesen würde; neue
# optionale Schlüssel und neue Kursdatei-Syntax heben es nicht. Jede Migration beim Öffnen ist ein Eintrag hier:
# (seit: erste Version der Mühle, die die alte Form nicht mehr schreibt, Datei, Satz, Funktion). Die Funktion ändert
# das dict an Ort und Stelle (mappe.json bzw. Steckbrief) und gibt True zurück, wenn sie etwas geändert hat. Dieselbe
# Liste steht als Tabelle in references/kursdatei.md („Ältere Dateien“).
def _mig_format1(m):
    if m.get("format", 1) == 1:
        m["format"] = FORMAT           # fehlende Felder bekommen beim Neuaufbau in migriere() ihren Standard
        return True
    return False


def _mig_phasen(m):
    geaendert = False
    for e in m.get("bausteine") or []:
        if isinstance(e, dict) and e.get("phase") in PHASEN_ALT:
            e["phase"] = PHASEN_ALT[e["phase"]]
            geaendert = True
    return geaendert


def _mig_bildpruefung(m):
    if isinstance(m.get("bildpruefung"), list):   # ohne Dateinamen nicht zuzuordnen; bilder.js las daraus nie etwas
        del m["bildpruefung"]
        return True
    return False


def _mig_vorlage(sb):
    k = sb.get("kurs")
    design = k.get("design") if isinstance(k, dict) else None
    if not isinstance(design, dict) or "vorlage" not in design:
        return False
    vorlage = design.pop("vorlage")
    design.setdefault("familie", DS.migriere(vorlage))
    return True


MIGRATIONEN = [
    ("2.0.0-a2", "mappe.json", "Formatversion 1 (ohne `format`) wird Format 2", _mig_format1),
    ("2.0.0-b7", "steckbrief.yaml", "`design.vorlage` wird `design.familie`", _mig_vorlage),
    ("2.0.0-b9", "mappe.json", "alte Phasennamen der Vorlagen werden Phasen des Artikulationsschemas", _mig_phasen),
    ("2.0.0-b10", "mappe.json", "`bildpruefung` als Liste fällt weg", _mig_bildpruefung),
]


def migriere(mappe):
    """Ältere oder unvollständige mappe.json auf Formatversion 2 heben (Einträge „mappe.json“ in MIGRATIONEN)."""
    if not isinstance(mappe, dict):
        raise MappenFehler("mappe.json: Mapping erwartet")
    f = mappe.get("format", 1)
    if not isinstance(f, int) or f > FORMAT:
        raise MappenFehler(f"mappe.json: Formatversion {f} ist neuer als diese Kursmühle ({FORMAT}); Seite aktualisieren")
    mappe = copy.deepcopy(mappe)
    for _seit, datei, _satz, fn in MIGRATIONEN:
        if datei == "mappe.json":
            fn(mappe)
    out = neu(mappe.get("titel"), einheit=mappe.get("einheit") if isinstance(mappe.get("einheit"), dict) else None)
    out["erzeugt"] = mappe.get("erzeugt", out["erzeugt"])
    for k in ZUSATZ:
        if mappe.get(k) not in (None, ""):
            out[k] = mappe[k]
    if out.get("zweig") not in (None, "mach", "richtung", "steuer"):
        out["zweig"] = "steuer"        # AP13.5b: unbekannter Zweig (neuere Mühle) öffnet „Ich steuere“
    for e in mappe.get("bausteine", []) or []:
        if isinstance(e, dict) and e.get("id"):
            out["bausteine"].append({"id": e["id"], "typ": e.get("typ", ""), "titel": e.get("titel", ""),
                                     "abschnitt": e.get("abschnitt"), "minuten": e.get("minuten"),
                                     "auftrag": e.get("auftrag", ""), "phase": e.get("phase", ""),
                                     "soll": e.get("soll"),
                                     "geplant": bool(e.get("geplant", False)), "neu": bool(e.get("neu", False)),
                                     **({"schritt": e["schritt"]} if e.get("schritt") else {}),
                                     **({"herkunft": e["herkunft"]} if isinstance(e.get("herkunft"), dict) else {}),
                                     **{k: e[k] for k in BLEIBT if e.get(k)},
                                     **{k: e[k] for k in NUR_GEPLANT if e.get(k) and e.get("geplant")}})
    return out


def migriere_steckbrief(text):
    """steckbrief.yaml beim Öffnen heben (Einträge „steckbrief.yaml“ in MIGRATIONEN). Ändert sich nichts, kommt derselbe
    Text zurück (Byte für Byte, sonst wechselte die Prüfsumme des Autosaves ohne Änderung). Die Leseregeln „fehlt der
    Schlüssel, gilt der alte Wert“ (kurs.bilder, kurs.lehrplanbezug) bleiben Leseregeln und werden nicht geschrieben."""
    sb = api._steckbrief(text)
    geaendert = False
    for _seit, datei, _satz, fn in MIGRATIONEN:
        if datei == "steckbrief.yaml":
            geaendert = fn(sb) or geaendert
    return api.steckbrief_schreiben(sb) if geaendert else text


def herkunft_hinweis(gespeichert, hier=""):
    """Satz beim Öffnen (Status, ockerfarben), wenn die Mappe aus einer neueren Mühle oder aus der Beta-Vorschau kommt;
    sonst „“. gespeichert = {version, kanal} aus `aus_dateien`, hier = Kanal dieser Seite („beta“ oder „“)."""
    g = gespeichert or {}
    version, kanal = str(g.get("version") or ""), str(g.get("kanal") or "")
    rat = "Neue Angaben können hier rot erscheinen; öffne die Einheit dann in der Testversion."
    if kanal == "beta" and hier != "beta":
        mit = f" mit Kursmühle {version}" if version else ""
        return f"Gespeichert in der Testversion{mit}, diese Seite ist {api.VERSION}. {rat}"
    if version and api.version_neuer(version, api.VERSION):
        return f"Gespeichert mit Kursmühle {version}, diese Seite ist {api.VERSION}. {rat}"
    return ""


def dateiname(mappe, datum=None):
    """<kurstitel>_<JJJJ-MM-TT>.kursmappe.zip"""
    titel = api._dateiname(mappe.get("titel") or "kurs")
    if len(titel) > 40:             # AP13.34 §5: an der letzten Wortgrenze kürzen, nicht mitten im Wort
        kurz = titel[:41].rsplit("-", 1)[0]
        titel = kurz if "-" in titel[:41] and len(kurz) >= 12 else titel[:40]
    return f"{titel}_{datum or _heute()}.kursmappe.zip"


def schreiben(mappe, kurs_md, steckbrief, assets=None):
    """-> Bytes des ZIP. steckbrief: dict oder YAML-Text; assets: dict Name -> Bytes."""
    sb_text = steckbrief if isinstance(steckbrief, str) else api.steckbrief_schreiben(steckbrief or {})
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        def add(name, data):
            zi = zipfile.ZipInfo(name, date_time=_ZEIT)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            z.writestr(zi, data if isinstance(data, bytes) else str(data).encode("utf-8"))
        add("mappe.json", json.dumps(mappe, ensure_ascii=False, indent=1, sort_keys=True) + "\n")
        add("kurs.md", kurs_md or "")
        add("steckbrief.yaml", sb_text)
        for name in sorted(assets or {}):
            data = assets[name]
            add(f"assets/{os.path.basename(name)}", bytes(data.tobytes() if isinstance(data, memoryview) else data))
    return buf.getvalue()


def lesen(zip_bytes):
    """ZIP-Bytes -> dict(mappe, kurs_md, steckbrief (dict), steckbrief_text, assets {Name: Bytes})."""
    try:
        z = zipfile.ZipFile(io.BytesIO(bytes(zip_bytes)))
    except zipfile.BadZipFile:
        raise MappenFehler("Die Datei ist keine Kursmappe (kein ZIP)")
    namen = z.namelist()
    # auch Mappen akzeptieren, die in einem Unterordner gepackt wurden
    praefix = ""
    if "mappe.json" not in namen and "kurs.md" not in namen:
        for n in namen:
            if n.endswith("/kurs.md") or n.endswith("/mappe.json"):
                praefix = n.rsplit("/", 1)[0] + "/"
                break
    dateien = {n[len(praefix):]: z.read(n) for n in namen if n.startswith(praefix) and not n.endswith("/")}
    return aus_dateien(dateien)


def aus_dateien(dateien):
    """Dateien eines Ordners oder ZIPs (Pfad relativ -> Bytes): Kursmappe oder 1.x-Kursordner (kurs.md,
    steckbrief.yaml, assets/). Ohne mappe.json wird die Baustein-Liste aus der Kursdatei gelesen."""
    norm = {}
    for pfad, data in dateien.items():
        p = str(pfad).replace("\\", "/").lstrip("./")
        teile = p.split("/")
        # Ordnername davor (Import eines ganzen Ordners) abschneiden
        if len(teile) >= 2 and teile[-2] == "assets":
            p = "assets/" + teile[-1]
        elif teile[-1] in ("kurs.md", "steckbrief.yaml", "mappe.json"):
            p = teile[-1]
        else:
            continue
        norm[p] = bytes(data.tobytes() if isinstance(data, memoryview) else data)
    if "kurs.md" not in norm:
        raise MappenFehler("kurs.md fehlt (Kursmappe oder Kursordner mit kurs.md, steckbrief.yaml, assets/ erwartet)")
    kurs_md = norm["kurs.md"].decode("utf-8-sig")
    sb_text = norm.get("steckbrief.yaml", b"").decode("utf-8-sig")
    try:
        sb_text = migriere_steckbrief(sb_text)
        sb = api.steckbrief_lesen(sb_text)
    except Exception as e:     # yaml-Fehler als Mappenfehler melden
        raise MappenFehler(f"steckbrief.yaml: {e}")
    assets = {k[len("assets/"):]: v for k, v in norm.items() if k.startswith("assets/") and k != "assets/"}
    gespeichert = {"version": "", "kanal": ""}
    if "mappe.json" in norm:
        try:
            roh = json.loads(norm["mappe.json"].decode("utf-8-sig"))
        except json.JSONDecodeError as e:
            raise MappenFehler(f"mappe.json: {e}")
        if isinstance(roh, dict):       # vor migriere: das setzt `kursmuehle` auf die eigene Version
            gespeichert = {"version": str(roh.get("kursmuehle") or ""), "kanal": str(roh.get("kanal") or "")}
        mappe = migriere(roh)
    else:
        titel = (sb.get("kurs") or {}).get("titel")
        # Nachtrag AP13.41: der Titel endet erst vor ` · N min` (ein Malpunkt im Titel bleibt)
        m = re.search(r"^# (?:Drehbuch\s*v?\d*\s*·\s*)?(.+?)(?:\s*·\s*\d+\s*(?:min\b.*)?)?$", kurs_md, re.M)
        mappe = neu(titel or (m.group(1).strip() if m else ""))
        pr = api.pruefe(kurs_md, assets, sb)
        abgleich(mappe, pr["bausteine"])
    return {"mappe": mappe, "kurs_md": kurs_md, "steckbrief": sb, "steckbrief_text": sb_text, "assets": assets,
            "gespeichert": gespeichert}


# ---------------------------------------------------------------- Katalog
_KATALOG = None


def katalog():
    """references/katalog.yaml (liegt neben scripts/, auch im generator.zip der Browser-Fassung)."""
    global _KATALOG
    if _KATALOG is None:
        pfad = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "references", "katalog.yaml")
        with open(pfad, encoding="utf-8") as f:
            _KATALOG = yaml.safe_load(f)
    return _KATALOG


# ---------------------------------------------------------------- Textoperationen auf kurs.md
def _bereiche(kurs_md):
    pr = api.pruefe(kurs_md)
    return pr["kursdatei"].splitlines(), pr["bausteine"]


def _text(lines):
    while lines and not lines[-1].strip():
        lines.pop()
    return "\n".join(lines) + "\n" if lines else ""


def _finde(bausteine, id):
    b = next((b for b in bausteine if b["id"] == id), None)
    if b is None:
        raise MappenFehler(f"Baustein {id} steht nicht in der Kursdatei")
    return b


def entferne(kurs_md, id):
    """Baustein (samt Unterbausteinen eines Unterabschnitts) aus der Kursdatei nehmen."""
    lines, bs = _bereiche(kurs_md)
    b = _finde(bs, id)
    del lines[b["zeile"] - 1:b["zeile"] - 1 + b["zeilen"]]
    return _text(lines)


_RE_BILD_ANGABE = re.compile(r"^\s*(?:Bild|kachelbild):\s*([^\s|·]+\.(?:png|jpe?g))(?=\s|\||$)", re.I)
_RE_BILDZEILE_TEXT = re.compile(r"^(\s*)Bildzeile:\s*([^\s|·]+\.(?:png|jpe?g))\s*(?:\|[^|]*(?:\|(.*))?)?$", re.I)
_RE_BILD_KARTE = re.compile(r"\s*·\s*Bild:\s*([^\s|·]+\.(?:png|jpe?g))(?:\s*\|[^·]*)?", re.I)
_RE_BILD_WUNSCH = re.compile(r"^(Bildwunsch|Bildprompt):\s*(.*)$")


def bilder_entfernen(kurs_md, namen=None):
    """MF3 (Konzept §3.6, „Ohne Bilder weiter“): nimmt die Bilder `namen` (ohne Liste alle) aus der Kursdatei, damit im
    Kurs an ihrer Stelle kein Platzhalter steht: Zeilen `Bild:`, `bild:` und `kachelbild:` mit dieser Datei fallen weg,
    `Bildzeile:` behält ihren Text, `· Bild:` an einer Lernkarte entfällt, ebenso `Bildwunsch:` und `Bildprompt:` zu
    diesen Dateien (ein `Bildprompt:` ohne Dateinamen gehört zum Wunsch davor). Leerzeilen, die dabei doppelt würden,
    fallen mit weg. -> kurs_md"""
    lines = api.pruefe(kurs_md)["kursdatei"].splitlines()
    alle = namen is None
    namen = set(namen or ())

    def trifft(name):
        return alle or name in namen
    out, weg, wunsch_weg = [], False, False
    for z in lines:
        m = _RE_BILD_WUNSCH.match(z)
        if m:
            d = api._RE_DATEI.match(m.group(2).strip())
            datei = d.group(1) if d else None
            if datei:
                treffer = trifft(datei)
            else:
                treffer = alle or (m.group(1) == "Bildprompt" and wunsch_weg)
            wunsch_weg = treffer if m.group(1) == "Bildwunsch" else wunsch_weg
            if treffer:
                weg = True
                continue
            out.append(z)
            continue
        m = _RE_BILD_ANGABE.match(z)
        if m and trifft(m.group(1)):
            weg = True
            continue
        m = _RE_BILDZEILE_TEXT.match(z)
        if m and trifft(m.group(2)):
            weg = True
            if (m.group(3) or "").strip():
                out.append(m.group(1) + m.group(3).strip())
            continue
        neu = _RE_BILD_KARTE.sub(lambda x: "" if trifft(x.group(1)) else x.group(0), z)
        if neu != z:
            weg = True
            z = neu
        if weg and not z.strip() and out and not out[-1].strip():
            weg = False
            continue                              # Leerzeile davor steht schon
        weg = False
        out.append(z)
    return _text(out)


_RE_MARKE = re.compile(r"§(\d+)§")


def loesung_zulassen(kurs_md, id, aufgabe, luecke, wert):
    """Antwort aus dem Gegenprüfen als weitere Lösung (AP13.5h a9): an Lücke `luecke` der Aufgabe `aufgabe` (gezählt im
    Baustein `id` wie `prompt.fragen`) `/wert` anhängen (`*Quellen/Glücksquellen:…*`), bei einer Kurzantwort ` · wert`.
    Steht der Wert schon unter den Lösungen, bleibt die Kursdatei, wie sie ist."""
    from . import prompt as P             # prompt importiert mappe; hier erst beim Aufruf
    wert = " ".join(str(wert or "").replace("*", "").replace("/", " ").replace(":", " ").split())
    if not wert:
        raise MappenFehler("Die Antwort ist leer")
    lines, bs = _bereiche(kurs_md)
    b = _finde(bs, id)
    a, e = b["zeile"] - 1, b["zeile"] - 1 + b["zeilen"]
    # jede Lücke und jede Kurzantwort-Zeile bekommt eine Marke; die Fragen des markierten Bausteins zeigen, welche
    # Stelle zu Aufgabe und Lücke gehört
    stellen, markiert = [], []
    for i in range(a, e):
        def marke(m, i=i):
            stellen.append(("luecke", i, m.start(1), m.end(1)))
            kopf, _, tipp = m.group(1).partition(":")
            return "*" + kopf + f"§{len(stellen) - 1}§" + (":" + tipp if tipp else "") + "*"
        z = P._RE_STERN.sub(marke, K.luecken_sterne(lines[i])[0])      # Malzeichen sind keine Lücken (AP13.34)
        mk = P._RE_ART.match(z.strip())
        if mk and mk.group(1) == "Kurzantwort":
            stellen.append(("kurz", i, None, None))
            z += f"§{len(stellen) - 1}§"
        markiert.append(z)
    fragen = P._fragen_baustein({"typ": b["typ"], "text": "\n".join(markiert)})
    if not 1 <= aufgabe <= len(fragen):
        raise MappenFehler(f"Aufgabe {aufgabe} steht nicht in Baustein {id}")
    f = fragen[aufgabe - 1]
    alt = (f["loesung"] or [[]])[luecke - 1] if f["art"] in ("luecken", "kurz") and 1 <= luecke <= len(f["loesung"]) \
        else None
    m = _RE_MARKE.search(" ".join(alt or []))
    if not m or f.get("markieren"):
        raise MappenFehler(f"Aufgabe {aufgabe} in Baustein {id} hat keine Lücke {luecke} für eine weitere Lösung")
    if P._norm(wert) in {P._norm(_RE_MARKE.sub("", x)) for x in alt}:
        return _text(lines)
    art, i, von, bis = stellen[int(m.group(1))]
    if art == "kurz":
        lines[i] = lines[i].rstrip() + " · " + wert
    else:
        kopf, trenner, tipp = lines[i][von:bis].partition(":")
        lines[i] = lines[i][:von] + kopf.rstrip() + "/" + wert + trenner + tipp + lines[i][bis:]
    return _text(lines)


def verschiebe(kurs_md, id, richtung):
    """Baustein um einen Platz nach oben (richtung < 0) oder unten verschieben, unter Bausteinen derselben Ebene. Am Rand
    seines Abschnitts (oder Unterabschnitts) wechselt er in den Nachbarn: ans Ende des vorigen, an den Anfang des
    nächsten. Gibt die Kursdatei unverändert zurück, wenn es keinen Nachbarn gibt."""
    lines, bs = _bereiche(kurs_md)
    x = _finde(bs, id)
    gleich = [b for b in bs if b["ebene"] == x["ebene"]]
    k = gleich.index(x) + (-1 if richtung < 0 else 1)
    if not 0 <= k < len(gleich):
        return _text(lines)
    ziel = gleich[k]
    eltern = (ziel["abschnitt"], ziel["unterabschnitt"]) == (x["abschnitt"], x["unterabschnitt"])
    davor = eltern if richtung < 0 else not eltern
    a, e = x["zeile"] - 1, x["zeile"] - 1 + x["zeilen"]
    block = lines[a:e]
    if not x.get("id_explizit"):        # die berechnete ID hängt am Abschnitt: festschreiben, damit sie bleibt
        block.insert(1, f"id: {x['id']}")
    if block and block[-1].strip():
        block.append("")
    rest = lines[:a] + lines[e:]
    za = ziel["zeile"] - 1 - (x["zeilen"] if ziel["zeile"] > x["zeile"] else 0)
    ze = za + ziel["zeilen"]
    pos = za if davor else ze
    if not davor and ze > 0 and rest[ze - 1].strip():
        block.insert(0, "")
    return _text(rest[:pos] + block + rest[pos:])


def umbenennen(kurs_md, id, titel):
    """Titel in der Überschrift des Bausteins ersetzen; Minuten und Drehbuch-Marker bleiben stehen. Die bisherige ID
    wird als `id:` festgeschrieben, damit Auftrag, Phase und Soll am Baustein bleiben."""
    titel = " ".join(str(titel).split())
    if not titel:
        raise MappenFehler("Der Titel ist leer")
    lines, bs = _bereiche(kurs_md)
    b = _finde(bs, id)
    kopf = lines[b["zeile"] - 1]
    m = re.match(r"^(#{3,4}\s+[^:]+:\s*)(.*)$", kopf)
    if not m or b["titel"] not in m.group(2):
        raise MappenFehler(f"Überschrift von „{b['titel']}“ nicht gefunden")
    lines[b["zeile"] - 1] = m.group(1) + m.group(2).replace(b["titel"], titel, 1)
    if not b.get("id_explizit"):
        lines.insert(b["zeile"], f"id: {b['id']}")
    return _text(lines)


# ---------------------------------------------------------------- Kennzahlen für die Diagnosen am Rand
_RE_FRAGE = re.compile(r"^(?:\d+\.\s+)?(MC|RF|Einsetzen|Markieren|Lückentext|Kurzantwort|Schnellquiz|Aussagen)\b")
_RE_NUM_MC = re.compile(r"^\d+\.\s+.*\s·\s.*[✔✓]")
_FRAGE_TYPEN = {"Quiz", "Test", "Lesebuch"}
ROLLEN = ["einstieg", "lesen", "üben", "sichern"]


def fragen(b):
    """Fragen eines Bausteins zählen: (alle, Multiple Choice, Auswahlfragen MC/RF, davon mit Rückmeldung)."""
    if b.get("typ") not in _FRAGE_TYPEN:
        return 0, 0, 0, 0
    alle = mc = auswahl = mit = 0
    offen = None            # laufende MC-Frage in Listenform: hat sie schon eine Rückmeldung?
    gruppe = None           # Schnellquiz/Aussagen: jede Listenzeile eine Frage
    for s in (b.get("text") or "").splitlines()[1:]:
        t = s.strip()
        m = _RE_FRAGE.match(t)
        if m or _RE_NUM_MC.match(t):
            art = m.group(1) if m else "MC"
            offen, gruppe = None, None
            if art in ("Schnellquiz", "Aussagen"):
                gruppe = art
                continue
            alle += 1
            if art in ("MC", "RF"):
                auswahl += 1
                mc += art == "MC"
                if "→" in t:
                    mit += 1
                elif art == "MC" and " · " not in t:
                    offen = "wartet"
            continue
        if t.startswith("- ") and gruppe:
            alle += 1
            mc += 1
            auswahl += 1
            continue
        if t.startswith("- ") and offen == "wartet" and "→" in t:
            mit += 1
            offen = "fertig"
        elif t and not t.startswith("- "):
            offen, gruppe = None, None
    return alle, mc, auswahl, mit


def _rollen():
    kat = katalog()
    typ = {e["typ"]: e.get("rolle", "rahmen") for e in kat["typen"]}
    phase = {}
    for v in kat.get("vorlagen", []):
        for p in v["phasen"]:
            phase.setdefault(p["phase"], p.get("rolle", "rahmen"))
    return typ, phase


def struktur():
    """Typen ohne Zeitbedarf (`minuten: false` im Katalog): Kursbanner, Überblick, Unterabschnitt, Abzeichen, Datei …"""
    return {e["typ"] for e in katalog()["typen"] if e.get("minuten") is False}


# ---------------------------------------------------------------- Zeitbedarf aus dem Inhalt
_RE_WORT = re.compile(r"[0-9A-Za-zÄÖÜäöüßÀ-ÿ²³√π]+")
_RE_HTML = re.compile(r"<[^<>]*>")
_RE_LUECKE = re.compile(r"(?<!\*)\*(?!\*)[^*\n]+?(?<!\*)\*(?!\*)")
_RE_PRAEFIX = re.compile(r"^(?:\d+\.\s+|- |(?:Vorspann|Überschrift|Hervorhebung|Merke|Kasten|Beispiel|Hinweis|Schritte|Seite|"
                         r"Kapitel|Unterkapitel|Text|MC|RF|Einsetzen|Markieren|Lückentext|Kurzantwort|Aussagen|Schnellquiz|"
                         r"Szene|Frage|Ende)(?:\s*\([^)]*\))?:\s*)+")
_RE_ABSCHREIBEN = re.compile(r"\b(?:Übernimm|Übertrag\w*)\b[^.\n]*\bins Heft")
_RE_FRAGEZEILE = re.compile(r"^(?:\d+\.\s+)?(?:MC|RF|Einsetzen|Markieren|Lückentext|Kurzantwort)\b|^\d+\.\s+.*\s·\s")


def _jahrgang_faktor(jahrgang):
    tab = katalog()["zeitbedarf"]["jahrgang_faktor"]
    try:
        jg = int(re.match(r"\d+", str(jahrgang)).group(0))
    except (AttributeError, TypeError, ValueError):
        jg = katalog()["zeitbedarf"]["jahrgang_ohne"]     # AP13.4: ohne Angabe rechnet die Mühle mit Stufe 7
    stufen = sorted(int(k) for k in tab)
    return tab[max([k for k in stufen if jg >= k] or [stufen[0]])]


def mindestzahl(m, jahrgang=None):
    """Mindestmaß eines Typs (`mindest` im Katalog) für eine Jahrgangsstufe: `ab_jahrgang` staffelt (AP13.3, Hefteintrag
    bis 6 mindestens 50 Wörter, ab 7 mindestens 80); ohne Stufe oder Staffel gilt `zahl`."""
    stufen = m.get("ab_jahrgang") or {}
    jg = re.match(r"\d+", str(jahrgang or ""))
    if not stufen or not jg:
        return m["zahl"]
    passend = [int(k) for k in stufen if int(jg.group(0)) >= int(k)]
    return stufen[max(passend)] if passend else stufen[min(stufen, key=int)]


def rolle_von(e):
    """Rolle eines Mappen-Eintrags: Phase aus der Vorlage vor Rolle des Typs (einstieg, lesen, üben, sichern, rahmen)."""
    typ_rolle, phase_rolle = _rollen()
    return phase_rolle.get(e.get("phase")) or typ_rolle.get(e.get("typ"), "rahmen")


def zeitbedarf(b, jahrgang=None, rolle=None):
    """Minuten (Kommazahl), die ein Baustein braucht, aus dem Inhalt gerechnet (Werte in katalog.yaml `zeitbedarf`):
    Lesetext nach Rolle (Einstieg 120, Erarbeitung 60 Wörter je Minute für Jahrgangsstufe 9, Faktor je Stufe),
    Hefteintrag mit Abschreibtempo, jede Aufgabe 1,5 oder mit Rechenausdruck 3 Minuten (ihre Wörter zählen nicht noch
    einmal), dazu Sekunden je Lernkarte, Aussage, Szene und Bild. None für Strukturbausteine und Typen, deren Zeit der
    Inhalt nicht zeigt (Video, Link, Abgabe)."""
    z = katalog()["zeitbedarf"]
    typ = b.get("typ")
    if typ in struktur() or typ in z["ohne_rechnung"] or typ == "Unterabschnitt":
        return None
    sek, auf = z["sekunden"], z["aufgabe_minuten"]
    rechnen = re.compile(z["rechnen_muster"])
    rolle = rolle or _rollen()[0].get(typ, "rahmen")
    faktor = _jahrgang_faktor(jahrgang)
    kat = next((e for e in katalog()["typen"] if e["typ"] == typ), {})
    angaben = set(kat.get("angaben", [])) | set(katalog()["gemeinsam"]["angaben"])
    zeilen = (b.get("text") or "").splitlines()[1:]
    woerter, sekunden, kopf = 0, 0.0, True
    aufgaben = []                 # Text je Aufgabe (Frage und ihre Zeilen), für den Rechenaufwand
    in_aufgabe, gruppe, kasten = False, False, None
    for roh in zeilen:
        t = roh.strip()
        if not t:
            continue
        # Kasten mit einer Frage (Denkaufgabe, „Denk kurz nach“) zählt einmal als einfache Aufgabe
        if t.startswith("Kasten:"):
            kasten = "offen"
        elif kasten and roh.startswith("  "):
            if kasten == "offen" and "?" in t:
                aufgaben.append("Denkaufgabe")
                kasten = "gezaehlt"
        else:
            kasten = None
        if kopf:
            m = re.match(r"^([a-zäöüß ]+):\s", t)
            if m and m.group(1) in angaben:
                continue
            kopf = False
        if re.match(r"^(?:\d+\.\s+)?Hilfe:", t):     # AP13.14: gestufte Hilfen kosten nur, wer sie öffnet
            continue
        if t.startswith(("Bild:", "Bildzeile:")):
            sekunden += sek["bild"]
            teile = t.split("|")
            if not (t.startswith("Bildzeile:") and len(teile) > 2):
                continue
            t = teile[2]
        if _RE_FRAGEZEILE.match(t):
            aufgaben.append(t)
            in_aufgabe, gruppe = True, False
            continue
        if re.match(r"^(?:\d+\.\s+)?(Schnellquiz|Aussagen)\b", t):
            in_aufgabe, gruppe = False, True
            continue
        if gruppe and t.startswith("- "):
            sekunden += sek["aussage"]
            continue
        if in_aufgabe and not re.match(r"^(Seite|Kapitel|Unterkapitel|Überschrift|Vorspann|Merke|Kasten|Beispiel|Hinweis|"
                                       r"Hervorhebung|Schritte|Text)\b", t):
            aufgaben[-1] += " " + t          # Optionen, Einsetzen- und Lückentext-Zeilen gehören zur Aufgabe
            continue
        in_aufgabe = gruppe = False
        if typ == "Zuordnen" and t.startswith("- "):
            sekunden += sek["zuordnung"]
            continue
        if typ == "Lernkarten" and t.startswith("- "):
            sekunden += sek["karte"]
            continue
        if typ == "Umfrage" and t.startswith("- "):
            sekunden += sek["umfrage"]
            continue
        if typ == "Geschichte" and re.match(r"^(Szene|Frage|Ende)\b", t):
            sekunden += sek["szene"]
        if typ == "Lückentext":
            sekunden += sek["luecke"] * len(_RE_LUECKE.findall(re.sub(r"\*\*[^*]+\*\*", " ", K.luecken_sterne(t)[0])))
        t = t.split(" → ")[0]
        t = _RE_PRAEFIX.sub("", _RE_HTML.sub(" ", t))
        woerter += len(_RE_WORT.findall(t.replace("✔", " ").replace("✘", " ")))
    minuten = sum(auf["rechnen"] if rechnen.search(a) else auf["einfach"] for a in aufgaben)
    if typ in ("Zuordnen", "Lückentext") and not aufgaben:
        text = b.get("text") or ""
        minuten += auf["rechnen"] if rechnen.search(text) else auf["einfach"]
        sekunden = max(0.0, sekunden - auf["einfach"] * 60) if typ == "Zuordnen" else sekunden
    heft = "Hefteintrag" in (b.get("titel") or "") or bool(_RE_ABSCHREIBEN.search(b.get("text") or ""))
    wpm = (z["abschreiben"] if heft else z["woerter_je_minute"].get(rolle, z["woerter_je_minute"]["rahmen"])) * faktor
    return max(1.0, minuten + woerter / wpm + sekunden / 60)


def _vorgesehen(e, karten):
    """AP13.34 §2.4: Hat die Lehrkraft den Typ dieses Bausteins vorgesehen? Entweder wählte sie ihn an der Karte (`typ_fest`),
    oder der Baustein ist ein Zusatz (`b2-2`), den Teilschritt oder Auftrag der Karte davor mit dem Typ verlangt
    („Fragen als Quiz direkt nach der Seite“)."""
    if e.get("typ_fest"):
        return True
    m = re.fullmatch(r"(.+)-\d+", e.get("id") or "")
    basis = next((x for x in karten if m and x["id"] == m.group(1)), None)
    return bool(basis) and (e.get("typ") or "").lower() in f"{basis.get('schritt') or ''} {basis.get('auftrag') or ''}".lower()


def _luecke(e, genau, ziel):
    """Hinweis an der Karte, was fehlt: „Erarbeitung für 4 Minuten statt 15“ (`ziel` = Soll, sonst Angabe)."""
    name = re.sub(r"\s+\d+$", "", e.get("phase") or "") or next(
        (t["formularname"] for t in katalog()["typen"] if t["typ"] == e.get("typ")), e.get("typ", "Baustein"))
    n = round(genau)
    return f"{name} für {n} Minute{'' if n == 1 else 'n'} statt {ziel}"


# ---------------------------------------------------------------- Plan der Einheit: reichen die Karten? (AP13.1)
def laufende_einheit(mappe):
    """Teil der Einheit, an der gerade gearbeitet wird: beim Anhängen die neue (`anhaengen`), danach `laufend`; None =
    die erste Einheit (Karten ohne `einheit`)."""
    return mappe.get("anhaengen") or mappe.get("laufend") or None


def _einheit_karten(mappe):
    """Eingeschaltete Karten der laufenden Einheit ohne Strukturbausteine: beim Anhängen und danach nur die neue
    Einheit, sonst die Karten ohne `einheit`."""
    teil = laufende_einheit(mappe)
    return [e for e in mappe.get("bausteine", []) if not e.get("aus") and e.get("typ") not in struktur()
            and not e.get("zusatzaufgabe") and (e.get("einheit") == teil if teil else not e.get("einheit"))]


def naechste_nummer(mappe, kurs_md=""):
    """AP13.30: Nummer für die nächste neue Karte (b<n>): hinter der höchsten vergebenen in Mappe und Kursdatei (b6-2
    zählt als 6), nie in ein Loch; dieselbe Regel wie karten.js naechsteNummer."""
    n = 0
    for e in (mappe or {}).get("bausteine", []):
        m = re.fullmatch(r"b(\d+)(?:-\d+)?", str(e.get("id") or ""))
        if m:
            n = max(n, int(m.group(1)))
    for m in re.finditer(r"^id:\s*b(\d+)(?:-\d+)?\s*$", kurs_md or "", re.M):
        n = max(n, int(m.group(1)))
    return n + 1


def ist_zusatzaufgabe(e, b=None):
    """AP13.14: Karte „Zusatz“ der Mappe oder Baustein mit `zusatz: ja` (Minuten außerhalb der Summe)."""
    return bool(e.get("zusatzaufgabe")) or str(((b or {}).get("angaben") or {}).get("zusatz", "")).strip().lower() in K.JA


def zusatzaufgabe(mappe, an=True):
    """AP13.14, Schalter „Hilfen und Zusatzaufgaben“: an = Karte „Zusatz“ (Typ automatisch, `zusatzaufgabe`, Soll aus
    `prompt.differenzierung.karte`) hinter der letzten Karte der laufenden Einheit, wenn sie noch keine hat; aus = eine
    leere Karte „Zusatz“ fällt weg, eine mit Inhalt bleibt. Ändert die Mappe und gibt sie zurück."""
    liste = mappe.setdefault("bausteine", [])
    teil = laufende_einheit(mappe)
    eigene = [e for e in liste if (e.get("einheit") or None) == teil]
    da = [e for e in eigene if e.get("zusatzaufgabe")]
    if not an:
        mappe["bausteine"] = [e for e in liste if not (e in da and e.get("geplant"))]
        return mappe
    if da:
        return mappe
    k = katalog()["prompt"]["differenzierung"]["karte"]
    n = naechste_nummer(mappe)
    karte = dict(geplant(f"b{n}", AUTO, k["titel"], k["phase"], k["minuten"], schritt=k["schritt"]), zusatzaufgabe=True)
    if teil:
        karte["einheit"] = teil
    inhalt = [e for e in eigene if e.get("typ") != "Badge"]
    liste.insert(liste.index(inhalt[-1]) + 1 if inhalt else len(liste), karte)
    return mappe


def _rolle_im_plan(e, uebung):
    """Rolle einer Karte für den Plan: Phase vor Typ; eine Karte mit Inhalt zählt nur als Übung, wenn ihr Typ eine Übung
    ist (ein Kasten mit Fragen im Lesetext ist keine Übung)."""
    r = rolle_von(e)
    if r == "üben" and not e.get("geplant") and e.get("typ") not in uebung:
        return _rollen()[0].get(e.get("typ"), "rahmen")
    return r


def _vorlage(mappe):
    # AP13.40: eine Stunde einer Sequenz mit Plan folgt dem Sequenzplan, nicht der Vorlage (keine Warnungen der Vorlage)
    seq = sequenz_stunde(mappe) and not sequenz_offen(mappe)
    name = None if seq else (mappe.get("einheit") or {}).get("vorlage")
    return next((v for v in katalog().get("vorlagen", []) if v["name"] == name), None)


def _nach_vorlage(mappe):
    """Folgt die laufende Einheit ihrer Vorlage? Außer in „Ich steuere“ immer. Im Plan („Ich steuere“, AP13.31/AP13.39)
    nur, wenn eine Kachel der Einheit aus dem Aufbau stammt (`aufbau`: „Nach Phasen beginnen“ oder ältere Mappe) oder
    die Einheit noch keine Kachel hat (Karten von vor AP13.31)."""
    if mappe.get("zweig") != "steuer":
        return True
    tag = laufende_einheit(mappe)
    eigene = [k for k in mappe.get("kacheln") or [] if isinstance(k, dict) and (k.get("einheit") or None) == tag]
    return not eigene or any(k.get("aufbau") for k in eigene)


def planung(mappe):
    """Reicht der Plan für die Minuten? Summe der Richtwerte je Karte nach Rolle (`zeitbedarf.karte_minuten`) gegen die
    Minuten der Einheit, dazu die Rollen der Vorlage, die keine eingeschaltete Karte mehr trägt. Nur für Einheiten aus
    einer Vorlage; eine Einheit, die die Lehrkraft in „Ich steuere“ in eigenen Kacheln plant (AP13.31: eine Kachel ohne
    `aufbau`, also nicht aus Vorlage oder älterer Mappe) oder deren Plan noch leer ist, folgt keiner. AP13.39: mit
    „Nach Phasen beginnen“ angelegt (eine Kachel der Einheit trägt `aufbau`), gilt die Vorlage über alle Kacheln, auch
    über eigene; „Leer beginnen“ (nur eigene Kacheln) folgt keiner, auch wenn Elemente eine Phase als Etikett tragen.
    -> {karten, minuten, traegt, zu_wenig, fehlen: [Warnung], text}"""
    kat = katalog()
    karten = _einheit_karten(mappe)
    eigen = mappe.get("zweig") == "steuer" and (not karten or not _nach_vorlage(mappe))
    v = None if eigen else _vorlage(mappe)
    minuten = (mappe.get("einheit") or {}).get("minuten")
    richt = kat["zeitbedarf"]["karte_minuten"]
    regeln = kat["pruefregeln"]
    rollen = [_rolle_im_plan(e, regeln["uebung"]) for e in karten]
    traegt = sum(richt.get(r, richt["rahmen"]) for r in rollen)
    soll = [] if v is None else list(dict.fromkeys(p.get("rolle") for p in v["phasen"] if not p.get("optional")))
    fehlen = [regeln["fehlt"][r] for r in soll if r in regeln["fehlt"] and r not in rollen]
    zu_wenig = bool(v is not None and minuten and traegt < int(minuten))
    n = len(karten)
    text = f"{n} {'Karte' if n == 1 else 'Karten'} für {minuten} Minuten" if zu_wenig else ""
    return {"karten": n, "minuten": minuten, "traegt": traegt, "zu_wenig": zu_wenig, "fehlen": fehlen, "text": text}


def _vorlage_karte(b, phase, soll, id):
    """Karte aus einem Eintrag der Vorlage („Typ: Titel | Teilschritt“) mit Typ automatisch."""
    kopf, _, schritt = b.partition(" | ")
    titel = kopf.split(":", 1)[1].strip() if ":" in kopf else phase["phase"]
    return geplant(id, AUTO, titel, phase["phase"], soll, schritt=schritt.strip())


def auffuellen(mappe):
    """„Vorlage auffüllen“: fehlende Rollen der Vorlage als Karten mit Typ automatisch an ihren Platz in der Phasenfolge
    (nach der letzten Karte einer früheren oder gleichen Rolle); tragen die Karten die Minuten dann noch nicht, je eine
    weitere Karte in den dehnbaren Phasen, bis sie reichen (höchstens sechs neue Karten). Nur die laufende Einheit."""
    v = _vorlage(mappe) if _nach_vorlage(mappe) else None     # AP13.39: „Leer beginnen“ ergänzt nichts
    if v is None:
        return mappe
    liste = mappe.setdefault("bausteine", [])
    minuten = int((mappe.get("einheit") or {}).get("minuten") or 45)
    uebung = katalog()["pruefregeln"]["uebung"]
    reihe = {r: i for i, r in enumerate(ROLLEN)}
    teil = laufende_einheit(mappe)
    ids = {e["id"] for e in liste}

    def neue_id():
        n = naechste_nummer({"bausteine": [{"id": i} for i in ids]})
        ids.add(f"b{n}")
        return f"b{n}"

    def einsetzen_nach_rolle(karte, rolle):
        eigene = _einheit_karten(mappe)
        frueher = [e for e in eigene if reihe.get(_rolle_im_plan(e, uebung), -1) <= reihe.get(rolle, -1)]
        if frueher:
            pos = liste.index(frueher[-1]) + 1
        else:
            pos = liste.index(eigene[0]) if eigene else len(liste)
        if teil:
            karte["einheit"] = teil
        liste.insert(pos, karte)

    neu = 0
    vorhanden = {_rolle_im_plan(e, uebung) for e in _einheit_karten(mappe)}
    for p in v["phasen"]:
        if p.get("optional") or p.get("rolle") in vorhanden:
            continue
        vorhanden.add(p.get("rolle"))
        soll = max(1, round(p["anteil"] / 100 * minuten / len(p["bausteine"])))
        for b in p["bausteine"]:
            einsetzen_nach_rolle(_vorlage_karte(b, p, soll, neue_id()), p.get("rolle"))
            neu += 1
    dehnbar = [p for p in v["phasen"] if p.get("dehnbar") and not p.get("optional")]
    k = 0
    while dehnbar and planung(mappe)["zu_wenig"] and neu < 6:
        p = dehnbar[k % len(dehnbar)]
        k += 1
        karte = _vorlage_karte(p["bausteine"][0], p, max(1, round(p["anteil"] / 100 * minuten / 2)), neue_id())
        karte["titel"] = f"{karte['titel']} {k // len(dehnbar) + 2}"
        einsetzen_nach_rolle(karte, p.get("rolle"))
        neu += 1
    return mappe


def nummern(mappe):
    """AP13.33 §1.6: Nummer je Baustein-id wie an der Karte, im Editor und am Rand: Platz in der Bausteinliste, ohne
    ausgeschaltete Karten (die haben keine Nummer und lassen keine Lücke). -> {id: n}"""
    out, n = {}, 0
    for e in (mappe or {}).get("bausteine", []):
        if not e.get("aus"):
            n += 1
            out[e["id"]] = n
    return out


def kennzahlen(mappe, pruefung=None, minuten=None, steckbrief=None):
    """Zahlen für den Rand: Minuten (gerechnet) gegen Soll, Folge Lesen → Üben → Sichern, Anteil Multiple Choice,
    Rückmeldungen, und Hinweise je Baustein (Fehler, Bild fehlt, Rückmeldung fehlt, ohne Inhalt). `zeit` je Baustein:
    gerechnete Minuten, Angabe aus der Überschrift und ob sie um mehr als 20 % abweicht. Strukturbausteine (Kursbanner,
    Überblick, Abzeichen, Datei …) zählen nicht. Nummern = Platz in der Bausteinliste ohne ausgeschaltete Karten (AP13.33
    §1.6, wie an den Karten und im Editor)."""
    pruefung = pruefung or {}
    nach_id = {b["id"]: b for b in pruefung.get("bausteine", [])}
    typ_rolle, phase_rolle = _rollen()
    ohne = struktur()
    # AP13.3: nur die laufende Einheit (beim Anhängen und danach die neue, sonst die Karten ohne `einheit`)
    tag = laufende_einheit(mappe)
    eigene = {e["id"] for e in mappe.get("bausteine", []) if (e.get("einheit") or None) == tag}
    eintraege = [e for e in mappe.get("bausteine", []) if e.get("typ") not in ohne and not e.get("aus") and e["id"] in eigene]
    # Zeit je Phase selbst eingestellt (AP13)? Sonst verteilt das Modell, Soll der Karten zählt nicht
    selbst = mappe.get("zeit_selbst", True) is not False
    soll_von = (lambda e: e.get("soll")) if selbst else (lambda e: None)
    nummer = nummern(mappe)
    einheit = mappe.get("einheit") or {}
    jahrgang = einheit.get("jahrgang") or ((api._steckbrief(steckbrief).get("kurs") or {}).get("jahrgangsstufe")
                                           if steckbrief else None)
    from . import prompt as P             # prompt importiert mappe; hier erst beim Aufruf
    # AP13.37 §2.2: dieselbe Zahl wie im Text für den Chat (prompt.einheit_zeit: mit eigenen Minuten deren Summe)
    soll = minuten or P.pruef_minuten(mappe, eintraege) or einheit.get("minuten") or sum(
        int(soll_von(e) or 0) for e in eintraege if not ist_zusatzaufgabe(e)) or None
    grenze = katalog()["zeitbedarf"]["abweichung"] / 100
    ist = zusatz_min = 0             # AP13.14: Zusatzaufgaben getrennt
    zeit = {}
    folge, zaehl = [], {"fragen": 0, "mc": 0, "auswahl": 0, "rueckmeldung": 0}
    hinweise = []
    for e in eintraege:
        b = nach_id.get(e["id"])
        if b is not None and not e.get("geplant"):
            genau = zeitbedarf(b, jahrgang, rolle_von(e))
            gerechnet = round(genau) if genau is not None else None
            angabe = b.get("minuten")
            ziel = soll_von(e) or angabe
            # mehr als 20 % und mindestens eine ganze Minute neben dem Soll (sonst der Angabe des Chats)
            ab = bool(genau and ziel and abs(ziel - genau) > max(grenze * genau, 1))
            zeit[e["id"]] = {"gerechnet": gerechnet, "angabe": angabe, "soll": soll_von(e), "abweichung": ab,
                             "text": _luecke(e, genau, ziel) if ab else ""}
            if ab:
                hinweise.append({"art": "zeit", "stufe": "hinweis", "baustein": e["id"], "nummer": nummer.get(e["id"]),
                                 "text": f"Baustein {nummer[e['id']]}: {zeit[e['id']]['text']}"})
            wert = gerechnet if gerechnet is not None else int(angabe or soll_von(e) or 0)
        else:
            wert = int(soll_von(e) or 0)
        if ist_zusatzaufgabe(e, b):
            zusatz_min += wert
        else:
            ist += wert
        rolle = phase_rolle.get(e.get("phase")) or typ_rolle.get(e.get("typ"), "rahmen")
        if rolle in ROLLEN[1:] and (not folge or folge[-1] != rolle):
            folge.append(rolle)
        if b is None:
            continue
        alle, mc, auswahl, mit = fragen(b)
        zaehl["fragen"] += alle
        zaehl["mc"] += mc
        zaehl["auswahl"] += auswahl
        zaehl["rueckmeldung"] += mit
        if auswahl > mit and b["typ"] in ("Quiz", "Lesebuch") and rolle != "sichern":
            hinweise.append({"art": "rueckmeldung", "stufe": "hinweis", "baustein": e["id"], "nummer": nummer.get(e["id"]),
                             "text": f"Rückmeldung fehlt bei {auswahl - mit} von {auswahl} Auswahlfragen in Baustein "
                                     f"{nummer[e['id']]}"})
    for d in pruefung.get("diagnosen", []):
        if d.get("baustein") and d["baustein"] not in eigene and d["baustein"] in nummer:
            continue
        n = nummer.get(d.get("baustein"))
        if d["stufe"] == "fehler":
            hinweise.append({"art": "fehler", "stufe": "fehler", "baustein": d.get("baustein"), "nummer": n,
                             "text": (f"Baustein {n}: " if n else "") + d["text"]})
        elif d.get("regel") == "bild.fehlt" and n:
            # AP13.28: grau, ein Hinweis je Baustein, kein Eintrag bei den Warnungen
            if not any(h["art"] == "bild" and h["baustein"] == d["baustein"] and h["stufe"] == "hinweis" for h in hinweise):
                hinweise.append({"art": "bild", "stufe": "hinweis", "baustein": d["baustein"], "nummer": n,
                                 "text": katalog()["oberflaeche"]["bild_spaeter"]})
        elif d.get("regel") == "bild.alt" and n:
            hinweise.append({"art": "bild", "stufe": "warnung", "baustein": d["baustein"], "nummer": n,
                             "text": f"Baustein {n}: Bild ohne Alt-Text"})
        elif d.get("regel") == "wunschtyp":      # AP13.5b: bevorzugter Übungstyp fehlt, gelb am Rand
            hinweise.append({"art": "wunschtyp", "stufe": "warnung", "baustein": None, "nummer": None,
                             "regel": "wunschtyp", "text": d["text"]})
    ohne_lehrplan = bool(steckbrief) and lehrplanbezug(api._steckbrief(steckbrief).get("kurs") or {}) == "nein"
    # AP13.18: geistige Entwicklung arbeitet nach Stufenspannen, ohne Jahrgangsstufe also kein Hinweis
    if steckbrief and not ohne_lehrplan:
        ohne_lehrplan = foerderschwerpunkt(lehrplan_sauber((api._steckbrief(steckbrief).get("kurs") or {})
                                                           .get("lehrplan"))) == FOERDERSCHWERPUNKTE["G"]
    if einheit and not str(einheit.get("jahrgang") or "").strip() and not jahrgang and not ohne_lehrplan:
        hinweise.append({"art": "jahrgang", "stufe": "warnung", "baustein": None, "nummer": None, "regel": "jahrgang.fehlt",
                         "text": f"Jahrgangsstufe fehlt, die Mühle rechnet mit {katalog()['zeitbedarf']['jahrgang_ohne']}"})
    if steckbrief and lehrplan_fehlt(api._steckbrief(steckbrief).get("kurs") or {}):
        hinweise.append({"art": "lehrplan", "stufe": "warnung", "baustein": None, "nummer": None, "regel": "lehrplan.fehlt",
                         "text": LEHRPLAN_FEHLT})
    # AP13.4: Variation der Übungstypen (gelb, keine Korrektur) und Typen, die der Text nicht mehr anbietet
    kat = katalog()
    variation = kat["pruefregeln"]["variation"]
    karten = [e for e in mappe.get("bausteine", []) if e["id"] in eigene and not e.get("aus")]
    angebot = [t for t in auto_typen(karten) if t in variation]
    voll = [e for e in eintraege if not e.get("geplant") and e["id"] in nach_id]
    uebungen = [e for e in voll if nach_id[e["id"]]["typ"] in variation]
    arten = {nach_id[e["id"]]["typ"] for e in uebungen}
    warn_var = False
    for a, b in zip(voll, voll[1:]):
        ta, tb = nach_id[a["id"]]["typ"], nach_id[b["id"]]["typ"]
        if ta == tb and ta in variation and not (_vorgesehen(a, eintraege) and _vorgesehen(b, eintraege)):
            warn_var = True
            hinweise.append({"art": "variation", "stufe": "warnung", "baustein": b["id"], "nummer": nummer[b["id"]],
                             "regel": "variation", "text": f"Baustein {nummer[a['id']]} und {nummer[b['id']]}: zweimal "
                                                           f"{nach_id[a['id']]['typ']} hintereinander"})
    if len(uebungen) >= 4 and len(arten) < 3:
        warn_var = True
        hinweise.append({"art": "variation", "stufe": "warnung", "baustein": None, "nummer": None, "regel": "variation",
                         "text": f"{len(uebungen)} Übungen mit nur {len(arten)} Typen; ab vier Übungen sind drei vorgesehen"})
    zusatz = [t for t in kat["automatisch"].get("zusatz", []) if t not in auto_typen(karten)]
    if zusatz:
        hinweise.append({"art": "typen", "stufe": "hinweis", "baustein": None, "nummer": None,
                         "text": f"{' und '.join(zusatz)} stehen nicht im Text (mehr als "
                                 f"{kat['automatisch']['zusatz_bis']} Karten mit Typ automatisch)"})
    stufe = bilder_stufe(angaben_lesen(steckbrief or "").get("bilder"))
    bilder = {"zahl": api.bilder_zahl([nach_id[e["id"]] for e in voll]), "stufe": stufe["satz"], "wert": stufe["wert"],
              "bytes": api.bilder_bytes([nach_id[e["id"]] for e in voll], pruefung.get("bild_bytes") or {})}
    grenze_mb = kat["pruefregeln"]["bilder_mb"]
    if bilder["bytes"] > grenze_mb * 1024 * 1024:
        hinweise.append({"art": "bilder", "stufe": "warnung", "baustein": None, "nummer": None, "regel": "bilder.groesse",
                         "text": f"Die Bilder dieser Einheit haben zusammen {groesse_text(bilder['bytes'])}, mehr als "
                                 f"{grenze_mb} MB"})
    for e in mappe.get("bausteine", []):
        if e.get("weggelassen") and e["id"] in eigene:
            n = int((e["weggelassen"] or {}).get("minuten") or 0)
            hinweise.append({"art": "weggelassen", "stufe": "warnung", "baustein": e["id"], "nummer": nummer.get(e["id"]),
                             "text": f"„{e.get('titel', '')}“ weggelassen" + (f", {n} Minuten fehlen" if n else "")})
    plan = planung(mappe)
    for text in plan["fehlen"]:
        hinweise.append({"art": "phase", "stufe": "warnung", "baustein": None, "nummer": None, "text": text,
                         "regel": "phase.fehlt"})
    # AP13.30 §4a: geplante Karte nach der Antwort noch leer (gelb, Link auf die Karte); ID über Typ und Titel ergänzt (grau)
    for e in mappe.get("bausteine", []):
        if e["id"] not in eigene:
            continue
        if e.get("geplant") and e.get("leer_antwort") and not e.get("aus"):
            hinweise.append({"art": "leer_antwort", "stufe": "warnung", "baustein": e["id"], "nummer": nummer.get(e["id"]),
                             "regel": "leer.antwort", "text": _editor_text("leer_antwort", n=nummer[e["id"]],
                                                                            titel=e.get("titel", ""))})
        elif e.get("id_ergaenzt") and not e.get("geplant"):
            hinweise.append({"art": "id", "stufe": "hinweis", "baustein": e["id"], "nummer": nummer.get(e["id"]),
                             "text": _editor_text("id_ergaenzt", n=nummer.get(e["id"]))})
    leer = [e for e in mappe.get("bausteine", []) if e.get("geplant") and not e.get("aus") and e["id"] in eigene
            and not e.get("leer_antwort")]
    # AP13.40 (Korrekturrunde, Punkt 10): in einer Sequenz vor dem Plan keine Zahl aus der Vorlage, danach über alle Stunden
    if sequenz_stunde(mappe) or isinstance(mappe.get("sequenz"), dict):
        leer = [] if sequenz_offen(mappe) else [e for e in mappe.get("bausteine", []) if e.get("geplant")
                                                and not e.get("aus") and not e.get("leer_antwort")]
    if leer:
        hinweise.append({"art": "leer", "stufe": "hinweis", "baustein": leer[0]["id"], "nummer": nummer.get(leer[0]["id"]),
                         "text": f"{len(leer)} {'Baustein' if len(leer) == 1 else 'Bausteine'} noch ohne Inhalt"})
    rang = {"fehler": 0, "warnung": 1, "hinweis": 2}
    hinweise.sort(key=lambda h: (rang[h["stufe"]], h["nummer"] or 0))
    # AP13.14: Sprachmessung je Lesetext aus der Prüfung (api.einheit_pruefen): Zeile „Sätze“ am Rand, Werte je Karte
    lese = [(e["id"], nach_id[e["id"]]["sprache"]) for e in voll if nach_id[e["id"]].get("sprache")]
    sprache = {"lesetexte": len(lese), "ueber": sum(1 for _, x in lese if x["ueber"]),
               "mittel_max": max((x["satz_mittel"] for _, x in lese), default=None),
               "je": {i: {k: x[k] for k in ("satz_mittel", "lix", "ueber")} for i, x in lese}} if lese else None
    # Brüche der Folge: Schritte zurück nach dem Sichern und Übungen vor dem ersten Lesetext (Lesen nach Üben ist der
    # Normalfall bei mehreren Lesetexten und zählt nicht)
    rueck = sum(1 for a in folge[:-1] if a == "sichern")
    vor_lesen = len(folge) if "lesen" not in folge else folge.index("lesen")
    return {"minuten": {"ist": ist, "soll": soll, "zusatz": zusatz_min}, "folge": [r.capitalize() for r in folge],
            "folge_brueche": rueck + vor_lesen, "fragen": zaehl,
            "mc_anteil": round(100 * zaehl["mc"] / zaehl["fragen"]) if zaehl["fragen"] else None,
            "bausteine": len(eintraege), "geplant": len(leer), "hinweise": hinweise, "zeit": zeit,
            "inhalt": any(not e.get("geplant") for e in eintraege), "zeit_selbst": selbst, "planung": plan,
            "uebungstypen": {"zahl": len(arten), "von": len(angebot), "warn": warn_var}, "bilder": bilder,
            "sprache": sprache}


# ---------------------------------------------------------------- Antwort des Chats einsetzen
_FORTSETZUNG = re.compile(r"^[\W_]*fortsetzung folgt[\W_]*$", re.I)


def _ohne_fortsetzung(text):
    """AP13.8: endet die Antwort mit der Zeile „Fortsetzung folgt“ (Abbruchregel im Text für den Chat), fällt die Zeile
    weg, auch innerhalb des Codeblocks. -> (Text, bool)"""
    zeilen = (text or "").splitlines()
    for i in range(len(zeilen) - 1, -1, -1):
        z = zeilen[i].strip()
        if not z or z.startswith("```"):
            continue
        if _FORTSETZUNG.match(z):
            return "\n".join(zeilen[:i] + zeilen[i + 1:]) + "\n", True
        break
    return text or "", False


def fortsetzung(text):
    """True, wenn die Antwort mit „Fortsetzung folgt“ endet: die Bausteine gelten, der Rest kommt noch."""
    return _ohne_fortsetzung(text)[1]


def jahrgang_zahl(wert):
    """AP13.8: erste Zahl 1 bis 13 im Feld Jahrgangsstufe oder Zielgruppe („9“, „Klasse 9b“, „Q12“), sonst „“."""
    m = re.search(r"(?<!\d)(1[0-3]|[1-9])(?!\d)", str(wert or ""))
    return m.group(1) if m else ""


def antwort(text):
    """Antwort des Chats lesen; einzelne Bausteine ohne Abschnitt (`## `) bekommen einen, damit der Parser sie annimmt.
    Eine Schlusszeile „Fortsetzung folgt“ zählt nicht zum letzten Baustein.
    -> Ergebnis von gen.api.pruefe"""
    md, _ = api.extrahiere_kursdatei(_ohne_fortsetzung(text)[0])
    if not re.search(r"^## ", md, re.M) and re.search(r"^#{3,6} ", md, re.M):
        kopf, rest = [], []
        for z in md.splitlines():
            (rest if rest or re.match(r"^#{3,6} ", z) else kopf).append(z)
        kopf = [z for z in kopf if not z.startswith("```")]
        if not kopf or not kopf[0].startswith("# "):
            kopf.insert(0, "# Drehbuch v1 · Antwort")
        rest = ["###" + z.lstrip("#") if z.startswith("####") and not any(r.startswith("### Unterabschnitt") for r in rest)
                else z for z in rest if not z.startswith("```")]
        md = "\n".join(kopf + ["", "## Antwort"] + rest) + "\n"
    return api.pruefe(md)


def _bloecke(kursdatei, bausteine):
    """Oberste Bausteine einer Antwort mit ihren Zeilen (Unterbausteine eines Unterabschnitts gehören zum Block)."""
    lines = kursdatei.splitlines()
    out, ende = [], 0
    for b in bausteine:
        if b["zeile"] <= ende:
            continue
        block = lines[b["zeile"] - 1:b["zeile"] - 1 + b["zeilen"]]
        while block and not block[-1].strip():
            block.pop()
        out.append((b, block))
        ende = b["zeile"] + b["zeilen"] - 1
    return out


def _kopfzeilen(kursdatei):
    """Zeilen `Bildwunsch:`, `Bildprompt:`, `Angenommen:`, `Offen:`, `Abweichung:` vor dem ersten Abschnitt."""
    out = []
    for z in kursdatei.splitlines():
        if z.startswith("## "):
            break
        if re.match(r"^(Bildwunsch|Bildprompt|Angenommen|Offen|Abweichung):", z):
            out.append(z)
    return out


def _ebene(block, ebene):
    if block and re.match(r"^#{3,4}\s", block[0]):
        block = ["#" * ebene + block[0].lstrip("#")] + block[1:]
    return block


def _mit_id(block, id):
    if any(re.match(rf"^id:\s*{re.escape(id)}\s*$", z) for z in block[1:6]):
        return block
    rest = [z for z in block[1:] if not re.match(r"^id:\s", z)]
    return [block[0], f"id: {id}"] + rest


def _skelett(mappe, antwort_md, ohne_abschnitt=False):
    """Kopf einer leeren Kursdatei für das erste Einsetzen; mit dem ersten Abschnitt der Antwort (die Minuten der Einheit
    darin), `ohne_abschnitt` (AP13.37: Karten mit Kachel, die einsetzen selbst anlegt) nur die Zeile `# `."""
    e = mappe.get("einheit") or {}
    titel = e.get("thema") or mappe.get("titel") or "Einheit"
    if ohne_abschnitt:
        return f"# Drehbuch v1 · {titel}\n"
    m = re.search(r"^## .+$", antwort_md, re.M)
    kopf = m.group(0) if m and "Allgemeines" not in m.group(0) else f"## {titel}"
    if e.get("minuten"):
        # ein Teil der Stückelung schreibt oft seine eigenen Minuten in die Abschnittsüberschrift; es gilt die Einheit
        kopf = re.sub(r"\s*·\s*\d+\s*min\s*$", "", kopf) + f" · {e['minuten']} min"
    return f"# Drehbuch v1 · {titel}\n\n{kopf}\n"


def modus(mappe, text):
    """Vorschlag, wie die Antwort des Chats eingesetzt wird: `baustein`, wenn ein einzelner Baustein kam oder alle
    Bausteine eine `id:` tragen, die es in der Einheit gibt, und es weniger sind als die Einheit hat; sonst `ersetzen`;
    `keine`, wenn der Text keine Bausteine enthält. Anhängen wählt die Lehrkraft selbst. AP13.8: endet die Antwort mit
    „Fortsetzung folgt“ (`fortsetzung`), gilt `baustein`, sobald eine id passt (eine halbe Einheit ersetzt nie die ganze),
    und `rest` ist die Bitte um die Karten des Teils (sonst der laufenden Einheit), die danach noch leer sind
    (`rest_ids`)."""
    pa = antwort(text)
    bl = _bloecke(pa["kursdatei"], pa["bausteine"])
    nach_id = {e["id"]: e for e in mappe.get("bausteine", [])}
    bekannt = set(nach_id)
    n = len(bl)
    tag = laufende_einheit(mappe) or ""
    # AP13.37 (Sachprüfung): die id einer Karte einer anderen Einheit trifft nur, wenn Typ und Titel dazu passen; sonst
    # hat der Chat neu nummeriert, und der Baustein gehört zur laufenden Einheit
    treffer = [b["id"] for b, _ in bl if b.get("id_explizit") and b["id"] in bekannt
               and ((nach_id[b["id"]].get("einheit") or "") == tag or _passt(b, nach_id[b["id"]]))]
    # AP13.42 A4: ein Zusatzbaustein (b2-2 zu b2 der laufenden Einheit) zählt mit, wenn eine Karte der Einheit außerhalb
    # der Antwort schon Inhalt hat (Teil 1 nach Teil 2 eingefügt); sonst ersetzte die Antwort sie
    ids_a = {b["id"] for b, _ in bl}
    if any(not e.get("geplant") and (e.get("einheit") or "") == tag and e["id"] not in ids_a
           and e.get("typ") not in struktur() for e in mappe.get("bausteine", [])):
        treffer += [b["id"] for b, _ in bl if b.get("id_explizit") and b["id"] not in bekannt
                    and any(_ist_zusatz(b["id"], t) and (nach_id[t].get("einheit") or "") == tag for t in bekannt)]
    # AP13.40: geplante Karten anderer Einheiten (die späteren Stunden einer Sequenz) zählen nicht mit
    gesamt = len([e for e in mappe.get("bausteine", []) if e.get("typ") not in struktur() and not e.get("aus")
                  and not (e.get("geplant") and (e.get("einheit") or "") != tag)]) or len(bekannt)
    weiter = fortsetzung(text)
    if not n:
        art = "keine"
    elif n == 1 or (len(treffer) == n and n < gesamt) or (weiter and treffer):
        art = "baustein"
    else:
        art = "ersetzen"
    ids = [b["id"] for b, _ in bl]
    rest_ids = _rest(mappe, ids) if weiter and n else []
    rest = ""
    if rest_ids:
        from . import prompt as P             # prompt importiert mappe; hier erst beim Aufruf
        rest = P.fortsetzung(mappe, rest_ids)
    return {"modus": art, "bausteine": n, "treffer": len(treffer), "ids": ids, "fortsetzung": weiter,
            "rest": rest, "rest_ids": rest_ids}


def _rest(mappe, ids):
    """Karten, die nach einer Antwort mit „Fortsetzung folgt“ noch fehlen: im gestückelten Text die des Teils mit den
    meisten ids der Antwort (b7-2 zählt zu b7), sonst alle der laufenden Einheit; ohne Inhalt, eingeschaltet."""
    basis = {re.sub(r"-\d+$", "", i) for i in ids} | set(ids)
    tag = laufende_einheit(mappe)
    st = mappe.get("stueckelung") or {}
    teile = st.get("ids") if (st.get("einheit") or None) == tag else None
    if teile:
        kreis = max(teile, key=lambda t: len(basis & set(t)))
    else:
        kreis = [e["id"] for e in mappe.get("bausteine", []) if (e.get("einheit") or None) == tag]
    nach_id = {e["id"]: e for e in mappe.get("bausteine", [])}
    return [i for i in kreis if i not in basis and i in nach_id and nach_id[i].get("geplant")
            and not nach_id[i].get("aus") and nach_id[i].get("typ") not in struktur() | {"Badge"}]


def einheit_teil(teil):
    """AP13.37 §3: `teil:` einer angehängten Einheit der Mühle („e2“ …) oder „“ (erste Einheit; ein `teil:` aus
    Kursdateien 1.x trennt keine Einheiten). Dieselbe Regel wie gen/uebersicht.py _einheit."""
    return teil if re.fullmatch(r"e\d+", teil or "") else ""


def _mappe_einheiten(mappe):
    """AP13.37: Einheiten der Mappe (Werte von `einheit`, `anhaengen`, `laufend`); ein `teil:` aus einer Kursdatei 1.x
    (Nachlieferung) ohne Einheit der Mappe gehört zur ersten Einheit."""
    m = mappe or {}
    out = {e.get("einheit") for e in m.get("bausteine", []) if e.get("einheit")} | {m.get("anhaengen"), m.get("laufend")}
    out.discard(None)
    out.discard("")
    return out


def _tn(teil, einh):
    """Einheit zu einem Wert von `teil:`: der Wert, wenn er eine Einheit der Mappe ist, sonst „“ (erste)."""
    return teil if teil and teil in einh else ""


def _abschnitt_teil(lines, s_, e_):
    """Einheit eines Abschnitts aus seinem Kopfblock: Wert von `teil:`, „“ für die erste."""
    for z in lines[s_ + 1:_kopfblock(lines, s_, e_)]:
        m = re.match(r"^teil:\s*(\S+)\s*$", z)
        if m:
            return m.group(1)
    return ""


def _antwort_kopf(antwort_md, b, echt):
    """Kopfblock des Abschnitts der Antwort, in dem der Baustein b steht (ohne Zeilen `teil:`); [] ohne eigene Abschnitte
    der Antwort (`echt` False: antwort() hat „## Antwort“ ergänzt) und für „Allgemeines“."""
    if not echt:
        return []
    lines = antwort_md.splitlines()
    for s_, e_ in _abschnitt_bereiche(lines):
        if s_ < b["zeile"] - 1 < e_:
            kopf = [z for z in lines[s_:_kopfblock(lines, s_, e_)] if not re.match(r"^teil\s*:", z)]
            return [] if _falte(kopf[0][3:]) in _ALLGEMEIN else kopf
    return []


def _ist_zusatz(i, zu):
    """AP13.42 A4: `i` ist ein Zusatzbaustein des Chats zu `zu` (b2-2, b2-3, b2-2-1 zu b2)."""
    return bool(re.fullmatch(re.escape(zu) + r"(?:-\d+)+", str(i or "")))


def _hinter_zusatz(bs, x):
    """Letzter Baustein der Folge aus `x` und den direkt folgenden Zusatzbausteinen zu ihm oder zu seiner Karte (hinter
    b2-2 auch b2-3 zu b2), auf seiner Ebene."""
    wurzel = re.sub(r"(?:-\d+)+$", "", x["id"])
    if not re.search(r"\d", wurzel):              # Hilfs-id des Parsers (b-1a2b3c4d) hat keine Karte
        wurzel = x["id"]
    oben = [y for y in bs if y.get("ebene") == x.get("ebene")]
    j = next((k for k, y in enumerate(oben) if y is x), None)
    while j is not None and j + 1 < len(oben) and _ist_zusatz(oben[j + 1]["id"], wurzel):
        j += 1
    return oben[j] if j is not None else x


def _in_kachel(md, block, ebene, titel, teil, kopf, davor, danach, neu_kopf=None, einh=frozenset()):
    """AP13.37 §1.1: Block in die Kachel `titel` (Titel gefaltet, auch einer aus `kopf`) der Einheit `teil` („“ = erste)
    setzen: hinter den letzten Baustein dieser Kachel aus `davor` (ids, die im Plan davor stehen), sonst vor den ersten aus
    `danach`, sonst ans Ende der Kachel. Fehlt die Kachel, entsteht sie mit `kopf` (Kopfblock der Antwort) oder
    „## titel“, mit `teil:`, hinter der Kachel des nächsten Bausteins aus `davor` (nächster zuerst), sonst vor der des
    nächsten aus `danach`, sonst am Ende der Einheit. Nur Zeilen dieser Einheit ändern sich. `neu_kopf`: Liste, in die
    (Einheit, gefalteter Titel) der Kachel kommt; einsetzen zählt danach ihre Minuten (ein Teil der Stückelung schreibt
    nur die Minuten seiner Bausteine in die Überschrift).
    -> (md, Titel der Kachel)"""
    lines, bs = _bereiche(md)
    ber = _abschnitt_bereiche(lines)
    teile = [_tn(_abschnitt_teil(lines, s_, e_), einh) for s_, e_ in ber]
    namen = {_falte(titel)} | ({_falte(kopf[0][3:])} if kopf else set())
    namen -= {""}
    k = next((i for i, (s_, e_) in enumerate(ber) if teile[i] == teil and _falte(lines[s_][3:]) in namen), None)
    oben = [x for x in bs if x.get("ebene") == 3 or not x.get("unterabschnitt")]

    def ende_von(x):
        return max(y["zeile"] + y["zeilen"] - 1 for y in bs if y is x or (
            x["typ"] == "Unterabschnitt" and y.get("unterabschnitt") == x["titel"] and y["abschnitt"] == x["abschnitt"]))

    def bereich_von(x):
        return next((i for i, (s_, e_) in enumerate(ber) if s_ < x["zeile"] - 1 < e_), None)

    if k is not None:
        s_, e_ = ber[k]
        drin = [x for x in oben if s_ < x["zeile"] - 1 < e_]
        vor = [x for x in drin if x["id"] in davor]
        nach = [x for x in drin if x["id"] in danach]
        if vor:
            x = _hinter_zusatz(bs, vor[-1])                # AP13.42 A4: hinter die Zusatzbausteine (b2-2)
            pos, ebene = ende_von(x), x["ebene"]
        elif nach:
            pos, ebene = nach[0]["zeile"] - 1, nach[0]["ebene"]
        else:
            pos = e_
            while pos > s_ + 1 and not lines[pos - 1].strip():
                pos -= 1
        neu_block = _ebene(block, ebene)
        if pos > 0 and lines[pos - 1].strip():
            neu_block = [""] + neu_block
        lines[pos:pos] = neu_block + [""]
        if neu_kopf is not None:
            neu_kopf.append((teil, _falte(lines[s_][3:])))
        return _text(lines), lines[s_][3:]
    # Kachel fehlt: anlegen
    kopf = list(kopf) if kopf else ["## " + _zeile_sauber(titel)]
    if neu_kopf is not None:
        neu_kopf.append((teil, _falte(kopf[0][3:])))
    if teil:
        kopf = kopf[:1] + [f"teil: {teil}"] + kopf[1:]
    nach_id = {x["id"]: x for x in oben}
    ref = next((bereich_von(nach_id[i]) for i in davor[::-1] if i in nach_id and bereich_von(nach_id[i]) is not None
                and teile[bereich_von(nach_id[i])] == teil), None)
    if ref is not None:
        pos = ber[ref][1]
    else:
        ref = next((bereich_von(nach_id[i]) for i in danach if i in nach_id and bereich_von(nach_id[i]) is not None
                    and teile[bereich_von(nach_id[i])] == teil), None)
        if ref is not None:
            pos = ber[ref][0]
        else:
            eigene = [i for i, t in enumerate(teile) if t == teil and _falte(lines[ber[i][0]][3:]) not in _ALLGEMEIN]
            if eigene:
                pos = ber[eigene[-1]][1]
            elif not teil:                            # erste Einheit vor den angehängten
                pos = next((ber[i][0] for i, t in enumerate(teile) if t), len(lines))
            else:
                pos = len(lines)
    davor_z = lines[:pos]
    while davor_z and not davor_z[-1].strip():
        davor_z.pop()
    rest = lines[pos:]
    neu = kopf + [""] + _ebene(block, 3) + [""]
    return _text(davor_z + ([""] if davor_z else []) + neu + rest), kopf[0][3:]


def _kachel_minuten(md, teil, titel, einh):
    """Minuten in der Überschrift der Kachel `titel` (gefaltet) der Einheit `teil` als Summe ihrer Bausteine (Kacheln,
    in die einsetzen Bausteine gesetzt hat); nur diese Zeile ändert sich."""
    lines = md.splitlines()
    for n, a in enumerate(_gliederung(md)[1]):
        if a["kopf"] and _falte(a["kopf"][0][3:]) == titel and _tn(_teil_von(a), einh) == teil:
            alt = a["kopf"][0]
            _minuten_zaehlen(a)
            if a["kopf"][0] != alt:
                lines[_abschnitt_bereiche(lines)[n][0]] = a["kopf"][0]
                return _text(lines)
    return md


def einsetzen(mappe, kurs_md, text, nur=None, kopf=False, marker=False, einheit=False, erlaubt=None, ohne_karte=True):
    """Nur die Bausteine der Antwort in die Kursdatei setzen, Abgleich über `id:`: steht die ID in der Kursdatei, ersetzt
    der Block den alten (Ebene wie dort); ist sie ein geplanter Baustein der Mappe, kommt der Block an seinen Platz in der
    Reihenfolge der Mappe. Ein einzelner Baustein ohne `id:` geht an die markierte Karte (`neu`), wenn genau eine
    markiert ist. Sonst eine Fehlermeldung mit Vorschlag; die Kursdatei bleibt dann für diesen Baustein unverändert.
    `nur` (AP13.1, seit AP13.3 der Korrekturblock mit genau einer Karte): ein einzelner Baustein der Antwort ohne `id:`
    (oder mit einer, die es nicht gibt) geht an diese Karte; eine bekannte `id:` der Antwort geht vor (Protokoll
    24.10.: die Antwort mit `id: b4` landete in b3-3). `kopf` (Korrekturblock): bringt die Antwort eigene Zeilen
    `Angenommen:` mit, ersetzen sie die bisherigen (die Zeit-Annahme verschwindet mit der Korrektur). `marker`
    (Handänderung, AP13.11): die Drehbuch-Marker `[Quelle: …]`, `[Zweck: …]`, `[KI]` der alten Überschrift bleiben; das
    Feld im Editor zeigt sie nicht.
    AP13.37 §1.1: eine geplante Karte mit Kachel (`abschnitt`, Plan in „Ich steuere“) kommt in diese Kachel ihrer
    Einheit; fehlt die Kachel, entsteht sie mit dem Kopf des Abschnitts der Antwort (sonst „## Kachel“) an ihrer Stelle im
    Plan. §1.3 `einheit` (Schritt 5 und Korrekturfeld): die Antwort gehört zur laufenden Einheit. Die id eines Bausteins
    einer anderen Einheit (nicht markiert, nicht `nur`) ändert ihn dort nur, wenn Typ und Titel passen und sie in
    `erlaubt` steht (die Seite hat gefragt); passen sie nicht, hat der Chat neu nummeriert, und der Baustein kommt in die
    Kachel, die der Chat nennt, innerhalb der laufenden Einheit (freie id). Ein Baustein ohne Karte ebenso, wenn
    `ohne_karte` und die Antwort Kacheln oder Karten der Einheit nennt. Jede Änderung in einer anderen Einheit steht in
    `fehler` („Geändert in Einheit 1: …“). Immer: eine id, die die Antwort zum zweiten Mal nennt, und ein Baustein mit
    Typ und Titel eines anderen Bausteins der laufenden Einheit werden nicht ein zweites Mal eingesetzt (Meldung).
    -> {kurs_md, ersetzt, eingefuegt, fehler}"""
    pa = antwort(text)
    antwort_md = pa["kursdatei"]
    echt = bool(re.search(r"^## ", api.extrahiere_kursdatei(_ohne_fortsetzung(text)[0])[0], re.M))
    bl = _bloecke(antwort_md, pa["bausteine"])
    plan = mappe.get("bausteine", [])
    nach_id = {e["id"]: e for e in plan}
    markiert = [e for e in plan if e.get("neu")]
    tag = laufende_einheit(mappe) or ""
    einh = _mappe_einheiten(mappe)
    md = kurs_md if (kurs_md or "").strip() else ""
    ersetzt, eingefuegt, fehler_ = [], [], []
    neue_koepfe = []
    gesetzt = {}                                       # id -> Titel des Blocks, den diese Antwort schon eingesetzt hat
    letzte_kachel = None
    ziele = {_ziel_id(b, bl, nach_id, markiert, nur) for b, _ in bl} - {None}   # ids, die diese Antwort ersetzt
    # §1.3: ein Baustein ohne Karte kommt nur dann in eine Kachel, wenn die Antwort Kacheln (`## `) oder Karten der
    # Einheit nennt; ein einzelner Baustein mit unbekannter id bleibt ein Fehler mit Vorschlag
    eigene_ziele = any((nach_id[i].get("einheit") or "") == tag for i in ziele if i in nach_id)
    erlaubt = set(erlaubt or [])
    anderswo = {}                                      # Einheit -> Zahl der dort geänderten Bausteine
    for b, block in bl:
        id = _ziel_id(b, bl, nach_id, markiert, nur)
        roh_id = next((m_.group(1) for z in block[1:6] for m_ in [re.match(r"^id:\s*(\S+)\s*$", z)] if m_), None)
        if id is None and roh_id in gesetzt:           # der Parser nimmt eine doppelte id nicht als explizit
            id = roh_id
        if id is not None and id in gesetzt:
            fehler_.append(_editor_text("doppelt_id", titel=b["titel"], id=id, erster=gesetzt[id]))
            continue
        basis = re.match(r"^(.+)-\d+$", id or "")
        zweiter = id is not None and id not in nach_id and basis is not None and basis.group(1) in nach_id
        lines, bs = _bereiche(md) if md else ([], [])
        alt = next((x for x in bs if x["id"] == id), None) if id is not None else None
        karte = nach_id.get(id) if id is not None else None
        fremd = False
        andere = None                                  # Einheit eines Bausteins einer anderen Einheit, den die id trifft
        if alt is not None and _tn(alt.get("teil"), einh) != tag:
            andere = _tn(alt.get("teil"), einh)
        elif alt is None and karte is not None and (karte.get("einheit") or "") != tag:
            andere = karte.get("einheit") or ""
        if einheit and id is not None and not zweiter and id != nur and not (karte or {}).get("neu"):
            if andere is not None and _passt(b, alt if alt is not None else karte):
                if id not in erlaubt:
                    fehler_.append(stunden_wort(mappe, _editor_text("nicht_geaendert", titel=b["titel"],
                                                                    name=_einheit_name(andere))))
                    continue
            elif andere is not None:                   # neu nummeriert: gehört zur laufenden Einheit
                if not ohne_karte:
                    fehler_.append(f"„{b['titel']}“ trägt eine Kennung, die es in dieser Einheit nicht gibt.")
                    continue
                fremd = True
            elif alt is None and karte is None:
                fremd = ohne_karte and (echt or eigene_ziele)
        # gleicher Typ und Titel wie ein anderer Baustein der laufenden Einheit: nicht doppelt
        doppel = next((x for x in bs if x["id"] != id and x["id"] not in ziele - set(gesetzt)
                       and _tn(x.get("teil"), einh) == tag and x["typ"] == b["typ"]
                       and _titel_gleich(x["titel"], b["titel"])), None)
        if doppel is not None and id is not None and (alt is None or fremd) and (fremd or id in nach_id or zweiter):
            fehler_.append(_editor_text("doppelt_titel", titel=b["titel"], id=doppel["id"]))
            continue
        if fremd:
            # §1.3: in die Kachel, die der Chat nennt, innerhalb der laufenden Einheit
            belegt = {x["id"] for x in bs} | set(nach_id) | set(gesetzt) | (ziele - {id})
            neu_id = id
            if id in belegt:
                n = naechste_nummer(mappe, md)
                while f"b{n}" in belegt:
                    n += 1
                neu_id = f"b{n}"
            kopf_a = _antwort_kopf(antwort_md, b, echt)
            if kopf_a:
                titel = kopf_a[0][3:]
            elif letzte_kachel:
                titel = letzte_kachel
            else:
                eigene = [x for x in bs if _tn(x.get("teil"), einh) == tag and x.get("abschnitt")]
                titel = eigene[-1]["abschnitt"] if eigene else (
                    (mappe.get("einheit") or {}).get("thema") or mappe.get("titel") or "Einheit")
            if not md:
                md = _skelett(mappe, antwort_md, ohne_abschnitt=True)
            md, letzte_kachel = _in_kachel(md, _mit_id(block, neu_id), 3, titel, tag, kopf_a, [], [], neue_koepfe, einh)
            eingefuegt.append(neu_id)
            gesetzt[neu_id] = b["titel"]
            fehler_.append(_editor_text("fremde_kachel" if neu_id != id else "fremde_kachel_id", titel=b["titel"], id=id,
                                        neu=neu_id, kachel=_RE_ZEIT_SUFFIX.sub("", letzte_kachel).strip()))
            continue
        if id is None or (id not in nach_id and not zweiter):
            gleich = [e for e in plan if e.get("titel") == b["titel"] or (e.get("neu") and e.get("typ") == b["typ"])]
            # MF3 (Konzept §3.5): die Meldung steht auf der Seite, ohne Kennung; der Titel genügt dem Chat (ids_ergaenzen)
            vorschlag = (f" Meinst du „{gleich[0]['titel']}“? Bitte den Chat, ihn unter diesem Titel noch einmal "
                         f"auszugeben.") if gleich else \
                " Markiere die Karte, die er ersetzen soll, mit „Diesen Baustein neu beauftragen“, oder wähle „Einheit ersetzen“."
            fehler_.append((f"„{b['titel']}“ trägt keine Kennung." if id is None else
                            f"„{b['titel']}“ trägt eine Kennung, die es in dieser Einheit nicht gibt.") + vorschlag)
            continue
        kachel = (karte or {}).get("abschnitt") if (karte or {}).get("geplant") else None
        if not md:
            md = _skelett(mappe, antwort_md, ohne_abschnitt=bool(kachel))
            lines, bs = _bereiche(md)
        if alt is not None:
            neu_block = _mit_id(_ebene(block, alt["ebene"]), id)
            if marker:
                m_ = [x.strip() for x in _RE_MARKER.findall(lines[alt["zeile"] - 1]) if x.strip() not in neu_block[0]]
                if m_:
                    neu_block = [neu_block[0].rstrip() + " " + " ".join(m_)] + neu_block[1:]
            lines[alt["zeile"] - 1:alt["zeile"] - 1 + alt["zeilen"]] = neu_block + [""]
            ersetzt.append(id)
            letzte_kachel = alt.get("abschnitt") or letzte_kachel
            md = _text(lines)
        elif kachel:
            # §1.1: geplante Karte mit Kachel: in diese Kachel ihrer Einheit, Stelle nach dem Plan
            reihe = [e["id"] for e in plan]
            i = reihe.index(id)
            md, letzte_kachel = _in_kachel(md, _mit_id(block, id), 3, kachel, karte.get("einheit") or "",
                                           _antwort_kopf(antwort_md, b, echt), reihe[:i], reihe[i + 1:], neue_koepfe,
                                           einh)
            eingefuegt.append(id)
        else:
            reihe = [e["id"] for e in plan]
            if id not in reihe:                       # zweiter Baustein zu einer Karte: direkt dahinter
                reihe.insert(reihe.index(basis.group(1)) + 1, id)
            i = reihe.index(id)
            vorher = next((x for k in range(i - 1, -1, -1) for x in bs if x["id"] == reihe[k]), None)
            nachher = next((x for k in range(i + 1, len(reihe)) for x in bs if x["id"] == reihe[k]), None)
            if vorher is not None:
                # nach dem vorigen Baustein (samt Unterbausteinen) einfügen, auf seiner Ebene; AP13.42 A4: auch hinter
                # seine Zusatzbausteine (b2-2 bleibt hinter b2, wenn b3 danach kommt)
                vorher = _hinter_zusatz(bs, vorher)
                ende = max(x["zeile"] + x["zeilen"] - 1 for x in bs if x is vorher or
                           (vorher["typ"] == "Unterabschnitt" and x.get("unterabschnitt") == vorher["titel"]
                            and x["abschnitt"] == vorher["abschnitt"]))
                pos, ebene = ende, vorher["ebene"]
            elif nachher is not None:
                pos, ebene = nachher["zeile"] - 1, nachher["ebene"]
            else:
                pos, ebene = len(lines), 3
            neu_block = _mit_id(_ebene(block, ebene), id)
            if pos > 0 and lines[pos - 1].strip():
                neu_block = [""] + neu_block
            lines[pos:pos] = neu_block + [""]
            eingefuegt.append(id)
            md = _text(lines)
        if einheit and andere is not None:
            anderswo[andere] = anderswo.get(andere, 0) + 1
        gesetzt[id] = b["titel"]
    for teil, titel in dict.fromkeys(neue_koepfe):
        md = _kachel_minuten(md, teil, titel, einh)
    for t, n in anderswo.items():                      # nie still: jede andere Einheit, die sich ändert
        fehler_.append(stunden_wort(mappe, _editor_text("anderswo_geaendert", name=_einheit_name(t), zahl=_bausteine_zahl(n))))
    if (ersetzt or eingefuegt) and kopf:
        neu_annahmen = [z for z in _kopfzeilen(antwort_md) if z.startswith("Angenommen:")]
        ganz = re.search(r"^# ", api.extrahiere_kursdatei(text or "")[0], re.M)    # ganze Kursdatei mit eigenem Kopf
        if neu_annahmen or ganz:
            lines, im_kopf = [], True
            for z in md.splitlines():
                im_kopf = im_kopf and not z.startswith("## ")
                if not (im_kopf and z.startswith("Angenommen:")):
                    lines.append(z)
            md = _text(lines)
    if ersetzt or eingefuegt:
        kopf = [z for z in _kopfzeilen(antwort_md) if z not in md]
        if kopf:
            lines = md.splitlines()
            pos = 1 if lines and lines[0].startswith("# ") else 0
            lines[pos:pos] = kopf
            md = _text(lines)
    fehler_ = [stunden_wort(mappe, f) for f in fehler_]          # AP13.40: in einer Sequenz „Stunde“
    return {"kurs_md": md if (ersetzt or eingefuegt) else kurs_md, "ersetzt": ersetzt, "eingefuegt": eingefuegt,
            "fehler": fehler_}


def _einheiten_der_kursdatei(kurs_md, einh=frozenset()):
    """Einheiten der Kursdatei in ihrer Reihenfolge: [Wert von `teil:`] („“ = erste, auch ohne Abschnitt); Einheit n ist
    die n-te dieser Liste."""
    lines = (kurs_md or "").splitlines()
    out = [""]
    for s_, e_ in _abschnitt_bereiche(lines):
        t = _tn(_abschnitt_teil(lines, s_, e_), einh)
        if t not in out:
            out.append(t)
    return out


def _einheiten_name(nummern):
    """„Einheit 3“, „Einheit 1 und 3“, „Einheit 1 bis 3“, „Einheit 1, 2 und 4“ (Nummern aufsteigend)."""
    n = sorted(set(nummern))
    if len(n) == 1:
        return f"Einheit {n[0]}"
    if len(n) >= 3 and n == list(range(n[0], n[-1] + 1)):
        return f"Einheit {n[0]} bis {n[-1]}"
    return "Einheit " + ", ".join(str(x) for x in n[:-1]) + f" und {n[-1]}"


def _bausteine_zahl(n):
    return f"{n} Baustein" + ("" if n == 1 else "e")


def stunden_wort(mappe, text):
    """AP13.40 (Korrekturrunde, Punkt 9): in einer Sequenz heißen die Einheiten Stunden („Stunde 2“, „Stunden 1 bis 3“);
    dieselbe Regel wie kern.js stundenWort."""
    if not isinstance((mappe or {}).get("sequenz"), dict):
        return text
    return re.sub(r"Einheit(en)?", lambda m: "Stunden" if m.group(1) else "Stunde", text)


def _einheit_name(teil):
    """„Einheit n“ wie auf der Seite (kern.js einheitName): „e3“ ist Einheit 3, die erste Einheit 1."""
    return _editor_text("einheit_name", n=int(teil[1:]) if re.fullmatch(r"e\d+", teil or "") else 1)


def _titel_liste(titel, n=3):
    t = [f"„{x}“" for x in titel[:n]]
    return ", ".join(t) + (f" und {len(titel) - n} weitere" if len(titel) > n else "")


def andere_einheiten(mappe, kurs_md, text, modus="baustein", nur=None):
    """AP13.37 (Sachprüfung): Bausteine der Antwort, deren id einen Baustein (oder eine geplante Karte) einer anderen
    Einheit trifft und deren Typ und Titel dazu passen: die Antwort würde dort etwas ändern. Markierte Karten (`neu`) und
    `nur` zählen nicht (die Lehrkraft hat sie angefordert). Die Seite fragt dann mit Namen; mit „baustein“ ändert die
    Antwort diese Bausteine nur nach der Rückfrage, mit „ersetzen“ nie (sie kommen neu nummeriert in die laufende
    Einheit). -> {ids, einheiten, frage, haupt, abbrechen} (ids leer: keine Frage)"""
    leer = {"ids": [], "einheiten": [], "frage": "", "haupt": "", "abbrechen": ""}
    tag = laufende_einheit(mappe or {}) or ""
    einh = _mappe_einheiten(mappe)
    pa = antwort(text)
    nach_id = {e["id"]: e for e in (mappe or {}).get("bausteine", [])}
    im_kurs = {x["id"]: x for x in api.pruefe(kurs_md)["bausteine"]} if (kurs_md or "").strip() else {}
    ids, titel, einheiten = [], [], []
    for b, _ in _bloecke(pa["kursdatei"], pa["bausteine"]):
        i = b["id"]
        if not b.get("id_explizit") or i == nur or (nach_id.get(i) or {}).get("neu"):
            continue
        x = im_kurs.get(i)
        if x is not None:
            t = _tn(x.get("teil"), einh)
        elif (nach_id.get(i) or {}).get("geplant"):
            x, t = nach_id[i], nach_id[i].get("einheit") or ""
        else:
            continue
        if t != tag and _passt(b, x):
            ids.append(i)
            titel.append(b["titel"])
            if t not in einheiten:
                einheiten.append(t)
    if not ids:
        return leer
    name = _einheiten_name([int(t[1:]) if re.fullmatch(r"e\d+", t) else 1 for t in einheiten])
    n = _bausteine_zahl(len(ids))
    if modus == "ersetzen":
        frage = _editor_text("andere_frage_ersetzen", zahl=n, einheiten=name, titel=_titel_liste(titel))
        haupt = _editor_text("ersetzen_nur", name=_einheit_name(tag))
    else:
        frage = _editor_text("andere_frage", zahl=n, einheiten=name, titel=_titel_liste(titel))
        haupt = _editor_text("andere_aendern", einheiten=name)
    return {"ids": ids, "einheiten": einheiten, "frage": stunden_wort(mappe, frage), "haupt": stunden_wort(mappe, haupt),
            "abbrechen": _editor_text("abbrechen")}


def einheit_ersetzen(mappe, kurs_md, text):
    """AP13.37 §1.2: „Einheit ersetzen“: die Antwort ersetzt nur die Abschnitte der laufenden Einheit (über `teil:`; die
    erste Einheit sind die Abschnitte ohne `teil:`); alle übrigen Abschnitte bleiben Byte für Byte. Die Abschnitte der Antwort bekommen `teil:` der laufenden Einheit (eigene Zeilen
    `teil:` des Chats fallen weg) und stehen an der Stelle der ersetzten; ids, die in einer bleibenden Einheit stehen,
    bekommen eine freie Nummer. „Allgemeines“ der Kursdatei bleibt, außer die Antwort bringt eins mit und die erste
    Einheit wird ersetzt (oder die Kursdatei hat keins). Kopfzeilen der Antwort, die fehlen, kommen nach vorn. Hat die Kursdatei keine andere Einheit,
    gilt die Antwort wie bisher als ganze Kursdatei. -> kurs_md"""
    pa = antwort(text)
    amd = pa["kursdatei"]
    tag = laufende_einheit(mappe or {}) or ""
    weg = {tag}
    kurs_md = kurs_md if (kurs_md or "").strip() else ""
    lines = kurs_md.splitlines()
    ber = _abschnitt_bereiche(lines)
    einh = _mappe_einheiten(mappe)
    teile = [_tn(_abschnitt_teil(lines, s_, e_), einh) for s_, e_ in ber]
    allg = [_falte(lines[s_][3:]) in _ALLGEMEIN for s_, _ in ber]
    if not tag and all(t in weg or a for t, a in zip(teile, allg)):
        return amd                                  # nur die erste Einheit: wie bisher die ganze Kursdatei
    al = amd.splitlines()
    ziel = tag                                      # Teil der neuen Abschnitte
    belegt = {x["id"] for x in api.pruefe(kurs_md)["bausteine"] if _tn(x.get("teil"), einh) not in weg} if kurs_md else set()
    frei = [naechste_nummer(mappe, kurs_md + "\n" + amd)]
    umbenannt = {}

    def neue_id(i):
        if i not in umbenannt:
            while f"b{frei[0]}" in belegt:
                frei[0] += 1
            umbenannt[i] = f"b{frei[0]}"
            frei[0] += 1
        return umbenannt[i]
    zeilen, allg_neu = [], None
    for s_, e_ in _abschnitt_bereiche(al):
        if _falte(al[s_][3:]) in _ALLGEMEIN:
            if "" in weg or not any(allg):
                allg_neu = al[s_:e_]
            continue
        kb = _kopfblock(al, s_, e_)
        for j in range(s_, e_):
            z = al[j]
            if j < kb and re.match(r"^teil\s*:", z):
                continue
            m = re.match(r"^(\s*)id:\s*(\S+)\s*$", z)
            if m and m.group(2) in belegt:
                z = f"{m.group(1)}id: {neue_id(m.group(2))}"
            zeilen.append(z)
            if j == s_ and ziel:
                zeilen.append(f"teil: {ziel}")
    while zeilen and not zeilen[-1].strip():
        zeilen.pop()
    out = list(lines[:ber[0][0]] if ber else lines) or (al[:_abschnitt_bereiche(al)[0][0]] if _abschnitt_bereiche(al)
                                                         else [])
    kopf = [z for z in _kopfzeilen(amd) if z not in out]
    if kopf:
        pos = 1 if out and out[0].startswith("# ") else 0
        out[pos:pos] = kopf
    if allg_neu is not None and not any(allg):
        out += [""] + allg_neu
        allg_neu = None
    gesetzt = False

    def anfuegen(teil):
        while out and not out[-1].strip():
            out.pop()
        out.extend([""] + teil + [""])
    for (s_, e_), t, a in zip(ber, teile, allg):
        if a:
            anfuegen(allg_neu if allg_neu is not None else lines[s_:e_])
            continue
        if t in weg:
            if not gesetzt and zeilen:
                anfuegen(zeilen)
            gesetzt = True
            continue
        if not gesetzt and not tag and t:          # erste Einheit ohne Abschnitt: vor die angehängten
            anfuegen(zeilen)
            gesetzt = True
        out.extend(lines[s_:e_])
    if not gesetzt and zeilen:
        anfuegen(zeilen)
    return _text(out)


_RE_MARKER = re.compile(r"\s*\[(?:Quelle:|Zweck:|KI\b)[^\]]*\]")


def _passt(b, x):
    """AP13.37: Baustein der Antwort und Baustein bzw. Karte x haben denselben Typ (oder x „automatisch“) und denselben
    Titel nach Faltung."""
    return x is not None and x.get("typ") in (b["typ"], AUTO) and _titel_gleich(x.get("titel"), b["titel"])


def _titel_gleich(a, b):
    return _falte(_RE_MARKER.sub("", str(a or ""))) == _falte(_RE_MARKER.sub("", str(b or "")))


def ids_ergaenzen(mappe, text):
    """AP13.30 §4a (aus AP13.29 §3): ein Baustein der Antwort ohne `id:` mit demselben Typ und demselben Titel (nach
    Faltung) wie ein geplanter Baustein ohne Inhalt bekommt dessen ID: die Zeile `id:` kommt unter seine Überschrift im
    Text der Antwort (alles Übrige bleibt, auch „Fortsetzung folgt“). Jede geplante ID nur einmal, nur Karten der
    laufenden Einheit. AP13.37: eine explizite id, die nicht zu Typ und Titel ihrer Karte passt (verschoben, neu
    nummeriert, aus einer anderen Einheit), bekommt die id der Karte der laufenden Einheit mit diesem Typ und Titel,
    auch einer schon gefüllten; eine id, deren Karte passt, bleibt (auch in einer anderen Einheit: das fragt die Seite).
    -> {text, ids: [übernommene ids], umbenannt: {alt: neu}, titel: [Titel der umbenannten]}"""
    tag = laufende_einheit(mappe or {})
    eigene = [e for e in (mappe or {}).get("bausteine", []) if not e.get("aus") and (e.get("einheit") or None) == tag]
    plan = [e for e in eigene if e.get("geplant")]          # nur Karten der laufenden Einheit
    if not eigene or not (text or "").strip():
        return {"text": text, "ids": [], "umbenannt": {}, "titel": []}
    pa = antwort(text)
    lines = pa["kursdatei"].splitlines()
    alle = {e["id"]: e for e in (mappe or {}).get("bausteine", [])}
    bekannt = set(alle)

    passt = _passt
    roh = (text or "").split("\n")

    def kopfzeile(b):
        kopf = lines[b["zeile"] - 1].lstrip("#").strip()
        return next((i for i, z in enumerate(roh) if re.match(r"^\s*#{2,6}\s", z) and z.strip().lstrip("#").strip() == kopf),
                    None)
    # AP13.37 §1.3: explizite ids, die nicht zu ihrer Karte passen (um eins verschoben, neu nummeriert), während eine Karte
    # der Einheit denselben Typ und Titel hat: die id dieser Karte gilt
    explizit = [b for b in pa["bausteine"] if b.get("id_explizit")]
    fest = {b["id"] for b in explizit if passt(b, alle.get(b["id"]))}
    sperre = set(fest)
    while True:
        wahl, genutzt0 = {}, set()
        for n, b in enumerate(explizit):
            if b["id"] in fest:
                continue
            e = next((e for e in eigene if e["id"] not in sperre and e["id"] not in genutzt0 and e.get("typ") == b["typ"]
                      and _titel_gleich(e.get("titel"), b["titel"])), None)
            if e is not None:
                wahl[n] = e["id"]
                genutzt0.add(e["id"])
        # eine id, die ein Baustein ohne passende Karte behält, nimmt kein anderer
        bleibt = {b["id"] for n, b in enumerate(explizit) if b["id"] not in fest and n not in wahl}
        if not (set(wahl.values()) & bleibt - sperre):
            break
        sperre |= bleibt
    umbenannt, titel = {}, []
    for n, b in enumerate(explizit):
        neu_id = wahl.get(n)
        pos = kopfzeile(b) if neu_id else None
        j = next((k for k in range(pos + 1, min(pos + 8, len(roh))) if re.match(r"^\s*id:\s", roh[k])), None) \
            if pos is not None else None
        if j is None or neu_id == b["id"]:
            continue
        roh[j] = re.sub(r"id:\s*\S+", f"id: {neu_id}", roh[j], count=1)
        umbenannt[b["id"]] = neu_id
        titel.append(b["titel"])
    # AP13.40 (S2-1): eine explizite id, die eine geplante Karte einer anderen Einheit trifft und nicht zu ihr passt (etwa
    # ein zusätzlicher Baustein von Stunde 2 mit der id des Einstiegs von Stunde 4), bekommt eine neue Nummer; sie nähme
    # der anderen Stunde sonst die Karte weg
    frei_n = naechste_nummer(mappe, text)
    for b in explizit:
        k = alle.get(b["id"])
        if b["id"] in umbenannt or not k or not k.get("geplant") or (k.get("einheit") or None) == tag or passt(b, k):
            continue
        pos = kopfzeile(b)
        j = next((k_ for k_ in range(pos + 1, min(pos + 8, len(roh))) if re.match(r"^\s*id:\s", roh[k_])), None) \
            if pos is not None else None
        if j is None:
            continue
        roh[j] = re.sub(r"id:\s*\S+", f"id: b{frei_n}", roh[j], count=1)
        umbenannt[b["id"]] = f"b{frei_n}"
        frei_n += 1
    genutzt0 = set(umbenannt.values())
    vergeben = (fest | set(umbenannt.values()) | {b["id"] for b in explizit if b["id"] not in umbenannt})
    genutzt, ids = set(genutzt0), []
    for b in pa["bausteine"]:
        if b.get("id_explizit") or b["id"] in bekannt:
            continue
        e = next((e for e in plan if e["id"] not in genutzt and e["id"] not in vergeben and e.get("typ") == b["typ"]
                  and _titel_gleich(e.get("titel"), b["titel"])), None)
        if e is None:
            continue
        kopf = lines[b["zeile"] - 1].lstrip("#").strip()
        pos = next((i for i, z in enumerate(roh) if re.match(r"^\s*#{2,6}\s", z) and z.strip().lstrip("#").strip() == kopf
                    and not (i + 1 < len(roh) and re.match(r"^\s*id:\s", roh[i + 1]))), None)
        if pos is None:
            continue
        einzug = re.match(r"^(\s*)", roh[pos]).group(1)
        roh.insert(pos + 1, f"{einzug}id: {e['id']}")
        genutzt.add(e["id"])
        ids.append(e["id"])
    return {"text": "\n".join(roh) if ids or umbenannt else text, "ids": ids, "umbenannt": umbenannt, "titel": titel}


def leer_nach_antwort(mappe):
    """AP13.30 §4a: geplante Bausteine der laufenden Einheit, die nach dem Einsetzen einer Antwort noch leer sind (die
    Einheit hat Inhalt, kein Teil der Stückelung steht aus); ohne ausgeschaltete Karten und Strukturbausteine. Die Seite
    markiert sie (`leer_antwort`); Rand und Korrekturbitte nennen sie mit ihrer `id:`. -> [id]"""
    tag = laufende_einheit(mappe)
    eigene = [e for e in (mappe or {}).get("bausteine", []) if (e.get("einheit") or None) == tag]
    st = (mappe or {}).get("stueckelung") or {}
    if st.get("ids") and (st.get("einheit") or None) == tag:
        return []
    if not any(not e.get("geplant") and e.get("typ") not in struktur() for e in eigene):
        return []
    return [e["id"] for e in eigene if e.get("geplant") and not e.get("aus") and e.get("typ") not in struktur() | {"Badge"}]


def _ziel_id(b, bl, nach_id, markiert, nur):
    """Karte, an die ein Block der Antwort geht (einsetzen): eigene `id:`, sonst `nur` bzw. die eine markierte Karte."""
    id = b["id"] if b.get("id_explizit") else None
    if nur and len(bl) == 1 and (id is None or id not in nach_id):
        return nur
    if id is None and len(bl) == 1 and len(markiert) == 1:
        return markiert[0]["id"]
    return id


# ---------------------------------------------------------------- Handänderungen (AP13.11)
def _editor_text(schluessel, **werte):
    return katalog()["oberflaeche"]["editor"][schluessel].format(**werte)


_RE_MINUTEN_MITTE = re.compile(r"(·\s*(?:ca\.\s*)?\d+\s*min\.?)\s+([^\s\[].*?)\s*$")


def hand_pruefen(mappe, text, id):
    """Text aus dem Feld „Bearbeiten“ (oder „Selbst anpassen“) vor dem Übernehmen prüfen: Meldungen des Parsers mit
    „Zeile n:“, kein Baustein, zwei Bausteine, eine `id:` eines anderen Bausteins. Fehler verhindern das Übernehmen;
    Regeln der Einheit (Zeitbedarf, Mindestmaße) prüft erst der Stand danach. -> {ok, meldungen: [{stufe, text}]}"""
    pa = antwort(text)
    bl = _bloecke(pa["kursdatei"], pa["bausteine"])
    m = [{"stufe": d["stufe"], "text": (f"Zeile {d['zeile_im_baustein']} im Feld: " if d.get("zeile_im_baustein") else "")
          + d["text"]} for d in pa["diagnosen"] if d["stufe"] != "hinweis"]
    if not bl:
        m.insert(0, {"stufe": "fehler", "text": _editor_text("kein_baustein")})
    elif len(bl) > 1:
        m.insert(0, {"stufe": "fehler", "text": _editor_text("zwei_bausteine")})
    else:
        b = bl[0][0]
        nach_id = {e["id"]: e for e in (mappe or {}).get("bausteine", [])}
        # AP13.37 §3 (e7-9): Text hinter „· 8 min“ macht die Minuten zum Teil des Titels
        rest = _RE_MINUTEN_MITTE.search(bl[0][1][0] if bl[0][1] else "")
        if rest:
            m.append({"stufe": "warnung", "text": _editor_text("nach_minuten", minuten=rest.group(1).strip(),
                                                                 rest=rest.group(2).strip())})
        if b.get("id_explizit") and b["id"] != id and b["id"] in nach_id:
            m.insert(0, {"stufe": "fehler", "text": _editor_text("fremde_id", id=b["id"],
                                                                 titel=nach_id[b["id"]].get("titel", ""))})
    fehler_ = any(x["stufe"] == "fehler" for x in m)
    if not m:
        m = [{"stufe": "ok", "text": _editor_text("geprueft")}]
    return {"ok": not fehler_, "meldungen": m}


def stelle_setzen(mappe, text, id, nr, werte):
    """MF5: Feld für eine Stelle im Editor (gen/stelle.py setzen). -> {ok, text, unveraendert, meldungen}"""
    from . import stelle as ST
    return ST.setzen(mappe, text, id, nr, werte)


def plan_rueckfrage(mappe, text):
    """MF5 (Befund 15): „Ich steuere“, vor „Einheit ersetzen“ mit der ersten Antwort der laufenden Einheit, wenn die
    Lehrkraft im Plan eigene Kacheln angelegt oder geändert hat (wie plan.js planBelegt): fehlt eine Kachel unter den
    Abschnitten der Antwort, ersetzte sie die Kacheln der Lehrkraft. Dann fragt die Seite. `text` ist die Antwort nur mit den Bausteinen, deren id eine
    leere geplante Karte der Einheit trägt („Nur die leeren Bausteine füllen“), `leer` ihre Zahl.
    -> {frage, kacheln, leer, text}"""
    out = {"frage": False, "kacheln": 0, "leer": 0, "text": ""}
    if not mappe or mappe.get("zweig") != "steuer":
        return out
    tag = laufende_einheit(mappe) or ""
    kacheln = [k for k in mappe.get("kacheln") or [] if (k.get("einheit") or "") == tag]
    karten = [e for e in mappe.get("bausteine", []) if (e.get("einheit") or "") == tag and e.get("typ") not in struktur()]
    out["kacheln"] = len(kacheln)
    # eigene Kacheln wie plan.js planBelegt: nicht aus dem Aufbau, umbenannt, umgestellt oder mit Beschreibung
    eigene = [k for k in kacheln if not k.get("aufbau") or k.get("bearbeitet") or str(k.get("text") or "").strip()]
    if not eigene or any(not e.get("geplant") for e in karten):
        return out
    geplant = {e["id"] for e in karten if e.get("geplant") and not e.get("aus")}
    pa = antwort(text)
    bl = _bloecke(pa["kursdatei"], pa["bausteine"])
    titel = {_falte(a.get("titel") or "") for a in pa.get("abschnitte") or []}
    if all(_falte(k.get("titel") or "") in titel for k in kacheln):
        return out                                  # jede Kachel steht in der Antwort: sie bleiben, der Inhalt kommt neu
    treffer = [block for b, block in bl if b.get("id_explizit") and b["id"] in geplant]
    out.update(frage=True, leer=len(treffer), text="\n\n".join("\n".join(z) for z in treffer) + "\n" if treffer else "")
    return out


def _hand_ids(mappe, kurs_md):
    """Von Hand geänderte Bausteine, die in der Kursdatei stehen, in ihrer Reihenfolge."""
    hand = (mappe or {}).get("hand") or {}
    if not hand or not (kurs_md or "").strip():
        return []
    return [b["id"] for b in api.pruefe(kurs_md)["bausteine"] if b["id"] in hand]


def _in_einheit(mappe, kurs_md, ids):
    """AP13.37 §1.2: Handänderungen (Bausteine und Abschnitte), die in der laufenden Einheit stehen (nur die ersetzt
    „Einheit ersetzen“)."""
    weg = {laufende_einheit(mappe or {}) or ""}
    einh = _mappe_einheiten(mappe)
    teil = {b["id"]: _tn(b.get("teil"), einh) for b in api.pruefe(kurs_md)["bausteine"]} if (kurs_md or "").strip() else {}
    lines = (kurs_md or "").splitlines()
    ber = _abschnitt_bereiche(lines)
    out = []
    for i in ids:
        if str(i).startswith("abschnitt:"):
            nr = _abschnitt_finden(kurs_md, ((mappe or {}).get("hand") or {}).get(i) or {})
            t = _tn(_abschnitt_teil(lines, *ber[nr - 1]), einh) if nr else None
        else:
            t = teil.get(i)
        if t is None or t in weg:
            out.append(i)
    return out


def hand_betroffen(mappe, kurs_md, text, modus, nur=None):
    """Von Hand geänderte Bausteine, die eine neue Antwort ersetzen würde (§4): bei „ersetzen“ alle, bei „baustein“ (und
    Korrekturen, `nur` wie bei einsetzen) die, an deren Karte ein Block der Antwort geht; „anhaengen“ keine. Ausgenommen
    sind Karten, deren Neufassung die Lehrkraft angefordert hat (`neu`, „Neu schreiben lassen“). -> [id]"""
    if modus == "anhaengen":
        return []
    nach_id = {e["id"]: e for e in (mappe or {}).get("bausteine", [])}
    hand = [i for i in _hand_ids(mappe, kurs_md) if not (nach_id.get(i) or {}).get("neu")]
    if modus == "ersetzen":
        # §9: von Hand gesetzte Abschnittsköpfe, die die Antwort anders schreibt (der Kurstitel steht im Steckbrief,
        # den keine Antwort ändert)
        neu_md = antwort(text)["kursdatei"]
        for k_, v in sorted(((mappe or {}).get("hand") or {}).items()):
            if k_.startswith("abschnitt:") and v.get("nachher"):
                nr = _abschnitt_finden(neu_md, v)
                if nr and (abschnitt_kopf(neu_md, nr) != v["nachher"] or ("nach" in v and _vorgaenger(neu_md, nr) != v["nach"])):
                    hand.append(k_)
                elif "bausteine" in v and _gliederung_abweichung(neu_md, v):    # AP13.30: Gliederung der Lehrkraft
                    hand.append(k_)
        return _in_einheit(mappe, kurs_md, hand)
    if not hand:
        return hand
    pa = antwort(text)
    bl = _bloecke(pa["kursdatei"], pa["bausteine"])
    markiert = [e for e in nach_id.values() if e.get("neu")]
    ziele = {_ziel_id(b, bl, nach_id, markiert, nur) for b, _ in bl}
    return [i for i in hand if i in ziele]


def hand_erhalten(mappe, kurs_md, text, modus, nur=None, ids=None):
    """„Erhalten“ (§4): Text, der statt der Antwort eingesetzt wird, damit die Bausteine `ids` (Standard: alle
    betroffenen) in ihrer Handfassung bleiben. „baustein“: die Antwort ohne die Blöcke dieser Karten. „ersetzen“: die
    ganze Kursdatei der Antwort, darin je Handfassung der Block mit derselben id (sonst der Baustein gleichen Typs an
    derselben Stelle im selben Abschnitt) ersetzt; ohne Gegenstück kommt die Handfassung hinter ihren alten Vorgänger.
    AP13.33 §1.3: `vorher` = je Handfassung der Block der Antwort, den sie verdrängt (ohne Gegenstück fehlt die id); die
    Seite merkt ihn als Stand davor, „Handänderung zurücknehmen“ holt dann die Fassung der zuletzt eingesetzten Antwort.
    -> {text, bausteine: Zahl der Blöcke, die aus der Antwort bleiben, vorher: {id: Text}}"""
    if ids is None:
        ids = hand_betroffen(mappe, kurs_md, text, modus, nur)
    ids = list(ids or [])
    pa = antwort(text)
    md = pa["kursdatei"]
    bl = _bloecke(md, pa["bausteine"])
    if not ids:
        return {"text": text, "bausteine": len(bl), "vorher": {}}

    def block_text(zeilen):
        # ohne Zeile `id:`: der Block geht beim Zurücknehmen an seine Karte (einsetzen mit nur=id)
        zeilen = [z for z in zeilen if not re.match(r"^\s*id:\s", z)]
        while zeilen and not zeilen[-1].strip():
            zeilen.pop()
        return "\n".join(zeilen)
    vorher = {}
    if modus != "ersetzen":
        nach_id = {e["id"]: e for e in (mappe or {}).get("bausteine", [])}
        markiert = [e for e in nach_id.values() if e.get("neu")]
        lines = md.splitlines()
        weg = []
        for b, block in bl:
            ziel = _ziel_id(b, bl, nach_id, markiert, nur)
            if ziel in ids:
                weg.append(b)
                vorher.setdefault(ziel, block_text(block))
        for b in sorted(weg, key=lambda x: -x["zeile"]):
            del lines[b["zeile"] - 1:b["zeile"] - 1 + b["zeilen"]]
        return {"text": _text(lines), "bausteine": len(bl) - len(weg), "vorher": vorher}
    alt_lines, alt_bs = _bereiche(kurs_md)
    alt_oben = [b for b, _ in _bloecke("\n".join(alt_lines), alt_bs)]
    alt_nach_id = {b["id"]: b for b in alt_bs}

    def stelle(bs, b):
        """(Nummer des Abschnitts, Stelle im Abschnitt) eines obersten Bausteins."""
        reihe = []
        for x in bs:
            if not reihe or reihe[-1][0] != x.get("abschnitt"):
                reihe.append((x.get("abschnitt"), []))
            reihe[-1][1].append(x["id"])
        for n, (_, liste) in enumerate(reihe):
            if b["id"] in liste:
                return n, liste.index(b["id"])
        return None

    gesetzt = {}                                        # alte id -> id in der neuen Kursdatei
    for h in [i for i in ids if i.startswith("abschnitt:")]:
        v = ((mappe or {}).get("hand") or {}).get(h) or {}
        nr = _abschnitt_finden(md, v) if v.get("nachher") else None
        if not nr:                                      # Abschnitt nicht mehr in der Antwort: nichts überschreiben
            continue
        lines = md.splitlines()
        b = _abschnitt_bereiche(lines)
        lines[b[nr - 1][0]:_kopfblock(lines, *b[nr - 1])] = v["nachher"].splitlines()
        md = _text(lines)
        if "nach" in v and _vorgaenger(md, nr) != v["nach"]:
            md = _abschnitt_hinter(md, nr, v["nach"])
    for h in [i for i in ids if not _hand_kopf(i)]:
        alt = alt_nach_id.get(h)
        if alt is None:
            continue
        block = alt_lines[alt["zeile"] - 1:alt["zeile"] - 1 + alt["zeilen"]]
        while block and not block[-1].strip():
            block.pop()
        lines, bs = _bereiche(md)
        oben = [b for b, _ in _bloecke("\n".join(lines), bs)]
        gegen = next((b for b in oben if b["id"] == h), None)
        if gegen is None:
            st = stelle(alt_oben, alt)
            gegen = next((b for b in oben if b["typ"] == alt["typ"] and b["id"] not in gesetzt.values()
                          and b["id"] not in ids and st is not None and stelle(oben, b) == st), None)
        if gegen is not None:
            vorher[h] = block_text(lines[gegen["zeile"] - 1:gegen["zeile"] - 1 + gegen["zeilen"]])
            lines[gegen["zeile"] - 1:gegen["zeile"] - 1 + gegen["zeilen"]] = _mit_id(_ebene(block, gegen["ebene"]), h) + [""]
        else:
            i = next((k for k, b in enumerate(alt_oben) if b["id"] == h), 0)
            vor = None
            for b in reversed(alt_oben[:i]):
                ziel = gesetzt.get(b["id"], b["id"])
                vor = next((x for x in oben if x["id"] == ziel), None)
                if vor is not None:
                    break
            if vor is not None:
                pos, ebene = vor["zeile"] - 1 + vor["zeilen"], vor["ebene"]
            else:
                pos = next((k + 1 for k, z in enumerate(lines) if z.startswith("## ")), len(lines))
                ebene = 3
            neu_block = _mit_id(_ebene(block, ebene), h)
            if pos > 0 and lines[pos - 1].strip():
                neu_block = [""] + neu_block
            lines[pos:pos] = neu_block + [""]
        gesetzt[h] = h
        md = _text(lines)
    # AP13.30: Kacheln, die die Lehrkraft geteilt oder umgestellt hat, nach den ids ihrer Bausteine
    gl = [((mappe or {}).get("hand") or {}).get(i) or {} for i in ids if str(i).startswith("abschnitt:")]
    gl = [v for v in gl if v.get("bausteine")]
    if gl:
        md = _gliederung_erhalten(md, gl)
    return {"text": md, "bausteine": len(bl), "vorher": vorher}


# ---------------------------------------------------------------- Kursübersicht im Editor (AP13.11 §9)
# Geschrieben wird nur der Kopf (`# `) und die Zeilen `## Titel · N min` mit ihren Angaben; hier ist die eine Stelle dafür
# (keine Textarbeit in JavaScript). Ein Abschnitt heißt nach der Nummer seiner Zeile `## ` (1 = erste).
_RE_ZEIT_SUFFIX = re.compile(r"(\s*·\s*(?:ca\.\s*)?\d+\s*min\.?)\s*$")
_RE_KACHELICON = re.compile(r"^[a-z0-9-]+$")
UEBERSICHT_ANGABEN = ("kachelbild", "kachelicon", "farbe")


def _zeile_sauber(t):
    return re.sub(r"\s+", " ", str(t or "")).strip().lstrip("#").strip()


def _abschnitt_bereiche(lines):
    """[(start, ende)] je Zeile `## ` (ende exklusiv, bis zur nächsten `## `)."""
    pos = [i for i, z in enumerate(lines) if z.startswith("## ")]
    return [(p, pos[n + 1] if n + 1 < len(pos) else len(lines)) for n, p in enumerate(pos)]


def _kopfblock(lines, start, ende):
    """Ende des Kopfblocks eines Abschnitts: Überschrift und die Angaben `schlüssel: wert` direkt darunter."""
    j = start + 1
    while j < ende and (not lines[j].strip() or (K._RE_ATTR.match(lines[j]) and not lines[j].startswith(" ")
                                                  and not lines[j].startswith("#"))):
        j += 1
    while j > start + 1 and not lines[j - 1].strip():
        j -= 1
    return j


def abschnitt_kennung(block):
    """Stabile Kennung eines Abschnitts aus seinem Kopfblock: `teil:` wenn vorhanden, sonst der gefaltete Titel."""
    for z in (block or "").splitlines()[1:]:
        m = re.match(r"^teil:\s*(\S+)\s*$", z)
        if m:
            return "teil:" + m.group(1)
    return "titel:" + _falte(_kopf_titel(block))


def _koepfe(kurs_md):
    lines = (kurs_md or "").splitlines()
    return ["\n".join(lines[s_:_kopfblock(lines, s_, e_)]) for s_, e_ in _abschnitt_bereiche(lines)]


def _abschnitt_finden(kurs_md, v):
    """Nummer des Abschnitts zu einem Eintrag in `hand` ({vorher, nachher}): über `teil:`, sonst über den Titel vor oder
    nach der Handänderung; None, wenn es ihn nicht gibt."""
    koepfe = _koepfe(kurs_md)
    titel = {_falte(_kopf_titel(v.get("vorher"))), _falte(_kopf_titel(v.get("nachher")))} - {""}
    # über `teil:` nur mit dem Kopf vor der Handänderung; eine Kachel, die die Lehrkraft erst angelegt hat (AP13.30,
    # vorher leer), trägt den Teil der alten und heißt nur nach ihrem Titel
    for quelle in (v.get("vorher"),):
        k = abschnitt_kennung(quelle) if quelle else ""
        if k.startswith("teil:"):
            n = [i + 1 for i, x in enumerate(koepfe) if abschnitt_kennung(x) == k]
            if len(n) > 1:      # AP13.30: ein Teil mit mehreren Abschnitten; dann entscheidet der Titel
                n = [i for i in n if _falte(_kopf_titel(koepfe[i - 1])) in titel] or n[:1]
            if n:
                return n[0]
    return next((i + 1 for i, x in enumerate(koepfe) if _falte(_kopf_titel(x)) in titel), None)


_ALLGEMEIN = ("allgemeines", "allgemein", "0")


def _vorgaenger(kurs_md, nr):
    """Kennung des Abschnitts vor nr (ohne „Allgemeines“); „“ für den ersten."""
    koepfe = _koepfe(kurs_md)
    for i in range(nr - 2, -1, -1):
        if _falte(_kopf_titel(koepfe[i])) not in _ALLGEMEIN:
            return abschnitt_kennung(koepfe[i])
    return ""


def _abschnitt_hinter(kurs_md, nr, nach):
    """Abschnitt nr hinter den Abschnitt mit der Kennung `nach` setzen („“ = an den Anfang, hinter „Allgemeines“)."""
    lines = (kurs_md or "").splitlines()
    s_, e_ = _abschnitt_bereiche(lines)[nr - 1]
    block = lines[s_:e_]
    while block and not block[-1].strip():
        block.pop()
    rest = lines[:s_] + lines[e_:]
    b2 = _abschnitt_bereiche(rest)
    koepfe = _koepfe("\n".join(rest))
    if nach:
        ziel = next((b2[i][1] for i, k in enumerate(koepfe) if abschnitt_kennung(k) == nach), None)
        if ziel is None:
            return kurs_md
    else:
        allg = [b2[i][1] for i, k in enumerate(koepfe) if _falte(_kopf_titel(k)) in _ALLGEMEIN]
        ziel = allg[0] if allg else (b2[0][0] if b2 else len(rest))
    davor = rest[:ziel]
    while davor and not davor[-1].strip():
        davor.pop()
    return _text(davor + [""] + block + [""] + rest[ziel:])


def abschnitt_schluessel(kurs_md, nr, hand=None):
    """Schlüssel in `hand` für den Abschnitt nr: ein vorhandener Eintrag, der zu ihm gehört, sonst „abschnitt:“ und die
    Kennung seines jetzigen Kopfs (stabil über Verschieben und neue Antworten, nicht über die Nummer)."""
    for k, v in sorted((hand or {}).items()):
        if str(k).startswith("abschnitt:") and _abschnitt_finden(kurs_md, v or {}) == nr:
            return k
    kopf = abschnitt_kopf(kurs_md, nr)
    kennung = abschnitt_kennung(kopf)
    if kennung.startswith("teil:") and sum(1 for x in _koepfe(kurs_md) if abschnitt_kennung(x) == kennung) > 1:
        kennung = "titel:" + _falte(_kopf_titel(kopf))      # AP13.30: Teil mit mehreren Abschnitten
    return "abschnitt:" + kennung


def abschnitt_kopf(kurs_md, nr):
    """Kopfblock (Überschrift und Angaben) des Abschnitts nr als Text, sonst „“."""
    lines = (kurs_md or "").splitlines()
    b = _abschnitt_bereiche(lines)
    if not 1 <= nr <= len(b):
        return ""
    return "\n".join(lines[b[nr - 1][0]:_kopfblock(lines, *b[nr - 1])])


def abschnitt_setzen(kurs_md, nr, angaben, hand=None):
    """Titel und Angaben (kachelbild, kachelicon, farbe; leer = Zeile weg) des Abschnitts nr setzen; die Minuten in der
    Überschrift bleiben. Ändert sich der Titel, bekommen Bausteine des Abschnitts ohne `id:` ihre bisherige (aus dem Titel
    berechnete) ID als Zeile `id:`. `hand` = Handänderungen der Mappe, für den Schlüssel.
    -> {kurs_md, vorher, nachher, schluessel, fehler, hand: weitere Einträge (hand_nachfuehren)}"""
    from .kursdatei import FARBEN
    lines = (kurs_md or "").splitlines()
    b = _abschnitt_bereiche(lines)
    if not 1 <= nr <= len(b):
        return {"kurs_md": kurs_md, "vorher": "", "nachher": "", "fehler": f"Abschnitt {nr} steht nicht in der Einheit"}
    start, ende = b[nr - 1]
    vorher = abschnitt_kopf(kurs_md, nr)
    schluessel = abschnitt_schluessel(kurs_md, nr, hand)
    a = dict(angaben or {})
    if "titel" in a:
        titel = _zeile_sauber(a["titel"])
        if not titel:
            return {"kurs_md": kurs_md, "vorher": vorher, "nachher": vorher, "schluessel": schluessel,
                    "fehler": "Der Titel ist leer."}
        if _falte(titel) != _falte(_kopf_titel(vorher)):
            # N3: berechnete IDs hängen am Abschnittstitel; sie werden vorher als `id:` festgeschrieben
            for bs in sorted((x for x in api.pruefe(kurs_md)["bausteine"] if start < x["zeile"] <= ende
                              and not x.get("id_explizit")), key=lambda x: -x["zeile"]):
                lines.insert(bs["zeile"], f"id: {bs['id']}")
                ende += 1
        m = _RE_ZEIT_SUFFIX.search(lines[start])
        lines[start] = "## " + titel + (m.group(1) if m else "")
    for key in UEBERSICHT_ANGABEN:
        if key not in a:
            continue
        wert = _zeile_sauber(a[key])
        if key == "kachelicon" and wert and not _RE_KACHELICON.match(wert):
            return {"kurs_md": kurs_md, "vorher": vorher, "nachher": vorher, "fehler": f"Symbol „{wert}“ unbekannt."}
        if key == "farbe" and wert and wert.lower() not in FARBEN and not re.match(r"^#[0-9A-Fa-f]{6}$", wert):
            return {"kurs_md": kurs_md, "vorher": vorher, "nachher": vorher, "fehler": f"Farbe „{wert}“ unbekannt."}
        if key == "kachelbild" and wert and ("/" in wert or "\\" in wert or " " in wert):
            return {"kurs_md": kurs_md, "vorher": vorher, "nachher": vorher, "fehler": f"Bild „{wert}“ unbekannt."}
        kb = _kopfblock(lines, start, ende)
        da = next((j for j in range(start + 1, kb) if (K._RE_ATTR.match(lines[j]) or [None, ""])[1].strip().lower() == key),
                  None)
        if da is not None and wert:
            lines[da] = f"{key}: {wert}"
        elif da is not None:
            del lines[da]
            ende -= 1
        elif wert:
            lines.insert(kb, f"{key}: {wert}")
            ende += 1
    md = _text(lines)
    return {"kurs_md": md, "vorher": vorher, "nachher": abschnitt_kopf(md, nr), "schluessel": schluessel, "fehler": "",
            "hand": hand_nachfuehren(md, hand, [{"schluessel": schluessel}])}


def abschnitt_verschieben(kurs_md, nr, richtung, hand=None):
    """Abschnitt nr um eine Stelle nach oben (-1) oder unten (+1) tauschen; „Allgemeines“ bleibt vorn. Für die
    Handänderung (§8.7): Schlüssel, Kopf vorher und nachher, Kennung des neuen Vorgängers.
    -> {kurs_md, nach: neue Nummer (oder nr, wenn es nicht geht), schluessel, vorher, nachher, vorgaenger, hand: weitere
    Einträge für die übrigen Abschnitte mit Handänderung (hand_nachfuehren)}"""
    lines = (kurs_md or "").splitlines()
    b = _abschnitt_bereiche(lines)
    ziel = nr + (1 if richtung > 0 else -1)
    allg = [i + 1 for i, (s_, _) in enumerate(b) if lines[s_][3:].strip().lower().split(" ·")[0] in ("allgemeines",
                                                                                                     "allgemein", "0")]
    if not (1 <= nr <= len(b) and 1 <= ziel <= len(b)) or nr in allg or ziel in allg:
        return {"kurs_md": kurs_md, "nach": nr}
    if 1 <= nr <= len(b) and 1 <= ziel <= len(b) and einheit_teil(_abschnitt_teil(lines, *b[nr - 1])) != \
            einheit_teil(_abschnitt_teil(lines, *b[ziel - 1])):
        return {"kurs_md": kurs_md, "nach": nr}       # AP13.37 §3: eine Kachel bleibt in ihrer Einheit
    o, u = sorted((nr, ziel))
    (s1, e1), (s2, e2) = b[o - 1], b[u - 1]
    erster, zweiter = lines[s1:e1], lines[s2:e2]
    while erster and not erster[-1].strip():
        erster.pop()
    neu = lines[:s1] + zweiter + ([""] if zweiter and zweiter[-1].strip() else []) + erster + [""] + lines[e2:]
    md = _text(neu)
    schl = abschnitt_schluessel(kurs_md, nr, hand)
    return {"kurs_md": md, "nach": ziel, "schluessel": schl,
            "vorher": abschnitt_kopf(kurs_md, nr), "nachher": abschnitt_kopf(md, ziel), "vorgaenger": _vorgaenger(md, ziel),
            "hand": hand_nachfuehren(md, hand, [{"schluessel": schl}])}


def kurstitel_setzen(kurs_md, steckbrief, titel):
    """Kurstitel: Zeile `# ` der Kursdatei (Vorsatz „Drehbuch v1 · “ und Minuten bleiben) und `kurs.titel` im Steckbrief
    (er gilt in der Sicherung vor der Kursdatei). -> {kurs_md, steckbrief, vorher, fehler}"""
    titel = _zeile_sauber(titel)
    sb = api._steckbrief(steckbrief)
    vorher = str((sb.get("kurs") or {}).get("titel") or "")
    if not titel:
        return {"kurs_md": kurs_md, "steckbrief": steckbrief, "vorher": vorher, "fehler": "Der Titel ist leer."}
    lines = (kurs_md or "").splitlines()
    i = next((i for i, z in enumerate(lines) if z.startswith("# ") or z.startswith("## ")), None)
    if i is not None and lines[i].startswith("# "):
        m = re.match(r"^# ((?:Drehbuch\s*v?\d*\s*·\s*)?)(.*?)((?:\s*·\s*\d+\s*min.*)?)$", lines[i])
        vorher = vorher or m.group(2)
        lines[i] = "# " + m.group(1) + titel + m.group(3)
    elif lines:
        lines.insert(0, "# Drehbuch v1 · " + titel)
    return {"kurs_md": _text(lines) if lines else kurs_md, "steckbrief": angaben_schreiben(sb, {"thema": titel}),
            "vorher": vorher, "fehler": ""}


# ---------------------------------------------------------------- Gliederung im Editor (AP13.30)
# Kachel teilen, Baustein in eine andere Kachel, leere Kachel löschen: nur Zeilen der Kursdatei umstellen. Ein Baustein
# wandert als ganzer Block (Überschrift bis vor den nächsten Baustein, ein Unterabschnitt samt Kindern), seine Zeilen
# bleiben Byte für Byte; einzig Bausteine der betroffenen Abschnitte ohne `id:` bekommen ihre bisherige (aus dem
# Abschnittstitel berechnete) ID als Zeile `id:` wie bei verschiebe und abschnitt_setzen. Die Minuten in den Köpfen der
# betroffenen Abschnitte werden neu gezählt. Für die Handänderung (AP13.11 §9, Schlüssel „abschnitt:…“) liefert jeder
# Schritt je betroffenem Abschnitt {schluessel, vorher, werte: {nachher, nach, bausteine}}; `bausteine` (ids der obersten
# Bausteine) lässt „Erhalten“ bei einer neuen Antwort die Gliederung der Lehrkraft wiederherstellen.
KOPF_UEBERNEHMEN = ("farbe", "website", "teil", "sichtbar ab")


def _gliederung(kurs_md):
    """(vor, abschnitte): vor = Zeilen vor der ersten `## `; je Abschnitt {kopf: Zeilen bis vor den ersten Baustein,
    bloecke: [{b, zeilen, alle}]} mit den obersten Bausteinen (`alle` = der Baustein und seine Kinder, aus dem Parser)."""
    pr = api.pruefe(kurs_md or "")
    lines = pr["kursdatei"].splitlines()
    bs = pr["bausteine"]
    oben = [b for b, _ in _bloecke(pr["kursdatei"], bs)]
    bereiche = _abschnitt_bereiche(lines)
    vor = lines[:bereiche[0][0]] if bereiche else list(lines)
    abschnitte = []
    for s_, e_ in bereiche:
        drin = [b for b in oben if s_ < b["zeile"] - 1 < e_]
        bloecke = []
        for i, b in enumerate(drin):
            a = b["zeile"] - 1
            z = drin[i + 1]["zeile"] - 1 if i + 1 < len(drin) else e_
            bloecke.append({"b": b, "zeilen": lines[a:z], "alle": [x for x in bs if a <= x["zeile"] - 1 < z]})
        abschnitte.append({"kopf": lines[s_:drin[0]["zeile"] - 1 if drin else e_], "bloecke": bloecke})
    return vor, abschnitte


def _gliederung_text(vor, abschnitte):
    out = list(vor)
    for a in abschnitte:
        teil = list(a["kopf"])
        for bl in a["bloecke"]:
            if teil and teil[-1].strip():
                teil.append("")
            teil += bl["zeilen"]
        if out and out[-1].strip():
            out.append("")
        out += teil
    return _text(out)


def _allgemein(a):
    return _falte(a["kopf"][0][3:] if a["kopf"] else "") in _ALLGEMEIN


def _kopf_angaben(a):
    """Angaben `schlüssel: wert` unter der Überschrift eines Abschnitts: [(schlüssel, Zeile)]."""
    out = []
    for z in a["kopf"][1:]:
        m = K._RE_ATTR.match(z)
        if m and not z.startswith(" "):
            out.append((m.group(1).strip().lower(), z))
    return out


def _teil_von(a):
    """Teil (Einheit) eines Abschnitts: Wert von `teil:` im Kopf, „“ für die erste Einheit."""
    return next((z.split(":", 1)[1].strip() for k, z in _kopf_angaben(a) if k == "teil"), "")


def _ids_fest(a):
    """Bausteine des Abschnitts ohne `id:` bekommen ihre jetzige ID als Zeile (sie hängt am Abschnittstitel)."""
    for bl in a["bloecke"]:
        start = bl["b"]["zeile"] - 1
        for x in sorted(bl["alle"], key=lambda x: -x["zeile"]):
            if not x.get("id_explizit"):
                bl["zeilen"].insert(x["zeile"] - start, f"id: {x['id']}")
                x["id_explizit"] = True


def _minuten_zaehlen(a, mit=False):
    """Minuten im Kopf = Summe der Minuten der Bausteine (ohne Zusatzaufgaben); steht weder eine Angabe im Kopf noch an einem Baustein, bleibt
    der Kopf ohne (`mit`: trotzdem schreiben)."""
    m = []
    for bl in a["bloecke"]:
        # Zusatzaufgaben zählen nicht (wie in den Kennzahlen); ein Unterabschnitt zählt mit seinen Kindern, seine eigene
        # Angabe nur, wenn keins eine hat
        xs = [x for x in bl["alle"] if x.get("minuten") is not None and not ist_zusatzaufgabe({}, x)]
        kinder = [x for x in xs if x is not bl["b"]]
        m += [x["minuten"] for x in (kinder or xs)]
    z = a["kopf"][0]
    if not (m or mit or _RE_ZEIT_SUFFIX.search(z)):
        return
    a["kopf"][0] = _RE_ZEIT_SUFFIX.sub("", z).rstrip() + f" · {sum(m)} min"


def _oberste_ids(kurs_md):
    """Je Abschnitt (Nummer der Zeile `## `) die ids seiner obersten Bausteine."""
    return {nr: [bl["b"]["id"] for bl in a["bloecke"]] for nr, a in enumerate(_gliederung(kurs_md)[1], 1)}


def _gliederung_hand(alt_md, alt_nr, md, nr, hand):
    """Eintrag für die Handänderung des Abschnitts nr (vorher Nummer alt_nr in alt_md; None = neu entstanden)."""
    return {"schluessel": abschnitt_schluessel(alt_md, alt_nr, hand) if alt_nr else abschnitt_schluessel(md, nr, hand),
            "vorher": abschnitt_kopf(alt_md, alt_nr) if alt_nr else "",
            # AP13.35 §1.3: ids vor der ersten Änderung; die Frage vor einer neuen Antwort nennt damit, was verschoben ist
            "bausteine_vorher": _oberste_ids(alt_md).get(alt_nr, []) if alt_nr else _oberste_ids(md).get(nr, []),
            "werte": {"nachher": abschnitt_kopf(md, nr), "nach": _vorgaenger(md, nr),
                      "bausteine": _oberste_ids(md).get(nr, [])}}


def hand_nachfuehren(md, hand, eintraege=()):
    """AP13.30: Nach einer Änderung der Lehrkraft an der Gliederung gilt der neue Stand auch für die übrigen
    Abschnitte, die schon eine Handänderung tragen: Kopf, Vorgänger (`nach`) und ids (`bausteine`) wie jetzt in md. Sonst
    fragte eine neue Antwort mit genau dieser Gliederung nach (der Vorgänger der Nachbarkachel hätte sich geändert).
    -> zusätzliche Einträge {schluessel, vorher, werte} für die Handänderung (ohne die Schlüssel aus `eintraege`)"""
    schon = {e["schluessel"] for e in eintraege or ()}
    oben = None
    out = []
    for k, v in sorted((hand or {}).items()):
        if not str(k).startswith("abschnitt:") or k in schon or not v:
            continue
        nr = _abschnitt_finden(md, v)
        if not nr:
            continue
        werte = {"nachher": abschnitt_kopf(md, nr)}
        if "nach" in v:
            werte["nach"] = _vorgaenger(md, nr)
        if "bausteine" in v:
            oben = oben if oben is not None else _oberste_ids(md)
            werte["bausteine"] = oben.get(nr, [])
        if any(v.get(x) != y for x, y in werte.items()):
            out.append({"schluessel": k, "vorher": v.get("vorher", ""), "werte": werte})
    return out


def _mit_nachfuehrung(r, hand):
    if not r.get("fehler"):
        r["hand"] = list(r.get("hand") or []) + hand_nachfuehren(r["kurs_md"], {k: v for k, v in (hand or {}).items()
                                                                                 if k not in (r.get("weg") or [])},
                                                                 r.get("hand") or [])
    return r


def _finde_block(abschnitte, baustein_id):
    for nr, a in enumerate(abschnitte, 1):
        for i, bl in enumerate(a["bloecke"]):
            if bl["b"]["id"] == baustein_id:
                return nr, i
    return None, None


def _gliederung_fehler(kurs_md, schluessel, **werte):
    return {"kurs_md": kurs_md, "hand": [], "weg": [], "fehler": _editor_text(schluessel, **werte)}


def kachel_teilen(kurs_md, baustein_id, titel=None, hand=None):
    """„Hier neue Kachel beginnen“: vor dem Baustein `baustein_id` eine Zeile `## <titel> · <M> min` einfügen; die Bausteine
    ab dort wandern in die neue Kachel. Sie übernimmt farbe, website, teil und sichtbar ab der alten, kein Kachelbild und
    kein Symbol; ohne Titel heißt sie „<alter Titel> (Teil 2)“. Minuten beider Kacheln neu gezählt.
    -> {kurs_md, nr (Nummer der neuen Kachel), hand: [Einträge für die Handänderung], weg: [], fehler}"""
    vor, ab = _gliederung(kurs_md)
    nr, i = _finde_block(ab, baustein_id)
    if nr is None:
        return _gliederung_fehler(kurs_md, "gl_fehlt")
    a = ab[nr - 1]
    if i == 0 or _allgemein(a):
        return _gliederung_fehler(kurs_md, "gl_teilen_nicht")
    alt_titel = _RE_ZEIT_SUFFIX.sub("", a["kopf"][0][3:]).strip()
    titel = _zeile_sauber(titel) or _editor_text("teil_2", titel=alt_titel)
    _ids_fest(a)
    zeit = _RE_ZEIT_SUFFIX.search(a["kopf"][0])
    neu = {"kopf": ["## " + titel] + [z for k, z in _kopf_angaben(a) if k in KOPF_UEBERNEHMEN] + [""],
           "bloecke": a["bloecke"][i:]}
    a["bloecke"] = a["bloecke"][:i]
    _minuten_zaehlen(a)
    _minuten_zaehlen(neu, mit=bool(zeit))
    ab.insert(nr, neu)
    md = _gliederung_text(vor, ab)
    return _mit_nachfuehrung({"kurs_md": md, "nr": nr + 1, "weg": [], "fehler": "",
                              "hand": [_gliederung_hand(kurs_md, nr, md, nr, hand),
                                       _gliederung_hand(kurs_md, None, md, nr + 1, hand)]}, hand)


def baustein_verschieben(kurs_md, baustein_id, nr, hand=None):
    """„In Kachel …“: den Baustein ans Ende der Kachel nr (Nummer der Zeile `## `) setzen; Minuten beider Kacheln neu.
    -> {kurs_md, hand, weg: [], fehler}"""
    vor, ab = _gliederung(kurs_md)
    q, i = _finde_block(ab, baustein_id)
    if q is None:
        return _gliederung_fehler(kurs_md, "gl_fehlt")
    nr = int(nr)
    if not 1 <= nr <= len(ab) or _allgemein(ab[nr - 1]):
        return _gliederung_fehler(kurs_md, "gl_ziel_fehlt")
    if q == nr:
        return {"kurs_md": kurs_md, "hand": [], "weg": [], "fehler": ""}
    if _teil_von(ab[q - 1]) != _teil_von(ab[nr - 1]):        # sonst liefert die Nachlieferung doppelt oder zu wenig
        return _gliederung_fehler(kurs_md, "gl_andere_einheit")
    _ids_fest(ab[q - 1])
    _ids_fest(ab[nr - 1])
    ab[nr - 1]["bloecke"].append(ab[q - 1]["bloecke"].pop(i))
    _minuten_zaehlen(ab[q - 1])
    _minuten_zaehlen(ab[nr - 1])
    md = _gliederung_text(vor, ab)
    return _mit_nachfuehrung({"kurs_md": md, "weg": [], "fehler": "",
                              "hand": [_gliederung_hand(kurs_md, q, md, q, hand),
                                       _gliederung_hand(kurs_md, nr, md, nr, hand)]}, hand)


def kachel_loeschen(kurs_md, nr, hand=None):
    """„Leer – Kachel löschen?“: die Kachel nr ohne Bausteine samt Kopf entfernen; Handänderungen dieses Abschnitts
    fallen weg (`weg`). Kacheln mit Inhalt und „Allgemeines“ bleiben. -> {kurs_md, hand: [], weg, fehler}"""
    vor, ab = _gliederung(kurs_md)
    nr = int(nr)
    if not 1 <= nr <= len(ab):
        return _gliederung_fehler(kurs_md, "gl_ziel_fehlt")
    a = ab[nr - 1]
    rest = [z for z in a["kopf"][1:] if z.strip() and not (K._RE_ATTR.match(z) and not z.startswith(" "))]
    if a["bloecke"] or rest or _allgemein(a):
        return _gliederung_fehler(kurs_md, "gl_nicht_leer")
    if not [x for x in ab if x is not a and not _allgemein(x) and _teil_von(x) == _teil_von(a)]:
        return _gliederung_fehler(kurs_md, "gl_einzige")
    weg = sorted(k for k, v in (hand or {}).items()
                 if str(k).startswith("abschnitt:") and _abschnitt_finden(kurs_md, v or {}) == nr)
    del ab[nr - 1]
    return _mit_nachfuehrung({"kurs_md": _gliederung_text(vor, ab), "hand": [], "weg": weg, "fehler": ""}, hand)


def _gliederung_abweichung(md, v):
    """Weicht die Gliederung in md von der Handänderung v (mit `bausteine`) ab? Abschnitt fehlt, obwohl seine Bausteine
    da sind, oder er hat sie nicht in dieser Reihenfolge."""
    oben = _oberste_ids(md)
    da = {i for ids in oben.values() for i in ids}
    soll = [i for i in v.get("bausteine") or [] if i in da]
    if not soll:
        return False
    nr = _abschnitt_finden(md, v)
    return nr is None or [i for i in oben.get(nr, []) if i in set(soll)] != soll


def _gliederung_erhalten(md, eintraege):
    """„Erhalten“ (AP13.30): die Gliederung der Lehrkraft in der Kursdatei einer neuen Antwort wiederherstellen. Je
    Eintrag {vorher, nachher, nach, bausteine}: fehlt der Abschnitt, entsteht er mit dem Kopf `nachher` hinter `nach`; die
    Bausteine mit diesen ids kommen in dieser Reihenfolge hinein (an die Stelle des ersten, der schon dort steht, sonst
    ans Ende). Bausteine, die die Lehrkraft nicht kennt, bleiben, wo der Chat sie hinschrieb; ein Abschnitt der Antwort,
    der dabei leer wird, fällt weg. Minuten der berührten Abschnitte neu gezählt."""
    vor, ab = _gliederung(md)
    beruehrt, ziele = [], []
    for v in eintraege:
        da = {bl["b"]["id"]: bl for a in ab for bl in a["bloecke"]}
        soll = [i for i in v.get("bausteine") or [] if i in da]
        if not soll:
            continue
        text = _gliederung_text(vor, ab)
        nr = _abschnitt_finden(text, v)
        if nr is None:
            koepfe = _koepfe(text)
            nach = v.get("nach")
            if nach:
                pos = next((k + 1 for k, x in enumerate(koepfe) if abschnitt_kennung(x) == nach), len(ab))
            else:
                pos = 1 if ab and _allgemein(ab[0]) else 0
            ab.insert(pos, {"kopf": (v.get("nachher") or "## " + _editor_text("teil_2", titel="")).splitlines() + [""],
                            "bloecke": []})
            nr = pos + 1
        ziel = ab[nr - 1]
        stelle = next((k for k, bl in enumerate(ziel["bloecke"]) if bl["b"]["id"] in soll), None)
        for a in ab:
            vorher_ = len(a["bloecke"])
            a["bloecke"] = [bl for bl in a["bloecke"] if bl["b"]["id"] not in soll]
            if len(a["bloecke"]) != vorher_ and all(a is not x for x in beruehrt):
                beruehrt.append(a)
        stelle = len(ziel["bloecke"]) if stelle is None else min(stelle, len(ziel["bloecke"]))
        ziel["bloecke"][stelle:stelle] = [da[i] for i in soll]
        if all(ziel is not x for x in beruehrt):
            beruehrt.append(ziel)
        ziele.append(ziel)
    ab = [a for a in ab if a["bloecke"] or all(a is not x for x in beruehrt) or any(a is x for x in ziele)]
    for a in beruehrt:
        if any(a is x for x in ab):
            _minuten_zaehlen(a)
    return _gliederung_text(vor, ab)


def anhaengen(kurs_md, text, teil=None):
    """Antwort als weitere Einheit hinten an die Kursdatei hängen: ihre Abschnitte ab dem ersten `## ` (ein zweites
    „Allgemeines“ fällt weg, wenn die Kursdatei schon eins hat), Kopfzeilen nach vorn, doppelte `id:` mit Endung -2.
    `teil` (AP13, etwa „e2“): jeder angehängte Abschnitt bekommt die Zeile `teil: e2`, damit die Seite nur diese Einheit
    als Nachlieferung bauen kann (Bau mit `delta`, Wiederherstellen mit „zusammenführen“)."""
    pa = antwort(text)
    antwort_md = pa["kursdatei"]
    if not (kurs_md or "").strip():
        return antwort_md
    vorhanden = {b["id"] for b in api.pruefe(kurs_md)["bausteine"]}
    lines = antwort_md.splitlines()
    start = next((i for i, z in enumerate(lines) if z.startswith("## ")), len(lines))
    teil_name, teile, weg = teil, [], False
    hat_allgemein = re.search(r"^## Allgemeines\s*$", kurs_md, re.M) is not None
    for z in lines[start:]:
        if z.startswith("## "):
            weg = hat_allgemein and z.strip() == "## Allgemeines"
        if weg:
            continue
        m = re.match(r"^id:\s*(\S+)\s*$", z)
        if m and m.group(1) in vorhanden:
            n = 2
            while f"{m.group(1)}-{n}" in vorhanden:
                n += 1
            z = f"id: {m.group(1)}-{n}"
            vorhanden.add(z[4:])
        if teil_name and re.match(r"^teil\s*:", z):
            continue                                  # AP13.30: jede teil:-Zeile des Chats weicht der Einheit
        teile.append(z)
        if teil_name and z.startswith("## ") and z.strip() != "## Allgemeines":
            teile.append(f"teil: {teil_name}")
    md = kurs_md.rstrip("\n").splitlines()
    kopf = [z for z in _kopfzeilen(antwort_md) if z not in kurs_md]
    if kopf:
        pos = 1 if md and md[0].startswith("# ") else 0
        md[pos:pos] = kopf
    return _text(md + [""] + teile)


# ---------------------------------------------------------------- Bilder-Stufe und Typen „automatisch“ (AP13.4)
def groesse_text(n):
    """Bytes als „2,4 MB“ oder „160 KB“ (Karte im Schritt Bilder, Rand)."""
    if n >= 1024 * 1024:
        return f"{n / 1024 / 1024:.1f} MB".replace(".", ",")
    return f"{max(1, round(n / 1024))} KB"


def bild_verkleinert(vorher, nachher):
    """Satz an der Karte nach dem Hochladen: „2,4 MB → 160 KB“. Wird die Datei größer (AP13.34 §5), steht dabei, warum:
    der Browser speichert jedes Bild für den Kurs neu, und das kann bei kleinen, schon sparsam gespeicherten Bildern
    mehr Platz brauchen."""
    z = f"{groesse_text(vorher)} → {groesse_text(nachher)}"
    if nachher > vorher and groesse_text(nachher) != groesse_text(vorher):
        z += ". Das Bild wird für den Kurs neu gespeichert; kleine Bilder werden dabei manchmal größer."
    return z


BILDER_MAX = 30          # AP13.5g a2: größte Zahl für `kurs.bilder` als Zahl


def bilder_standard():
    """Bilder-Stufe, die eine neue Einheit vorgewählt bekommt (`standard` in katalog.yaml, seit AP13.12 „keine“)."""
    return next((w["wert"] for w in katalog()["oberflaeche"]["bilder"] if w.get("standard")), "0")


def bilder_rueckfall():
    """Bilder-Stufe für einen Steckbrief ohne (oder mit unbekanntem) `kurs.bilder` (`alt` in katalog.yaml): der Standard
    vor AP13.12, damit bestehende Einheiten ihren Wert behalten."""
    return next((w["wert"] for w in katalog()["oberflaeche"]["bilder"] if w.get("alt")), bilder_standard())


def bilder_stufe(wert):
    """Eintrag der Bilder-Stufe (`kurs.bilder`: 0, 2-3, 4-7, 8+) -> {wert, text, min, max, satz}; seit AP13.5g auch eine
    Zahl von 1 bis 30 (genau so viele, `satz` ist die Zahl); unbekannt = `bilder_rueckfall()`."""
    t = str(wert).strip() if wert is not None else ""
    if re.fullmatch(r"[0-9]{1,2}", t) and 1 <= int(t) <= BILDER_MAX:
        n = int(t)
        return {"wert": str(n), "text": str(n), "min": n, "max": n, "satz": str(n)}
    liste = katalog()["oberflaeche"]["bilder"]
    w = dict(next((w for w in liste if w["wert"] == str(wert)), next(w for w in liste if w["wert"] == bilder_rueckfall())))
    w["satz"] = "keine" if w["max"] == 0 else str(w["min"]) if w["min"] == w["max"] \
        else f"{w['min']} bis {w['max']}" if w["max"] else f"mindestens {w['min']}"
    return w


def bildbeschriftung(wert):
    """Beschriftung im Bild (`kurs.bildbeschriftung`, AP13.5h a8): `woerter` oder `ziffern`; unbekannt oder leer = der
    Standard aus dem Katalog."""
    liste = katalog()["oberflaeche"]["bildbeschriftung"]
    t = str(wert or "").strip().lower()
    return t if any(w["wert"] == t for w in liste) else next(w["wert"] for w in liste if w.get("standard"))


def auto_typen(karten, bevorzugt=None, angaben=None):
    """Typen, die der Text für „Typ frei“ anbietet: alle aus `automatisch.typen`; hat die Einheit mehr als `zusatz_bis`
    Karten vom Typ automatisch, ohne die Zusatztypen (Geschichte, Lesebuch), damit der Text unter der Grenze bleibt.
    Ein bevorzugter Zusatztyp (AP13.5b, `kurs.uebungstypen`) bleibt. AP13.43: dazu die Typen aus `automatisch.bedingt`,
    deren Bedingung gilt (Schwerpunkt in den Angaben oder Muster in einem Auftrag einer eingeschalteten Karte)."""
    a = katalog()["automatisch"]
    n = sum(1 for e in karten if e.get("typ") == AUTO and not e.get("aus"))
    out = [t for t in a["typen"] if not (n > a.get("zusatz_bis", 99) and t in a.get("zusatz", [])
                                         and t not in (bevorzugt or []))]
    schwer = set(_liste((angaben or {}).get("schwerpunkt")))
    auftraege = " ".join(str(e.get("auftrag") or "") for e in karten if not e.get("aus")).lower()
    for t, b in (a.get("bedingt") or {}).items():
        if t not in out and ((b.get("schwerpunkt") and b["schwerpunkt"] in schwer)
                             or (b.get("auftrag") and re.search(b["auftrag"], auftraege))):
            out.append(t)
    return out


def auto_text(typ):
    """AP13.43: Zeile eines Typs in der Liste für „Typ frei“ (feste und bedingte Typen)."""
    a = katalog()["automatisch"]
    return a["typen"].get(typ) or (a.get("bedingt") or {}).get(typ, {}).get("text", "")


# ---------------------------------------------------------------- Kursangaben der Oberfläche
def _liste(v):
    return [str(x) for x in v] if isinstance(v, list) else [str(v)] if v else []


# AP13.24: die Schwerpunkte stehen im Katalog (oberflaeche.schwerpunkt), höchstens zwei je Einheit; `vorschlag` nennt die
# Felder der Richtung, die aus dem Lehrplan vorbelegt sind (nicht die Lehrkraft gewählt hat)
RICHTUNG = {"schwerpunkt": tuple(w["wert"] for w in katalog()["oberflaeche"]["schwerpunkt"]),
            "sprache": ("einfach", "normal", "anspruchsvoll")}
SCHWERPUNKT_MAX = katalog()["zielarten"]["hoechstens"]
VORSCHLAG = ("schwerpunkt", "uebungstypen", "vorlage")


def uebungstypen_wahl():
    """Übungstypen für „Übungen bevorzugt“ (AP13.5b): automatisch.typen ohne Textfeld und Seite."""
    return [t for t in katalog()["automatisch"]["typen"] if t not in ("Textfeld", "Seite")]


def lehrplanbezug(k):
    """`kurs.lehrplanbezug` (AP13.6): „nein“ für Einheiten ohne Lehrplaninhalt, sonst „ja“ (fehlt die Zeile: „ja“, so
    lesen CLI und Steckbriefe von vor AP13.5f weiter wie bisher)."""
    v = k.get("lehrplanbezug", "ja")
    return "nein" if v is False or str(v).strip().lower() in ("nein", "no", "false", "0") else "ja"


def lehrplanbezug_gesetzt(k):
    """Wie `lehrplanbezug`, aber „“, wenn der Steckbrief den Haken nicht nennt und keinen Lehrplan trägt (AP13.5f: die
    Mühle setzt ihn dann nach der letzten Wahl im Browser, Standard aus)."""
    if "lehrplanbezug" not in k and not k.get("lehrplan"):
        return ""
    return lehrplanbezug(k)


def lehrplan_fehlt(k):
    """Haken ausdrücklich gesetzt, aber kein Lernbereich gewählt (Regel lehrplan.fehlt, gelb am Rand)."""
    return "lehrplanbezug" in k and lehrplanbezug(k) == "ja" and \
        not (lehrplan_sauber(k.get("lehrplan")) or {}).get("lernbereiche")


def _texte(v, n=None):
    return [str(x).strip() for x in (v if isinstance(v, list) else []) if str(x).strip()][:n]


def lehrplan_sauber(lp):
    """`kurs.lehrplan` aus dem Picker (AP13.6) auf die bekannten Felder gebracht; ohne Lernbereich None. Die Texte
    bleiben wörtlich (amtliches Werk, Änderungsverbot), nur Leerraum am Rand fällt weg."""
    if not isinstance(lp, dict):
        return None
    lbs = []
    for lb in lp.get("lernbereiche") if isinstance(lp.get("lernbereiche"), list) else []:
        if not isinstance(lb, dict) or not str(lb.get("titel") or "").strip():
            continue
        tbs = [{"titel": str(tb.get("titel") or "").strip(), "ziele": _texte(tb.get("ziele")),
                "rahmen": _texte(tb.get("rahmen"))}
               for tb in (lb.get("teilbereiche") if isinstance(lb.get("teilbereiche"), list) else [])
               if isinstance(tb, dict)]
        lbs.append({"kuerzel": str(lb.get("kuerzel") or "").strip(), "titel": str(lb["titel"]).strip(),
                    "teilbereiche": tbs})
    if not lbs:
        return None
    out = {f: str(lp.get(f) or "").strip() for f in ("quelle", "stand", "schulart", "fach", "zug", "variante",
                                                    "zusatz", "jahrgangsstufe")}
    out["lernbereiche"] = lbs
    return out


FOERDERSCHWERPUNKTE = {"L": "Förderschwerpunkt Lernen", "G": "Förderschwerpunkt geistige Entwicklung"}


def foerderschwerpunkt(lp):
    """AP13.18: Name des Förderschwerpunkts, wenn der gewählte Lehrplan (gesäubert, mit Lernbereich) einer der
    Förderschule ist (Zug L oder G), sonst „“; „Förderschule“ allein im Steckbrief ändert nichts."""
    lp = lp or {}
    if lp.get("schulart") != "foerderschule" or not lp.get("lernbereiche"):
        return ""
    return FOERDERSCHWERPUNKTE.get(lp.get("zug"), "")


# ---------------------------------------------------------------- Lizenz und KI-Hinweis im Kurs (AP13.15)
LIZENZ_NAME_MAX = 80


def lizenzen():
    """Erlaubte Werte für `kurs.lizenz` (oberflaeche.lizenz ohne „Keine Angabe“)."""
    return [w["wert"] for w in katalog()["oberflaeche"]["lizenz"] if w["wert"]]


def lizenz(wert):
    """`kurs.lizenz` -> bekannter Wert oder „“ (fehlt, unbekannt: keine Angabe)."""
    t = str(wert or "").strip()
    return t if t in lizenzen() else ""


def lizenz_name(wert):
    """Name für die Namensnennung: Leerraum gekürzt, höchstens 80 Zeichen."""
    return " ".join(str(wert or "").split())[:LIZENZ_NAME_MAX].strip()


def ki_hinweis(k):
    v = k.get("ki_hinweis")
    return v is True or str(v).strip().lower() in K.JA


def fusszeile(steckbrief):
    """Zeile am Ende jedes Abschnitts (api.baue_voll): KI-Hinweis und Lizenz für Texte und Aufgaben, Wortlaut aus dem
    Katalog; ohne Wahl „“. Feste Farbe auf dem weißen Grund der Kursseite (7,6 : 1), keine Farbe der Familie."""
    k = api._steckbrief(steckbrief).get("kurs") or {}
    o = katalog()["oberflaeche"]
    saetze = [html.escape(o["ki_hinweis"])] if ki_hinweis(k) else []
    w = next((w for w in o["lizenz"] if w["wert"] and w["wert"] == lizenz(k.get("lizenz"))), None)
    if w:
        name = html.escape(lizenz_name(k.get("lizenz_name")), quote=False)
        if w.get("url"):
            link = f'<a href="{html.escape(w["url"])}" rel="license">{html.escape(w["text"])}</a>'
            saetze.append(f"Texte und Aufgaben: {link}, {name}." if name else f"Texte und Aufgaben: {link}.")
        else:
            saetze.append(f"Texte und Aufgaben: © {name}, alle Rechte vorbehalten." if name
                          else "Texte und Aufgaben: alle Rechte vorbehalten.")
    if not saetze:
        return ""
    return f'<p style="color:#4B5563;font-size:.85em;margin:18px 0 0">{" ".join(saetze)}</p>'


def angaben_lesen(steckbrief):
    """Steckbrief (YAML-Text oder dict) -> Werte der Formularfelder."""
    sb = api._steckbrief(steckbrief)
    k = sb.get("kurs") or {}
    design = k.get("design") or {}
    farbe = str(k.get("farbe") or "")
    name = next((n for n, h in K.FARBEN.items() if h.lower() == farbe.lower() and "ue" not in n), "")
    if not name and re.match(r"^#[0-9A-Fa-f]{6}$", farbe):
        name = farbe.upper()            # eigene Farbe (AP13.5): Hex bleibt Hex
    familie, dichte, kasten = api.design_angaben(sb)
    website = str(k.get("website", "nein")).lower()
    heft = K.arbeitsheft_wahl(k)
    bilder = str(k.get("bilder") if k.get("bilder") is not None else bilder_rueckfall())
    return {"thema": k.get("titel", ""), "jahrgang": str(k.get("jahrgangsstufe") or ""),
            "minuten": k.get("umfang_min"), "fach": k.get("fach", ""), "schulart": k.get("schulart", ""),
            "kontext": str(k.get("kontext") or ""), "bilder": bilder,
            "bildbeschriftung": bildbeschriftung(k.get("bildbeschriftung")),
            "lehrplanbezug": lehrplanbezug_gesetzt(k),
            "lehrplan": lehrplan_sauber(k.get("lehrplan")) if lehrplanbezug(k) == "ja" else None,
            "format": k.get("format", "themen"), "start": str(k.get("start") or ""),
            "familie": familie, "dichte": str(dichte or "normal"), "kasten": str(kasten or "familie"),
            "schwerpunkt": _liste(k.get("schwerpunkt"))[:SCHWERPUNKT_MAX], "uebungstypen": _liste(k.get("uebungstypen")),
            "vorschlag": [w for w in _liste(k.get("vorschlag")) if w in VORSCHLAG],
            "sprache": str(k.get("sprache") or "normal"),
            "differenzierung": k.get("differenzierung") is True or str(k.get("differenzierung")).lower() in K.JA,
            "farbe": name,
            "website": "nein" if website in K.NEIN else "textfeld",
            # AP13.47: ohne Feld (Mappen davor) einzeln
            "arbeitsheft": "ja" if heft else "nein",
            "arbeitsheft_bestehen": str((heft or {}).get("bestehen") or ""),
            "abschluss": k.get("abschluss", "keiner"), "portionierung": k.get("portionierung", "keine"),
            "lizenz": lizenz(k.get("lizenz")), "lizenz_name": lizenz_name(k.get("lizenz_name")),
            "ki_hinweis": "ja" if ki_hinweis(k) else "nein"}


def angaben_schreiben(steckbrief, angaben):
    """Formularwerte in den Steckbrief schreiben (andere Schlüssel bleiben). Gibt den YAML-Text zurück."""
    sb = api._steckbrief(steckbrief)
    k = dict(sb.get("kurs") or {})
    a = angaben or {}
    if "thema" in a:
        k["titel"] = str(a["thema"]).strip()
    if "jahrgang" in a:
        k["jahrgangsstufe"] = str(a["jahrgang"]).strip()
    if a.get("minuten") not in (None, ""):
        k["umfang_min"] = int(a["minuten"])
    for feld in ("fach", "schulart", "format", "abschluss", "portionierung", "bilder"):
        if feld in a:
            k[feld] = str(a[feld]).strip()
    if "start" in a:                   # AP13.5d: Kursbeginn für das Format Wochen, JJJJ-MM-TT; leer = Tag des Baus
        wert = str(a["start"] or "").strip()
        if wert and not re.match(r"^\d{4}-\d{2}-\d{2}$", wert):
            raise ValueError(f"start „{wert}“: Datum als JJJJ-MM-TT")
        if wert:
            k["start"] = wert
        else:
            k.pop("start", None)
    if "kontext" in a:                 # AP13.4: „Worum geht es genau?“, nur für den Text für den Chat, nie in der Sicherung
        if str(a["kontext"]).strip():
            k["kontext"] = str(a["kontext"]).strip()
        else:
            k.pop("kontext", None)
    # AP13.6: Haken „Lehrplanbezug“ und der gewählte Lehrplan mit den Texten; wie kurs.kontext nie in der Sicherung
    if "lehrplanbezug" in a:           # AP13.5f: ausdrücklich ja oder nein (Standard der Mühle ist aus)
        k["lehrplanbezug"] = lehrplanbezug({"lehrplanbezug": a["lehrplanbezug"]})
    if "lehrplan" in a:
        lp = lehrplan_sauber(a["lehrplan"])
        if lp:
            k["lehrplan"] = lp
        else:
            k.pop("lehrplan", None)
    if lehrplanbezug(k) == "nein":     # Haken weg löst den Lehrplan
        k.pop("lehrplan", None)
    design = dict(k.get("design") or {})
    if "vorlage" in design:             # bis b6: design.vorlage, beim Schreiben migriert
        design.setdefault("familie", DS.migriere(design.pop("vorlage")))
    if "familie" in a or "vorlage" in a:
        design["familie"] = DS.familie(a.get("familie") or a.get("vorlage"))["name"]   # unbekannt: DesignFehler
    for feld, erlaubt, std in (("dichte", DS.DICHTE, "normal"), ("kasten", DS.KASTEN, "familie")):
        if feld in a:
            wert = str(a[feld] or std).strip().lower()
            if wert not in erlaubt:
                raise DS.DesignFehler(f"{feld} „{wert}“ unbekannt (erlaubt: {', '.join(erlaubt)})")
            if wert == std:
                design.pop(feld, None)
            else:
                design[feld] = wert
    if design or "design" in k:
        k["design"] = design
    # AP13.5b: Felder des dritten Zweigs; wie kurs.kontext nur für den Text für den Chat, nie in der Sicherung
    if "schwerpunkt" in a:
        werte = [w for w in _liste(a["schwerpunkt"]) if w in RICHTUNG["schwerpunkt"]][:SCHWERPUNKT_MAX]
        k["schwerpunkt"] = werte
        if not werte:
            k.pop("schwerpunkt")
    if "uebungstypen" in a:
        werte = [w for w in _liste(a["uebungstypen"]) if w in uebungstypen_wahl()]
        k["uebungstypen"] = werte
        if not werte:
            k.pop("uebungstypen")
    if "vorschlag" in a:               # AP13.24: welche Felder der Lehrplan vorbelegt hat; wie kurs.kontext nie in der Sicherung
        werte = [w for w in _liste(a["vorschlag"]) if w in VORSCHLAG]
        if werte:
            k["vorschlag"] = werte
        else:
            k.pop("vorschlag", None)
    if "sprache" in a:
        wert = str(a["sprache"] or "normal")
        if wert not in RICHTUNG["sprache"]:
            raise ValueError(f"sprache „{wert}“ unbekannt (erlaubt: {', '.join(RICHTUNG['sprache'])})")
        if wert == "normal":
            k.pop("sprache", None)
        else:
            k["sprache"] = wert
    if "differenzierung" in a:         # AP13.14: Schalter „Hilfen und Zusatzaufgaben“; aus = Schlüssel weg
        if a["differenzierung"] is True or str(a["differenzierung"]).lower() in K.JA:
            k["differenzierung"] = True
        else:
            k.pop("differenzierung", None)
    if "farbe" in a:
        wert = str(a["farbe"] or "").strip()
        if not wert:
            k.pop("farbe", None)
        elif re.match(r"^#[0-9A-Fa-f]{6}$", wert):
            k["farbe"] = wert.upper()
        else:
            k["farbe"] = K.FARBEN[wert.lower()]
    if "website" in a:
        k["website"] = "textfeld" if a["website"] == "textfeld" else "nein"
    if "arbeitsheft" in a:             # AP13.47: Übungen als ein Arbeitsheft je Einheit; einzeln = Schlüssel weg
        if a["arbeitsheft"] is True or str(a["arbeitsheft"]).strip().lower() in K.JA:
            k["arbeitsheft"] = "ja"
        else:
            k.pop("arbeitsheft", None)
            k.pop("arbeitsheft_bestehen", None)
    if "arbeitsheft_bestehen" in a:    # Prozent der Punkte für den Abschluss; leer = beim Absenden
        wert = str(a["arbeitsheft_bestehen"] if a["arbeitsheft_bestehen"] is not None else "").strip().rstrip("%").strip()
        if not wert:
            k.pop("arbeitsheft_bestehen", None)
        elif not wert.isdigit() or not 1 <= int(wert) <= 100:
            raise ValueError(f"arbeitsheft_bestehen „{wert}“: Prozent von 1 bis 100")
        elif k.get("arbeitsheft"):
            k["arbeitsheft_bestehen"] = int(wert)
    if "bildbeschriftung" in a:        # AP13.5h a8: wie kurs.kontext nur für den Text für den Chat
        k["bildbeschriftung"] = bildbeschriftung(a["bildbeschriftung"])
    # AP13.15: Lizenz, Name für die Namensnennung und KI-Hinweis; wirken nur in der Sicherung (fusszeile), nie im Text
    # für den Chat; „Keine Angabe“, leerer Name und aus entfernen den Schlüssel
    if "lizenz" in a:
        wert = str(a["lizenz"] or "").strip()
        if wert and wert not in lizenzen():
            raise ValueError(f"lizenz „{wert}“ unbekannt (erlaubt: {', '.join(lizenzen())})")
        if wert:
            k["lizenz"] = wert
        else:
            k.pop("lizenz", None)
    if "lizenz_name" in a:
        wert = lizenz_name(a["lizenz_name"])
        if wert:
            k["lizenz_name"] = wert
        else:
            k.pop("lizenz_name", None)
    if "ki_hinweis" in a:
        if ki_hinweis({"ki_hinweis": a["ki_hinweis"]}):
            k["ki_hinweis"] = "ja"
        else:
            k.pop("ki_hinweis", None)
    if not k.get("kurzname") and k.get("titel"):
        k["kurzname"] = k["titel"][:20].strip()
    sb["kurs"] = k
    return api.steckbrief_schreiben(sb)


# ---------------------------------------------------------------- Sequenz (AP13.40)
# Eine Sequenz ist eine Mappe mit mehreren Einheiten, eine je Stunde: Stunde 1 ist die erste Einheit (Karten ohne
# `einheit`), Stunde n die Einheit „e<n>“ (`teil: e<n>` in der Kursdatei, angehängt über den Weg aus AP13.37). Der erste
# Text für den Chat holt den Sequenzplan; sequenzplan_einsetzen legt daraus die geplanten Karten aller Stunden an.
SEQUENZ_MIN, SEQUENZ_MAX = 2, 20
_SEQ_KOPF = re.compile(r"^#{1,4}\s*Stunde\s+(\d+)\b\s*[:.\-–]?\s*(.*?)\s*$", re.I)
_SEQ_MIN = re.compile(r"\s*·\s*(?:ca\.\s*)?(\d+)\s*min\.?\s*$", re.I)
_SEQ_ZIEL = re.compile(r"^\s*(?:[-*]\s*)?\**Ziel\**\s*:\s*\**\s*(.+?)\s*$", re.I)
_SEQ_PHASE = re.compile(r"^\s*(?:[-*•]|\d+\.)\s+\**([^:|*]+?)\**\s*:\s*(.+?)\s*$")
_SEQ_FREI = {"automatisch", "typ frei", "frei", "mühle entscheidet"}


def stunde_tag(n):
    """Einheit der Stunde n: „“ für Stunde 1 (die erste Einheit), sonst „e<n>“."""
    return "" if int(n) <= 1 else f"e{int(n)}"


def sequenz_stunde(mappe):
    """Stunde der laufenden Einheit in einer Sequenz. -> {n, von, thema, ziel, themen: [Thema je Stunde]} oder None"""
    s = (mappe or {}).get("sequenz")
    if not isinstance(s, dict) or not s.get("stunden"):
        return None
    tag = laufende_einheit(mappe) or ""
    n = int(tag[1:]) if re.fullmatch(r"e\d+", tag) else 1
    stunden = [x if isinstance(x, dict) else {} for x in s["stunden"]]
    if n > len(stunden):                     # Einheit hinter der letzten Stunde (sequenz.js zählt sie als Stunde dazu)
        return None
    st = stunden[n - 1]
    return {"n": n, "von": len(stunden), "thema": str(st.get("thema") or "").strip(),
            "ziel": str(st.get("ziel") or "").strip(), "themen": [str(x.get("thema") or "").strip() for x in stunden]}


def sequenz_offen(mappe):
    """Braucht die Sequenz noch ihren Plan (erster Text für den Chat, Einsetzen der Antwort als Sequenzplan)? Nein,
    sobald er eingesetzt ist; in „Ich steuere“ auch, wenn die Lehrkraft jeder Stunde selbst ein Element gegeben hat."""
    s = (mappe or {}).get("sequenz")
    if not isinstance(s, dict) or not s.get("stunden") or s.get("plan"):
        return False
    if mappe.get("zweig") == "steuer":
        da = {e.get("einheit") or "" for e in mappe.get("bausteine", []) if not e.get("aus")
              and e.get("typ") not in struktur()}
        if all(stunde_tag(i + 1) in da for i in range(len(s["stunden"]))):
            return False
    return True


def sequenz_typen():
    """Typen, die der Sequenzplan nennen darf (die Liste „automatisch“ des Katalogs)."""
    return list(katalog()["automatisch"]["typen"])


def _seq_typ(wert):
    """Typ aus dem Sequenzplan -> Typ des Katalogs (Name oder Formularname, ohne Strukturbausteine), AUTO oder None."""
    w = " ".join(str(wert or "").replace("*", "").replace("`", "").split()).strip(" .")
    if w.lower() in _SEQ_FREI:
        return AUTO
    for t in katalog()["typen"]:
        if t["typ"] in struktur():
            continue
        if w.lower() in (t["typ"].lower(), str(t.get("formularname") or "").lower()):
            return t["typ"]
    return None


def sequenzplan_lesen(text, mappe):
    """Antwort des Chats auf den Sequenzplan-Text lesen und prüfen: Zahl der Stunden, Minuten je Stunde, Typen aus dem
    Katalog, jede Stunde mit mindestens einer Phase. Zeilen außerhalb (Codeblock, Leerzeilen, Sätze) übergeht der Parser.
    Korrekturrunde: Nummern der Stunden fortlaufend ab 1 (doppelt, Lücke, Reihenfolge: Fehler); eine Zeile in einer
    Stunde, die der Parser übergeht (Phasenzeile ohne Doppelpunkt, zweites `Ziel:`), ist ein Hinweis mit Zeile.
    -> {ok, stunden: [{nr, thema, minuten, ziel, phasen: [{phase, typ, titel}]}], meldungen: [{zeile, zitat, text}],
    hinweise: [{zeile, zitat, text}], satz: Korrekturbitte für den Chat („“ ohne Fehler)}"""
    p = katalog()["prompt"]
    pm = p["sequenzplan_meldung"]
    s = (mappe or {}).get("sequenz") or {}
    soll = len(s.get("stunden") or [])
    minuten = ((mappe or {}).get("einheit") or {}).get("minuten")
    stunden, meldungen, hinweise = [], [], []
    for i, roh in enumerate(str(text or "").splitlines(), 1):
        z = roh.rstrip()
        if not z.strip() or z.strip().startswith("```"):
            continue
        m = _SEQ_KOPF.match(z.strip())
        if m:
            rest, ist = m.group(2), None
            mm = _SEQ_MIN.search(rest)
            if mm:
                ist, rest = int(mm.group(1)), rest[:mm.start()]
            stunden.append({"nr": int(m.group(1)), "thema": rest.strip(" *·:-–"), "minuten": ist, "ziel": "",
                            "phasen": [], "zeile": i, "zitat": z.strip()})
            continue
        if not stunden:
            continue
        m = _SEQ_ZIEL.match(z)
        if m and not stunden[-1]["ziel"]:
            stunden[-1]["ziel"] = m.group(1).strip("* ")
            continue
        if m:
            hinweise.append({"zeile": i, "zitat": z.strip(), "text": pm["ziel_zwei"]})
            continue
        m = _SEQ_PHASE.match(z)
        if m:
            typ_roh, _, titel = m.group(2).partition("|")
            typ = _seq_typ(typ_roh)
            if typ is None:
                meldungen.append({"zeile": i, "zitat": z.strip(), "text": pm["typ"].format(
                    typ=typ_roh.strip(), typen=", ".join(sequenz_typen()))})
                continue
            stunden[-1]["phasen"].append({"phase": m.group(1).strip(), "typ": typ,
                                          "titel": " ".join(titel.replace("*", "").split())})
            continue
        hinweise.append({"zeile": i, "zitat": z.strip(), "text": pm["uebergangen"]})
    if not stunden:
        meldungen.insert(0, {"zeile": None, "zitat": "", "text": pm["keine"].format(minuten=minuten or 45)})
    elif soll and len(stunden) != soll:
        meldungen.insert(0, {"zeile": None, "zitat": "", "text": pm["zahl"].format(ist=len(stunden), soll=soll)})
    nummern = [st["nr"] for st in stunden]
    if stunden and nummern != list(range(1, len(stunden) + 1)):
        falsch = next(st for k, st in enumerate(stunden, 1) if st["nr"] != k)
        meldungen.append({"zeile": falsch["zeile"], "zitat": falsch["zitat"], "text": pm["nummer"].format(
            nummern=", ".join(str(n) for n in nummern), bis=len(stunden))})
    for k, st in enumerate(stunden, 1):
        if minuten and st["minuten"] is not None and st["minuten"] != int(minuten):
            meldungen.append({"zeile": st["zeile"], "zitat": st["zitat"], "text": pm["minuten"].format(
                n=k, ist=st["minuten"], soll=minuten)})
        if not st["phasen"]:
            meldungen.append({"zeile": st["zeile"], "zitat": st["zitat"], "text": pm["leer"].format(n=k)})
    satz = ""
    if meldungen:
        teile = [(f"Zeile {m['zeile']} („{m['zitat']}“): " if m["zeile"] else "") + m["text"] for m in meldungen[:5]]
        satz = p["sequenzplan_korrektur"].format(meldungen=". ".join(teile))
    for st in stunden:
        st.pop("zitat", None)
        st.pop("zeile", None)
    return {"ok": not meldungen, "stunden": stunden, "meldungen": meldungen[:5], "hinweise": hinweise[:5], "satz": satz}


def _minuten_verteilen(n, minuten):
    if not n or not minuten:
        return [None] * n
    m = int(minuten)
    return [m // n + (1 if i < m % n else 0) for i in range(n)]


def sequenzplan_einsetzen(mappe, text):
    """Sequenzplan aus der Antwort des Chats in die Mappe: Thema und Ziel je Stunde (ein Thema, das die Lehrkraft
    vorgegeben hat, bleibt), `themen` je Einheit, je Stunde eine Kachel mit dem Thema und je Phase eine geplante Karte
    (Typ, Arbeitstitel, Phase) mit der Einheit der Stunde. In „Ich steuere“ behält eine Stunde, der die Lehrkraft schon
    Elemente gegeben hat, ihren Plan. Eine Antwort mit Fehlern ändert nichts.
    -> {ok, mappe, stunden, meldungen, satz}"""
    r = sequenzplan_lesen(text, mappe)
    if not r["ok"]:
        return {"ok": False, "mappe": mappe, "stunden": len(r["stunden"]), "meldungen": r["meldungen"], "satz": r["satz"],
                "hinweise": r["hinweise"]}
    mappe = copy.deepcopy(mappe)
    s = mappe["sequenz"]
    alt = [x if isinstance(x, dict) else {} for x in s.get("stunden") or []]
    behalten = set()
    if mappe.get("zweig") == "steuer":
        behalten = {e.get("einheit") or "" for e in mappe.get("bausteine", []) if e.get("geplant")}
    neu = []
    for i, st in enumerate(r["stunden"]):
        vorgabe = str((alt[i] if i < len(alt) else {}).get("thema") or "").strip()
        neu.append({"thema": vorgabe or st["thema"] or katalog()["oberflaeche"]["sequenz"]["stunde_n"].format(n=i + 1),
                    "ziel": st["ziel"]})
    s["stunden"], s["plan"] = neu, True
    themen = mappe.setdefault("themen", {})
    for i, st in enumerate(neu):
        themen[f"e{i + 1}"] = st["thema"]
    mappe["bausteine"] = [e for e in mappe.get("bausteine", []) if not e.get("geplant")
                          or (e.get("einheit") or "") in behalten]
    mappe["kacheln"] = [k for k in mappe.get("kacheln") or [] if isinstance(k, dict)
                        and (k.get("einheit") or "") in behalten]
    nr = naechste_nummer(mappe)
    minuten = (mappe.get("einheit") or {}).get("minuten")
    for i, st in enumerate(r["stunden"]):
        tag = stunde_tag(i + 1)
        if tag in behalten:
            continue
        thema = neu[i]["thema"]
        ka = {"titel": thema, "text": "", "aufbau": True}
        if tag:
            ka["einheit"] = tag
        mappe["kacheln"].append(ka)
        for ph, soll in zip(st["phasen"], _minuten_verteilen(len(st["phasen"]), minuten)):
            k = geplant(f"b{nr}", ph["typ"], ph["titel"] or ph["phase"], phase=ph["phase"], soll=soll)
            k["abschnitt"] = thema
            if tag:
                k["einheit"] = tag
            mappe["bausteine"].append(k)
            nr += 1
    stufe = lambda e: int(e["einheit"][1:]) if re.fullmatch(r"e\d+", e.get("einheit") or "") else 1
    mappe["bausteine"].sort(key=stufe)                       # Stunde für Stunde, innerhalb wie bisher
    mappe["kacheln"].sort(key=stufe)
    return {"ok": True, "mappe": mappe, "stunden": len(neu), "meldungen": [], "satz": "", "hinweise": r["hinweise"]}
