"""AP13.24: Zielart der Kompetenzerwartungen im LehrplanPLUS und die Vorbelegung von „Ich gebe die Richtung“ daraus.

    hauptoperator(satz)        -> Operator der Kompetenzerwartung (Verb am Satzanfang, trennbare Verben und feste
                                  Wendungen aufgelöst) oder ""
    operatoren(satz)           -> [Hauptoperator, weitere Operatoren nach „und“, „sowie“, Komma, Semikolon]
    zielart(operator)          -> Schwerpunkt oder „haltung“ („“ = unbekannt)
    fachgruppe(fach, titel)    -> Eintrag aus zielarten.faecher; Fach nach Namensanfang
    fachwoerter(fach, titel)   -> {material, produkt} für die graue Zeile und den Text für den Chat
    vorschlag(lehrplan, fach)  -> {schwerpunkt: [..], uebungstypen: [..], vorlage: "", grund: ""}

Alle Daten stehen in references/katalog.yaml unter `zielarten`; die Regeln leben nur hier (kein JavaScript-Port).
Gleicher Eingang, gleiches Ergebnis: keine Zufälligkeit, keine Sortierung nach Hash.
"""
import re

_WORT = re.compile(r"[^\W\d_]+")
_TAB = {}


def _daten():
    """Katalogblock `zielarten` mit abgeleiteten Tabellen (einmal gebaut)."""
    from . import mappe as M
    z = M.katalog()["zielarten"]
    if _TAB.get("z") is not z:
        ops = {}
        for art, liste in z["operatoren"].items():
            for o in liste:
                ops[o] = art
        _TAB.clear()
        _TAB.update(z=z, ops=ops, partikel=set(z["trennbar"]["partikel"]), grund=set(z["trennbar"]["grundverben"]),
                    titel=[(r["zielart"], re.compile(r["muster"])) for r in z["titel"]],
                    lb=[(g, re.compile(g["lb"])) for g in z["faecher"] if g.get("lb")])
    return _TAB


def zielart(operator):
    """Schwerpunktwert oder „haltung“ zu einem Operator; „“, wenn der Operator unbekannt ist."""
    return _daten()["ops"].get(operator, "")


def _aufloesen(wort, ab):
    """Operator, der mit dem Wort an Stelle `ab` beginnt (Wörter klein), sonst „“: feste Wendung, trennbares Verb mit
    einem Partikel weiter hinten im Satz, sonst das Verb selbst."""
    t = _daten()
    v, satz = wort[ab], " ".join(wort[ab:])
    for verb, wortlaut, op in t["z"]["wendungen"]:
        if v == verb and wortlaut in satz:
            return op
    if v in t["grund"]:
        for p in wort[ab + 1:]:
            if p in t["partikel"] and p + v in t["ops"]:
                return p + v
    return v if v in t["ops"] else ""


def operatoren(satz):
    """Hauptoperator (erstes Wort) und weitere Operatoren: Verben, die nach „und“, „sowie“, Komma oder Semikolon
    kleingeschrieben beginnen. Ohne Treffer am Anfang bleibt der Hauptoperator leer, die weiteren zählen trotzdem."""
    treffer = list(_WORT.finditer(satz or ""))
    wort = [m.group().lower() for m in treffer]
    if not wort:
        return [""]
    out = [_aufloesen(wort, 0)]
    for i in range(1, len(wort)):
        m = treffer[i]
        davor = satz[:m.start()].rstrip()
        if not m.group()[0].islower() or not (wort[i - 1] in ("und", "sowie") or davor.endswith((",", ";"))):
            continue
        op = _aufloesen(wort, i)
        if op:
            out.append(op)
    return out


def hauptoperator(satz):
    return operatoren(satz)[0]


# ---------------------------------------------------------------- Fachgruppen
def _passt(fach, namen):
    f = " ".join(str(fach or "").lower().split())
    # ab drei Zeichen trifft auch die Eingabe, die der Anfang eines Namens ist („Mathe“); Namen mit „/“ nur von vorn
    return any(f.startswith(n.lower()) or len(f) >= 3 and "/" not in n and n.lower().startswith(f) for n in namen)


def fachgruppe(fach, titel=()):
    """Eintrag aus zielarten.faecher: der erste, dessen Namen zum Fach passen (und dessen `lb`-Muster zu einem der Titel
    passt, wenn es eins gibt); der letzte ohne `namen` gilt für alles andere, auch für ein leeres Fach."""
    t = _daten()
    klein = [str(x).lower() for x in titel]
    for g in t["z"]["faecher"]:
        if not g.get("namen"):
            return g
        if _passt(fach, g["namen"]) and (not g.get("lb") or any(re.search(g["lb"], x) for x in klein)):
            return g
    return t["z"]["faecher"][-1]


def fachwoerter(fach, titel=()):
    """{material, produkt} der Fachgruppe (zielarten.woerter)."""
    t = _daten()["z"]
    return t["woerter"][fachgruppe(fach, titel)["wort"]]


def fachwoerter_aus(angaben):
    """Wörter für den Text für den Chat aus den Kursangaben: Fach des gewählten Lehrplans, sonst `fach`; gewählte
    Lernbereiche und Teilbereiche sind die Titel für die Fachgruppen mit `lb` (HSU Raum und Zeit)."""
    a = angaben or {}
    lp = a.get("lehrplan") if a.get("lehrplanbezug") != "nein" else None
    lp = lp if isinstance(lp, dict) else {}
    titel = [x for lb in lp.get("lernbereiche") or [] for x in [lb.get("titel")] + [tb.get("titel") for tb in
             lb.get("teilbereiche") or []] if x]
    return fachwoerter(lp.get("fach") or a.get("fach") or "", titel)


# ---------------------------------------------------------------- Vorschlag
def _titelart(titel, lernbereich):
    """Zielart der ersten Titelregel, die auf den Teilbereichstitel passt, sonst auf den Lernbereichstitel; sonst „“."""
    for text in (titel, lernbereich):
        k = str(text or "").lower()
        for art, muster in _daten()["titel"]:
            if muster.search(k):
                return art
    return ""


def _punkte(erwartungen):
    """Punkte je Schwerpunkt: Hauptoperator 2, jeder weitere Operator 1; Handeln und Unbekanntes zählen nicht."""
    p = {}
    for e in erwartungen:
        for i, op in enumerate(operatoren(e)):
            art = zielart(op)
            if art and art != "haltung":
                p[art] = p.get(art, 0) + (2 if i == 0 else 1)
    return p


def vorschlag(lehrplan, fach=""):
    """Vorschlag für Schwerpunkt, Übungstypen und Art der Einheit aus `kurs.lehrplan` (Lernbereiche mit Teilbereichen
    {titel, ziele, rahmen}). Erwartungen: die angehakten Ziele, ohne Haken alle Erwartungen der gewählten Teilbereiche.
    Je Teilbereich zuerst die Titelregel (nur Fächer mit `titel: true`), sonst die Operatoren; die Punkte aller Teilbereiche
    zählen zusammen. Schwerpunkt = meiste Punkte, ein zweiter ab 60 % davon (höchstens zwei), Gleichstand: der Fachstandard
    zuerst; ohne Punkte der Fachstandard. -> {schwerpunkt, uebungstypen, vorlage, grund}"""
    kat = _daten()["z"]
    lp = lehrplan or {}
    fach = lp.get("fach") or fach or ""
    lbs = [lb for lb in lp.get("lernbereiche") or [] if isinstance(lb, dict)]
    tbs = [(lb, tb) for lb in lbs for tb in lb.get("teilbereiche") or [] if isinstance(tb, dict)]
    gruppe = fachgruppe(fach, [x for lb, tb in tbs for x in (lb.get("titel"), tb.get("titel")) if x])
    mit_zielen = any(tb.get("ziele") for _, tb in tbs)
    punkte, titel_punkte, gesehen = {}, {}, set()
    for lb, tb in tbs:
        erw = [e for e in (tb.get("ziele") if mit_zielen else tb.get("rahmen")) or [] if e and e not in gesehen]
        gesehen.update(erw)
        if not erw:
            continue
        art = _titelart(tb.get("titel"), lb.get("titel")) if gruppe.get("titel") else ""
        teil = {art: 2 * len(erw)} if art else _punkte(erw)
        if art:
            titel_punkte[art] = titel_punkte.get(art, 0) + teil[art]
        for a, p in teil.items():
            punkte[a] = punkte.get(a, 0) + p
    reihenfolge = [w["wert"] for w in _oberflaeche()]
    standard = gruppe["standard"]
    if punkte:
        rang = sorted(punkte, key=lambda a: (-punkte[a], a != standard, reihenfolge.index(a)))
        schwerpunkt = [rang[0]] + [a for a in rang[1:2] if punkte[a] >= 0.6 * punkte[rang[0]]]
    else:
        schwerpunkt = [standard]
    haupt = schwerpunkt[0]
    # der Titel hat den Hauptschwerpunkt bestimmt, wenn er mindestens die Hälfte seiner Punkte stellt
    titel_art = haupt if titel_punkte.get(haupt, 0) * 2 >= punkte.get(haupt, 1) else ""
    grund = "Titel" if titel_art else "Operatoren" if punkte else "Fachstandard"
    vorlage = ""
    for r in kat["vorlagen"]:
        w = r.get("wenn") or {}
        if gruppe["gruppe"] in w.get("gruppen", [gruppe["gruppe"]]) and w.get("titel", titel_art) == titel_art \
                and w.get("schulart", lp.get("schulart")) == lp.get("schulart") \
                and w.get("schwerpunkt", haupt) == haupt:
            vorlage = r["vorlage"]
            break
    ersatz = kat["uebungen_ersatz"] if lp.get("schulart") == "foerderschule" and lp.get("zug") == "G" else {}
    typen = []
    for a in schwerpunkt:
        for t in kat["uebungen"][a][:2]:
            t = ersatz.get(t, t)
            if t not in typen:
                typen.append(t)
    return {"schwerpunkt": schwerpunkt, "uebungstypen": typen, "vorlage": vorlage, "grund": grund}


def _oberflaeche():
    from . import mappe as M
    return M.katalog()["oberflaeche"]["schwerpunkt"]
