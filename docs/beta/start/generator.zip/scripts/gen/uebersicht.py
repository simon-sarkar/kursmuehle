"""Kursübersicht für den Editor (AP13.11 §9): die Kursseite im gewählten Format (Themen, Kacheln, Themen zum Aufklappen,
ein Thema je Reiter, Wochen) mit Kurstitel, Abschnitt 0 (Banner, Überblick), Abschnittstiteln, Kachelbildern, -icons und
Farben, aus dem Ergebnis des Parsers. Die Plattform zeichnet die Kursseite selbst; dies ist ihre Anschauung in der Mühle,
nicht Teil der Sicherung. Stellen, die die Lehrkraft ändern kann, tragen `data-ziel` („kopf“, „abschnitt:n“ mit der
Nummer der Zeile `## ` in der Kursdatei, AP13.30 „weitere“ für die Kachel „Weitere Einheit“), die Pfeile und „Löschen“
an einer leeren Kachel `data-aktion` („hoch“, „runter“, „kachel-loeschen“); editor.js macht sie bedienbar.
Text ist escaped (Namen aus inl() bleiben, wie der Parser sie setzt), Bilder als `@@PLUGINFILE@@/name`, Flächen der
Familie als SVG aus gen/motiv.py."""
import base64
import datetime
import re

from . import html as T
from . import motiv as M

ART = {"label": "Text", "page": "Seite", "hvp": "Übung", "quiz": "Test", "url": "Link", "resource": "Datei",
       "assign": "Aufgabe", "forum": "Forum", "book": "Buch", "choice": "Abstimmung", "glossary": "Glossar",
       "folder": "Verzeichnis", "feedback": "Umfrage", "subsection": "Unterabschnitt"}
MONATE = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November",
          "Dezember"]
ALLGEMEIN = ("allgemeines", "allgemein", "0")

CSS = """
.km-ue { font: 15px/1.45 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; color: #1d2125; }
.km-ue-titel { margin: 0 0 12px; font-size: 1.5rem; font-weight: 700; line-height: 1.25; }
.km-ue [data-ziel] { cursor: pointer; border-radius: 6px; }
.km-ue [data-ziel]:hover { box-shadow: 0 0 0 2px #e8dcc0; }
.km-ue [data-ziel]:focus { outline: none; }
.km-ue [data-ziel]:focus-visible { outline: 2px dashed #8a6416; outline-offset: 3px; }
.km-ue-null { margin-bottom: 14px; }
.km-ue-akt { display: flex; align-items: center; gap: 8px; padding: 6px 0; border-top: 1px solid #eceef1; font-size: 14px; }
.km-ue-sym { flex: none; width: 22px; height: 22px; border-radius: 5px; }
.km-ue-name { flex: 1 1 auto; min-width: 0; overflow-wrap: anywhere; }
.km-ue-art { flex: none; font-size: 12px; color: #5b6475; }
.km-ue-ab { margin: 12px 0; padding: 10px 14px; border: 1px solid #dee2e6; border-radius: 8px; background: #fff; }
.km-ue-kopf { display: flex; align-items: center; gap: 8px; }
.km-ue-abtitel { flex: 1 1 auto; margin: 0 0 6px; font-size: 1.1rem; font-weight: 650; overflow-wrap: break-word;
  hyphens: auto; }
.km-ue-datum { display: block; font-size: 12px; font-weight: 400; color: #5b6475; }
.km-ue-pfeile { display: inline-flex; gap: 2px; }
.km-ue-pfeile button { min-width: 30px; min-height: 30px; border: 1px solid #c3c8d2; border-radius: 6px; background: #fff;
  color: #1d2125; font: inherit; font-size: 14px; cursor: pointer; pointer-events: auto; }
.km-ue-pfeile button:disabled { opacity: 0.35; cursor: default; }
.km-ue-zu .km-ue-abtitel::before { content: "▸ "; }
.km-ue-auf .km-ue-abtitel::before { content: "▾ "; }
.km-ue-kacheln { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 14px; }
.km-ue-kachel { position: relative; overflow: hidden; border: 1px solid #dee2e6; border-radius: 10px; background: #fff; }
.km-ue-bild { display: block; width: 100%; aspect-ratio: 3 / 2; object-fit: cover; }
.km-ue-flaeche { display: flex; align-items: center; justify-content: center; aspect-ratio: 3 / 2; color: #fff;
  font-size: 13px; font-weight: 600; }
.km-ue-kachel .km-ue-abtitel { margin: 0; padding: 8px 10px 4px; font-size: 15px; }
.km-ue-kachel .km-ue-zahl { display: block; padding: 0 10px 8px; font-size: 12px; color: #5b6475; }
.km-ue-kachel .km-ue-pfeile { position: absolute; top: 6px; right: 6px; }
.km-ue-reiter { display: flex; flex-wrap: wrap; gap: 4px; border-bottom: 1px solid #dee2e6; }
.km-ue-tab { padding: 6px 12px; border: 1px solid #dee2e6; border-bottom: 0; border-radius: 8px 8px 0 0; background: #f2f4f7;
  font-weight: 600; font-size: 14px; }
.km-ue-tab.km-ue-aktiv { background: #fff; }
.km-ue-seite { padding: 8px 14px 12px; border: 1px solid #dee2e6; border-top: 0; background: #fff; }
.km-ue-leer { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; margin: 4px 0 2px; font-size: 13px;
  color: #5b6475; }
.km-ue-kachel .km-ue-leer { padding: 0 10px 10px; }
.km-ue-leer button, .km-ue-weitere-k { border: 1px solid #c3c8d2; border-radius: 6px; background: #fff; color: #1d2125;
  font: inherit; cursor: pointer; pointer-events: auto; }
.km-ue-leer button { min-height: 30px; padding: 2px 10px; font-size: 13px; }
.km-ue-weitere { border: 2px dashed #c3c8d2; border-radius: 10px; background: #f8f9fb; color: #3d4452; display: flex;
  align-items: center; justify-content: center; gap: 8px; min-height: 64px; font-weight: 650; }
.km-ue-kacheln .km-ue-weitere { min-height: 150px; flex-direction: column; }
.km-ue-plus { font-size: 26px; line-height: 1; font-weight: 400; }
"""


def _esc(s):
    return str(s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def _woche(start, i):
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", str(start or ""))
    if not m:
        return f"Woche {i + 1}"
    a = datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3))) + datetime.timedelta(days=7 * i)
    b = a + datetime.timedelta(days=6)
    return f"{a.day}. {MONATE[a.month - 1]} – {b.day}. {MONATE[b.month - 1]}"


def _bild(foto):
    """tile_photo des Parsers: (Pfad, Name) einer hochgeladenen Datei oder ((Name, SVG-Bytes), Name) der Fläche."""
    pfad, name = foto
    if isinstance(pfad, tuple):
        return f'<img class="km-ue-bild" alt="" src="data:image/svg+xml;base64,{base64.b64encode(pfad[1]).decode()}">'
    return f'<img class="km-ue-bild" alt="" src="@@PLUGINFILE@@/{_esc(name)}">'


def _akt(item, hue, namen=None):
    art = "Website" if getattr(item, "website", False) else ART.get(item.modname, "Aktivität")
    if getattr(item, "km_typ", None):          # AP13.33 §1.7: Übung als Block im Textfeld mit ihrem Typ, nicht „Text“
        art = (namen or {}).get(item.km_typ, item.km_typ)
    return (f'<div class="km-ue-akt"><span class="km-ue-sym" style="background:{T._tint(hue, 0.35)}"></span>'
            f'<span class="km-ue-name">{_esc(item.name)}</span><span class="km-ue-art">{_esc(art)}</span></div>')


def _pfeile(nr, erster, letzter, quer, texte):
    vor, nach = (texte["links"], texte["rechts"]) if quer else (texte["hoch"], texte["runter"])
    return (f'<span class="km-ue-pfeile"><button type="button" data-aktion="hoch" data-nr="{nr}" aria-label="{_esc(vor)}" '
            f'title="{_esc(vor)}"{" disabled" if erster else ""}>{"←" if quer else "↑"}</button>'
            f'<button type="button" data-aktion="runter" data-nr="{nr}" aria-label="{_esc(nach)}" title="{_esc(nach)}"'
            f'{" disabled" if letzter else ""}>{"→" if quer else "↓"}</button></span>')


def _leer(nr, a, texte, zahl=None):
    """AP13.30: Kachel ohne Bausteine: „Leer – Kachel löschen?“ mit Knopf (nur im Editor bedienbar); nicht an der einzigen
    Kachel einer Einheit (`zahl` = Kacheln je Teil)."""
    if a.get("bausteine") or not texte.get("leer_kachel") or (zahl or {}).get(_teil(a), 2) < 2:
        return ""
    return (f'<p class="km-ue-leer"><span>{_esc(texte["leer_kachel"])}</span><button type="button" '
            f'data-aktion="kachel-loeschen" data-nr="{nr}">{_esc(texte["kachel_loeschen"])}</button></p>')


def _teil(a):
    return str((a.get("angaben") or {}).get("teil") or "")


def _einheit(a):
    """AP13.37 §3: Einheit eines Abschnitts für die Pfeile: `teil:` einer angehängten Einheit der Mühle („e2“ …), sonst
    „“ (erste Einheit; ein `teil:` aus Kursdateien 1.x trennt keine Einheiten)."""
    t = _teil(a)
    return t if re.fullmatch(r"e\d+", t) else ""


def _rand(benannt, i):
    """(erster, letzter) für die Pfeile des Abschnitts i: am Rand der Liste oder seiner Einheit (Pfeile nur innerhalb der
    Einheit, wie „In Kachel …“)."""
    e = _einheit(benannt[i][1])
    return (i == 0 or _einheit(benannt[i - 1][1]) != e, i == len(benannt) - 1 or _einheit(benannt[i + 1][1]) != e)


def _weitere(texte, cls):
    """AP13.30: leere Kachel „Weitere Einheit“ am Ende (öffnet im Editor Thema und Dauer)."""
    if not texte.get("weitere"):
        return ""
    return (f'<div class="{cls} km-ue-weitere" data-ziel="weitere"><span class="km-ue-plus" aria-hidden="true">+</span>'
            f'<span>{_esc(texte["weitere"])}</span></div>')


def abschnitte(k):
    """[(nr, Angaben-dict des Abschnitts, Section)] in der Reihenfolge der Kursdatei; nr zählt die Zeilen `## `."""
    secs = list(k["sections"])
    ab = k["abschnitte"]
    j = 1 if secs and secs[0].name is None and not (ab and ab[0]["titel"].lower() in ALLGEMEIN) else 0
    out = []
    for i, a in enumerate(ab):
        if j + i < len(secs):
            out.append((i + 1, a, secs[j + i]))
    return out


def html(k, sb, fmt, titel, texte, label_html, namen=None):
    """HTML der Kursübersicht. fmt: Wert aus oberflaeche.format (themen, kacheln, komprimiert, einthemen, wochen);
    label_html(item) -> HTML eines Textfelds in Abschnitt 0 (für die Vorschau gesichert); namen: Typ -> Begriff der
    Oberfläche (katalog formularname)."""
    meta = sb.get("kurs") or {}
    hue = k.get("farbe") or T.HUE
    teile = [f'<style>{CSS}</style><div class="km-ue" data-format="{_esc(fmt)}">',
             f'<h1 class="km-ue-titel" data-ziel="kopf">{_esc(titel)}</h1>']
    liste = abschnitte(k)
    null = [s for _, a, s in liste if s.name is None]
    benannt = [(nr, a, s) for nr, a, s in liste if s.name is not None]
    if null:
        teile.append('<div class="km-ue-null">')
        for it in null[0].items:
            teile.append(label_html(it) if it.modname == "label" else _akt(it, hue, namen))
        teile.append("</div>")
    zahl = {}
    for _, a, _s in benannt:
        zahl[_teil(a)] = zahl.get(_teil(a), 0) + 1

    def farbe(a):
        f = (a.get("angaben") or {}).get("farbe", "").strip().strip("'\"")
        from .kursdatei import FARBEN
        return FARBEN.get(f.lower(), f) if f else hue

    def items(s, h):
        return "".join(_akt(it, h, namen) for it in s.items)

    if fmt == "kacheln":
        teile.append('<div class="km-ue-kacheln">')
        for i, (nr, a, s) in enumerate(benannt):
            h = farbe(a)
            bild = _bild(s.tile_photo) if getattr(s, "tile_photo", None) else (
                f'<span class="km-ue-flaeche" style="background:{T._a(h)}">{_esc(s.tile_icon or "")}</span>')
            teile.append(f'<div class="km-ue-kachel" data-ziel="abschnitt:{nr}" data-titel="{_esc(s.name)}">{bild}'
                         f'<p class="km-ue-abtitel">{_esc(s.name)}</p><span class="km-ue-zahl">{len(s.items)} '
                         f'{"Eintrag" if len(s.items) == 1 else "Einträge"}</span>{_leer(nr, a, texte, zahl)}'
                         f'{_pfeile(nr, *_rand(benannt, i), True, texte)}</div>')
        teile.append(_weitere(texte, "km-ue-wk"))
        teile.append("</div>")
    elif fmt == "einthemen":
        teile.append('<div class="km-ue-reiter">')
        for i, (nr, a, s) in enumerate(benannt):
            teile.append(f'<span class="km-ue-tab{" km-ue-aktiv" if i == 0 else ""}" data-ziel="abschnitt:{nr}" '
                         f'data-titel="{_esc(s.name)}">{_esc(s.name)}</span>')
        teile.append("</div>")
        if benannt:
            nr, a, s = benannt[0]
            teile.append(f'<div class="km-ue-seite"><div class="km-ue-kopf"><span class="km-ue-abtitel"></span>'
                         f'{_pfeile(nr, True, _rand(benannt, 0)[1], True, texte)}</div>{items(s, farbe(a))}'
                         f'{_leer(nr, a, texte, zahl)}</div>')
        # die übrigen Reiter zeigt die Plattform erst beim Wechsel; leere bekommen ihre Zeile hier
        teile += [f'<div class="km-ue-seite">{_esc(s.name)}{_leer(nr, a, texte, zahl)}</div>'
                  for nr, a, s in benannt[1:] if not a.get("bausteine")]
        teile.append(_weitere(texte, "km-ue-ab"))
    else:
        for i, (nr, a, s) in enumerate(benannt):
            zu = fmt == "komprimiert"
            datum = f'<span class="km-ue-datum">{_esc(_woche(meta.get("start"), i))}</span>' if fmt == "wochen" else ""
            klasse = " km-ue-auf" if zu and i == 0 else " km-ue-zu" if zu else ""
            teile.append(f'<div class="km-ue-ab{klasse}"><div class="km-ue-kopf"><p class="km-ue-abtitel" '
                         f'data-ziel="abschnitt:{nr}" data-titel="{_esc(s.name)}">{_esc(s.name)}{datum}</p>'
                         f'{_pfeile(nr, *_rand(benannt, i), False, texte)}</div>'
                         f'{items(s, farbe(a)) if not zu or i == 0 else ""}{_leer(nr, a, texte, zahl)}</div>')
        teile.append(_weitere(texte, "km-ue-ab"))
    teile.append("</div>")
    return "".join(teile)
