"""MF5 (Konzept §2.6, Befund 14): ein Feld nur für eine Stelle eines Bausteins im Editor.

Eine Stelle ist ein Absatz (auch Vorspann, Zwischenüberschrift, Merksatz, Hinweis in einer Zeile), eine Liste, eine
Frage mit Antworten (MC), eine Aussage (RF) oder ein Text mit Lücken (Lückentext, `Einsetzen:` im Quiz). `stellen`
liest sie aus dem Text eines Bausteins (dem Text des Felds „Bearbeiten“, ohne `id:`), Zeile für Zeile und vorsichtig:
was es nicht sicher erkennt, bietet es nicht an (dann bleibt der Weg über „Erweitert“). `setzen` schreibt neue Werte
an genau diese Zeilen zurück, ohne Drehbuch-Zeichen in der Oberfläche: Haken, Malpunkte, Pfeile, Sterne und Fettdruck
setzt die Mühle selbst. Danach liest derselbe Parser den Baustein (gen/mappe.py antwort): ein neuer Fehler verhindert
das Übernehmen und kommt als Satz für die Seite zurück (gen/prompt.py seite_satz, MF3). Liest die Mühle die neue Stelle
anders als gemeint (ein Zeichen wie „·“ in einer Antwort), ebenso.
"""
import re
from collections import Counter

from . import kursdatei as K

OK, NOK = K.OK, K.NOK
_RE_KOPF = re.compile(r"^#{3,4}\s+([A-Za-zÄÖÜäöüß]+)\s*:")
_RE_LISTE = re.compile(r"^(\s*)([-*•]|\d+\.)\s+(.*)$")
_RE_PUNKT = re.compile(r"^(\s*)[-*•]\s+(.*)$")
_RE_NUM = re.compile(r"^(\d+\.\s+)(.*)$")
_RE_ANGABE = re.compile(r"^([a-zäöüß][a-zäöüß ]{1,24}):\s*(.*)$")
_RE_LUECKE = re.compile(r"(?<!\*)\*(?!\*)([^*\n]+?)(?<!\*)\*(?!\*)")
_RE_STRICHE = re.compile(r"_{3,}")
_RE_HTML = re.compile(r"<[A-Za-z/!]")
# Inline-Format wie kursdatei.inl: **fett**, ==markiert==, *kursiv*
_RE_FORMAT = re.compile(r"\*\*(?=\S)(.+?)(?<=\S)\*\*|==(?=\S)(.+?)(?<=\S)==|(?<![\w*])\*(?=[^\s*])(.+?)(?<=[^\s*])\*(?![\w*])")
_RE_FORMAT_OHNE_KURSIV = re.compile(r"\*\*(?=\S)(.+?)(?<=\S)\*\*|==(?=\S)(.+?)(?<=\S)==")

PROSA = {"Textfeld", "Seite", "Buch", "Lesebuch", "Aufgabe", "Forum", "Glossar"}
FRAGEN = {"Quiz", "Test", "Lesebuch"}
EINZEILER = {"Vorspann", "Überschrift", "Hervorhebung", "Merke"}
KASTEN = {"Kasten", "Beispiel", "Hinweis", "Text"}


class StelleFehler(Exception):
    """Eingabe, die sich nicht schreiben lässt: Schlüssel in katalog.yaml oberflaeche.stelle und Werte dazu."""
    def __init__(self, schluessel, **werte):
        super().__init__(schluessel)
        self.schluessel, self.werte = schluessel, werte


def _texte():
    from . import mappe as M
    return M.katalog()["oberflaeche"]["stelle"]


def _satz(schluessel, **werte):
    return _texte()[schluessel].format(**werte)


def typ_von(text):
    m = _RE_KOPF.match((text or "").split("\n", 1)[0])
    return m.group(1) if m else None


# ---------------------------------------------------------------- Format ohne Zeichen
def ohne_format(s, kursiv=True):
    """-> (Text ohne `**`, `==`, `*`, [(Zeichen, Inhalt)] in ihrer Folge)."""
    marken = []

    def weg(m):
        if m.group(1) is not None:
            marken.append(("**", m.group(1)))
            return m.group(1)
        if m.group(2) is not None:
            marken.append(("==", m.group(2)))
            return m.group(2)
        marken.append(("*", m.group(3)))
        return m.group(3)
    return (_RE_FORMAT if kursiv else _RE_FORMAT_OHNE_KURSIV).sub(weg, s), marken


def mit_format(neu, marken):
    """Die Formate des alten Texts an dieselben Wörter im neuen setzen, in ihrer Folge; fehlt ein Wort, fällt sein
    Format weg."""
    pos = 0
    for mk, innen in marken:
        i = neu.find(innen, pos)
        if i < 0:
            continue
        neu = neu[:i] + mk + innen + mk + neu[i + len(innen):]
        pos = i + len(innen) + 2 * len(mk)
    return neu


def _einzeilig(s):
    return " ".join(str(s or "").split())


# ---------------------------------------------------------------- Lücken
def luecken_lesen(zeile):
    """Eine Zeile mit `*Lücken*` -> (Zeile mit ___, [{loesung, auch, tipp}]). Sterne ohne Gegenstück bleiben Text."""
    z = K.luecken_sterne(zeile)[0]
    out = []

    def ersetze(m):
        innen = m.group(1)
        kopf, trenner, tipp = innen.partition(":")
        teile = [t.strip() for t in kopf.split("/")]
        out.append({"loesung": teile[0].replace(K.STERN, "*"), "auch": [t.replace(K.STERN, "*") for t in teile[1:] if t],
                    "tipp": tipp.strip().replace(K.STERN, "*") if trenner else None})
        return "___"
    return _RE_LUECKE.sub(ersetze, z).replace(K.STERN, "*"), out


def _luecke_schreiben(l):
    loesung = _einzeilig(l.get("loesung"))
    auch = [_einzeilig(a) for a in re.split(r"[,/]", str(l.get("auch") or "")) if a.strip()] \
        if not isinstance(l.get("auch"), list) else [_einzeilig(a) for a in l["auch"] if str(a).strip()]
    tipp = _einzeilig(l.get("tipp")) if l.get("tipp") is not None else ""
    if not loesung:
        raise StelleFehler("luecke_leer", n=l.get("_n", ""))
    if any(c in x for x in [loesung] + auch for c in "*:/") or "*" in tipp:
        raise StelleFehler("luecke_zeichen", n=l.get("_n", ""))
    return "*" + "/".join([loesung] + auch) + (":" + tipp if tipp else "") + "*"


def _luecken_text(text, luecken):
    """Text mit ___ und die Lösungen darunter -> Zeilen mit `*Lücken*`."""
    stellen = list(_RE_STRICHE.finditer(text))
    if len(stellen) != len(luecken):
        raise StelleFehler("luecken_zahl", text=len(stellen), loesungen=len(luecken))
    if not luecken:
        raise StelleFehler("luecken_keine")
    teile, pos = [], 0
    for n, (m, l) in enumerate(zip(stellen, luecken), 1):
        teile.append(text[pos:m.start()])
        teile.append(_luecke_schreiben(dict(l, _n=n)))
        pos = m.end()
    teile.append(text[pos:])
    return "".join(teile)


# ---------------------------------------------------------------- Stellen lesen
def stellen(text, typ=None):
    """Stellen eines Bausteins (Text wie im Feld „Bearbeiten“). -> [{nr, art, name, zeilen (1-basiert), z (Zeile, an
    der der Parser den Block beginnt), werte, frage (Nummer der Frage im Baustein wie „Fragen und Lösungen“ oder
    None)}]; art: absatz {text}, liste {punkte}, mc {frage, antworten: [{text, richtig}]}, rf {aussage, richtig},
    luecken {aufgabe (oder None), text, luecken: [{loesung, auch, tipp}]}."""
    zeilen = (text or "").split("\n")
    typ = typ or typ_von(text)
    out = []
    if typ == "Lückentext":
        _lueckentext(zeilen, out)
    elif typ in PROSA or typ in FRAGEN:
        _block([(i, zeilen[i]) for i in range(1, len(zeilen))], zeilen, out, typ, "")
    for n, s in enumerate(out, 1):
        s["nr"] = n
    _fragen_zuordnen(text, typ, out)
    return out


def _neu(out, art, name, zeilen, z, werte, **mehr):
    s = {"art": art, "name": name, "zeilen": [i + 1 for i in zeilen], "z": z + 1, "werte": werte, "frage": None}
    s.update(mehr)
    out.append(s)
    return s


def _vorn(zeile, rest):
    voll = zeile.rstrip()
    if rest and voll.endswith(rest):
        return voll[:len(voll) - len(rest)]
    return voll + " " if not rest else None


def _absatz(out, name, i, zeile, rest, kursiv=True):
    vorn = _vorn(zeile, rest)
    if vorn is None or not rest.strip() or _RE_HTML.search(rest):
        return
    anzeige, marken = ohne_format(rest, kursiv)
    _neu(out, "absatz", name, [i], i, {"text": anzeige}, _schreib={"vorn": vorn, "marken": marken, "kursiv": kursiv})


def _block(items, zeilen, out, typ, ein):
    """items: [(Index der Zeile, Inhalt ohne die Einrückung `ein`)]."""
    quiz = typ in ("Quiz", "Test")
    frag = typ in FRAGEN
    prosa = typ in PROSA
    j, n = 0, len(items)
    while j < n:
        i, s = items[j]
        st = s.strip()
        if not st or s.startswith("#") or st.startswith(("<", "|")) or K._RE_HILFE.match(s) or s.startswith(" "):
            j += 1
            continue
        a = _RE_ANGABE.match(st)
        if a and not ein and st[0].islower():
            j += 1
            continue
        num, kern = "", st
        if quiz:
            m = _RE_NUM.match(st)
            if m:
                num, kern = m.group(1), m.group(2)
        d = K._directive(kern)
        if d:
            name, _, rest = d
            if name in EINZEILER and prosa:
                _absatz(out, name, i, zeilen[i], rest)
                j += 1
                continue
            if name in KASTEN:
                k, body = j + 1, []
                while k < n:
                    i2, s2 = items[k]
                    if s2.startswith("  "):
                        body.append((i2, s2[2:]))
                        k += 1
                    elif not s2.strip() and k + 1 < n and items[k + 1][1].startswith("  ") and body:
                        body.append((i2, ""))
                        k += 1
                    else:
                        break
                if prosa and rest and (name == "Text" or (not body and name != "Kasten")):
                    _absatz(out, name, i, zeilen[i], rest)
                if body and prosa:
                    _block(body, zeilen, out, typ, ein + "  ")
                j = k
                continue
            if frag and name == "MC":
                j = _mc(items, j, zeilen, out, num, rest)
                continue
            if frag and name == "RF":
                _rf(out, i, zeilen[i], rest)
                j += 1
                continue
            if frag and name in ("Einsetzen", "Lückentext"):
                j = _einsetzen(items, j, zeilen, out, rest, quiz)
                continue
            if name == "Schritte" and prosa:
                j = _liste(items, j + 1, zeilen, out, i, kopf=True)
                continue
            # andere Teile (Bild, Tabelle, Vergleich, Szene, Seite, Kapitel …): samt Folgezeilen überspringen
            j += 1
            while j < n and items[j][1].strip() and (items[j][1].startswith(" ") or _RE_LISTE.match(items[j][1])
                                                     or name in K.TEXT_DIRS):
                if K._directive(items[j][1].strip()):
                    break
                j += 1
            continue
        if frag and " · " in kern and any(c in kern for c in OK):
            j = _mc(items, j, zeilen, out, num, kern)
            continue
        if frag and kern.endswith("?") and j + 1 < n and _RE_PUNKT.match(items[j + 1][1]):
            k = j + 1
            while k < n and _RE_PUNKT.match(items[k][1]):
                k += 1
            if any(c in items[x][1] for x in range(j + 1, k) for c in OK):
                j = _mc(items, j, zeilen, out, num, kern)
                continue
        if _RE_LISTE.match(s):
            if prosa and not quiz:
                j = _liste(items, j, zeilen, out, None)
            else:
                j += 1
                while j < n and _RE_LISTE.match(items[j][1]):
                    j += 1
            continue
        # Absatz: Zeilen bis zur Leerzeile oder zum nächsten Teil (wie kursdatei.parse_body)
        k, teile = j + 1, [st]
        while k < n:
            s2 = items[k][1]
            if (not s2.strip() or s2.lstrip().startswith(("<", "|", "#")) or _RE_LISTE.match(s2)
                    or (quiz and any(c in s2 for c in OK)) or K._directive(s2.strip()) or s2.startswith(" ")):
                break
            teile.append(s2.strip())
            k += 1
        if prosa and not quiz:
            roh = " ".join(teile)
            if not _RE_HTML.search(roh):
                anzeige, marken = ohne_format(roh)
                _neu(out, "absatz", "Absatz", [x for x, _ in items[j:k]], i, {"text": anzeige},
                     _schreib={"vorn": ein, "marken": marken, "kursiv": True})
        j = k


def _liste(items, j, zeilen, out, kopf_i, kopf=False):
    """Flache Liste ab items[j] (ohne Unterpunkte); mit Unterpunkten keine Stelle. -> nächster Index."""
    n = len(items)
    if j >= n or not _RE_LISTE.match(items[j][1]):
        return j
    basis = _RE_LISTE.match(items[j][1])
    tiefe, k, punkte, flach = len(basis.group(1)), j, [], True
    while k < n:
        m = _RE_LISTE.match(items[k][1])
        if not m:
            break
        if len(m.group(1)) != tiefe:
            flach = False
        punkte.append((items[k][0], m))
        k += 1
    texte = [m.group(3) for _, m in punkte]
    if flach and texte and not any(_RE_HTML.search(t) for t in texte):
        nummern = bool(re.match(r"\d+\.", basis.group(2)))
        anzeige = [ohne_format(t) for t in texte]
        ein = zeilen[punkte[0][0]][:len(zeilen[punkte[0][0]]) - len(items[j][1])] + basis.group(1)
        _neu(out, "liste", "Schritte" if kopf else "Liste", [x for x, _ in punkte], kopf_i if kopf else punkte[0][0],
             {"punkte": [a for a, _ in anzeige]},
             _schreib={"ein": ein, "zeichen": None if nummern else basis.group(2), "marken": [m for _, m in anzeige]})
    return k


def _antwort_lesen(a):
    a = a.strip()
    richtig = bool(a) and a[0] in OK
    if richtig:
        a = a[1:].strip()
    rm = ""
    if " → " in a:
        a, rm = a.split(" → ", 1)
    anzeige, marken = ohne_format(a.strip())
    return {"text": anzeige, "richtig": richtig, "_rm": rm.strip(), "_marken": marken}


def _mc(items, j, zeilen, out, num, rest):
    """MC in einer Zeile (`Frage? · ✔A · B`) oder mit Antworten als Liste darunter. -> nächster Index."""
    i = items[j][0]
    vorn = _vorn(zeilen[i], rest)
    if vorn is None:
        return j + 1
    liste_folgt = j + 1 < len(items) and _RE_PUNKT.match(items[j + 1][1])
    if " · " in rest and (any(c in rest for c in OK) or not liste_folgt):     # ohne Haken: der Fehler „keine richtig“
        frage, teile = K.frage_teilen(rest)
        antworten = [_antwort_lesen(t) for t in teile]
        f_anz, f_marken = ohne_format(frage)
        _neu(out, "mc", "Frage", [i], i, {"frage": f_anz, "antworten": [{"text": a["text"], "richtig": a["richtig"]}
                                                                         for a in antworten]},
             _schreib={"form": "zeile", "vorn": vorn, "marken": f_marken, "antworten": antworten})
        return j + 1
    k, liste = j + 1, []
    while k < len(items):
        m = _RE_PUNKT.match(items[k][1])
        if not m:
            break
        liste.append((items[k][0], m))
        k += 1
    if not liste:
        return j + 1
    antworten = [_antwort_lesen(m.group(2)) for _, m in liste]
    f_anz, f_marken = ohne_format(rest)
    ein = zeilen[liste[0][0]][:len(zeilen[liste[0][0]]) - len(liste[0][1].group(0))] + liste[0][1].group(1)
    _neu(out, "mc", "Frage", [i] + [x for x, _ in liste], i,
         {"frage": f_anz, "antworten": [{"text": a["text"], "richtig": a["richtig"]} for a in antworten]},
         _schreib={"form": "liste", "vorn": vorn, "marken": f_marken, "antworten": antworten, "ein": ein + "- "})
    return k


def _rf(out, i, zeile, rest):
    vorn = _vorn(zeile, rest)
    if vorn is None:
        return
    m = re.search(f"[{OK}{NOK}]", rest)
    aussage = rest[:m.start()].strip() if m else rest.split("→")[0].strip()
    tail = rest[m.end():] if m else (rest[len(rest.split("→")[0]):] if "→" in rest else "")
    anzeige, marken = ohne_format(aussage)
    _neu(out, "rf", "Aussage", [i], i, {"aussage": anzeige, "richtig": bool(m) and rest[m.start()] in OK},
         _schreib={"vorn": vorn, "marken": marken, "tail": tail})


def _einsetzen(items, j, zeilen, out, rest, quiz):
    """`Einsetzen: Auftrag` (oder `Lückentext:`) und die Zeilen mit Lücken darunter. -> nächster Index."""
    i = items[j][0]
    vorn = _vorn(zeilen[i], rest)
    k, folge = j + 1, []
    while k < len(items):
        s2 = items[k][1]
        if not s2.strip() or s2.startswith("#") or K._RE_HILFE.match(s2) \
                or K._directive(re.sub(r"^\d+\.\s+", "", s2.strip()) if quiz else s2.strip()) \
                or (quiz and any(c in s2 for c in OK) and not _RE_PUNKT.match(s2)) or K.RE_RUECKMELDUNG.match(s2.strip()):
            break
        folge.append(items[k])
        k += 1
    if vorn is None or not folge or any(s.startswith(" ") or _RE_HTML.search(s) for _, s in folge):
        return k
    texte, luecken = [], []
    for _, s in folge:
        t, l = luecken_lesen(s.strip())
        texte.append(t)
        luecken += l
    if not luecken:
        return k
    _neu(out, "luecken", "Lücken", [i] + [x for x, _ in folge], i,
         {"aufgabe": ohne_format(rest)[0], "text": "\n".join(texte), "luecken": luecken},
         _schreib={"vorn": vorn, "marken": ohne_format(rest)[1], "folge": [x for x, _ in folge], "zeilen": True})
    return k


def _lueckentext(zeilen, out):
    """Baustein Lückentext: `aufgabe:` als Stelle, jeder Absatz mit Lücken als Stelle."""
    i, n = 1, len(zeilen)
    while i < n:
        s = zeilen[i]
        st = s.strip()
        a = _RE_ANGABE.match(st)
        if a and st[0].islower():
            if a.group(1) == "aufgabe" and a.group(2).strip():
                _absatz(out, "Arbeitsauftrag", i, s, a.group(2).strip())
            i += 1
            continue
        if not st or s.startswith((" ", "#")) or st.startswith(("<", "|")) or K._directive(st) or _RE_LISTE.match(s) \
                or K.RE_RUECKMELDUNG.match(st):
            i += 1
            while i < n and zeilen[i].startswith("  "):          # Inhalt eines Kastens
                i += 1
            continue
        k = i
        while k < n and zeilen[k].strip() and not zeilen[k].startswith((" ", "#")) \
                and not K._directive(zeilen[k].strip()) and not _RE_LISTE.match(zeilen[k]) \
                and not K.RE_RUECKMELDUNG.match(zeilen[k].strip()) and not zeilen[k].lstrip().startswith(("<", "|")):
            k += 1
        roh = " ".join(z.strip() for z in zeilen[i:k])
        t, l = luecken_lesen(roh)
        if l and not _RE_HTML.search(roh):
            _neu(out, "luecken", "Lücken", list(range(i, k)), i, {"aufgabe": None, "text": t, "luecken": l},
                 _schreib={"vorn": "", "folge": list(range(i, k)), "zeilen": False})
        i = k


def _fragen_zuordnen(text, typ, out):
    """Nummer der Frage im Baustein, wie „Fragen und Lösungen“ zählt (gen/prompt.py _fragen_baustein): die Stellen der
    Fragen der Reihe nach über den Fragetext."""
    from . import prompt as P
    try:
        fr = P._fragen_baustein({"typ": typ, "text": text})
    except Exception:                 # Zählen ist Hilfe zum Springen; ohne Nummer bleibt die Stelle erreichbar
        return
    if typ == "Lückentext":
        ziel = next((s for s in out if s["art"] == "luecken"), None)
        if fr and ziel:
            ziel["frage"] = 1
        return
    k = 0
    for s in out:
        if s["art"] not in ("mc", "rf", "luecken"):
            continue
        frage = _einzeilig(s["werte"].get("frage") or s["werte"].get("aussage") or s["werte"].get("aufgabe") or "")
        for x in range(k, min(k + 3, len(fr))):
            f = fr[x]
            if f["frage"] == frage or (s["art"] == "luecken" and f["art"] == "luecken" and f["frage"].startswith(frage)):
                s["frage"] = x + 1
                k = x + 1
                break


def oeffentlich(liste):
    """Stellen ohne die Angaben zum Schreiben (für die Seite)."""
    return [{k: v for k, v in s.items() if not k.startswith("_")} for s in liste]


# ---------------------------------------------------------------- Stellen schreiben
def _schreiben(zeilen, s, w):
    """Neue Zeilen des Bausteins mit den Werten `w` an der Stelle `s`."""
    sch, art = s["_schreib"], s["art"]
    idx = [z - 1 for z in s["zeilen"]]
    neu = list(zeilen)
    if art == "absatz":
        t = _einzeilig(w.get("text"))
        if not t:
            raise StelleFehler("leer")
        ersatz = [sch["vorn"] + mit_format(t, sch["marken"])]
    elif art == "liste":
        punkte = [_einzeilig(p) for p in (w.get("punkte") or []) if _einzeilig(p)]
        if not punkte:
            raise StelleFehler("liste_leer")
        alt = sch["marken"]
        ersatz = [sch["ein"] + (sch["zeichen"] + " " if sch["zeichen"] else f"{n}. ")
                  + mit_format(p, alt[n - 1] if n - 1 < len(alt) else []) for n, p in enumerate(punkte, 1)]
    elif art == "mc":
        frage = _einzeilig(w.get("frage"))
        if not frage:
            raise StelleFehler("frage_leer")
        alt = sch["antworten"]
        antworten = []
        for n, a in enumerate(w.get("antworten") or []):
            t = _einzeilig(a.get("text"))
            if not t:
                continue
            vorher = alt[n] if n < len(alt) else {"_rm": "", "_marken": []}
            antworten.append(("✔" if a.get("richtig") else "") + mit_format(t, vorher["_marken"])
                             + (" → " + vorher["_rm"] if vorher["_rm"] else ""))
        kopf = sch["vorn"] + mit_format(frage, sch["marken"])
        if sch["form"] == "zeile":
            ersatz = [kopf + "".join(" · " + a for a in antworten)]
        else:
            ersatz = [kopf] + [sch["ein"] + a for a in antworten]
    elif art == "rf":
        t = _einzeilig(w.get("aussage"))
        if not t:
            raise StelleFehler("aussage_leer")
        ersatz = [sch["vorn"] + mit_format(t, sch["marken"]) + " " + ("✔" if w.get("richtig") else "✘") + sch["tail"]]
    elif art == "luecken":
        text = str(w.get("text") or "")
        luecken = list(w.get("luecken") or [])
        if sch["zeilen"]:
            zz = [_einzeilig(z) for z in text.split("\n") if _einzeilig(z)]
            voll = _luecken_text("\n".join(zz), luecken).split("\n")
        else:
            voll = [_luecken_text(_einzeilig(text), luecken)]
        if s["werte"].get("aufgabe") is not None:
            aufgabe = _einzeilig(w.get("aufgabe"))
            if not aufgabe:
                raise StelleFehler("aufgabe_leer")
            ersatz = [sch["vorn"] + mit_format(aufgabe, sch.get("marken") or [])] + voll
        else:
            ersatz = voll
    else:
        raise StelleFehler("anders")
    return neu[:idx[0]] + ersatz + neu[idx[-1] + 1:]


def _n(t):
    return ohne_format(_einzeilig(t))[0]


def _vergleich(s):
    """Werte einer Stelle zum Vergleich: Leerraum und Formatzeichen zählen nicht."""
    w = s["werte"]
    if s["art"] == "absatz":
        return ("absatz", _n(w["text"]))
    if s["art"] == "liste":
        return ("liste", tuple(_n(p) for p in w["punkte"]))
    if s["art"] == "mc":
        return ("mc", _n(w["frage"]), tuple((_n(a["text"]), bool(a["richtig"])) for a in w["antworten"]))
    if s["art"] == "rf":
        return ("rf", _n(w["aussage"]), bool(w["richtig"]))
    return ("luecken", _n(w.get("aufgabe") or ""), _RE_STRICHE.sub("___", _einzeilig(w["text"])),
            tuple((_einzeilig(l["loesung"]), tuple(_einzeilig(a) for a in l["auch"]), _einzeilig(l["tipp"] or ""))
                  for l in w["luecken"]))


def _soll(s, w):
    """Wie die Stelle nach dem Schreiben aussehen soll (für den Vergleich nach dem Lesen)."""
    x = {"art": s["art"], "werte": {}}
    if s["art"] == "absatz":
        x["werte"] = {"text": w.get("text")}
    elif s["art"] == "liste":
        x["werte"] = {"punkte": [p for p in (w.get("punkte") or []) if _einzeilig(p)]}
    elif s["art"] == "mc":
        x["werte"] = {"frage": w.get("frage"), "antworten": [a for a in (w.get("antworten") or []) if _einzeilig(a.get("text"))]}
    elif s["art"] == "rf":
        x["werte"] = {"aussage": w.get("aussage"), "richtig": w.get("richtig")}
    else:
        luecken = []
        for l in w.get("luecken") or []:
            auch = l.get("auch")
            auch = [a for a in (auch if isinstance(auch, list) else re.split(r"[,/]", str(auch or ""))) if str(a).strip()]
            luecken.append({"loesung": l.get("loesung"), "auch": auch, "tipp": l.get("tipp") if _einzeilig(l.get("tipp")) else None})
        text = str(w.get("text") or "")
        text = "\n".join(_einzeilig(z) for z in text.split("\n") if _einzeilig(z)) if s["_schreib"]["zeilen"] \
            else _einzeilig(text)
        x["werte"] = {"aufgabe": w.get("aufgabe") if s["werte"].get("aufgabe") is not None else None, "text": text,
                      "luecken": luecken}
    return _vergleich(x)


def _fehler(text):
    from . import mappe as M
    pa = M.antwort(text)
    return [d for d in pa["diagnosen"] if d["stufe"] == "fehler"], pa


def setzen(mappe, text, id, nr, werte):
    """Neue Werte an Stelle `nr` des Bausteins (Text wie im Feld „Bearbeiten“). Verhindert das Übernehmen ein neuer
    Fehler des Parsers, eine Stelle, die die Mühle danach anders liest, oder eine Eingabe, die sich nicht schreiben lässt,
    kommt ein Satz für die Seite zurück (Fehler, die der Baustein schon vorher hatte, halten nicht auf).
    -> {ok, text, unveraendert, meldungen: [Satz]}"""
    from . import prompt as P
    typ = typ_von(text)
    alle = stellen(text, typ)
    s = next((x for x in alle if x["nr"] == nr), None)
    if s is None:
        return {"ok": False, "text": text, "unveraendert": False, "meldungen": [_satz("weg")]}
    zeilen = (text or "").split("\n")
    try:
        if _soll(s, werte) == _vergleich(s):
            return {"ok": True, "text": text, "unveraendert": True, "meldungen": []}
        neu = "\n".join(_schreiben(zeilen, s, werte))
    except StelleFehler as e:
        return {"ok": False, "text": text, "unveraendert": False, "meldungen": [_satz(e.schluessel, **e.werte)]}
    vorher = Counter(d["text"] for d in _fehler(text)[0])
    nachher, pa = _fehler(neu)
    neue = []
    for d in nachher:
        if vorher[d["text"]] > 0:
            vorher[d["text"]] -= 1
        else:
            neue.append(d)
    if neue or not pa["bausteine"]:
        saetze = []
        for d in neue:
            x = P.seite_satz(d, True)
            if x not in saetze:
                saetze.append(x)
        return {"ok": False, "text": text, "unveraendert": False, "meldungen": saetze or [_satz("anders")]}
    danach = next((x for x in stellen(neu, typ) if x["nr"] == nr), None)
    if danach is None or danach["art"] != s["art"] or _vergleich(danach) != _soll(s, werte):
        return {"ok": False, "text": text, "unveraendert": False, "meldungen": [_satz("anders")]}
    return {"ok": True, "text": neu, "unveraendert": False, "meldungen": []}
