"""Motive, Bannerfläche und Begleiter der Designfamilien (AP13.5e §1, §2, §4). Alles ist SVG als Text, ohne Verläufe,
ohne filter, ohne Text im Motiv; Zufall nur aus einem festen Startwert (gleiche Ausgabe in CPython und Pyodide).

    motiv(name, breite, hoehe, farbe, zweitfarbe, saat=0) -> SVG: Fläche `farbe`, Motiv in `zweitfarbe` (unter 3 KB)
    banner_svg(D, titel, hue, mit_bild=False)    -> (SVG der Bannerfläche mit Titel in der Titelschrift, Kante in %)
    bild_svg(D, hue, breite, hoehe, saat)        -> Kursbild oder Kachelbild: dieselbe Fläche ohne Text
    h2_stil(D, hue) / kasten_stil(D, hue)        -> (Inline-CSS, [(Farbe, Deckung) unter Text]) für Überschrift und Kasten
    begleiter(name, farbe)                       -> SVG 28 × 28, einfarbig
    uri(svg)                                     -> data:image/svg+xml,… für src="…" und url(&quot;…&quot;)

D ist der Tokensatz aus gen/design.py; welche Stelle ein Motiv trägt, steht in familien.yaml unter `motiv`.
"""
import html as _html
import math
import re
from urllib.parse import quote

from . import design as DS
from . import schrift as S

MOTIVE, BEGLEITER = DS.MOTIVE, DS.BEGLEITER
MAX_BYTES = 3072
DECKUNG_MAX = 0.12          # höchste Deckung eines Musters unter Text (sonst muss die Fläche selbst 4,5:1 tragen)
BANNER_B, BANNER_H, BILD_H, KANTE = 1000, 250, 170, 30


class _Zufall:
    """Lineare Kongruenz; reicht für Zittern an Kanten und Strichen."""

    def __init__(self, saat):
        self.x = (int(saat) * 2654435761 + 12345) & 0x7FFFFFFF

    def __call__(self, a=0.0, b=1.0):
        self.x = (1103515245 * self.x + 12345) & 0x7FFFFFFF
        return a + (b - a) * self.x / 0x7FFFFFFF


def _n(v):
    s = f"{v:.1f}".rstrip("0").rstrip(".")
    return "0" if s == "-0" else s


def _pfad(punkte, zu=True):
    return "M" + " ".join(f"{_n(x)},{_n(y)}" for x, y in punkte) + ("Z" if zu else "")


def _rund(punkte):
    """Geschlossene, weiche Kurve durch die Mitten der Kanten (quadratische Bögen)."""
    m = [((a[0] + b[0]) / 2, (a[1] + b[1]) / 2) for a, b in zip(punkte, punkte[1:] + punkte[:1])]
    d = f"M{_n(m[-1][0])},{_n(m[-1][1])}"
    for p, q in zip(punkte, m):
        d += f"Q{_n(p[0])},{_n(p[1])} {_n(q[0])},{_n(q[1])}"
    return d + "Z"


def _svg(breite, hoehe, inhalt, extra="", masse=True):
    """SVG-Wurzel; masse=False ohne width und height, damit Media Queries im SVG die angezeigte Breite sehen."""
    groesse = f" width='{_n(breite)}' height='{_n(hoehe)}'" if masse else ""
    return (f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {_n(breite)} {_n(hoehe)}'{groesse}{extra}>"
            f"{inhalt}</svg>")


def uri(svg):
    """data:-Adresse für src="…" und url(&quot;…&quot;): %, #, ", < und > kodiert, Nicht-ASCII als UTF-8, sonst wie es ist.
    < und > müssen kodiert sein: der Filter im Lesebuch und in H5P liest ein rohes < als Tag-Anfang (AP13.29 §1)."""
    out = svg.replace("%", "%25").replace("#", "%23").replace('"', "%22").replace("<", "%3C").replace(">", "%3E")
    return "data:image/svg+xml," + "".join(c if ord(c) < 128 else quote(c) for c in out)


def css_url(svg):
    return f"url(&quot;{uri(svg)}&quot;)"


# ---------------------------------------------------------------- die Motive (Flächenfüllung)
def _blob(z, cx, cy, r, n=9, zittern=0.18):
    return [(cx + r * (1 + z(-zittern, zittern)) * math.cos(2 * math.pi * i / n),
             cy + r * (1 + z(-zittern, zittern)) * 0.8 * math.sin(2 * math.pi * i / n)) for i in range(n)]


def _blatt(cx, cy, laenge, winkel):
    """Blattform (zwei Bögen) um (cx, cy) gedreht, ohne transform."""
    w = math.radians(winkel)

    def p(x, y):
        return cx + x * math.cos(w) - y * math.sin(w), cy + x * math.sin(w) + y * math.cos(w)
    a, b, o, u = p(-laenge / 2, 0), p(laenge / 2, 0), p(0, -laenge * 0.32), p(0, laenge * 0.32)
    return (f"M{_n(a[0])},{_n(a[1])}Q{_n(o[0])},{_n(o[1])} {_n(b[0])},{_n(b[1])}"
            f"Q{_n(u[0])},{_n(u[1])} {_n(a[0])},{_n(a[1])}Z")


def _strich(z, x0, x1, y, dicke, neigung=0.0, schritt=46):
    """Rauer Strich als Polygon: Ober- und Unterkante zittern, die Enden laufen schmal aus."""
    n = max(3, int((x1 - x0) / schritt))
    oben, unten = [], []
    for i in range(n + 1):
        x = x0 + (x1 - x0) * i / n
        yy = y + neigung * (x - x0)
        d = dicke * (0.35 if i in (0, n) else 1) / 2
        oben.append((x, yy - d + z(-1.6, 1.6)))
        unten.append((x, yy + d + z(-1.6, 1.6)))
    return _pfad(oben + unten[::-1])


def _kreide(z, x0, x1, y, c, neigung=0.0, lagen=3):
    """Kreidestrich: mehrere dünne, unterbrochene Linien übereinander (raue Kante, Lücken wie auf der Tafel)."""
    out = []
    for _ in range(lagen):
        n, off = max(2, int((x1 - x0) / 70)), z(-3, 3)
        pts = [(x0 + (x1 - x0) * i / n, y + neigung * (x1 - x0) * i / n + off + z(-1.5, 1.5)) for i in range(n + 1)]
        strich = " ".join(_n(z(14, 60)) if j % 2 == 0 else _n(z(2, 6)) for j in range(6))
        out.append(f"<path d='{_pfad(pts, False)}' fill='none' stroke='{c}' stroke-width='{_n(z(2.5, 4.5))}' "
                   f"stroke-linecap='round' stroke-dasharray='{strich}' opacity='{_n(z(.6, .95))}'/>")
    return "".join(out)


def _pinsel(z, x0, x1, y, dicke):
    """Breiter Pinselstrich: leicht unruhige Kanten, Borstenspitzen an beiden Enden."""
    oben = [(x0 + (x1 - x0) * i / 8, y - dicke / 2 + z(-dicke * 0.06, dicke * 0.06)) for i in range(1, 8)]
    unten = [(x0 + (x1 - x0) * i / 8, y + dicke / 2 + z(-dicke * 0.06, dicke * 0.06)) for i in range(7, 0, -1)]
    rechts = [(x1 - z(0, dicke * 0.22) * (k % 2) - z(0, 4), y - dicke / 2 + dicke * k / 7) for k in range(8)]
    links = [(x0 + z(0, dicke * 0.18) * (k % 2) + z(0, 4), y + dicke / 2 - dicke * k / 7) for k in range(8)]
    return _pfad(oben + rechts + unten + links)


def _elemente(name, w, h, c, z, c2=None):
    """Formen des Motivs in der Fläche w × h, Farbe c; Titel steht links, das Motiv hält die linken 55 % frei,
    außer an der Kante (Strich, Linie, Riss)."""
    e = []
    if name == "kreide":
        e.append(_kreide(z, w * 0.04, w * 0.46, h * 0.86, c, -0.01))
        for i in range(5):
            x = w * (0.7 + 0.045 * i)
            e.append(_kreide(z, x, x + w * 0.05, h * 0.62, c, -2.2, lagen=2))
        e.append(f"<circle cx='{_n(w * 0.86)}' cy='{_n(h * 0.3)}' r='{_n(h * 0.14)}' fill='none' stroke='{c2 or c}' "
                 f"stroke-width='4' stroke-linecap='round' stroke-dasharray='40 7 22 5 60' opacity='.85'/>")
    elif name == "aquarell":
        b1 = _rund(_blob(z, w * 0.8, h * 0.5, h * 0.55))
        e.append(f"<path d='{b1}' fill='{c}' opacity='.4'/>")
        e.append(f"<path d='{_rund(_blob(z, w * 0.9, h * 0.66, h * 0.42))}' fill='{c2 or c}' opacity='.38'/>")
        e.append(f"<path d='{_rund(_blob(z, w * 0.73, h * 0.62, h * 0.3))}' fill='{c}' opacity='.25'/>")
        e.append(f"<path d='{b1}' fill='none' stroke='#fff' stroke-width='5' opacity='.6'/>")
        e.append(f"<path d='{_blatt(w * 0.66, h * 0.3, h * 0.36, -35)}' fill='{c}' opacity='.8'/>")
        e.append(f"<path d='{_blatt(w * 0.72, h * 0.2, h * 0.26, 20)}' fill='{c2 or c}' opacity='.75'/>")
    elif name == "pinsel":
        e.append(f"<path d='{_pinsel(z, w * 0.66, w * 0.97, h * 0.3, h * 0.2)}' fill='{c}'/>")
        e.append(f"<path d='{_pinsel(z, w * 0.74, w * 0.95, h * 0.72, h * 0.14)}' fill='{c}' opacity='.75'/>")
    elif name == "punkte":
        for ecke_x, ecke_y, sx, sy in ((0, h, 1, -1), (w, 0, -1, 1)):
            for i in range(4):
                for j in range(4 - i):
                    e.append(f"<circle cx='{_n(ecke_x + sx * (14 + 18 * i))}' cy='{_n(ecke_y + sy * (14 + 18 * j))}' "
                             f"r='3' fill='{c}' opacity='.5'/>")
        e.append(f"<circle cx='{_n(w * 0.76)}' cy='{_n(h * 0.56)}' r='{_n(h * 0.4)}' fill='{c}' opacity='.28'/>")
        e.append(f"<circle cx='{_n(w * 0.66)}' cy='{_n(h * 0.78)}' r='{_n(h * 0.24)}' fill='#fff' opacity='.22'/>")
    elif name == "papier":
        rand = [(w * 0.7 + z(-10, 10), y) for y in range(0, int(h) + 1, 14)]
        e.append(f"<path d='{_pfad([(0, 0)] + [(x + 10, y + 8) for x, y in rand] + [(0, h)])}' fill='#000' "
                 f"opacity='.12'/>")
        e.append(f"<path d='{_pfad([(0, 0)] + rand + [(0, h)])}' fill='{c}'/>")
        e.append(f"<path d='{_blatt(w * 0.86, h * 0.38, h * 0.4, -50)}' fill='{c}' opacity='.5'/>")
    elif name == "schraeg":
        e.append(f"<path d='{_pfad([(w * 0.7, 0), (w, 0), (w, h * 0.46), (w * 0.62, h * 0.46)])}' fill='{c}'/>")
        e.append(f"<path d='{_pfad([(w * 0.64, 0), (w * 0.665, 0), (w * 0.585, h * 0.46), (w * 0.56, h * 0.46)])}' "
                 f"fill='{c}'/>")
    elif name == "linie":
        for y, d in ((14, 3), (22, 1), (h - 22, 1), (h - 14, 3)):
            e.append(f"<rect x='{_n(w * 0.04)}' y='{_n(y - d / 2)}' width='{_n(w * 0.92)}' height='{d}' fill='{c}' "
                     f"opacity='.8'/>")
        for y in (18, h - 18):
            e.append(f"<path d='{_pfad([(w / 2 - 9, y), (w / 2, y - 7), (w / 2 + 9, y), (w / 2, y + 7)])}' "
                     f"fill='{c}'/>")
    elif name == "raster":
        e.append(f"<defs><pattern id='m' width='8' height='8' patternUnits='userSpaceOnUse'><path d='M8,0V8H0' "
                 f"fill='none' stroke='{c}' stroke-width='.5'/></pattern><pattern id='g' width='40' height='40' "
                 f"patternUnits='userSpaceOnUse'><path d='M40,0V40H0' fill='none' stroke='{c}' stroke-width='1'/>"
                 f"</pattern></defs><rect width='{_n(w)}' height='{_n(h)}' fill='url(#m)' opacity='.5'/>"
                 f"<rect width='{_n(w)}' height='{_n(h)}' fill='url(#g)' opacity='.7'/>")
    return "".join(e)


def motiv(name, breite, hoehe, farbe, zweitfarbe, saat=0, drittfarbe=None):
    """Das Motiv als SVG: Fläche in `farbe` (None = durchsichtig), Formen in `zweitfarbe` (Aquarell und Kreide auch in
    `drittfarbe`); `keins` -> ""."""
    if name not in MOTIVE:
        raise ValueError(f"Motiv „{name}“ unbekannt (erlaubt: {', '.join(MOTIVE)})")
    if name == "keins":
        return ""
    grund = f"<rect width='{_n(breite)}' height='{_n(hoehe)}' fill='{farbe}'/>" if farbe else ""
    return _svg(breite, hoehe, grund + _elemente(name, breite, hoehe, zweitfarbe, _Zufall(saat), drittfarbe),
                " preserveAspectRatio='none'")


# ---------------------------------------------------------------- Farben der Fläche
def farben(D, hue):
    """(Fläche, Motivfarbe, Titelfarbe, zweite Motivfarbe) der Bannerfläche: Kreide auf dunklem Grund, Aquarell auf
    hellem Papier, Papier mit hellem Blatt (Titel in der Randfarbe der Familie), sonst Akzentfläche mit Zweitfarbe oder
    Weiß."""
    name = D["motiv"]["name"]
    z = DS.zweitfarbe(D, hue)
    if name == "kreide":
        grund = D["flaeche"] if D["dunkel"] else DS.mische("#000000", hue, 0.55)
        return grund, "#F4F1E8", D["ink"] if D["dunkel"] else DS.auf_akzent(D, grund), hue
    if name == "aquarell":
        return DS.pastell(hue, 0.95), hue, D["ink"], DS.drehe(hue, 150)
    if name == "papier":
        return hue, D["flaeche_alt"], D["line_card"], None
    if name == "linie":
        return hue, DS.auf_akzent(D, hue), DS.auf_akzent(D, hue), None
    return hue, z or "#ffffff", DS.auf_akzent(D, hue), None


def _titeltext(titel):
    """Titel aus dem Kurs-HTML (inl) als reiner Text für das SVG."""
    return _html.unescape(re.sub(r"<[^>]+>", "", titel or "")).strip()


def _xml(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# Satz des Titels je Motiv: Lage (oben, mitte = vertikal mittig, unten), zentriert, Größen in Einheiten von 1000,
# Breite als Anteil, Drehung in Grad; dazu die Größen für schmale Banner (Handy, unter 600 px)
SATZ = {
    "schraeg": {"lage": "unten", "groessen": (112, 104, 96, 88, 80, 72, 64, 56), "breite": 0.86, "schmal": 0.84,
                "hoehe": 300},
    "linie": {"lage": "mitte", "zentriert": True, "breite": 0.74, "hoehe": 230},
    "punkte": {"lage": "oben", "groessen": (56, 50, 44, 40, 36), "breite": 0.6, "hoehe": 210},
    "aquarell": {"lage": "oben", "breite": 0.56, "hoehe": 260},
    "pinsel": {"drehung": -3, "hoehe": 240},
    "papier": {"breite": 0.6, "schmal": 0.62},
    "kreide": {"hoehe": 230},
}
GROESSEN = (64, 58, 52, 46, 40, 36, 32)
SCHMAL_FAKTOR = 1.6


def _setze(datei, text, max_b, groessen, max_h):
    """Größe und Zeilen des Titels: die größte Größe aus `groessen`, bei der der Text in höchstens drei Zeilen und
    in die Höhe passt."""
    for g in groessen:
        for hoechstens in (1, 2, 3):
            z = S.zeilen(datei, text, g, max_b, hoechstens)
            if z and g + g * 1.12 * (len(z) - 1) <= max_h:
                return g, z
    g = groessen[-1] * 0.8
    return g, S.zeilen(datei, text, g, max_b * 1.3, 5) or [text]


def _titel(D, m, text, farbe, mfarbe, w, innen, kante, schmal):
    """Titel als SVG-Gruppe (Kasten, Text, Linie) für breite oder schmale Banner."""
    satz = SATZ.get(m["name"], {})
    datei = D["schrift_datei"]
    anordnung = D["formen"]["titel"]
    mitte = satz.get("zentriert", False)
    kasten = anordnung in ("ueberlagert", "vorangestellt")
    rand_x = 40 if schmal else 56
    if schmal:
        max_b = w * satz.get("schmal", 0.86) - (48 if kasten else 0)
        groessen = tuple(round(g * SCHMAL_FAKTOR) for g in satz.get("groessen", GROESSEN))
    else:
        max_b = w * satz.get("breite", 0.56) - (48 if kasten else 0)
        groessen = satz.get("groessen", GROESSEN)
    lage = satz.get("lage", "mitte") if not schmal or satz.get("lage") == "unten" else "mitte"
    max_h = innen * (0.42 if lage == "unten" else 0.7) - (40 if kasten else 0)
    g, zeilen = _setze(datei, text, max_b, groessen, max_h)
    lh = g * 1.12
    block_h = g + lh * (len(zeilen) - 1)
    rand_y = 28 + (20 if kasten else 0)
    oben = kante + {"oben": rand_y, "unten": innen - block_h - rand_y,
                    "mitte": (innen - block_h) / 2}[lage] + g * 0.8
    fam = f"'{S.name(datei)}', " if datei else ""
    stack = D["schrift_kopf"] or "system-ui, sans-serif"
    bt = max(S.breite(datei, z_, g) for z_ in zeilen)
    teile = []
    if kasten:      # Titel im Kasten; beim Pinsel ist der Kasten ein heller Pinselstrich
        y0, hk = oben - g * 0.8 - 20, block_h + 40
        if m["name"] == "pinsel":
            teile.append(f"<path d='{_pinsel(_Zufall(5), rand_x - 34, rand_x + bt + 40, y0 + hk / 2, hk)}' "
                         f"fill='{D['flaeche']}'/>")
        else:
            rand = f" stroke='{mfarbe}' stroke-width='2'" if m["name"] == "aquarell" else ""
            teile.append(f"<rect x='{rand_x - 24}' y='{_n(y0)}' width='{_n(bt + 48)}' height='{_n(hk)}' "
                         f"rx='{min(D['r_lg'] * 1.5, 30)}' fill='{D['flaeche']}'{rand}/>")
        farbe = D["ink"]
    anker = " text-anchor='middle'" if mitte else ""
    x = w / 2 if mitte else rand_x
    tspans = "".join(f"<tspan x='{_n(x)}' y='{_n(oben + i * lh)}'>{_xml(t)}</tspan>" for i, t in enumerate(zeilen))
    teile.append(f"<text font-family=\"{fam}{stack}\" font-size='{_n(g)}' font-weight='700' fill='{farbe}'"
                 f"{anker}>{tspans}</text>")
    if anordnung == "zeile" and lage != "unten":
        y = oben + lh * (len(zeilen) - 1) + g * 0.38
        x0 = w / 2 - bt / 2 if mitte else rand_x
        teile.append(f"<rect x='{_n(x0)}' y='{_n(y)}' width='{_n(min(bt, max_b))}' height='4' fill='{farbe}'/>")
    dreh = satz.get("drehung")
    if dreh:        # leicht schräg wie ein aufgeklebtes Etikett (SVG-Attribut, nicht CSS)
        mx, my = rand_x + bt / 2, oben - g * 0.8 + block_h / 2
        return f"<g transform='rotate({dreh} {_n(mx)} {_n(my)})'>{''.join(teile)}</g>"
    return "".join(teile)


def banner_svg(D, titel, hue, mit_bild=False):
    """Bannerfläche 1000 × 210 bis 300 je Motiv (mit Bild aus dem Chat 1000 × 170, Kante oben, die 30 Einheiten ins Bild ragt) mit dem
    Titel in der Titelschrift: als Kasten (formen.titel ueberlagert, vorangestellt), mit Linie (zeile) oder frei
    (block), Lage und Größe je Motiv (SATZ). Unter 600 px Breite (Handy) zeigt das SVG den Titel größer und das Motiv
    blasser (Media Query im SVG). -> (svg, kante in Prozent der Breite für margin-top)."""
    m = D["motiv"]
    w, h = BANNER_B, BILD_H if mit_bild else SATZ.get(m["name"], {}).get("hoehe", BANNER_H)
    grund, mfarbe, tfarbe, m2 = farben(D, hue)
    kante = KANTE if mit_bild and m["name"] in ("schraeg", "papier") else 0
    z = _Zufall(len(titel or ""))
    if kante and m["name"] == "schraeg":
        form = _pfad([(0, kante), (w, 0), (w, h), (0, h)])
    elif kante:
        form = _pfad([(x, kante * 0.5 + z(-kante * 0.4, kante * 0.4)) for x in range(0, w + 1, 20)] + [(w, h), (0, h)])
    else:
        form = None
    fl = f"<path d='{form}' fill='{grund}'/>" if form else f"<rect width='{w}' height='{h}' fill='{grund}'/>"
    innen = h - kante
    motiv_teil = _elemente(m["name"], w, innen, mfarbe, _Zufall(7), m2) if m["banner"] else ""
    motiv_teil = f"<svg y='{kante}' width='{w}' height='{innen}'>{motiv_teil}</svg>" if kante else motiv_teil
    text = _titeltext(titel)
    datei = D["schrift_datei"]
    blass = "" if m["name"] in ("papier", "linie", "schraeg") else ".m{opacity:.3}"
    stil = (f"<style>{S.font_face(datei) if datei else ''}.s{{display:none}}"
            f"@media (max-width:600px){{.b{{display:none}}.s{{display:inline}}{blass}}}</style>")
    return (_svg(w, h, stil + fl + f"<g class='m'>{motiv_teil}</g>"
                + f"<g class='b'>{_titel(D, m, text, tfarbe, mfarbe, w, innen, kante, False)}</g>"
                + f"<g class='s'>{_titel(D, m, text, tfarbe, mfarbe, w, innen, kante, True)}</g>", masse=False),
            kante / w * 100)


def bild_svg(D, hue, breite=1200, hoehe=600, saat=1):
    """Kursbild (overviewfiles) oder Kachelbild: Fläche und Motiv ohne Text (die Plattform legt den Namen darüber)."""
    grund, mfarbe, _, m2 = farben(D, hue)
    return motiv(D["motiv"]["name"], breite, hoehe, grund, mfarbe, saat, m2)


# ---------------------------------------------------------------- Überschrift und Kasten
def h2_stil(D, hue):
    """Motiv an der Zwischenüberschrift (motiv.h2: ja) -> (CSS, [(Farbe, Deckung) unter dem Text])."""
    m = D["motiv"]
    if not m["h2"] or m["name"] == "keins":
        return "", []
    name, z = m["name"], _Zufall(3)
    if name == "pinsel":
        ton = DS.mische(DS.zweitfarbe(D, hue) or hue, D["flaeche"], 0.2)
        svg = _svg(300, 40, f"<path d='{_strich(z, 2, 298, 22, 30, -0.015, 26)}' fill='{ton}'/>",
                   " preserveAspectRatio='none'")
        return (f"display:inline-block;padding:2px 14px 4px 10px;background:{css_url(svg)} no-repeat center/100% 100%;",
                [(ton, 1)])
    if name == "kreide":
        svg = _svg(240, 12, f"<path d='{_strich(z, 2, 236, 6, 6, 0, 30)}' fill='{hue}' opacity='.9'/>")
        return f"padding-bottom:14px;background:{css_url(svg)} no-repeat left bottom/180px 10px;", []
    if name == "linie":
        svg = _svg(400, 12, f"<rect y='3' width='180' height='2' fill='{hue}'/><rect y='8' width='180' height='1' "
                            f"fill='{hue}'/><path d='M190,6 L200,0 L210,6 L200,12Z' fill='{hue}'/><rect x='220' "
                            f"y='3' width='180' height='2' fill='{hue}'/><rect x='220' y='8' width='180' height='1' "
                            f"fill='{hue}'/>")
        return f"padding-bottom:16px;background:{css_url(svg)} no-repeat left bottom/240px 8px;", []
    if name == "schraeg":
        z2 = DS.zweitfarbe(D, hue) or hue
        svg = _svg(16, 30, f"<path d='M6,0H16L10,30H0Z' fill='{z2}'/>", " preserveAspectRatio='none'")
        return f"padding-left:26px;background:{css_url(svg)} no-repeat left center/16px 80%;", []
    if name == "papier":
        ton = D["flaeche_alt"]
        rand = [(300 - 6 + z(-4, 4), y) for y in range(0, 41, 8)]
        svg = _svg(300, 40, f"<path d='{_pfad([(0, 0)] + rand + [(0, 40)])}' fill='{ton}'/>",
                   " preserveAspectRatio='none'")
        return (f"display:inline-block;padding:4px 26px 4px 12px;background:{css_url(svg)} no-repeat center/100% 100%;",
                [(ton, 1)])
    return "", []


def kasten_stil(D, hue):
    """Motiv am Kasten nach motiv.kasten: rand (Streifen innen links) -> (CSS, [(Farbe, Deckung) unter Text])."""
    m = D["motiv"]
    if m["kasten"] != "rand" or m["name"] == "keins":
        return "", []
    svg = motiv(m["name"], 16, 16, None, D["ink"] if m["name"] == "raster" else hue)
    return f"background-image:{css_url(svg)};background-repeat:repeat-y;background-size:16px 16px;", [(D["ink"], 0.06)]


# ---------------------------------------------------------------- Begleiter
def begleiter(name, farbe):
    """Kleines Symbol (28 × 28, eine Farbe) an der Ecke von Merksatz, Hinweis und Aufgabe; keiner -> ""."""
    f = farbe
    formen = {
        "stern": f"<path d='M14,2 17.5,10.2 26.4,11 19.7,16.9 21.7,25.6 14,21 6.3,25.6 8.3,16.9 1.6,11 10.5,10.2Z' "
                 f"fill='{f}'/>",
        "sprechblase": f"<path d='M4,4H24A2,2 0 0 1 26,6V18A2,2 0 0 1 24,20H12L6,26V20H4A2,2 0 0 1 2,18V6A2,2 0 0 1 "
                       f"4,4Z' fill='{f}'/>",
        "blatt": f"<path d='{_blatt(14, 13, 24, -40)}' fill='{f}'/><path d='M4,25L13,14' stroke='{f}' "
                 f"stroke-width='2' stroke-linecap='round'/>",
        "punkt": f"<circle cx='14' cy='14' r='7' fill='{f}'/>",
        "ornament": f"<path d='M14,6 20,14 14,22 8,14Z' fill='{f}'/><circle cx='3.5' cy='14' r='2.5' fill='{f}'/>"
                    f"<circle cx='24.5' cy='14' r='2.5' fill='{f}'/>",
        "balken": f"<rect x='1' y='9' width='26' height='10' fill='{f}'/>",
        "ring": f"<circle cx='14' cy='14' r='10' fill='none' stroke='{f}' stroke-width='4'/>",
    }
    if name not in BEGLEITER:
        raise ValueError(f"Begleiter „{name}“ unbekannt (erlaubt: {', '.join(BEGLEITER)})")
    return _svg(28, 28, formen[name]) if name != "keiner" else ""
